#!/usr/bin/env python3
"""Catalogue sheets of every room object, floor and layout, per blockset.

    python3 tools/roomgen/catalog.py [blockset_hex ...]

Writes game/assets/rom/underworld/catalog/ (derived from the ROM, never committed):
  objects_<blockset>.png   each object alone (size 0, and size 5 for resizable ones), id + name
  floors_<blockset>.png    floor patterns 0-15
  layouts.png              the 8 default layouts
  objects.json             id -> name, label, kind, footprint (cells) at size 0 / 5
"""
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parent))
import roomgen as G  # noqa: E402
import underworld_build as B  # noqa: E402
import underworld_render as UR  # noqa: E402
import underworld_rom as U  # noqa: E402

OUT = G.UW_DIR / "catalog"
OX, OY = 12, 12  # where objects are placed (inside the NW quadrant of layout 7)


def font(size=10):
    try:
        return ImageFont.truetype("DejaVuSans.ttf", size)
    except OSError:
        return ImageFont.load_default()


def blockset_palettes() -> dict[int, int]:
    """Most used header palette of each blockset in the original rooms."""
    idx = json.load(open(G.UW_DIR / "rooms.json", encoding="utf-8"))["rooms"]
    counts: dict[int, dict[int, int]] = {}
    for r in idx.values():
        c = counts.setdefault(r["blockset"], {})
        c[r["palette"]] = c.get(r["palette"], 0) + 1
    return {b: max(c, key=c.get) for b, c in sorted(counts.items())}


def raw_batch(rom, header_spec: dict, variants: list[list]) -> list[dict]:
    """Draw many object lists on the same header without the full build (fast)."""
    out = []
    for i in range(0, len(variants), 300):
        chunk = variants[i:i + 300]
        custom = {"rooms": {}, "headers": {}, "blocks": [], "torches": {}}
        for j, objs in enumerate(chunk):
            spec = dict(header_spec, objects=objs)
            room, header, _, _ = G.encode_room(spec)
            custom["rooms"][j], custom["headers"][j] = room, header
        out += B.run_harness(rom, 0, len(chunk), custom)
    return out


def crop(r: dict, base: dict, atlas: np.ndarray):
    if r["failed"]:
        return None, None
    diff = (r["bg2"] != base["bg2"]) | (r["bg1"] != base["bg1"]) | (r["attr"][:4096] != base["attr"][:4096])
    g = diff.reshape(64, 64)
    ys, xs = np.nonzero(g)
    if not len(xs):
        return None, None
    x0, y0, x1, y1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    words = np.where(r["bg1"] != 0, r["bg1"], 0)  # both planes, BG2 on top (as mode 'normal')
    img = UR.tiles_rgba(words.reshape(64, 64)[y0:y1, x0:x1], atlas)
    top = UR.tiles_rgba(r["bg2"].reshape(64, 64)[y0:y1, x0:x1], atlas)
    img = np.where(top[..., 3:4] > 0, top, img)
    fp = [int(x0 - OX), int(y0 - OY), int(x1 - x0), int(y1 - y0)]
    return Image.fromarray(img.astype(np.uint8), "RGBA"), fp


def sheet_for(rom, blockset: int, palette: int, meta: dict) -> None:
    hdr = {"name": "cat", "blockset": blockset, "palette": palette, "floor1": 0, "layout": 7}
    ids = [oid for oid, name, _ in G.OBJECTS]
    variants = [[]]
    for oid in ids:
        variants.append([[oid, OX, OY, 0]])
        variants.append([[oid, OX, OY, 5]] if G.kind_of(oid) == "resizable" else [])
    raws = raw_batch(rom, hdr, variants)
    base = raws[0]
    bg_pal = U.palette_set(rom, palette)[0] >> 1
    ts = G.tileset_for(rom, blockset, blockset, bg_pal)
    atlas = UR.atlas_array(ts, G.UW_DIR)
    cell_w, cell_h, label, cols = 200, 120, 22, 10
    entries = []
    for k, oid in enumerate(ids):
        a, fa = crop(raws[1 + 2 * k], base, atlas)
        b, fb = crop(raws[2 + 2 * k], base, atlas) if G.kind_of(oid) == "resizable" else (None, None)
        m = meta.setdefault(f"{oid:03X}", {"name": G.object_name(oid), "label": G.BY_ID[oid][1],
                                            "kind": G.kind_of(oid), "footprint": {}})
        m["footprint"][f"{blockset:02x}"] = {"size0": fa, "size5": fb}
        if a is not None or b is not None:
            entries.append((oid, a, b))
    rows = (len(entries) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell_w, rows * (cell_h + label)), (30, 30, 36))
    d = ImageDraw.Draw(sheet)
    f = font(9)
    for i, (oid, a, b) in enumerate(entries):
        x, y = (i % cols) * cell_w, (i // cols) * (cell_h + label)
        d.text((x + 3, y + 1), f"{oid:03X} {G.object_name(oid)}"[:34], fill=(255, 240, 150), font=f)
        tag = "taille 0 | 5" if b is not None else "fixe"
        d.text((x + 3, y + 11), tag, fill=(150, 200, 255), font=f)
        slots = [a, b] if b is not None else [a]
        sw = cell_w // len(slots)
        for j, im in enumerate(slots):
            if im is None:
                continue
            scale = min(1.0, (sw - 6) / im.width, (cell_h - 4) / im.height)
            if scale < 1:
                im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.NEAREST)
            sheet.paste(im, (x + j * sw + 3, y + label + 2), im)
        d.rectangle((x, y, x + cell_w - 1, y + cell_h + label - 1), outline=(60, 60, 70))
    sheet.save(OUT / f"objects_{blockset:02x}.png", optimize=True)

    # floors
    specs = [dict(hdr, floor1=n, layout=0) for n in range(16)]
    custom = {"rooms": {}, "headers": {}, "blocks": [], "torches": {}}
    for j, s in enumerate(specs):
        room, header, _, _ = G.encode_room(s)
        custom["rooms"][j], custom["headers"][j] = room, header
    raws = B.run_harness(rom, 0, 16, custom)
    fs = Image.new("RGB", (8 * 136, 2 * 150), (30, 30, 36))
    d = ImageDraw.Draw(fs)
    for n, r in enumerate(raws):
        im = UR.tiles_rgba(r["bg2"].reshape(64, 64)[8:24, 8:24], atlas)
        x, y = (n % 8) * 136, (n // 8) * 150
        fs.paste(Image.fromarray(im.astype(np.uint8), "RGBA"), (x + 4, y + 18))
        d.text((x + 4, y + 2), f"floor {n}", fill=(255, 240, 150), font=font(11))
    fs.save(OUT / f"floors_{blockset:02x}.png", optimize=True)


def layouts_sheet(rom) -> None:
    res = G.build_rooms([{"name": f"l{n}", "blockset": 5, "palette": 11, "floor1": 0, "layout": n}
                         for n in range(8)], rom)
    im = Image.new("RGB", (4 * 256, 2 * 276), (30, 30, 36))
    d = ImageDraw.Draw(im)
    for n, r in enumerate(res):
        x, y = (n % 4) * 256, (n // 4) * 276
        im.paste(UR.render_room(r).convert("RGB").resize((256, 256), Image.NEAREST), (x, y + 20))
        d.text((x + 4, y + 3), f"layout {n}", fill=(255, 240, 150), font=font(12))
    im.save(OUT / "layouts.png", optimize=True)


def main(argv):
    rom = G.get_rom()
    OUT.mkdir(parents=True, exist_ok=True)
    pals = blockset_palettes()
    wanted = [int(a, 16) for a in argv] or list(pals)
    meta: dict = {}
    for b in wanted:
        sheet_for(rom, b, pals.get(b, 0), meta)
        print(f"blockset {b:02x} (palette {pals.get(b, 0)})", flush=True)
    layouts_sheet(rom)
    with open(OUT / "objects.json", "w", encoding="utf-8") as f:
        json.dump({"palettes": {f"{b:02x}": p for b, p in pals.items()}, "objects": meta}, f, indent=1,
                  ensure_ascii=False)


if __name__ == "__main__":
    main(sys.argv[1:])
