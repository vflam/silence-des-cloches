"""Room builder: our own underworld rooms, drawn by the original room drawing code.

A room is described as a list of ALttP room objects + a header (see docs/tech/ROOMGEN.md).
`build_room(spec)` encodes it in the ROM's room object format, runs tools/room_render (the
zelda3 `Dungeon_LoadRoom` code) on it and returns a dict in the exact format of
game/assets/rom/underworld/rooms/<id>.json (bg, fg, types, tileset, doors, stairs...).

    import sys; sys.path.insert(0, "tools/roomgen")
    import roomgen
    room = roomgen.build_room({"name": "test", "blockset": 3, "palette": 21, "floor1": 3,
                               "objects": [["chest", 20, 20]], "doors": [["down", 8]]})
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools" / "rom_extract"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402

import underworld_build as B  # noqa: E402
import underworld_render as UR  # noqa: E402
import underworld_rom as U  # noqa: E402
from objects_table import OBJECTS  # noqa: E402
from rom import Rom, find_rom  # noqa: E402

UW_DIR = ROOT / "game" / "assets" / "rom" / "underworld"
CUSTOM_DIR = UW_DIR / "custom"


def uw_dir() -> Path:
    """Underworld folder of the extraction being written (rom.assets_dir())."""
    import rom
    return rom.assets_dir() / "underworld"

# ------------------------------------------------------------------ catalogue of names

BY_ID = {oid: (name, label) for oid, name, label in OBJECTS}
BY_NAME = {name: oid for oid, name, _ in OBJECTS}

# Friendly aliases for the objects level designers use most (see the catalogue sheets).
ALIASES = {
    # walls (subtype 1, resizable along their axis)
    "wall_n": 0x001, "wall_s": 0x002, "wall_w": 0x061, "wall_e": 0x062,
    "wall_n_low": 0x003, "wall_s_low": 0x004, "wall_w_low": 0x063, "wall_e_low": 0x064,
    "ceiling_h": 0x000, "ceiling_v": 0x060, "ceiling_block": 0x0C0,
    # wall corners (subtype 2, fixed)
    "corner_out_nw": 0x100, "corner_out_sw": 0x101, "corner_out_ne": 0x102, "corner_out_se": 0x103,
    "corner_in_nw": 0x104, "corner_in_sw": 0x105, "corner_in_ne": 0x106, "corner_in_se": 0x107,
    # floors and decor areas (4-way: w and h)
    "floor_area": 0x0C5, "floor_area2": 0x0DB, "floor_area3": 0x0C7, "floor_area4": 0x0CA,
    "water_area": 0x0C8, "hole": 0x0A4, "carpet_h": 0x033, "carpet_v": 0x070,
    "spike_floor": 0x0DF, "chest_platform": 0x0C1, "table_rock": 0x0DD,
    # things
    "chest": 0xF99, "big_chest": 0xFB1, "pot": 0xFAF, "skull_pot": 0xFD1, "big_block": 0xFAC,
    "block": 0x134, "statue": 0x11D, "torch_lit": 0x120, "floor_torch": 0x087,
    "stand_torch_h": 0x03D, "column_h": 0x039, "column_v": 0x075, "statue_row_h": 0x038,
    "bed": 0x128, "table": 0x123, "chair": 0x127, "barrel": 0x121, "painting": 0x12A,
    "bookshelf": 0xFDC, "fairy_pot": 0x11C, "church_pew": 0x13E, "floor_switch": 0xFD0,
    "star_tile_off": 0x11E, "star_tile_on": 0x11F, "warp_tile": 0xFCA, "bomb_floor": 0xFC7,
    "prison_cell": 0xF8D, "throne": 0xFEB, "forge": 0xFDD, "window_light": 0xFF0,
    "crack_wall_n": 0xFE7, "crack_wall_s": 0xFE8, "crack_wall_w": 0xFE9, "crack_wall_e": 0xFEA,
    # stairs
    "stairs_up": 0x12D, "stairs_down": 0x12E, "stairs_down2": 0x12F,
    "spiral_up": 0xF9E, "spiral_down": 0xF9F, "spiral_up_lower": 0xFA0, "spiral_down_lower": 0xFA1,
    "stairs_n_layer": 0x131, "stairs_s_layer": 0xF9C, "mini_stairs": 0x021, "stairs_inroom": 0xF9B,
    "water_ladder": 0x135,
}

DOOR_KIND_IDS = {v: k for k, v in B.DOOR_KINDS.items()}
DIR_IDS = {"up": 0, "down": 1, "left": 2, "right": 3, "n": 0, "s": 1, "w": 2, "e": 3}
BG_MODE_IDS = {name: i for i, name in enumerate(B.BG_MODES)}
COLLISION_IDS = {name: i for i, name in enumerate(B.COLLISIONS)}


def object_id(o) -> int:
    """Object reference: readable name, alias, int id or hex string ("0xF99", "F99")."""
    if isinstance(o, int):
        oid = o
    elif o in ALIASES:
        oid = ALIASES[o]
    elif o in BY_NAME:
        oid = BY_NAME[o]
    else:
        try:
            oid = int(o, 16)
        except (TypeError, ValueError):
            raise ValueError(f"objet de salle inconnu : {o!r} (voir docs/tech/ROOMGEN.md)") from None
    if oid not in BY_ID:
        raise ValueError(f"id d'objet invalide : {oid:#x}")
    return oid


def object_name(oid: int) -> str:
    return BY_ID[oid][0]


def kind_of(oid: int) -> str:
    """'resizable' (subtype 1, size 0-15), 'fixed3' (subtype 3), 'fixed2' (subtype 2)."""
    if oid < 0xF8:
        return "resizable"
    return "fixed3" if oid >= 0xF80 else "fixed2"


# ------------------------------------------------------------------ encoding

def encode_object(oid: int, x: int, y: int, size: int = 0) -> bytes:
    """3-byte room object (inverse of underworld_rom.decode_object). x, y: 8x8 cells 0-63."""
    if not (0 <= x < 64 and 0 <= y < 64):
        raise ValueError(f"objet {object_name(oid)} hors de la salle : ({x}, {y})")
    k = kind_of(oid)
    if k == "resizable":
        if not 0 <= size <= 15:
            raise ValueError(f"taille {size} invalide (0-15) pour {object_name(oid)}")
        w, h = size >> 2, size & 3
        return bytes((x << 2 | w, y << 2 | h, oid))
    if k == "fixed3":
        i = oid - 0xF80
        return bytes((x << 2 | (i & 3), y << 2 | ((i >> 2) & 3), 0xF8 | (i >> 4)))
    i = oid - 0x100
    return bytes((0xFC | (x >> 4 & 3), (x << 4 & 0xF0) | (y >> 2 & 0xF), i | (y << 6 & 0xC0)))


def _norm_object(o) -> dict:
    """["name", x, y, size?, layer?] or {"o"|"obj": name, "x", "y", "size" | "w"+"h", "layer"}."""
    if isinstance(o, (list, tuple)):
        d = {"o": o[0], "x": o[1], "y": o[2]}
        if len(o) > 3:
            d["size"] = o[3]
        if len(o) > 4:
            d["layer"] = o[4]
        o = d
    ref = o.get("o", o.get("obj", o.get("id")))
    oid = object_id(ref)
    size = o.get("size")
    if size is None:
        size = (o.get("w", 0) << 2) | o.get("h", 0)
    return {"id": oid, "x": int(o["x"]), "y": int(o["y"]), "size": int(size), "layer": int(o.get("layer", 1))}


def _norm_door(d) -> dict:
    """["dir", pos, kind?] or {"dir", "pos", "kind"}; kind = name (B.DOOR_KINDS) or type byte."""
    if isinstance(d, (list, tuple)):
        d = {"dir": d[0], "pos": d[1], "kind": d[2] if len(d) > 2 else "normal"}
    kind = d.get("kind", "normal")
    t = kind if isinstance(kind, int) else DOOR_KIND_IDS.get(kind)
    if t is None:
        raise ValueError(f"type de porte inconnu : {kind!r}")
    pos = int(d["pos"])
    if not 0 <= pos <= 11:
        raise ValueError("position de porte : 0-11")
    return {"dir": DIR_IDS[d["dir"]], "pos": pos, "type": t}


def encode_header(spec: dict) -> bytes:
    bg = spec.get("bg_mode", "off")
    bg = BG_MODE_IDS[bg] if isinstance(bg, str) else int(bg)
    col = spec.get("collision", "one")
    col = COLLISION_IDS[col] if isinstance(col, str) else int(col)
    hole = spec.get("hole_to", [0, 0])
    stairs = list(spec.get("stairs_to", [])) + [[0, 0]] * 4
    tags = list(spec.get("tags", [0, 0])) + [0, 0]
    return bytes([
        bg << 5 | col << 2 | int(bool(spec.get("lights_out", False))),
        int(spec.get("palette", 0)), int(spec["blockset"]), int(spec.get("sprite_set", 0)),
        int(spec.get("effect", 0)), tags[0], tags[1],
        (hole[1] & 3) | (stairs[0][1] & 3) << 2 | (stairs[1][1] & 3) << 4 | (stairs[2][1] & 3) << 6,
        stairs[3][1] & 3,
        hole[0] & 0xFF, stairs[0][0] & 0xFF, stairs[1][0] & 0xFF, stairs[2][0] & 0xFF, stairs[3][0] & 0xFF,
    ])


def encode_room(spec: dict):
    """spec -> (floor byte, layout byte, [(objects, doors)] x 3), header bytes, blocks, torches."""
    layers = [[], [], []]
    for o in spec.get("objects", []):
        n = _norm_object(o)
        if n["layer"] not in (1, 2, 3):
            raise ValueError("couche d'objet : 1, 2 ou 3")
        layers[n["layer"] - 1].append(encode_object(n["id"], n["x"], n["y"], n["size"]))
    doors = [_norm_door(d) for d in spec.get("doors", [])]
    if len(doors) > 16:
        raise ValueError("16 portes au plus")
    door_words = [d["dir"] | d["pos"] << 4 | d["type"] << 8 for d in doors]
    floor = (int(spec.get("floor1", 0)) & 15) | (int(spec.get("floor2", 0)) & 15) << 4
    layout = (int(spec.get("layout", 0)) & 7) << 2 | (int(spec.get("start_quadrant", 0)) & 3)
    room = (floor, layout, [(layers[0], None), (layers[1], None), (layers[2], door_words)])
    blocks = [(y * 64 + x) * 2 for x, y in spec.get("blocks", [])]
    torches = [((t[1] * 64 + t[0]) * 2) | (0x8000 if len(t) > 2 and t[2] else 0) for t in spec.get("torches", [])]
    return room, encode_header(spec), blocks, torches


# ------------------------------------------------------------------ building

_rom: Rom | None = None


def get_rom() -> Rom:
    global _rom
    if _rom is None:
        import rom as _r
        _rom = _r.current() or Rom(find_rom(ROOT))
    return _rom


def slot_of(i: int) -> int:
    """Harness slots for a batch: never adjacent (doors of neighbours interact)."""
    return (i // 8) * 32 + (i % 8) * 2


def tileset_for(rom: Rom, main: int, aux: int, bg_pal: int, base: Path | None = None) -> str:
    """Atlas id (same naming as the underworld step); written if missing."""
    base = base or uw_dir()
    sig = B.gfx_signature(rom, main, aux)
    same = B.gfx_signature(rom, aux if aux < 0x20 else main, aux) == sig
    ts = f"uw_{aux:02x}_{bg_pal:02x}" if same else f"uw_{aux:02x}m{main:02x}_{bg_pal:02x}"
    path = base / "tilesets" / f"{ts}.png"
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        B.atlas_pixels(B.tile_bank(rom, main, aux), B.dungeon_cgram(rom, bg_pal)).save(path, optimize=True)
    return ts


def build_rooms(specs: list[dict], rom: Rom | None = None) -> list[dict]:
    """Build several rooms in one run of the harness (at most 80)."""
    from steps.underworld import chests_of, stairs_of, used_quadrants  # shared with the extraction

    rom = rom or get_rom()
    if len(specs) > 80:
        out = []
        for i in range(0, len(specs), 80):
            out += build_rooms(specs[i:i + 80], rom)
        return out
    custom = {"rooms": {}, "headers": {}, "blocks": [], "torches": {}}
    encoded = []
    for i, spec in enumerate(specs):
        slot = slot_of(i)
        room, header, blocks, torches = encode_room(spec)
        custom["rooms"][slot] = room
        custom["headers"][slot] = header
        custom["blocks"] += [(slot, w) for w in blocks]
        if torches:
            custom["torches"][slot] = torches
        encoded.append((slot, room, header))
    raw = B.run_harness(rom, 0, max(s for s, _, _ in encoded) + 1, custom)

    results = []
    for spec, (slot, room, header) in zip(specs, encoded):
        r = raw[slot]
        if r["failed"]:
            raise ValueError(f"salle {spec['name']} : le code de dessin d'origine a échoué "
                             "(objet inutilisé ou invalide ?)")
        h = U.decode_header(header)
        aux = h["blockset"]
        main = int(spec.get("main", aux if aux < 0x20 else 0))
        bg_pal = U.palette_set(rom, h["palette"])[0] >> 1
        ts = tileset_for(rom, main, aux, bg_pal)
        bank = B.tile_bank(rom, main, aux)
        bg, fg, lossy = B.merge_layers(r["bg2"], r["bg1"], h["bg2"], B.empty_tiles(bank), B.opaque_tiles(bank))
        types = r["attr"][:4096]
        two_level = h["collision"] in (1, 2) or h["bg2"] == 3
        doors = B.room_doors(r["state"])
        stairs = stairs_of(room[2], h)
        chest_items = [(c.get("item", 0), bool(c.get("big", False))) if isinstance(c, dict) else (int(c), False)
                       for c in spec.get("chests", [])]
        chests = chests_of(r["state"], chest_items)
        seeds = [(d["x"], d["y"]) for d in doors] + [(s["x"], s["y"]) for s in stairs] \
            + [(c["x"], c["y"]) for c in chests if "x" in c]
        name = spec["name"]
        data = {
            "id": name, "name": spec.get("title", name), "category": spec.get("category", "custom"),
            "dungeon": spec.get("dungeon", ""),
            "blockset": aux, "main": main, "palette": h["palette"], "bg_palette": bg_pal,
            "layout": {
                "id": room[1] >> 2, "bg_mode": B.BG_MODES[h["bg2"]],
                "collision": B.COLLISIONS[min(h["collision"], 4)], "two_levels": two_level,
                "lights_out": bool(h["lights_out"]), "merge_lossy_cells": lossy,
                "start_quadrant": room[1] & 3, "floor1": room[0] & 15, "floor2": room[0] >> 4,
                "used_quadrants": used_quadrants(types, seeds) or [0, 1, 2, 3],
            },
            "tileset": ts,
            "bg": bg.tolist(), "fg": fg.tolist(), "types": types.tolist(),
            "doors": [{k: d[k] for k in ("dir", "x", "y", "kind", "type", "lower")} for d in doors],
            "stairs": stairs,
            "original": {"name": spec.get("title", name), "roles": spec.get("roles", []), "chests": chests,
                         "sprites": [], "pots": [], "entrances": [], "header": h, "dungeon_map": None,
                         "source": "roomgen"},
        }
        if two_level:
            data["types_lower"] = r["attr"][4096:].tolist()
        if h["bg2"] in (4, 7) or (lossy and h["bg2"] != 0):
            data["layers"] = {"bg2": r["bg2"].tolist(), "bg1": r["bg1"].tolist()}
        if "entities" in spec:
            data["entities"] = spec["entities"]
        results.append(data)
    return results


def build_room(spec: dict, rom: Rom | None = None) -> dict:
    """One room spec -> dict in the format of underworld/rooms/<id>.json ("id" = spec name)."""
    return build_rooms([spec], rom)[0]


def save_room(room: dict, out_dir: Path | None = None) -> Path:
    out_dir = out_dir or uw_dir() / "custom"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{room['id']}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(room, f, separators=(",", ":"), ensure_ascii=False)
    import options
    if options.PREVIEWS:  # preview image, not read by the game
        UR.render_room(room).save(out_dir / f"{room['id']}.png", optimize=True)
    return path


def load_spec(path: Path) -> list[dict]:
    """A .json file (one room dict or a list) or a .py file defining ROOM or ROOMS."""
    path = Path(path)
    if path.suffix == ".json":
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
    else:
        ns: dict = {"__file__": str(path)}
        exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"), ns)
        d = ns.get("ROOMS", ns.get("ROOM"))
    specs = d if isinstance(d, list) else [d]
    for s in specs:
        s.setdefault("name", path.stem)
    return specs


def grid(room: dict, key: str = "types") -> np.ndarray:
    return np.asarray(room[key]).reshape(64, 64)


# ------------------------------------------------------------------ composition helpers
# All positions / sizes in 8x8 cells (0-63). Walls are 4 cells thick, corners 4x4.

def _chain(name: str, x: int, y: int, length: int, horizontal: bool, unit: int = 2) -> list:
    """Resizable wall-like object repeated to cover `length` cells (size s = s*unit cells, 1-15)."""
    out, pos, left = [], 0, length
    while left > 0:
        s = min(15, max(1, left // unit))
        out.append([name, x + pos if horizontal else x, y if horizontal else y + pos, s])
        pos += s * unit
        left -= s * unit
    return out


def hwall(side: str, x: int, y: int, length: int) -> list:
    """Horizontal wall of `length` cells (even), side 'n' (room's north wall, face down) or 's'."""
    return _chain("wall_n" if side == "n" else "wall_s", x, y, length, True)


def vwall(side: str, x: int, y: int, length: int) -> list:
    """Vertical wall of `length` cells (even), side 'w' (room's west wall) or 'e'."""
    return _chain("wall_w" if side == "w" else "wall_e", x, y, length, False)


def fill(name: str, x: int, y: int, w: int, h: int) -> list:
    """Cover a w x h rectangle (multiples of 4) with a 4-way object (ceiling_block, floor_area,
    water_area, spike_floor...): one object per 16x16 chunk."""
    out = []
    for yy in range(y, y + h, 16):
        for xx in range(x, x + w, 16):
            cw, ch = min(16, x + w - xx), min(16, y + h - yy)
            out.append([name, xx, yy, ((cw // 4 - 1) << 2) | (ch // 4 - 1)])
    return out


def room_box(x: int, y: int, w: int, h: int) -> list:
    """Walls + outer corners around a rectangular room part (outside edge at x, y; w, h multiples of 4)."""
    return (hwall("n", x + 4, y, w - 8) + hwall("s", x + 4, y + h - 4, w - 8)
            + vwall("w", x, y + 4, h - 8) + vwall("e", x + w - 4, y + 4, h - 8)
            + [["corner_out_nw", x, y], ["corner_out_ne", x + w - 4, y],
               ["corner_out_sw", x, y + h - 4], ["corner_out_se", x + w - 4, y + h - 4]])


def pillar(x: int, y: int, w: int, h: int, top: str = "ceiling_block") -> list:
    """A walled block standing inside a room (w, h multiples of 4, >= 12): walls facing out,
    inner corners, filled with `top` (ceiling_block = solid rock / wall top)."""
    o = (hwall("s", x + 4, y, w - 8) + hwall("n", x + 4, y + h - 4, w - 8)
         + vwall("e", x, y + 4, h - 8) + vwall("w", x + w - 4, y + 4, h - 8)
         + [["corner_in_se", x, y], ["corner_in_sw", x + w - 4, y],
            ["corner_in_ne", x, y + h - 4], ["corner_in_nw", x + w - 4, y + h - 4]])
    if top:
        o += fill(top, x + 4, y + 4, w - 8, h - 8)
    return o


# Door positions (pos 0-11) -> top-left cell of the door, measured with tools/room_render.
# Outer walls: north pos 0/1/2 (x 14/30/46, y 4), south pos 6/7/8 (y 58), west pos 0/1/2
# (x 2, y 15/31/47), east pos 6/7/8 (x 58). pos 3-5 / 9-11: same columns, wall 3 cells further
# in. Middle walls (between quadrants): north 6-11, south 0-5, west 6-11, east 0-5.
DOOR_CELLS = {
    "up": [(14, 4), (30, 4), (46, 4), (14, 7), (30, 7), (46, 7),
           (14, 36), (30, 36), (46, 36), (14, 39), (30, 39), (46, 39)],
    "down": [(14, 26), (30, 26), (46, 26), (14, 23), (30, 23), (46, 23),
             (14, 58), (30, 58), (46, 58), (14, 55), (30, 55), (46, 55)],
    "left": [(2, 15), (2, 31), (2, 47), (5, 15), (5, 31), (5, 47),
             (34, 15), (34, 31), (34, 47), (37, 15), (37, 31), (37, 47)],
    "right": [(26, 15), (26, 31), (26, 47), (23, 15), (23, 31), (23, 47),
              (58, 15), (58, 31), (58, 47), (55, 15), (55, 31), (55, 47)],
}
