#!/usr/bin/env python3
"""Build our own underworld rooms (tools/roomgen/rooms/*.py|*.json, or given files).

    python3 tools/roomgen/build.py                  # every room source in tools/roomgen/rooms/
    python3 tools/roomgen/build.py path/to/room.py  # some rooms only

Output: game/assets/rom/underworld/custom/<name>.json (format of underworld/rooms/<id>.json)
and <name>.png (preview). Needs the ROM at the project root and a C compiler.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import roomgen as G  # noqa: E402

SOURCES = Path(__file__).resolve().parent / "rooms"


def build_all(paths=None, out_dir: Path | None = None) -> list[str]:
    paths = [Path(p) for p in paths] if paths else sorted(
        p for p in SOURCES.iterdir() if p.suffix in (".py", ".json") and not p.name.startswith("_"))
    specs = []
    for p in paths:
        specs += G.load_spec(p)
    rooms = G.build_rooms(specs)
    for r in rooms:
        G.save_room(r, out_dir)
    return [r["id"] for r in rooms]


if __name__ == "__main__":
    t = time.time()
    names = build_all(sys.argv[1:])
    print(f"{len(names)} salle(s) : {', '.join(names)} → {G.CUSTOM_DIR} ({time.time() - t:.1f} s)")
