"""Démo : grotte (création originale) — grande caverne (layout 7) avec rochers, source, gouffre."""
import roomgen as G

ROOM = {
    "name": "demo_grotte",
    "title": "Grotte de la source (démo)",
    "category": "cave",
    "blockset": 0x14, "palette": 7,           # graphismes / couleurs des grottes de la Montagne
    "floor1": 1, "floor2": 5, "layout": 7,    # 7 = une seule grande salle 512x512
    "objects": [
        # deux massifs rocheux
        *G.pillar(8, 12, 16, 12),
        *G.pillar(36, 36, 12, 16),
        # coin nord-est bouché par la roche
        *G.fill("ceiling_block", 48, 0, 16, 16),
        *G.vwall("e", 44, 8, 8), *G.hwall("n", 48, 16, 12),
        ["corner_out_ne", 44, 4], ["corner_in_ne", 44, 16], ["corner_out_ne", 60, 16],
        # la source : bassin 8x8 et ses bords
        ["water_area", 28, 12, 5],
        ["water_edge_h", 27, 11, 7], ["water_edge_v", 27, 12, 7],
        ["water_edge_h_2", 27, 20, 7], ["water_edge_v_2", 36, 12, 7],
        # gouffre
        ["hole", 12, 40, 4],
        # rocher-table avec coffre, torches près de la sortie
        ["table_rock", 50, 50, 4], ["chest", 51, 50],
        ["torch_lit", 26, 54], ["torch_lit", 36, 54],
        # escalier vers le haut, jarres
        ["floor_stairs_up", 8, 28],
        ["pot", 20, 30], ["pot", 22, 30], ["pot", 56, 26],
    ],
    "doors": [["down", 7, "exit_cave"]],
    "stairs_to": [[0x00, 0]],
    "hole_to": [0x00, 0],
    "chests": [{"item": 0x28}],
}
