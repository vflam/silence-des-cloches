"""Démo : salle de donjon (création originale) — portes sur les 4 côtés, gouffre central,
torches, escalier, coffre, bloc poussable."""
import roomgen as G

ROOM = {
    "name": "demo_donjon",
    "title": "Salle du puits (démo)",
    "category": "dungeon",
    "blockset": 0x05, "palette": 11,          # pierre verte (style Palais de l'Est)
    "floor1": 0, "floor2": 0, "layout": 7,    # une seule salle 512x512 (murs extérieurs fournis)
    "objects": [
        # gouffre central 12x12 bordé d'un tapis de dalles
        *G.fill("floor_area", 22, 22, 20, 20),
        ["hole", 26, 26, 8],
        # allées de tapis vers les quatre portes
        ["carpet_v", 30, 8, 2], ["carpet_v", 30, 42, 3],
        ["carpet_h", 6, 30, 3], ["carpet_h", 42, 30, 3],
        # statues de part et d'autre de la porte nord, rangée de statues au sud
        ["statue", 24, 6], ["statue", 38, 6],
        ["statue_row_h", 8, 54, 3], ["statue_row_h", 44, 54, 3],
        # escalier qui descend (coin nord-ouest), coffre (nord-est)
        ["floor_stairs_down", 8, 8],
        ["chest", 52, 8],
        # zone de piques au sud-est, jarres
        ["spike_floor", 38, 46, 4],
        ["pot", 6, 40], ["pot", 8, 40], ["pot", 6, 42], ["skull_pot", 56, 22],
    ],
    "doors": [
        ["up", 1, "normal"], ["down", 7, "normal"],
        ["left", 1, "small_key"], ["right", 7, "shutter"],
    ],
    "torches": [[14, 20, True], [48, 20, True], [14, 42, False], [48, 42, False]],
    "blocks": [[20, 44]],
    "stairs_to": [[0x00, 0]],
    "hole_to": [0x00, 0],
    "chests": [{"item": 0x24}],
}
