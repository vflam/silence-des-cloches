"""Démo : maison (création originale) — une grande pièce 512x256 au sud (layout 5)."""
import roomgen as G

ROOM = {
    "name": "demo_maison",
    "title": "Maison du tisserand (démo)",
    "category": "house",
    "blockset": 0x03, "palette": 21,          # graphismes et couleurs des maisons de Cocorico
    "floor1": 3, "floor2": 14, "layout": 5,   # 5 = deux petites pièces en haut, une large en bas
    "bg_mode": "off",
    "objects": [
        # les deux petites pièces du haut ne servent pas : on les recouvre de « plafond »
        *G.fill("ceiling_block", 0, 0, 64, 32),
        # mur nord : étagères et tableau
        ["bookshelf", 7, 36], ["bookshelf", 13, 36], ["wall_painting", 28, 36], ["bookshelf", 44, 36],
        # coin chambre (est)
        ["bed", 52, 40], ["chest", 48, 41], ["barrel", 55, 52], ["barrel", 52, 53],
        # tapis devant la porte et table au centre
        ["table", 26, 43], ["chair", 23, 44], ["chair", 31, 44],
        ["table", 11, 45], ["plate_on_table", 11, 45], ["chair", 8, 46],
        # jarres dans le coin ouest
        ["pot", 6, 54], ["pot", 8, 54], ["pot", 6, 56], ["barrel", 18, 52], ["chair", 21, 53],
    ],
    "doors": [["down", 7, "normal"]],
    "chests": [{"item": 0x12}],
}
