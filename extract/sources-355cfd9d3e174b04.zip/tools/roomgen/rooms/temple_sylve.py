"""Temple de Sylve (chapitre 2, donjon `sylve`) — 15 salles NEUVES (LEVEL-TEMPLE).

Chaque salle est une liste d'objets de salle d'ALttP dessinée par le code d'origine
(tools/roomgen) : blockset du palais de l'Est (0x05), palette claire (11) au rez-de-chaussée,
palette de terre (24) au sous-sol, palette bleue (13) pour la salle du Carillon. Formes et
agencements inventés : nef en croix, cloître à quatre massifs, salle en L, en T, couloir à
niches, galerie en U, arène aux coins effondrés…

Coordonnées en cases de 8 px dans la salle (0-63). Intérieur jouable d'une salle pleine
(layout 7) : x 5-58, y 7-58. Attention : le tableau des dispositions de ROOMGEN.md inverse
4 et 6 (4 = deux salles larges nord / sud, 6 = une large au nord, deux petites au sud).

Ce fichier sert :
  - à `python3 tools/roomgen/build.py` (ROOMS : aperçus underworld/custom/temple_*.png, sans
    les trous peints) ;
  - aux cartes content/maps/temple_sylve_rdc.py / temple_sylve_s1.py (via `temple_build.py`),
    qui ajoutent les trous (PITS) et calculent les tuiles des portes / ponts / plots à partir
    de variantes (`variant()`).
"""
import copy

import roomgen as G

RDC_PAL = 11     # pierre claire (palais de l'Est)
S1_PAL = 24      # sous-sol : pierre brune, terre et racines
BELL_PAL = 13    # salle du Carillon : bleu profond


def _room(name, title, palette, objects, doors, floor1=0, layout=7, **kw):
    d = {"name": name, "title": title, "category": "dungeon", "dungeon": "sylve",
         "blockset": 0x05, "palette": palette, "floor1": floor1, "floor2": 0,
         "layout": layout, "objects": objects, "doors": doors}
    d.update(kw)
    return d


# ------------------------------------------------------------------ sculpting helpers
# (all sizes multiples of 4)

def notch(c, w, h):
    """Solid corner of the room (w x h cells, outer walls included), walls facing in."""
    if c == "ne":
        x0, y1 = 64 - w, h
        return [*G.fill("ceiling_block", x0, 0, w, y1), *G.vwall("e", x0 - 4, 8, y1 - 8), *G.hwall("n", x0, y1, 60 - x0),
                ["corner_out_ne", x0 - 4, 4], ["corner_in_ne", x0 - 4, y1], ["corner_out_ne", 60, y1]]
    if c == "nw":
        x1, y1 = w, h
        return [*G.fill("ceiling_block", 0, 0, x1, y1), *G.vwall("w", x1, 8, y1 - 8), *G.hwall("n", 4, y1, x1 - 4),
                ["corner_out_nw", x1, 4], ["corner_in_nw", x1, y1], ["corner_out_nw", 0, y1]]
    if c == "se":
        x0, y0 = 64 - w, 64 - h
        return [*G.fill("ceiling_block", x0, y0, w, h), *G.vwall("e", x0 - 4, y0, 56 - y0), *G.hwall("s", x0, y0 - 4, 60 - x0),
                ["corner_out_se", x0 - 4, 56], ["corner_in_se", x0 - 4, y0 - 4], ["corner_out_se", 60, y0 - 4]]
    if c == "sw":
        x1, y0 = w, 64 - h
        return [*G.fill("ceiling_block", 0, y0, x1, h), *G.vwall("w", x1, y0, 56 - y0), *G.hwall("s", 4, y0 - 4, x1 - 4),
                ["corner_out_sw", x1, 56], ["corner_in_sw", x1, y0 - 4], ["corner_out_sw", 0, y0 - 4]]
    raise ValueError(c)


def bump_n(x0, x1, y1, top=0, fill="ceiling_block"):
    """Solid block attached to the north wall (x0..x1-1, down to y1-1), walls facing the room."""
    return [*G.fill(fill, x0, top, x1 - x0, y1 - top), *G.hwall("n", x0, y1, x1 - x0),
            *G.vwall("e", x0 - 4, top + 8, y1 - top - 8), *G.vwall("w", x1, top + 8, y1 - top - 8),
            ["corner_out_ne", x0 - 4, top + 4], ["corner_in_ne", x0 - 4, y1],
            ["corner_out_nw", x1, top + 4], ["corner_in_nw", x1, y1]]


def bump_s(x0, x1, y0, bottom=64, fill="ceiling_block"):
    """Solid block attached to the south wall (x0..x1-1, from y0 down). bottom = 64 for a full
    room, 32 for the north room of layouts 4 / 6."""
    b = bottom - 8
    return [*G.fill(fill, x0, y0, x1 - x0, bottom - y0), *G.hwall("s", x0, y0 - 4, x1 - x0),
            *G.vwall("e", x0 - 4, y0, b - y0), *G.vwall("w", x1, y0, b - y0),
            ["corner_out_se", x0 - 4, b], ["corner_in_se", x0 - 4, y0 - 4],
            ["corner_out_sw", x1, b], ["corner_in_sw", x1, y0 - 4]]


def dais(x, y, w, h, stairs_x=None, top="floor_area3"):
    """Estrade : massif aux murs tournés vers l'extérieur, dessus dallé, escalier (4 cases)
    taillé dans le mur sud à la colonne stairs_x."""
    o = G.pillar(x, y, w, h, top=None)
    o += G.fill(top, x + 4, y + 4, w - 8, h - 8)
    if stairs_x is not None:
        o.append(["stairs_n_2", stairs_x, y + h - 4])
    return o


def roots_v(x, y, n):
    """Racine verticale (gros tuyau d'ALttP : brun avec la palette du sous-sol)."""
    return [["large_vert_rail_v", x, y, n]]


def roots_h(x, y, n):
    return [["large_horz_rail_h", x, y, n]]


# ====================================================================== rez-de-chaussée

# R1 — Hall d'entrée : nef en croix, rigole est-ouest, tapis, statues, dalle de runes.
R1 = _room("temple_r1", "Temple de Sylve – Hall d'entrée", RDC_PAL, [
    *notch("nw", 16, 16), *notch("ne", 16, 16), *notch("sw", 16, 16), *notch("se", 16, 16),
    *G.fill("water_area", 14, 30, 16, 4), *G.fill("water_area", 34, 30, 16, 4),
    ["water_edge_h", 14, 29, 13], ["water_edge_h", 34, 29, 13],
    *G.fill("floor_area", 26, 7, 12, 52),
    ["carpet_v", 30, 7, 12],
    ["statue", 22, 10], ["statue", 40, 10], ["statue", 22, 20], ["statue", 40, 20],
    ["statue", 22, 38], ["statue", 40, 38], ["statue", 22, 48], ["statue", 40, 48],
    ["column_v", 8, 20, 1], ["column_v", 54, 20, 1], ["column_v", 8, 36, 1], ["column_v", 54, 36, 1],
    ["torch_lit", 27, 8], ["torch_lit", 35, 8],
    ["telepathic_tile", 31, 42],
], [["down", 7, "exit_big"], ["up", 1, "big_key"]])

# R2 — Galerie des Échos : deux couloirs de rouleaux nord-sud, allée centrale.
R2 = _room("temple_r2", "Temple de Sylve – Galerie des Échos", RDC_PAL, [
    *G.fill("floor_area3", 14, 7, 8, 52), *G.fill("floor_area3", 42, 7, 8, 52),
    ["long_vert_rail_v", 13, 7, 15], ["long_vert_rail_v", 22, 7, 15],
    ["long_vert_rail_v", 41, 7, 15], ["long_vert_rail_v", 50, 7, 15],
    *G.fill("floor_area", 28, 7, 8, 52),
    ["statue_row_h", 6, 9, 1], ["statue_row_h", 52, 9, 1],
    ["statue_row_h", 6, 52, 1], ["statue_row_h", 52, 52, 1],
    ["statue", 25, 12], ["statue", 37, 12], ["statue", 25, 44], ["statue", 37, 44],
    ["floor_torch_v", 6, 20, 1], ["floor_torch_v", 56, 20, 1],
    ["floor_torch_v", 6, 38, 1], ["floor_torch_v", 56, 38, 1],
    ["telepathic_tile", 31, 50],
], [["down", 7, "normal"], ["up", 1, "shutter"], ["left", 1, "normal"], ["right", 7, "normal"]],
    floor1=3)

# R3 — Salle des Chauves-souris : salle octogonale, fossé en anneau (peint), île aux jarres.
R3 = _room("temple_r3", "Temple de Sylve – Salle des Chauves-souris", RDC_PAL, [
    *notch("nw", 12, 12), *notch("ne", 12, 12), *notch("sw", 12, 12), *notch("se", 12, 12),
    *G.fill("floor_area3", 22, 22, 20, 20),
    ["statue", 23, 23], ["statue", 39, 23], ["statue", 23, 38], ["statue", 39, 38],
    ["floor_torch_v", 6, 18, 1], ["floor_torch_v", 56, 18, 1],
    ["floor_torch_v", 6, 38, 1], ["floor_torch_v", 56, 38, 1],
], [["right", 7, "normal"]], floor1=1)

# R4 — Salle de la Carte : salle en L, estrade au nord-est (coffre), enclos de blocs au
# sud-ouest (l'interrupteur (12,46) n'est accessible qu'au bloc poussé depuis (14,46)).
R4 = _room("temple_r4", "Temple de Sylve – Salle de la Carte", RDC_PAL, [
    *notch("nw", 28, 24),
    *G.fill("floor_area", 36, 7, 20, 4),
    *dais(36, 10, 20, 16, stairs_x=44),
    ["statue", 32, 12], ["statue", 32, 20], ["statue", 56, 28],
    ["block", 10, 44], ["block", 12, 44], ["block", 14, 44],
    ["block", 10, 46],
    ["block", 10, 48], ["block", 12, 48], ["block", 14, 48],
    ["floor_switch", 12, 46],
    *G.fill("floor_area3", 18, 42, 8, 12),
    ["floor_torch_v", 6, 28, 1], ["floor_torch_v", 6, 46, 1], ["floor_torch_v", 56, 46, 1],
    ["telepathic_tile", 22, 36],
], [["left", 1, "normal"]], floor1=0)

# R5 — Salle de la Trappe : cloître à quatre massifs, cercle d'étoiles autour de dalles
# fissurées (qui deviennent un trou après la trappe).
R5_CRACK = [["bomb_floor", 28, 28], ["bomb_floor", 32, 28], ["bomb_floor", 28, 32], ["bomb_floor", 32, 32]]
R5 = _room("temple_r5", "Temple de Sylve – Salle de la Trappe", RDC_PAL, [
    *dais(12, 12, 12, 12, top="floor_area"), *dais(40, 12, 12, 12, top="floor_area"),
    *dais(12, 40, 12, 12, top="floor_area"), *dais(40, 40, 12, 12, top="floor_area"),
    *G.fill("floor_area3", 24, 24, 16, 16),
    ["star_tile_off", 25, 25], ["star_tile_off", 37, 25], ["star_tile_off", 25, 37], ["star_tile_off", 37, 37],
    *R5_CRACK,
    ["statue", 8, 8], ["statue", 54, 8], ["statue", 8, 50], ["statue", 54, 50],
    ["torch_lit", 16, 8], ["torch_lit", 46, 8],
], [["down", 7, "normal"], ["left", 1, "normal"], ["right", 6, "small_key"]], floor1=3)

# R6 — Salle des Torches : salle en T, coffre muré au nord entre deux torches, fossé
# est-ouest (peint) avec passerelle, alcôve au sud.
R6_FRONT_BLOCKS = [["block", 29, 10], ["block", 31, 10], ["block", 33, 10]]
R6 = _room("temple_r6", "Temple de Sylve – Salle des Torches", RDC_PAL, [
    *notch("sw", 20, 20), *notch("se", 20, 20),
    *G.fill("floor_area", 24, 7, 16, 8),
    ["block", 29, 8], ["block", 33, 8], *R6_FRONT_BLOCKS,
    ["statue", 10, 8], ["statue", 52, 8],
    *G.fill("floor_area3", 24, 44, 16, 12),
    ["floor_torch_v", 24, 46, 1], ["floor_torch_v", 38, 46, 1],
], [["right", 7, "normal"]], floor1=0,
    torches=[[21, 9, False], [41, 9, False]])

# R7 — Couloir verrouillé : salle nord seule (layout 6), couloir balayé par un rouleau, une
# niche pour l'éviter ; escalier vers le sous-sol au bout.
R7 = _room("temple_r7", "Temple de Sylve – Couloir verrouillé", RDC_PAL, [
    *bump_s(16, 24, 20, bottom=32), *bump_s(36, 44, 20, bottom=32),
    *G.fill("floor_area3", 5, 7, 40, 8),
    *G.fill("floor_area3", 44, 7, 12, 8),
    ["floor_stairs_down", 48, 12],
    ["torch_lit", 45, 12], ["torch_lit", 53, 12],
    ["statue", 28, 22], ["statue", 8, 22],
], [["left", 0, "normal"]], layout=6, floor1=3)

# ====================================================================== sous-sol

# R8 — Crypte des Racines : coin nord-ouest effondré, racines, trois trous, escalier.
R8 = _room("temple_r8", "Temple de Sylve – Crypte des Racines", S1_PAL, [
    *notch("nw", 24, 20),
    *roots_v(36, 7, 2), *roots_v(20, 36, 3), *roots_h(38, 44, 2), *roots_v(56, 24, 2),
    *G.fill("floor_area3", 48, 7, 8, 12),
    ["floor_stairs_up", 50, 8],
    ["statue", 8, 52], ["statue", 54, 52],
], [["down", 7, "small_key"], ["left", 1, "shutter"]], floor1=9)

# R9 — Salle obscure : murets de blocs, gouffre central, deux torches, coffre au fond.
R9 = _room("temple_r9", "Temple de Sylve – Salle obscure", S1_PAL, [
    ["block_h", 8, 20, 4], ["block_h", 40, 20, 4],
    ["block_h", 8, 44, 4], ["block_h", 40, 44, 4],
    ["block_vert_v", 20, 24, 3], ["block_vert_v", 42, 30, 3],
    *G.fill("floor_area3", 48, 48, 8, 8),
    *roots_v(6, 36, 1), *roots_v(56, 34, 1),
], [["up", 1, "normal"], ["left", 1, "normal"]], floor1=9, lights_out=True,
    torches=[[12, 30, False], [50, 26, False]])

# R10 — Balcon d'Oriane : fossé nord-sud (peint), balcon au nord-ouest, pont (variante),
# île du cristal, plots bleus devant la porte ouest ; au sud, porte de la grande clé (pas de
# porte « grande clé » sur un mur sud dans ALttP : entité `door` + sprite door_down_big_key).
R10_PEGS = [["single_blue_peg", 6, 28], ["single_blue_peg", 8, 28], ["single_blue_peg", 6, 30],
            ["single_blue_peg", 8, 30], ["single_blue_peg", 6, 32], ["single_blue_peg", 8, 32],
            ["single_blue_peg", 6, 34], ["single_blue_peg", 8, 34]]
R10_BRIDGE = [*G.fill("floor6", 36, 30, 8, 4)]
R10 = _room("temple_r10", "Temple de Sylve – Balcon d'Oriane", S1_PAL, [
    *dais(6, 7, 20, 16, top="floor_area"),
    ["star_tile_on", 18, 12],
    *G.fill("floor_area3", 46, 26, 12, 12),
    ["statue", 12, 50], ["statue", 50, 50], ["statue", 50, 10],
    *roots_v(46, 7, 2), *roots_v(56, 44, 1),
], [["right", 7, "normal"], ["left", 1, "small_key"], ["up", 1, "normal"], ["down", 7, "normal"]],
    floor1=9)

# R11 — Salle de la Grande Clé : salle octogonale, estrade centrale, colonnes.
R11 = _room("temple_r11", "Temple de Sylve – Salle de la Grande Clé", S1_PAL, [
    *notch("nw", 12, 12), *notch("ne", 12, 12), *notch("sw", 12, 12), *notch("se", 12, 12),
    *G.fill("floor_area", 16, 20, 32, 24),
    *dais(22, 24, 20, 16, stairs_x=30),
    ["column_v", 10, 16, 1], ["column_v", 52, 16, 1], ["column_v", 10, 38, 1], ["column_v", 52, 38, 1],
    ["torch_lit", 20, 8], ["torch_lit", 42, 8],
], [["right", 7, "normal"]], floor1=9)

# R12 — Salle du Grand Coffre : salle en T, haute estrade, interrupteur du raccourci.
R12 = _room("temple_r12", "Temple de Sylve – Salle du Grand Coffre", S1_PAL, [
    *notch("sw", 16, 20), *notch("se", 16, 20),
    *dais(18, 8, 28, 20, stairs_x=30),
    ["statue", 12, 12], ["statue", 50, 12], ["statue", 12, 24], ["statue", 50, 24],
    *roots_v(6, 8, 2), *roots_v(56, 8, 2),
    ["floor_switch", 52, 36],
    ["torch_lit", 26, 36], ["torch_lit", 36, 36],
], [["down", 7, "normal"], ["left", 1, "normal"], ["right", 7, "shutter"]], floor1=9)

# R13 — Galerie des Yeux : galerie en anneau autour d'une terrasse centrale (escalier au sud).
R13 = _room("temple_r13", "Temple de Sylve – Galerie des Yeux", S1_PAL, [
    *dais(14, 16, 36, 36, stairs_x=30, top="floor_area"),
    ["statue", 20, 22], ["statue", 42, 22], ["statue", 20, 44], ["statue", 42, 44],
    ["torch_lit", 28, 32], ["torch_lit", 34, 32],
    ["floor_switch", 6, 54],
], [["right", 7, "normal"]], floor1=9)

# R14 — Arène des Veilleurs (layout 4, une seule zone) : antichambre au nord (derrière la porte de
# la grande clé de R10), herse dans le mur du milieu (interrupteur de R13), arène au sud aux
# coins effondrés (trous peints) ; porte est vers le Carillon (après le boss).
R14 = _room("temple_r14", "Temple de Sylve – Arène des Veilleurs", S1_PAL, [
    *bump_n(8, 20, 12), *bump_n(44, 56, 12),
    ["statue", 22, 8], ["statue", 40, 8],
    ["torch_lit", 10, 20], ["torch_lit", 52, 20],
    *G.fill("floor_area3", 16, 40, 32, 16),
    ["star_tile_off", 31, 42], ["star_tile_off", 31, 54], ["star_tile_off", 20, 48], ["star_tile_off", 42, 48],
], [["up", 1, "normal"], ["up", 7, "shutter"], ["right", 8, "shutter"]], layout=4, floor1=9)

# R15 — Salle du Carillon : racines du grand chêne qui descendent dans une fosse ; deux racines
# courtes et une racine horizontale forment un portique d'où pend la cloche (entité `sign` au
# sprite original `bell`, cases 30-33 x 11-14, au-dessus de la fosse) ; on la frappe depuis le bord.
R15 = _room("temple_r15", "Temple de Sylve – Salle du Carillon", BELL_PAL, [
    *notch("nw", 16, 16), *notch("ne", 16, 16),
    *roots_v(22, 7, 2), *roots_v(40, 7, 2), *roots_h(24, 8, 10),
    *G.fill("floor_area3", 24, 17, 16, 8),
    ["statue", 18, 34], ["statue", 44, 34],
    ["torch_lit", 10, 44], ["torch_lit", 52, 44],
    ["warp_tile", 50, 52],
], [["left", 2, "normal"]], floor1=0)

ROOMS = [R1, R2, R3, R4, R5, R6, R7, R8, R9, R10, R11, R12, R13, R14, R15]


# ---------------------------------------------------------------- trous peints (formes libres)
# room name -> {"pit": rectangles (x, y, w, h) of pit cells, "keep": rectangles left as floor}
PITS = {
    "temple_r3": {"pit": [(16, 16, 32, 32)], "keep": [(22, 22, 20, 20), (42, 30, 6, 4), (30, 16, 4, 6)]},
    "temple_r5_trappe": {"pit": [(28, 28, 8, 8)], "keep": []},
    "temple_r6": {"pit": [(5, 18, 54, 6)], "keep": [(28, 18, 8, 6)]},
    "temple_r8": {"pit": [(10, 26, 6, 6), (40, 18, 6, 6), (28, 44, 6, 6)], "keep": []},
    "temple_r9": {"pit": [(28, 26, 8, 12)], "keep": []},
    "temple_r10": {"pit": [(36, 7, 8, 52)], "keep": [(38, 46, 4, 4)]},
    "temple_r14": {"pit": [(5, 39, 8, 4), (5, 43, 4, 4), (51, 39, 8, 4), (55, 43, 4, 4),
                           (5, 55, 8, 4), (5, 51, 4, 4), (51, 55, 8, 4), (55, 51, 4, 4)], "keep": []},
    "temple_r15": {"pit": [(19, 7, 26, 10)], "keep": []},   # roots (type 0x27) are never painted over
}
# R10 with the drawbridge down: same pits minus the bridge
PITS["temple_r10_pont"] = {"pit": PITS["temple_r10"]["pit"], "keep": PITS["temple_r10"]["keep"] + [(36, 30, 8, 4)]}


def variant(spec, suffix, doors=None, objects=None, drop_objects=None, torches=None):
    """Copy of a room spec with door kinds changed ({index: kind}) and/or objects added /
    removed."""
    s = copy.deepcopy(spec)
    s["name"] = spec["name"] + "_" + suffix
    if doors:
        for i, kind in doors.items():
            s["doors"][i] = [s["doors"][i][0], s["doors"][i][1], kind]
    if drop_objects:
        s["objects"] = [o for o in s["objects"] if o not in drop_objects]
    if objects:
        s["objects"] = s["objects"] + objects
    if torches is not None:
        s["torches"] = torches
    return s


# ================================================================ helpers for the map files
# (numpy only, no mapgen import: content/maps/temple_sylve_*.py use them)

PIT_TYPE = 0x20


def pit_mask(key):
    import numpy as np
    m = np.zeros((64, 64), bool)
    p = PITS.get(key)
    if not p:
        return m
    for x, y, w, h in p["pit"]:
        m[y:y + h, x:x + w] = True
    for x, y, w, h in p["keep"]:
        m[y:y + h, x:x + w] = False
    return m


# tile types that a pit may touch without a lip: walls / ceilings (the wall goes straight down
# into the pit, like ALttP's "wall pit" objects) and the roots (rails) standing in it
PIT_NO_LIP = {0x01, 0x02, 0x04, 0x27}


def paint_pits(bg, fg, types, mask):
    """Paint free-form pits (ALttP hole tiles: lip on the edges facing the floor, black inside)
    in place. No lip against walls, ceilings and roots."""
    import numpy as np
    mask = mask & (types != 0x27)          # roots standing in the pit stay drawn
    solid = np.isin(types, list(PIT_NO_LIP)) & ~mask

    def P(x, y):
        return 0 <= x < 64 and 0 <= y < 64 and (bool(mask[y, x]) or bool(solid[y, x]))
    for y in range(64):
        for x in range(64):
            if not mask[y, x]:
                continue
            n, s, w, e = P(x, y - 1), P(x, y + 1), P(x - 1, y), P(x + 1, y)
            if not n and not w:
                v = 0x09DA
            elif not n and not e:
                v = 0x49DA
            elif not s and not w:
                v = 0x09DC
            elif not s and not e:
                v = 0x49DC
            elif not n:
                v = 0x09DB
            elif not s:
                v = 0x09DD
            elif not w:
                v = 0x09DE
            elif not e:
                v = 0x49DE
            elif not P(x - 1, y - 1):
                v = 0xC9DF
            elif not P(x + 1, y - 1):
                v = 0x89DF
            elif not P(x - 1, y + 1):
                v = 0x49DF
            elif not P(x + 1, y + 1):
                v = 0x09DF
            else:
                v = 0
            bg[y, x] = v
            fg[y, x] = 0
            types[y, x] = PIT_TYPE


def build(specs, pits=None):
    """Build room specs with roomgen (one batch) -> {name: {"bg","fg","types" (64x64 arrays),
    "room": built dict}}, pits painted (pits = {name: PITS key}; default: PITS[name] if it
    exists, else the pits of the base room "temple_rN")."""
    import numpy as np
    out = {}
    # bare version of each room (layout, doors, no objects): floors drawn over the walls' inner
    # trim (or over the walls) get the trim back
    bares = [dict(copy.deepcopy(s), name=s["name"] + "__bare", objects=[], torches=[]) for s in specs]
    built = G.build_rooms(list(specs) + bares)
    for spec, r, rb in zip(specs, built[:len(specs)], built[len(specs):]):
        a = {k: np.array(r[k], np.int64).reshape(64, 64) for k in ("bg", "fg", "types")}
        b = {k: np.array(rb[k], np.int64).reshape(64, 64) for k in ("bg", "fg", "types")}
        wall = b["types"] != 0
        near = np.zeros_like(wall)
        near[1:, :] |= wall[:-1, :]
        near[:-1, :] |= wall[1:, :]
        near[:, 1:] |= wall[:, :-1]
        near[:, :-1] |= wall[:, 1:]
        fix = (wall | near) & (a["types"] == 0) & (a["bg"] != b["bg"])
        for k in ("bg", "fg", "types"):
            a[k][fix] = b[k][fix]
        name = spec["name"]
        key = (pits or {}).get(name) or (name if name in PITS else "_".join(name.split("_")[:2]))
        paint_pits(a["bg"], a["fg"], a["types"], pit_mask(key))
        a["room"] = r
        out[spec["name"]] = a
    return out


def diff_cells(a, b, ox=0, oy=0):
    """Cells of b that differ from a -> [{x, y, bg, fg, type}] in map pixels (origin ox, oy)."""
    import numpy as np
    d = (a["bg"] != b["bg"]) | (a["fg"] != b["fg"]) | (a["types"] != b["types"])
    ys, xs = np.nonzero(d)
    return [{"x": ox + int(x) * 8, "y": oy + int(y) * 8, "bg": int(b["bg"][y, x]), "fg": int(b["fg"][y, x]),
             "type": int(b["types"][y, x])} for y, x in zip(ys, xs)]


def bbox(cells):
    xs = [c["x"] for c in cells]
    ys = [c["y"] for c in cells]
    return min(xs), min(ys), max(xs) + 8 - min(xs), max(ys) + 8 - min(ys)


def install(scr, arrays, room):
    """Put painted arrays into a mapgen Screen8 (unused quadrants left empty, like
    Map.room_custom does)."""
    scr.bg[:, :] = arrays["bg"]
    scr.fg[:, :] = arrays["fg"]
    scr.types[:, :] = arrays["types"]
    used = room.get("layout", {}).get("used_quadrants") or [0, 1, 2, 3]
    for i in range(4):
        if i not in used:
            ys, xs = slice((i // 2) * 32, (i // 2) * 32 + 32), slice((i % 2) * 32, (i % 2) * 32 + 32)
            scr.bg[ys, xs] = 0
            scr.fg[ys, xs] = 0
            scr.types[ys, xs] = 0x01
