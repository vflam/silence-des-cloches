"""Builds game/assets/rom/sprites/<id>.png + catalog.json from the recipes of every
tools/rom_extract/sprites_recipes_*.py module (list RECIPES)."""
from __future__ import annotations

import importlib
import sys
import traceback
from pathlib import Path

import numpy as np
from PIL import Image

import gfx
import sprites_common as sc
import sprites_custom_items as sci
import sprites_preview
from rom import Rom
from sprites_engine import Engine
from sprites_recipe import Recipe

SHADOW_CHARS = (0x6C, 0x38)


def all_recipes() -> list[Recipe]:
    out = []
    here = Path(__file__).parent
    for p in sorted(here.glob("sprites_recipes_*.py")):
        mod = importlib.import_module(p.stem)
        out.extend(getattr(mod, "RECIPES", []))
    return out


def vram_cgram(rom: Rom, r: Recipe):
    ts = r.tileset or gfx.sprite_tileset(rom, r.set + (0x40 if r.world == "uw" else 0))
    # misc_sprites_graphics_index: 1 light world, $0B dark world, $0A underworld
    v = sc.Vram.for_sprites(rom, ts, common={"lw": 0x01, "dw": 0x0B, "uw": 0x0A}[r.world])
    return v, sc.sprite_cgram(rom, r.world, r.pal)


def render_recipe(rom: Rom, r: Recipe) -> tuple[list[sc.Frame], dict]:
    """-> (unique frames, anims with frame indices)."""
    if r.custom is not None:
        vram, cg, drawn = r.custom(rom)

        def draw(i_anim, i_frame, state):
            return drawn[state["key"]]
    else:
        vram, cg = vram_cgram(rom, r)
        eng = Engine(rom)
        eng.spawn(r.type, indoors=r.world == "uw", dark=r.world == "dw", pre=dict(r.pre),
                  globals_=dict(r.pokes), link=r.link, prep=r.prep, before=sci.load_item_gfx)
        if r.post:
            eng.set(**r.post)

        def draw(i_anim, i_frame, state):
            st = dict(state)
            pokes = st.pop("poke", None)
            frame = st.pop("frame", 0)
            objs = eng.draw(st, pokes=pokes, frame=frame)
            sci.stream_tiles(vram, eng.cpu.wram, rom=rom)   # tiles the NMI streams from WRAM
            return objs

    frames: list[sc.Frame] = []
    keys: dict[tuple, int] = {}
    anims = {}
    for ai, (name, a) in enumerate(r.anims.items()):
        idx = []
        for fi, state in enumerate(a.states):
            objs = [o for o in draw(ai, fi, state) if o.char not in r.drop_chars]
            if not r.shadow:
                objs = [o for o in objs if not (o.char in SHADOW_CHARS and o.pal == 4)]
            f = sc.crop(sc.render_objs(vram, cg, objs)) if objs else sc.Frame(np.zeros((1, 1, 4), np.uint8), 0, 0)
            k = (f.img.shape, f.img.tobytes(), f.x0, f.y0)
            if k not in keys:
                keys[k] = len(frames)
                frames.append(f)
            idx.append(keys[k])
        dur = a.durations if isinstance(a.durations, list) else [a.durations] * len(idx)
        anims[name] = {"frames": idx, "durations": dur, "loop": a.loop}
    return frames, anims


def build(rom: Rom, out: Path, only: set | None = None, previews: bool = True) -> dict:
    catalog = {}
    errors = {}
    for r in all_recipes():
        if only and r.id not in only:
            continue
        try:
            frames, anims = render_recipe(rom, r)
        except Exception as e:  # a broken recipe must not stop the extraction
            errors[r.id] = f"{type(e).__name__}: {e}"
            traceback.print_exc(file=sys.stderr)
            continue
        atlas = sc.Atlas(width=max(64, min(256, sum(f.w + 1 for f in frames))))
        rects = [atlas.add(f.img) for f in frames]
        img = atlas.image()
        img.save(out / f"{r.id}.png")
        entry = {
            "png": f"sprites/{r.id}.png",
            "frames": [],
            "anims": anims,
            "tags": r.tags,
            "palette": f"{r.world}:{r.pal}",
            "source": (f"sprite 0x{r.type:02X}" if r.type is not None else "custom") + f", set {r.set}",
            "desc": r.desc,
        }
        for f, ri in zip(frames, rects):
            x, y, w, h = atlas.rects[ri]
            entry["frames"].append({"x": x, "y": y, "w": w, "h": h,
                                    "ox": r.foot[0] - f.x0, "oy": r.foot[1] - f.y0})
        catalog[r.id] = entry
        if previews:
            sprites_preview.sprite_sheet(entry, img, out / "previews" / f"{r.id}.png", title=f"{r.id}: {r.desc}")
    if errors:
        print("sprites: recipes en erreur:", errors, file=sys.stderr)
    return catalog
