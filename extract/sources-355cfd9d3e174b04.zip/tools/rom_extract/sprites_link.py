"""Link's sword and shield overlays (DrawLinksWeapon / DrawLinksShield, bank 0D) and the
sword hit box (CalculateSwordHitbox, bank 07 + SetupActionHitbox, bank 06).

Every table is read from the JP 1.0 ROM (labels of jpdasm). For an animation index
r2 = LinkAnimationDataOffsets[dir * 40 + type] + step (same index as link.json
`animation_indices`), the game draws:
  sword  : up to 3 OAM entries from WeaponDrawTiles[WeaponIndex[r2] * 3 ..], placed at
           (SwordX[r2], SwordY[r2]) then +8 x, then (+0, +8) ; 8x8 or 16x16 (WeaponDrawSize)
  shield : same with ShieldDrawTiles / ShieldIndex / ShieldX / ShieldY - 1
Characters 0x05/0x06/0x15/0x16 (sword) and 0x07/0x08/0x17/0x18 (shield) are streamed each
frame from the WRAM buffers built by DecompressSword/ShieldGraphics (sprite sheets 0x5E-0x5F
expanded "high"), via SwordGfxPointers / ShieldGfxPointers. All drawn with OAM palette 5
(CGRAM row 13): colours 9-11 = sword palette, 12-15 = shield palette.
"""
from __future__ import annotations

import numpy as np

import link
import sprites_common as sc
from rom import A, Rom

# ---- bank 0D (LinkOAM) -------------------------------------------------------------
WEAPON_DRAW_TILES = A(0x0D839B)     # 76 x 3 words (kSwordTiledata)
SHIELD_DRAW_TILES = A(0x0D8563)     # 18 x 3 words
ANIM_AUX_BUFFER_SET = A(0x0D9CF1)   # 511 bytes: OAM slot layout of each r2 (kPlayerOamSpriteLocs)
WEAPON_INDEX = A(0x0D8AF1)          # 511 bytes, $FF = none
SHIELD_INDEX = A(0x0D8CF0)          # 511 bytes
SWORD_Y, SWORD_X = A(0x0D8EEF), A(0x0D90EE)
SHIELD_Y, SHIELD_X = A(0x0D94DD), A(0x0D96DC)
ATTACK_HITBOX_Y, ATTACK_HITBOX_X = A(0x0D98F3), A(0x0D9AF2)
WEAPON_OAM_SLOTS = A(0x0DA090)      # WeaponOAMBufferOffsets_SetA (12)
BODY_OAM_SLOTS = A(0x0DA09C)        # ElfOAMBufferOffsets_SetA (12)
SHIELD_OAM_SLOTS = A(0x0DA0A8)      # ShieldOAMBufferOffsets_SetA (12)
WEAPON_DRAW_INDEX = A(0x0DAACC)     # 76 bytes: sword gfx id (x2) streamed to chars 05/06
WEAPON_DRAW_SIZE = A(0x0DAB22)      # 76 bytes: 0 = 8x8, 2 = 16x16
SHIELD_GFX_ID = A(0x0DABCA)         # SetEquipmentVRAMOffsets.shield_id (18)
TIP_TILE = A(0x0DAC45)              # SwordSwingTipTile: 4 dirs x 9 words
TIP_Y, TIP_X = A(0x0DAC8D), A(0x0DACB1)
# ---- bank 00 ------------------------------------------------------------------------
SWORD_GFX_PTRS = A(0x00849C)        # 8 words ($7E9000...)
SHIELD_GFX_PTRS = A(0x0084AC)       # 3 words
SWORD_GFX_OFFSET = A(0x00D2FE)      # DecompressSwordGraphics.offset (5 words, by sword level)
SHIELD_GFX_OFFSET = A(0x00D340)     # DecompressShieldGraphics.offset (4 words)
SWORD_SHEETS = (0x5E, 0x5F)
# ---- banks 06 / 07 ------------------------------------------------------------------
ACTION_HITBOX = A(0x06F473)         # ActionHitbox: offset_x, size_x, offset_y, size_y (65 each)
SWORD_VALIDITY = A(0x06F577)        # 13 bytes, 0 = the sword hits at this button_b_frames
SWORD_SWING_TIMERS = A(0x079CAF)    # 18 bytes (kSpinAttackDelays): frame f lasts timer[f]+1

N_SWORD_GFX = 29                 # WeaponIndex values < 29 are sword pieces (above: items)
N_SHIELD_GFX = 8


def _signed_add8(a: int, b: int) -> int:
    return sc.int8((a + b) & 0xFF)


def _expand_high(tiles: np.ndarray, off: int, num: int) -> list[np.ndarray]:
    """Expand3To4High from byte offset `off` of the decompressed sheets ($7F4000 based):
    after every tile, when the source address & 0x78 == 0 (end of a 16-tile row) the
    routine skips the next row (0x180 bytes), as sheets store 16x16 halves in row pairs."""
    out = []
    for _ in range(num):
        out.append(sc.hi(tiles[off // 24]))
        off += 24
        if not off & 0x78:
            off += 0x180
    return out


def _wram_buffers(rom: Rom, sword: int, shield: int) -> dict[int, np.ndarray]:
    """The 4bpp tiles of $7E9000-$7E947F (0x20 bytes / tile) for a sword / shield level
    (DecompressSwordGraphics / DecompressShieldGraphics)."""
    tiles = np.concatenate([sc.spr_tiles(rom, SWORD_SHEETS[0]), sc.spr_tiles(rom, SWORD_SHEETS[1]),
                            np.zeros((64, 8, 8), np.uint8)])
    buf: dict[int, np.ndarray] = {}
    so = rom.word(SWORD_GFX_OFFSET + 2 * sword)
    for base, off in ((0x9000, so), (0x9180, so + 0x180)):
        for i, t in enumerate(_expand_high(tiles, off, 12)):
            buf[base + i * 0x20] = t
    ho = rom.word(SHIELD_GFX_OFFSET + 2 * shield)
    for base, off in ((0x9300, ho), (0x93C0, ho + 0x180)):
        for i, t in enumerate(_expand_high(tiles, off, 6)):
            buf[base + i * 0x20] = t
    return buf


def _vram(rom: Rom, buf: dict[int, np.ndarray], sword_ptr: int | None, shield_ptr: int | None) -> sc.Vram:
    """Characters 0x00-0x3F: sprite sheet 0 (LoadDefaultGraphics) + the streamed sword/shield."""
    v = sc.Vram()
    v.load_sheet(0, 0x00, rom, high=True)
    z = np.zeros((8, 8), np.uint8)

    def stream(char: int, addr: int, n: int) -> None:
        for i in range(n):
            v.chars[char + i] = buf.get((addr & 0xFFFF) + i * 0x20, z)

    if sword_ptr is not None:
        stream(0x05, sword_ptr, 2)
        stream(0x15, sword_ptr + 0x180, 2)
    if shield_ptr is not None:
        stream(0x07, shield_ptr, 2)
        stream(0x17, shield_ptr + 0xC0, 2)
    return v


def _pieces(words: list[int], big: bool, x: int = 0, y: int = 0) -> list[sc.Obj]:
    out = []
    for i, w in enumerate(words):
        if w != 0xFFFF:
            out.append(sc.Obj.from_word(x + (8 if i == 1 else 0), y + (8 if i == 2 else 0), w, big))
    return out


def extract(rom: Rom, atlas: sc.Atlas) -> dict:
    n = link.ANIM_POSE_COUNT
    weapon_index = list(rom.bytes(WEAPON_INDEX, n))
    shield_index = list(rom.bytes(SHIELD_INDEX, n))
    sword_x, sword_y = sc.int8s(rom, SWORD_X, n), sc.int8s(rom, SWORD_Y, n)
    shield_x, shield_y = sc.int8s(rom, SHIELD_X, n), sc.int8s(rom, SHIELD_Y, n)
    hb_x, hb_y = list(rom.bytes(ATTACK_HITBOX_X, n)), list(rom.bytes(ATTACK_HITBOX_Y, n))
    layout = list(rom.bytes(ANIM_AUX_BUFFER_SET, n))
    wslot = list(rom.bytes(WEAPON_OAM_SLOTS, 12))
    bslot = list(rom.bytes(BODY_OAM_SLOTS, 12))
    sslot = list(rom.bytes(SHIELD_OAM_SLOTS, 12))
    wtiles = rom.words(WEAPON_DRAW_TILES, 76 * 3)
    stiles = rom.words(SHIELD_DRAW_TILES, 18 * 3)
    wdraw_index = list(rom.bytes(WEAPON_DRAW_INDEX, 76))
    wdraw_size = list(rom.bytes(WEAPON_DRAW_SIZE, 76))
    shield_gfx_id = list(rom.bytes(SHIELD_GFX_ID, 18))
    sword_ptrs = rom.words(SWORD_GFX_PTRS, 8)
    shield_ptrs = rom.words(SHIELD_GFX_PTRS, 3)
    tip_tile = rom.words(TIP_TILE, 36)
    tip_x, tip_y = list(rom.bytes(TIP_X, 36)), list(rom.bytes(TIP_Y, 36))
    ah = list(rom.bytes(ACTION_HITBOX, 65 * 4))
    ah_off_x, ah_w = ah[0:65], ah[65:130]
    ah_off_y, ah_h = ah[130:195], ah[195:260]
    validity = list(rom.bytes(SWORD_VALIDITY, 13))
    timers = list(rom.bytes(SWORD_SWING_TIMERS, 18))
    offsets = rom.words(link.ANIM_OFFSETS, 160)

    def rect(i: int, f: sc.Frame) -> dict:
        x, y, w, h = atlas.rects[i]
        return {"x": x, "y": y, "w": w, "h": h, "ox": f.x0, "oy": f.y0}

    # ---- graphics: one pre-composed image per (piece id, level) ----------------------
    sword_gfx: dict[str, list] = {}
    tip_gfx: dict[str, dict] = {}
    for level in (1, 2, 3, 4):
        cg = sc.sprite_cgram(rom, sword=level, shield=1)
        buf = _wram_buffers(rom, level, 1)
        lst = []
        for j in range(N_SWORD_GFX):
            v = _vram(rom, buf, sword_ptrs[wdraw_index[j] >> 1], None)
            f = sc.crop(sc.render_objs(v, cg, _pieces(wtiles[j * 3:j * 3 + 3], wdraw_size[j] == 2)))
            lst.append(rect(atlas.add(f.img), f))
        sword_gfx[str(level)] = lst
        # swing tip (sword >= 2): characters of sheet 0 (and the sword char 05)
        tips = {}
        for w in sorted(set(t for t in tip_tile if t & 0xFF != 0xFF)):
            v = _vram(rom, buf, sword_ptrs[0], None)
            f = sc.crop(sc.render_objs(v, cg, [sc.Obj.from_word(0, 0, w, False)]))
            tips["%04x" % w] = rect(atlas.add(f.img), f)
        tip_gfx[str(level)] = tips
    shield_gfx: dict[str, list] = {}
    for level in (1, 2, 3):
        cg = sc.sprite_cgram(rom, sword=1, shield=level)
        buf = _wram_buffers(rom, 1, level)
        lst = []
        for j in range(N_SHIELD_GFX):
            v = _vram(rom, buf, None, shield_ptrs[shield_gfx_id[j] >> 1])
            f = sc.crop(sc.render_objs(v, cg, _pieces(stiles[j * 3:j * 3 + 3], True)))
            lst.append(rect(atlas.add(f.img), f))
        shield_gfx[str(level)] = lst

    # ---- per animation index --------------------------------------------------------
    sword, shield, layers = {}, {}, {}
    for r2 in range(n):
        loc = layout[r2]
        body = bslot[loc]
        j = weapon_index[r2]
        if j < N_SWORD_GFX:
            sword[str(r2)] = {"g": j, "x": sword_x[r2], "y": sword_y[r2], "front": wslot[loc] < body}
        j = shield_index[r2]
        if j < N_SHIELD_GFX:
            shield[str(r2)] = {"g": j, "x": shield_x[r2], "y": shield_y[r2] - 1, "front": sslot[loc] < body}
        if str(r2) in sword or str(r2) in shield:
            order = [("body", body + 4), ("head", body)]
            if str(r2) in sword:
                order.append(("sword", wslot[loc]))
            if str(r2) in shield:
                order.append(("shield", sslot[loc]))
            # OAM: lower slot drawn on top -> list back to front
            layers[str(r2)] = [name for name, s in sorted(order, key=lambda t: (-t[1], t[0] != "body"))]

    # ---- sword swing: tip + hit boxes ------------------------------------------------
    def hitbox(dir_i: int, bframes: int, level: int, r2: int) -> list[int] | None:
        if validity[bframes]:
            return None
        oy, ox = hb_y[r2], hb_x[r2]
        if level >= 2 and bframes < 9:
            i = dir_i * 9 + bframes
            if tip_tile[i] & 0xFF != 0xFF:
                oy, ox = tip_y[i], tip_x[i]
        t = dir_i * 16 + bframes + 1
        return [_signed_add8(ah_off_x[t], ox), _signed_add8(ah_off_y[t], oy), ah_w[t], ah_h[t]]

    attacks = {}
    for dir_i, dname in enumerate(link.DIRECTIONS):
        slash = []
        for f in range(9):
            r2 = offsets[dir_i * 40 + 39] + f
            tip = None
            i = dir_i * 9 + f
            if tip_tile[i] & 0xFF != 0xFF:
                tip = {"t": "%04x" % tip_tile[i], "x": sc.int8(tip_x[i]),
                       "y": sc.int8(tip_y[i])}
            slash.append({
                "r2": r2, "button_b_frames": f, "duration": timers[f] + 1,
                "hitbox": {str(lv): hitbox(dir_i, f, lv, r2) for lv in (1, 2, 3, 4)},
                "tip": tip,
            })
        ready = offsets[dir_i * 40 + 2]
        poke = []
        for f in range(10, 13):
            r2 = offsets[dir_i * 40 + 3] + (f - 10)
            poke.append({"r2": r2, "button_b_frames": f, "duration": timers[f] + 1,
                         "hitbox": {str(lv): hitbox(dir_i, f, lv, r2) for lv in (1, 2, 3, 4)}})
        spin = offsets[dir_i * 40 + 15]
        starts = sorted(set(offsets) | {n})
        spin_len = starts[starts.index(spin) + 1] - spin
        attacks[dname] = {
            "sword_slash": slash,
            "sword_ready": {"r2": ready, "hitbox": {str(lv): hitbox(dir_i, 9, lv, ready) for lv in (1, 2, 3, 4)}},
            "sword_poke": poke,
            "spin_attack": {"r2": [spin + k for k in range(spin_len)]},
        }

    return {
        "doc": ("Overlays of Link's sword and shield. Coordinates are relative to Link.pos = "
                "top-left of the head (body at y+8), like link.json. For an animation index r2 "
                "(link.json animation_indices), draw sword[r2] with sword_gfx[level][g] at "
                "pos + (x + ox, y + oy) and shield[r2] with shield_gfx[level][g] likewise; "
                "layers[r2] lists body/head/sword/shield from back to front. "
                "attacks[dir].sword_slash: the 9 swing frames (r2, duration in frames, sword "
                "hit box [x, y, w, h] per sword level, relative to Link.pos; null = no hit), "
                "tip = extra swing-tip tile for swords >= 2 (tip_gfx, at pos + (x + ox, y + oy))."),
        "png": "sprites/link_weapons.png",
        "sword_gfx": sword_gfx,
        "shield_gfx": shield_gfx,
        "tip_gfx": tip_gfx,
        "sword": sword,
        "shield": shield,
        "layers": layers,
        "attacks": attacks,
        "spin_hitbox": [-14, -10, 44, 45],
        "swing_timers": timers,
        "source": "LinkAnimationWeaponIndex/ShieldIndex, WeaponDrawTiles, AttackHitbox, ActionHitbox (JP 1.0)",
    }
