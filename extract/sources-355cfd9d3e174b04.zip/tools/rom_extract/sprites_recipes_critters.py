"""Sprite recipes, group "critters": small overworld / dungeon enemies (octoroks, keese, rats,
ropes, blobs, baris, crabs, ...). Only sprite ids, set indices and state values here: every
tile, palette and OAM layout comes from the ROM (sprites_engine runs the game's own code)."""
from __future__ import annotations

import math

from sprites_recipe import Recipe as R, Anim, dirs4, seq, D_RLDU

DIRS = ("up", "down", "left", "right")


def same4(prefix, states, dur=8, loop=True):
    """Same animation for the 4 directions (symmetric sprites)."""
    return {f"{prefix}_{d}": Anim(list(states), dur, loop) for d in DIRS}


def per_dir(prefix, table, dur=8, loop=True):
    """table: {dir: [states]}"""
    return {f"{prefix}_{d}": Anim(list(s), dur, loop) for d, s in table.items()}


def flipx(states, base):
    """Same states with the horizontal flip bit ($0F50 bit 6) toggled on top of `base`."""
    return [dict(s, oam_flags=base ^ 0x40) for s in states]


# ------------------------------------------------------------------ octorok (0x08 / 0x0A)
# graphics: horizontal (D 0/1) walk cycle g 0-3, vertical (D 2/3) g 4-7, 8 frames each
# (subtype2 >> 3). Spitting: mouth size $0DB0 (C) 0,1,2,0 over the 60-frame pause.
def _oct_g(d):
    return 0 if d < 2 else 4


def octorok_anims(four_way=False):
    a = dirs4("walk", lambda d, n: seq(D=d, g=[_oct_g(d) + i for i in range(4)], C=0), dur=8)
    if not four_way:
        a.update(dirs4("attack", lambda d, n: seq(D=d, g=_oct_g(d), C=[0, 1, 2, 0]),
                       dur=[5, 24, 24, 7], loop=False))
    else:
        # 4-way shooter: spins right -> down -> left -> up, spitting every 16 frames
        spin = [{"D": d, "g": _oct_g(d), "C": 2} for d in (0, 2, 1, 3)]
        a["attack"] = Anim(spin, 16, True)
    return a


OCTOROK = [
    R("octorok", 0x08, set=11, pal=3, world="lw", tags=["enemy"],
      desc="Octorok (crache des pierres)", anims=octorok_anims()),
    R("octorok_4way", 0x0A, set=11, pal=3, world="lw", tags=["enemy"],
      desc="Octorok tourniquet (crache dans les 4 directions)", anims=octorok_anims(True)),
    R("octorok_rock", 0x0C, set=11, pal=3, world="lw", tags=["fx"],
      desc="Pierre crachée par l'Octorok",
      anims={"idle": Anim([{"g": 0}], 8),
             # crumbling: state 6, delay 31 -> 0, 4 fragments flying apart (8 frames each)
             "die": Anim([{"state": 6, "flags2": 3, "delay": t} for t in (28, 20, 12, 4)], 8, False)}),
]

# ------------------------------------------------------------------ castle vermin (uw set 1)
RAT_WALK = {"right": [8, 9], "left": [4, 5], "down": [0, 1], "up": [12, 13]}
RAT_IDLE = {"right": [10, 11], "left": [6, 7], "down": [2, 3], "up": [14, 15]}
ROPE_A = {"right": [4, 5], "left": [2, 3], "down": [0, 1], "up": [6, 7]}

VERMIN = [
    R("rat", 0x6D, set=1, pal=1, world="uw", tags=["enemy"], desc="Rat",
      anims={**per_dir("walk", {d: seq(A=v) for d, v in RAT_WALK.items()}, 4),
             **per_dir("idle", {d: seq(A=v) for d, v in RAT_IDLE.items()}, 8)}),
    R("rope", 0x6E, set=1, pal=1, world="uw", tags=["enemy"], desc="Serpent (Rope)",
      anims={**per_dir("walk", {d: seq(A=v) for d, v in ROPE_A.items()}, 4),
             **per_dir("idle", {d: seq(A=v) for d, v in ROPE_A.items()}, 8),
             # charge towards Link: twice as fast
             **per_dir("attack", {d: seq(A=v) for d, v in ROPE_A.items()}, 2)}),
    R("keese", 0x6F, set=1, pal=1, world="uw", tags=["enemy"], desc="Chauve-souris (Keese)",
      anims={**same4("idle", [{"g": 0}]), **same4("walk", seq(g=[1, 2]), 4)}),
]

# ------------------------------------------------------------------ overworld critters
BUZZBLOB = R("buzzblob", 0x0D, set=7, pal=6, world="lw", tags=["enemy"],
             desc="Buzzblob (électrique)",
             anims={**same4("walk", seq(g=[0, 1, 0, 2]), 8),
                    # electrified after being hit
                    "attack": Anim(seq(g=[3, 4, 3, 5]), 8)})

CRAB = R("crab", 0x58, set=4, pal=3, world="lw", tags=["enemy"], desc="Crabe",
         anims={"walk_right": Anim(seq(g=[0, 1]), 2), "walk_left": Anim(seq(g=[0, 1]), 2),
                "walk_down": Anim(seq(g=[0, 1]), 8), "walk_up": Anim(seq(g=[0, 1]), 8),
                **same4("idle", [{"g": 0}])})

# Rock crab (0x3E, "hoarder"): hides under a rock, runs away once uncovered (oam_flags 9)
ROCK_CRAB = R("rock_crab", 0x3E, set=10, pal=3, world="lw", tags=["enemy"],
              desc="Crabe caché sous un rocher",
              anims={**same4("idle", [{"ai": 0, "g": 0}]),
                     **same4("walk", seq(ai=0, g=[3, 4, 5, 4]), 2),
                     "special_run": Anim(seq(ai=1, g=[0, 1, 0, 1], oam_flags=[9, 9, 0x49, 9]), 2)})

DEADROCK = R("deadrock", 0x27, set=16, pal=9, world="lw", tags=["enemy"],
             desc="Deadrock (se pétrifie quand on le frappe)",
             anims={**dirs4("walk", lambda d, n: seq(ai=1, A=[2 * d, 2 * d + 1]), dur=4),
                    **dirs4("idle", lambda d, n: seq(ai=0, A=2 * d), dur=8),
                    "special_petrified": Anim([{"ai": 2}], 8)})

TEKTITE = R("tektite", 0xC9, set=5, pal=7, world="dw", tags=["enemy"], desc="Tektite (araignée sauteuse)",
            anims={**same4("idle", seq(g=[0, 1]), 16),
                   # hop: z_vel ~28, gravity 1/frame -> ~25 px high, ~56 frames
                   **same4("walk", seq(g=2, z=[2, 10, 17, 22, 25, 22, 17, 10, 2]), 6)})

LEEVER_EMERGE = [0, 0, 1, 2, 1, 2, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
LEEVER = R("leever", 0x71, set=10, pal=9, world="uw", tags=["enemy"], desc="Leever (sort du sable)",
           anims={**same4("walk", seq(ai=2, g=[9, 10, 11, 12]), 4),
                  "special_emerge": Anim(seq(ai=1, g=LEEVER_EMERGE), 8, False),
                  "special_submerge": Anim(seq(ai=3, g=LEEVER_EMERGE[::-1]), 8, False)})

POE = R("poe", 0x19, set=3, pal=2, world="lw", tags=["enemy"], desc="Poe (fantôme à lanterne)",
        anims={"walk_right": Anim(seq(x_vel=0x10, subtype2=[0, 8, 16, 24]), 8),
               "walk_left": Anim(seq(x_vel=0xF0, subtype2=[0, 8, 16, 24]), 8),
               "walk_down": Anim(seq(x_vel=0xF0, subtype2=[0, 8, 16, 24]), 8),
               "walk_up": Anim(seq(x_vel=0x10, subtype2=[0, 8, 16, 24]), 8)})

# Snapdragon: D = diagonal (0 down-right, 1 down-left, 2 up-right, 3 up-left), B = mouth open
SNAP_D = {"right": 0, "left": 1, "down": 1, "up": 3}
SNAPDRAGON = R("snapdragon", 0x0E, set=19, pal=14, world="dw", tags=["enemy"],
               desc="Snapdragon (bondit en diagonale)",
               anims={**per_dir("idle", {d: seq(D=v, B=[0, 1]) for d, v in SNAP_D.items()}, [8, 24]),
                      **per_dir("walk", {d: seq(D=v, B=1, z=[0, 2, 4, 2]) for d, v in SNAP_D.items()},
                                [2, 3, 3, 2])})

ROPA = R("ropa", 0x22, set=19, pal=14, world="dw", tags=["enemy"], desc="Ropa (plante sauteuse)",
         anims={**same4("idle", seq(g=[0, 1, 2, 3]), 8),
                # pounce: z_vel 20-35, gravity 2/frame -> ~11 px, ~28 frames
                **same4("walk", seq(g=[0, 1, 2, 3, 0, 1, 2], z=[2, 6, 9, 11, 9, 6, 2]), 4)})

RAVEN_OAM = 0x09
RAVEN = R("crow", 0x00, set=4, pal=3, world="lw", tags=["enemy"], desc="Corbeau",
          anims={"idle_right": Anim([{"ai": 0, "g": 0, "oam_flags": RAVEN_OAM}]),
                 "idle_left": Anim([{"ai": 0, "g": 0, "oam_flags": RAVEN_OAM | 0x40}]),
                 "walk_right": Anim(seq(g=[1, 2], oam_flags=RAVEN_OAM), 2),
                 "walk_left": Anim(seq(g=[1, 2], oam_flags=RAVEN_OAM | 0x40), 2)})

VULTURE = R("vulture", 0x01, set=8, pal=4, world="dw", tags=["enemy"], desc="Vautour",
            anims={**same4("idle", [{"g": 0}]), **same4("walk", seq(g=[1, 2, 3, 2]), 2)})

BEE = R("bee", 0x79, set=1, pal=1, world="uw", tags=["enemy"], desc="Abeille",
        anims={"walk_left": Anim(seq(ai=1, g=[0, 1], oam_flags=0x06), 2),
               "walk_right": Anim(seq(ai=1, g=[0, 1], oam_flags=0x46), 2)})

CRITTERS = [BUZZBLOB, CRAB, ROCK_CRAB, DEADROCK, TEKTITE, LEEVER, POE, SNAPDRAGON, ROPA, RAVEN,
            VULTURE, BEE]

# ------------------------------------------------------------------ dungeon critters
BARI_ANIMS = {**same4("walk", seq(C=0, g=[0, 1]), 8),
              # electrified: flashes g 0 / 2 every 2 frames
              "attack": Anim(seq(C=0, ai=1, g=[0, 2]), 2)}

HELMA = {"right": 0, "left": 1, "down": 2, "up": 3}


def _moldorm_pokes(d, bend=0):
    """History buffer (bank 7F $FC00.. x lo/hi, $FD00.. y lo/hi) filled as if the mini
    moldorm had been crawling in direction d (16 angles, 0 = right) at 1.5 px/frame.
    With subtype2 = 0 the drawer reads the segments 6 and 11 frames old."""
    pokes = {}
    x0 = y0 = 0x880
    for age, bend_k in ((6, 0), (11, bend)):
        a = (d + bend_k) * math.pi / 8
        x = round(x0 - math.cos(a) * 1.5 * age)
        y = round(y0 - math.sin(a) * 1.5 * age)
        i = (-age) & 0x1F
        pokes[0x1FC00 + i] = x & 0xFF
        pokes[0x1FC80 + i] = x >> 8
        pokes[0x1FD00 + i] = y & 0xFF
        pokes[0x1FD80 + i] = y >> 8
    return pokes


MOLDORM_D = {"right": 0, "down": 4, "left": 8, "up": 12}

DUNGEON = [
    R("bari_red", 0x23, set=8, pal=15, world="uw", tags=["enemy"],
      desc="Bari rouge (méduse électrique, se divise en Biri)", anims=BARI_ANIMS),
    R("bari_blue", 0x24, set=8, pal=15, world="uw", tags=["enemy"],
      desc="Bari bleu (méduse électrique)", anims=BARI_ANIMS),
    R("biri", 0x23, set=8, pal=15, world="uw", tags=["enemy"],
      desc="Biri (petit Bari issu de la division)",
      post={"C": 1, "flags3": 0x33, "oam_flags": 3, "flags4": 1},
      anims={**same4("walk", seq(g=[3, 4]), 8)}),
    R("popo", 0x4E, set=8, pal=11, world="uw", tags=["enemy"], desc="Popo (gelée)",
      anims={**same4("idle", seq(A=[0, 1, 2, 3]), 16), **same4("walk", seq(A=[0, 1, 2, 3]), 8)}),
    R("hardhat", 0x26, set=19, pal=13, world="uw", tags=["enemy"],
      desc="Hardhat beetle rouge (scarabée casqué)",
      post={"oam_flags": 6}, anims=same4("walk", seq(subtype2=[0, 4]), 4)),
    R("hardhat_blue", 0x26, set=19, pal=13, world="uw", tags=["enemy"],
      desc="Hardhat beetle bleu (scarabée casqué)",
      post={"oam_flags": 8}, anims=same4("walk", seq(subtype2=[0, 4]), 4)),
    R("mini_helmasaur", 0x13, set=12, pal=26, world="uw", tags=["enemy"], desc="Mini-Helmasaur",
      anims=per_dir("walk", {d: seq(D=v, subtype2=[0, 4]) for d, v in HELMA.items()}, 4)),
    R("sluggula", 0x20, set=29, pal=17, world="uw", tags=["enemy"], desc="Sluggula (limace poseuse de bombes)",
      anims=per_dir("walk", {d: seq(D=v, subtype2=[0, 8]) for d, v in HELMA.items()}, 8)),
    R("mini_moldorm", 0x18, set=19, pal=13, world="uw", tags=["enemy"], desc="Mini-Moldorm (ver)",
      anims=per_dir("walk", {d: [{"D": v, "subtype2": 0, "poke": _moldorm_pokes(v, b)}
                                 for b in (0, 1, 0, -1)] for d, v in MOLDORM_D.items()}, 8)),
    R("anti_fairy", 0x15, set=8, pal=10, world="uw", tags=["enemy"],
      desc="Anti-fée (bulle, vide la magie)", anims={"idle": Anim(seq(g=[0, 1, 2, 3, 4, 5]), 2)}),
    R("stalfos_head", 0x7C, set=8, pal=11, world="uw", tags=["enemy"],
      desc="Tête de Stalfos volante",
      anims={"walk_right": Anim([{"D": 0}]), "walk_left": Anim([{"D": 1}]),
             "walk_down": Anim([{"D": 3}]), "walk_up": Anim([{"D": 2}])}),
    R("zol", 0x8F, set=17, pal=8, world="uw", tags=["enemy"], desc="Zol (blob qui sort du sol)",
      anims={"walk_right": Anim(seq(ai=3, g=[0, 1], oam_flags=0x0B), 8),
             "walk_left": Anim(seq(ai=3, g=[0, 1], oam_flags=0x4B), 8),
             "walk_down": Anim(seq(ai=3, g=[0, 1], oam_flags=0x0B), 8),
             "walk_up": Anim(seq(ai=3, g=[0, 1], oam_flags=0x4B), 8),
             "special_emerge": Anim(seq(ai=1, g=[4, 5, 6, 5, 6, 7, 1, 0]),
                                    [32, 16, 16, 16, 16, 16, 8, 7], False)}),
    R("water_bug", 0x81, set=17, pal=10, world="uw", tags=["enemy"], desc="Punaise d'eau (Hover)",
      anims={"walk_left": Anim(seq(g=[0, 1], oam_flags=0x0B), 8),
             "walk_right": Anim(seq(g=[0, 1], oam_flags=0x4B), 8),
             "idle_left": Anim(seq(g=[0, 2], oam_flags=0x0B), 16),
             "idle_right": Anim(seq(g=[0, 2], oam_flags=0x4B), 16)}),
    R("babasu", 0x9C, set=17, pal=10, world="uw", tags=["enemy"],
      desc="Babasu (surgit des murs)",
      anims={"walk_right": Anim(seq(ai=3, g=[18, 19]), 2), "walk_left": Anim(seq(ai=3, g=[14, 15]), 2),
             "walk_down": Anim(seq(ai=3, g=[12, 13]), 2), "walk_up": Anim(seq(ai=3, g=[16, 17]), 2),
             "special_emerge": Anim(seq(ai=2, g=[6, 7, 8, 9, 10, 11]), 4, False),
             "special_emerge_v": Anim(seq(ai=2, g=[0, 1, 2, 3, 4, 5]), 4, False)}),
    R("terrorpin", 0x8E, set=25, pal=15, world="uw", tags=["enemy"], desc="Terrorpin (tortue à renverser au marteau)",
      anims={**same4("walk", seq(g=[0, 1]), 8),
             "special_overturned": Anim(seq(g=2, oam_flags=[0x0B, 0x4B]), 8)}),
]

RECIPES = OCTOROK + VERMIN + CRITTERS + DUNGEON
