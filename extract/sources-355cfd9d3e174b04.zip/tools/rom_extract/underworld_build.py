"""Underworld rooms: run the room drawing code (tools/room_render, C, zelda3 MIT) on the ROM
data, then turn its tilemaps into our tile8 screens, tilesets and previews."""
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np

import gfx
import native
import palettes as pal
import render as R
import underworld_rom as U
from rom import Rom

ROOT = Path(__file__).resolve().parents[2]
RENDER_DIR = ROOT / "tools" / "room_render"
RECORD = 0x8000

# kDungAnimatedTiles (zelda3 dungeon.c): animated sheet per main tile theme.
DUNG_ANIMATED_SHEETS = [0x5D, 0x5D, 0x5D, 0x5D, 0x5D, 0x5D, 0x5D, 0x5F, 0x5D, 0x5F, 0x5F, 0x5E,
                        0x5F, 0x5E, 0x5E, 0x5D, 0x5D, 0x5E, 0x5D, 0x5D, 0x5D, 0x5D, 0x5D, 0x5D]
ANIM_SHEET_B = 0x5C

BG_MODES = ["off", "parallax", "dark", "on_top", "translucent", "parallax2", "normal", "addition"]
COLLISIONS = ["one", "both", "both_scroll", "moving_floor", "moving_water"]

DOOR_KINDS = {
    0x00: "normal", 0x02: "normal_lower", 0x04: "exit_lower", 0x06: "exit_unused",
    0x08: "waterfall", 0x0A: "exit_big", 0x0C: "exit_big_lower", 0x0E: "exit_cave",
    0x10: "exit_cave_lower", 0x12: "exit_marker", 0x14: "dungeon_swap", 0x16: "layer_swap",
    0x18: "shutter", 0x1A: "invisible", 0x1C: "small_key", 0x1E: "big_key",
    0x20: "key_stairs_up", 0x22: "key_stairs_down", 0x24: "key_stairs_up_lower",
    0x26: "key_stairs_down_lower", 0x28: "bombable_open", 0x2A: "bombable_cave",
    0x2C: "dash_wall", 0x2E: "bombable", 0x30: "exploding_wall", 0x32: "curtain",
    0x34: "unused_34", 0x36: "shutter_one_way_bottom", 0x38: "shutter_one_way_top",
    0x3A: "unused_3a", 0x3C: "unused_3c", 0x3E: "unused_3e", 0x40: "normal_40",
    0x42: "unused_42", 0x44: "shutter_trap", 0x46: "warp_room", 0x48: "shutter_trap_ur",
    0x4A: "shutter_trap_dl",
}
DIRS = ["up", "down", "left", "right"]


# ------------------------------------------------------------------ C harness

def _compiler() -> str | None:
    for cc in (os.environ.get("CC"), "gcc", "cc", "clang"):
        if cc and shutil.which(cc):
            return cc
    return None


def harness_binary() -> Path:
    """tools/room_render/build/room_render, built if missing or stale (in the browser: the
    WebAssembly build shipped with the page, see native.py)."""
    return native.binary("room_render", _build_harness)


def _build_harness() -> Path:
    exe = RENDER_DIR / "build" / ("room_render.exe" if os.name == "nt" else "room_render")
    srcs = [RENDER_DIR / "room_render.c", RENDER_DIR / "stubs.c", RENDER_DIR / "zelda3" / "src" / "dungeon.c"]
    newest = max(p.stat().st_mtime for p in srcs + list((RENDER_DIR / "zelda3").rglob("*.h")))
    if exe.exists() and exe.stat().st_mtime >= newest:
        return exe
    cc = _compiler()
    if not cc:
        raise RuntimeError("compilateur C introuvable (gcc/cc/clang) : nécessaire pour dessiner les salles")
    exe.parent.mkdir(parents=True, exist_ok=True)
    cmd = [cc, "-O1", "-w", "-fno-strict-aliasing", "-iquote", str(RENDER_DIR / "zelda3" / "src"),
           "-iquote", str(RENDER_DIR / "zelda3"), *map(str, srcs), "-o", str(exe)]
    subprocess.run(cmd, check=True)
    return exe


def run_harness(rom: Rom, first: int = 0, count: int = U.NUM_ROOMS, custom: dict | None = None) -> list[dict]:
    """Draw rooms with the original code. Per room: state (8 KiB of WRAM $7E0000),
    bg2 / bg1 (4096 words each), attr (8192 bytes: BG2 then BG1)."""
    exe = harness_binary()
    with tempfile.TemporaryDirectory() as tmp:
        assets, out = Path(tmp) / "assets.bin", Path(tmp) / "out.bin"
        assets.write_bytes(U.asset_pack(rom, custom))
        r = native.run(exe, [assets, out, first, count], inputs=[assets], outputs=[out],
                       capture=bool(custom))
        if r.returncode != 0:
            raise subprocess.CalledProcessError(r.returncode, str(exe), r.stdout, r.stderr)
        raw = out.read_bytes()
    rooms = []
    for i in range(count):
        rec = raw[i * RECORD:(i + 1) * RECORD]
        rooms.append({
            "state": rec[:0x2000],
            "bg2": np.frombuffer(rec[0x2000:0x4000], "<u2").astype(np.int64),
            "bg1": np.frombuffer(rec[0x4000:0x6000], "<u2").astype(np.int64),
            "attr": np.frombuffer(rec[0x6000:0x8000], np.uint8).astype(np.int64),
            "failed": rec[0x1FFE:0x2000] == b"\xad\xde",
        })
    return rooms


def _w(state: bytes, addr: int) -> int:
    return state[addr] | state[addr + 1] << 8


def room_doors(state: bytes) -> list[dict]:
    """Doors drawn in the room: door_type_and_slot ($1980), dung_door_tilemap_address ($19A0),
    dung_door_direction ($19C0). x, y = 8x8 cell of the door's top-left tilemap position."""
    doors = []
    for i in range(16):
        ts = _w(state, 0x1980 + i * 2)
        addr = _w(state, 0x19A0 + i * 2)
        if not addr and not ts:
            continue
        kind = ts & 0xFF
        pos = (addr & 0x1FFF) >> 1
        doors.append({"dir": DIRS[_w(state, 0x19C0 + i * 2) & 3], "x": pos % 64, "y": pos // 64,
                      "kind": DOOR_KINDS.get(kind, f"type_{kind:02x}"), "type": kind,
                      "lower": bool(addr & 0x2000)})
    return doors


# ------------------------------------------------------------------ graphics

def anim_tiles(rom: Rom, main: int) -> np.ndarray:
    """First frame of the animated tiles (VRAM tiles 0x1B0-0x1CF), DecompressAnimatedDungeonTiles."""
    a = R.tiles_to_array(R.bg_sheet_cached(rom, DUNG_ANIMATED_SHEETS[min(main, 23)]).tiles[:16])
    b = R.tiles_to_array(R.bg_sheet_cached(rom, ANIM_SHEET_B).tiles[:16])
    return np.concatenate([a, b])


def tile_bank(rom: Rom, main: int, aux: int) -> np.ndarray:
    bank = R.bg_tile_bank(rom, main, aux).copy()
    bank[0x1B0:0x1D0] = anim_tiles(rom, main)
    return bank


def gfx_signature(rom: Rom, main: int, aux: int) -> tuple:
    mt, at = gfx.main_tileset(rom, main), gfx.aux_tileset(rom, aux)
    return (mt[0], mt[1], mt[2], at[0] or mt[3], at[1] or mt[4], at[2] or mt[5], at[3] or mt[6], mt[7],
            DUNG_ANIMATED_SHEETS[min(main, 23)])


def dungeon_cgram(rom: Rom, bg_palette: int) -> list[int]:
    """128 colours: HUD rows 0-1, dungeon palette rows 2-7 cols 1-15 (Palette_Load_DungeonSet)."""
    cg = [0] * 128
    cg[0:32] = pal.group(rom, "hud")[0]
    d = pal.group(rom, "dungeon")[bg_palette]
    for r in range(6):
        cg[(2 + r) * 16 + 1:(2 + r) * 16 + 16] = d[r * 15:(r + 1) * 15]
    for r in range(8):
        cg[r * 16] = 0
    return cg


def atlas_pixels(bank: np.ndarray, cgram: list[int]):
    """512x512 RGBA atlas: cell palette*512 + tile, 64 cells per line, colour 0 transparent."""
    rgb = R.cgram_rgb(cgram)
    idx = np.zeros((4096, 8, 8), np.int64)
    for p in range(8):
        idx[p * 512:(p + 1) * 512] = np.where(bank != 0, bank + p * 16, 0)
    idx[0] = 0  # word 0 (HUD palette, tile 0: never used by rooms) = empty cell
    grid = idx.reshape(64, 64, 8, 8).transpose(0, 2, 1, 3).reshape(512, 512)
    return R.colorize(grid, rgb)


# ------------------------------------------------------------------ layer merge

def merge_layers(bg2: np.ndarray, bg1: np.ndarray, mode: int, empty: np.ndarray, opaque: np.ndarray):
    """Collapse the two SNES layers into our bg (under sprites) / fg (over sprites).

    With every header BG mode except 0 and 3, the game puts BG1 on the sub screen (TS=BG1):
    it only shows where BG2 is transparent and is always under sprites. Mode 0 hides BG1.
    Mode 3 ("on top") puts BG1 on the main screen with normal priorities.
    `empty[tile]` / `opaque[tile]`: tile fully transparent / without any transparent pixel.
    Returns bg, fg, number of cells where a partially transparent tile hides another one."""
    e2, e1 = empty[bg2 & 0x1FF], empty[bg1 & 0x1FF]
    p2, p1 = (bg2 & 0x2000) != 0, (bg1 & 0x2000) != 0
    bg = np.zeros_like(bg2)
    fg = np.zeros_like(bg2)
    lossy = 0
    if mode == 0:
        bg = np.where(~e2 & ~p2, bg2, 0)
        fg = np.where(~e2 & p2, bg2, 0)
        return bg, fg, 0
    if mode == 3:
        lower = [(bg2, ~e2 & ~p2), (bg1, ~e1 & ~p1)]
        upper = [(bg2, ~e2 & p2), (bg1, ~e1 & p1)]
    else:
        lower = [(bg1, ~e1), (bg2, ~e2 & ~p2)]
        upper = [(bg2, ~e2 & p2)]
    for words, mask in lower:
        lossy += int(np.count_nonzero(mask & (bg != 0) & ~opaque[words & 0x1FF]))
        bg = np.where(mask, words, bg)
    for words, mask in upper:
        lossy += int(np.count_nonzero(mask & (fg != 0) & ~opaque[words & 0x1FF]))
        fg = np.where(mask, words, fg)
    return bg, fg, lossy


def empty_tiles(bank: np.ndarray) -> np.ndarray:
    return ~bank.reshape(512, -1).any(axis=1)


def opaque_tiles(bank: np.ndarray) -> np.ndarray:
    return bank.reshape(512, -1).all(axis=1)
