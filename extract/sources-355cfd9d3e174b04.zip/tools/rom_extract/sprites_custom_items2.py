"""Custom drawers of the second "items" batch: boomerang, received-item icons, dungeon
objects (torches, switches, pegs, blocks, rollers, locked doors).

As in sprites_custom_items: every tile, palette and timing comes from the JP 1.0 ROM (the
game's own code run on sprites_cpu.Cpu, or tables / tilemap words read from the ROM at the
jpdasm addresses quoted in comments).
"""
from __future__ import annotations

from typing import Callable

import sprites_common as sc
from sprites_cpu import Cpu
import sprites_custom_items as C
from rom import A, Rom

WRITE_ITEM_GFX = A(0x00D52D)           # WriteTo4BPPBuffer_item_gfx (RTL): A = item graphics index
ITEM_GFX_INDEX = A(0x0983FE)           # AncillaAdd_ItemReceipt.item_gfx_index (1 byte per receipt id)


def item_icon(receipt_id: int, world: str = "lw", pal_: int = 1, gset: int = 1,
              sword: int = 1, shield: int = 1, mail: int = 0) -> Callable:
    """The item Link holds up when he receives `receipt_id` (ancilla $22 ItemReceipt): the
    game's item graphics loader fills the animated sprite tile, then the ancilla's draw
    routine places it. sword / shield / mail = the palettes loaded at that moment. Key "idle"."""

    def custom(rom: Rom):
        h = C.Harness(rom, world)
        c = h.cpu
        C.load_item_gfx(c)
        g = rom.byte(ITEM_GFX_INDEX + receipt_id)
        c.p, c.s, c.d, c.dbr, c.a = 0x30, 0x1FF, 0, 0, 0 if g == 0xFF else g
        c.call(WRITE_ITEM_GFX, long=True)
        h.ancilla(0x22, item=receipt_id, numspr=4)
        c.w8(C.SUBMODULE, 1)                 # draw only (item held above Link's head)
        objs = h.run(C.ANCILLA_MAIN, 0)
        vram = C.sprite_vram(rom, world, gset)
        C.stream_tiles(vram, c.wram)
        cg = sc.sprite_cgram(rom, world, pal_, sword=sword, shield=shield, mail=mail)
        return vram, cg, {"idle": objs}

    return custom


# ------------------------------------------------------------------ dungeon background objects

OBJ_DATA_PTRS = {1: A(0x018000), 2: A(0x0183F0), 3: A(0x0184F0)}   # RoomDraw data offsets of objects
#   $000-$0F7 (subtype 1), $100-$13F (subtype 2), $200-$27F (subtype 3), bank 01
ANIMATED_TILE_SHEETS = A(0x02802E)     # AnimatedTileSheets: BG sheet of the animated tiles per main theme
DECOMP_ANIM_UW_TILES = A(0x00D377)     # DecompressAnimatedUnderworldTiles (RTL): Y = sheet
ANIM_TILES_BUF = 0xA680             # 3 frames x $400 bytes (BG tiles $1B0-$1CF), cycled every 9 frames
PEG_GFX_BUF = 0xB340                # 4 peg images x $80 bytes (4 tiles), LoadItemGFX_Auxiliary
PEG_TILE = 0x1D0                    # NMI_UpdatePegTiles: VRAM $3D00 = BG tiles $1D0-$1D3 (blue) / $1D4-$1D7 (orange)
DOOR_GFX = {"up": A(0x00CD9E), "down": A(0x00CE06), "left": A(0x00CE66), "right": A(0x00CEC6)}   # DoorGFXDataOffset_*
DOOR_TYPE = {"key": 0x1C, "big_key": 0x1E}


def obj_data(rom: Rom, obj: int) -> int:
    """RoomDrawObjectData offset of a room object id ($000-$0F7, $100-$13F, $200-$27F)."""
    if obj < 0x100:
        return rom.word(OBJ_DATA_PTRS[1] + 2 * obj)
    if obj < 0x200:
        return rom.word(OBJ_DATA_PTRS[2] + 2 * (obj - 0x100))
    return rom.word(OBJ_DATA_PTRS[3] + 2 * (obj - 0x200))


def operand(rom: Rom, addr: int) -> int:
    """16-bit operand of the instruction at addr (e.g. LDX.w #RoomDrawObjectData.objXXXX)."""
    return rom.word(addr + 1)


def door_data(rom: Rom, side: str, kind: str) -> int:
    return rom.word(DOOR_GFX[side] + DOOR_TYPE[kind])


def dungeon_banks(rom: Rom, main: int, blockset: int):
    """(bank per animation frame 0-2, peg images 0-3): the BG tiles of a room with the
    animated tiles and peg tiles the game uploads, decoded by running the ROM loaders."""
    import underworld_build as B
    c = Cpu(rom)
    C.load_item_gfx(c)
    c.p, c.s, c.d, c.dbr, c.y = 0x30, 0x1FF, 0, 0, rom.byte(ANIMATED_TILE_SHEETS + main)
    c.call(DECOMP_ANIM_UW_TILES, long=True)
    base = B.tile_bank(rom, main, blockset)
    banks = []
    for f in range(3):
        b = base.copy()
        b[0x1B0:0x1D0] = C._chars4(bytes(c.wram[ANIM_TILES_BUF + 0x400 * f:ANIM_TILES_BUF + 0x400 * (f + 1)]))
        banks.append(b)
    pegs = [C._chars4(bytes(c.wram[PEG_GFX_BUF + 0x80 * i:PEG_GFX_BUF + 0x80 * (i + 1)])) for i in range(4)]
    return banks, pegs


def dungeon_objects(room: int, main: int, parts: dict) -> Callable:
    """Custom drawer: dungeon background objects of `room` (tiles + palette of that room).
    parts: key -> (data_fn(rom) -> RoomDrawObjectData offset, cols, rows, opts) with opts
    {"frame": animated tile frame 0-2, "pegs": (blue image, orange image)}; words are laid
    out column-major (RoomDraw_Rightwards2x2 / 1x3_rightwards / door drawers)."""

    def custom(rom: Rom):
        import underworld_build as B
        import underworld_rom as U
        h = U.decode_header(U.room_header(rom, room))
        banks, pegs = dungeon_banks(rom, main, h["blockset"])
        cg = C.R.cgram_rgb(B.dungeon_cgram(rom, U.palette_set(rom, h["palette"])[0] >> 1))
        vram = sc.Vram()
        out = {}
        n = 0
        for key, (fn, cols, rows, opts) in parts.items():
            bank = banks[opts.get("frame", 0)].copy()
            if "pegs" in opts:
                blue, orange = opts["pegs"]
                bank[PEG_TILE:PEG_TILE + 4] = pegs[blue]
                bank[PEG_TILE + 4:PEG_TILE + 8] = pegs[orange]
            words = rom.words(C.ROOM_DRAW_OBJECT_DATA + fn(rom), cols * rows)
            v, objs = C.bake(bank, C.words_objs(words, cols, rows, "col"), False)
            vram.chars[n:n + len(objs)] = v.chars[:len(objs)]
            out[key] = [sc.Obj(b.x, b.y, b.char + n, b.pal) for b in objs]
            n += len(objs)
        return vram, cg, out

    return custom
