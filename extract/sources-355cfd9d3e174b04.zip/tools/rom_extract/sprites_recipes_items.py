"""Sprite recipes of the "items" group: pickups, scenery objects and effects.

Pickups are ROM sprites ($D8-$EB) drawn by their own code; the tiles the NMI streams from
WRAM (rupee glint, big key / heart container) are rebuilt by running the ROM's loader.
Effects run the game's ancilla / garnish / sprite-module code frame by frame; durations
are the frame counts observed in those simulations. Scenery (chests, pots, bushes, rocks,
signs) is drawn from the background tiles with the tilemap words the game uses.
See sprites_custom_items.py.
"""
from sprites_recipe import Recipe as R, Anim, D_UDLR
import sprites_custom_items as C

LW, LW_PAL, LW_SET = "lw", 1, 1          # light world, palette set 1 (every area before Zelda's rescue)
UW_ROOM, UW_MAIN, UW_PAL = 0x32, 1, 1    # Hyrule Castle room $32 (tile theme 1, palette set 1)

SHADOW = lambda o: o.char in (0x6C, 0x38) and o.pal == 4
EXPLOSION = [(159, 6), (165, 4), (169, 4), (173, 4), (177, 4), (181, 4), (185, 6), (191, 6), (197, 6), (203, 6)]
FUSE = [(0, 128)] + [(f, 2) for f in range(128, 158, 2)] + [(158, 1)]
DEBRIS = [(0, 3), (3, 4), (7, 4), (11, 4), (15, 4), (19, 4), (23, 4), (27, 3)]
RUPEE = C.keys_anim(["r0", "r1", "r2", "r0", "r1", "r2"], [14, 4, 6, 16, 6, 8])   # RupeeTile.step


def pickup(id_, type_, desc, world=LW, pal=LW_PAL, gset=LW_SET, **st):
    """A pickup sprite drawn in its resting state (E = 0: not hidden under a bush)."""
    return R(id_, None, set=gset, pal=pal, world=world, tags=["item"], desc=desc,
             anims={"idle": C.keys_anim(["idle"], 8)},
             custom=C.sprite_states(type_, world, pal, gset, {"idle": dict(E=0, **st)}))


def bomb_ancilla(h):
    h.ancilla(7, item=0, arr3=0xA0, numspr=8)    # a bomb Link just put down (fuse $A0 frames)


def smash(id_, what, world, pal, desc):
    return R(id_, None, set=LW_SET, pal=pal, world=world, tags=["fx"], desc=desc,
             anims={"idle": C.sim_anim(DEBRIS)}, custom=C.smash_sim(what, world, pal, LW_SET, 31))


def lifted(id_, what, world, pal, desc):
    return R(id_, None, set=LW_SET, pal=pal, world=world, tags=["item"], desc=desc,
             anims={"idle": C.keys_anim(["idle"], 8)},
             custom=C.sprite_states(0xEC, world, pal, LW_SET, {"idle": {"C": what}}))


def scenery(id_, attr, desc, big=False):
    return R(id_, None, world=LW, tags=["item"], desc=desc, shadow=False,
             anims={"idle": C.keys_anim(["idle"], 8)}, custom=C.ow_scenery(attr, big))


RECIPES = [
    # ------------------------------------------------------------------ pickups
    pickup("heart", 0xD8, "Petit cœur (recharge 1 cœur)"),
    R("rupee_green", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"], desc="Rubis vert (1)",
      anims={"idle": RUPEE}, custom=C.rupee(0xD9)),
    R("rupee_blue", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"], desc="Rubis bleu (5)",
      anims={"idle": RUPEE}, custom=C.rupee(0xDA)),
    R("rupee_red", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"], desc="Rubis rouge (20)",
      anims={"idle": RUPEE}, custom=C.rupee(0xDB)),
    pickup("bomb_refill", 0xDC, "Bombe à ramasser (1)"),
    pickup("bomb_refill_4", 0xDD, "Bombes à ramasser (4)"),
    pickup("bomb_refill_8", 0xDE, "Bombes à ramasser (8)"),
    pickup("magic_jar_small", 0xDF, "Petite fiole de magie"),
    pickup("magic_jar_big", 0xE0, "Grande fiole de magie"),
    pickup("arrow_refill", 0xE1, "Flèches à ramasser (5)"),
    pickup("arrow_refill_10", 0xE2, "Flèches à ramasser (10)"),
    R("fairy", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"], desc="Fée (vol, ailes battantes)",
      anims={"idle": C.keys_anim(["g0", "g1"], 8)},     # graphics = frame_counter >> 3 & 1
      custom=C.sprite_states(0xE3, LW, LW_PAL, LW_SET, {"g0": dict(E=0, g=0), "g1": dict(E=0, g=1)})),
    pickup("key", 0xE4, "Petite clé", world="uw", pal=UW_PAL),
    pickup("big_key", 0xE5, "Grande clé", world="uw", pal=UW_PAL),
    pickup("heart_container", 0xEA, "Réceptacle de cœur", world="uw", pal=UW_PAL),
    pickup("heart_piece", 0xEB, "Quart de cœur"),
    R("shadow", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"],
      desc="Ombre au sol (idle = grande, special_small = petite)",
      anims={"idle": C.keys_anim(["big"], 8), "special_small": C.keys_anim(["small"], 8)},
      custom=C.merge(C.sprite_states(0xE3, LW, LW_PAL, LW_SET, {"big": dict(E=0)}, keep=SHADOW),
                     C.sprite_states(0xE4, LW, LW_PAL, LW_SET, {"small": dict(E=0)}, keep=SHADOW))),
    R("bomb", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"], foot=(-8, -8),
      desc="Bombe posée par Link (idle ; special_fuse = mèche puis clignotement ; special_explode)",
      anims={"idle": C.sim_anim([(0, 1)], loop=True), "special_fuse": C.sim_anim(FUSE),
             "special_explode": C.sim_anim(EXPLOSION)},
      custom=C.harness_sim(LW, LW_PAL, LW_SET, 210, bomb_ancilla, C.ANCILLA_MAIN)),
    R("arrow", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"], desc="Flèche tirée par Link",
      anims={f"{a}_{d}": C.keys_anim([d], 8) for a in ("idle", "fly") for d in D_UDLR},
      custom=C.harness_states(LW, LW_PAL, LW_SET, {
          d: (lambda h, v=v: h.ancilla(9, dir=v, numspr=4, item=0xFF)) for d, v in D_UDLR.items()},
          C.ANCILLA_MAIN, submodule=1)),

    # ------------------------------------------------------------------ scenery
    R("chest", None, world="uw", tags=["item"], desc="Coffre (idle fermé, special_open ouvert)", shadow=False,
      anims={"idle": C.keys_anim(["closed"], 8), "special_open": C.keys_anim(["open"], 8, loop=False)},
      custom=C.uw_scenery(UW_ROOM, UW_MAIN, {"closed": (0x219, 2, 2), "open": (0x21A, 2, 2)})),
    R("chest_big", None, world="uw", tags=["item"], desc="Grand coffre (idle fermé, special_open ouvert)",
      shadow=False,
      anims={"idle": C.keys_anim(["closed"], 8), "special_open": C.keys_anim(["open"], 8, loop=False)},
      custom=C.uw_scenery(UW_ROOM, UW_MAIN, {"closed": (0x231, 4, 3), "open": (0x232, 4, 3)})),
    R("pot", None, world="uw", tags=["item"], desc="Pot (donjon, tuile de décor avec son carreau de sol)", shadow=False,
      anims={"idle": C.keys_anim(["pot"], 8)},
      custom=C.uw_scenery(UW_ROOM, UW_MAIN, {"pot": (0x22F, 2, 2)})),
    scenery("bush", 0x50, "Buisson"),
    scenery("bush_alt", 0x51, "Buisson d'une autre couleur"),
    scenery("rock", 0x52, "Pierre claire (soulevable)"),
    scenery("rock_heavy", 0x53, "Pierre lourde (gants requis)"),
    scenery("sign", 0x54, "Panneau"),
    scenery("rock_big", 0x55, "Gros rocher clair (32x32)", big=True),
    scenery("rock_big_heavy", 0x56, "Gros rocher lourd (32x32)", big=True),
    lifted("bush_lifted", 2, LW, LW_PAL, "Buisson soulevé / lancé"),
    lifted("rock_lifted", 1, LW, LW_PAL, "Pierre soulevée / lancée"),
    lifted("rock_heavy_lifted", 5, LW, LW_PAL, "Pierre lourde soulevée / lancée"),
    lifted("sign_lifted", 0, LW, LW_PAL, "Panneau arraché / lancé"),
    lifted("pot_lifted", 2, "uw", UW_PAL, "Pot soulevé / lancé"),

    # ------------------------------------------------------------------ effects
    R("fx_enemy_death", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["fx"],
      desc="Disparition d'un ennemi vaincu (SpriteModule_Die)",
      anims={"idle": C.sim_anim([(0, 5), (5, 5), (10, 5), (15, 6), (21, 10), (31, 6), (37, 3)])},
      custom=C.sprite_sim(0x08, LW, LW_PAL, LW_SET, 40, {"state": 6, "delay": 31}, without_body=True,
                          rel_flags2=4)),
    R("fx_poof", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["fx"],
      desc="Nuage « pouf » (SpriteModule_Poof)",
      anims={"idle": C.sim_anim([(0, 8), (8, 8), (16, 8), (24, 7)])},
      custom=C.sprite_sim(0x08, LW, LW_PAL, LW_SET, 31, {"state": 2, "delay": 32}, without_body=True)),
    R("fx_explosion", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["fx"], foot=(-8, -8),
      desc="Explosion de bombe", anims={"idle": C.sim_anim(EXPLOSION)},
      custom=C.harness_sim(LW, LW_PAL, LW_SET, 210, bomb_ancilla, C.ANCILLA_MAIN)),
    R("fx_sword_tink", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["fx"], foot=(-4, -4),
      desc="Étincelle d'épée repoussée (armure, objet dur)",
      anims={"idle": C.sim_anim([(0, 5), (5, 2), (7, 2), (9, 1)])},
      custom=C.harness_sim(LW, LW_PAL, LW_SET, 10, lambda h: [
          h.cpu.w8(0x0FAC, 5), h.cpu.w8(0x0FAD, C.ORIGIN & 0xFF), h.cpu.w8(0x0FAE, C.ORIGIN & 0xFF),
          h.cpu.w8(0x0FAF, 1)], C.ANCILLA_MAIN)),
    R("fx_sword_wall_hit", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["fx"], foot=(-8, -8),
      desc="Étincelle de l'épée contre un mur",
      anims={"idle": C.sim_anim([(0, 1), (1, 2), (3, 2), (5, 2), (7, 2), (9, 2), (11, 2), (13, 2)])},
      custom=C.harness_sim(LW, LW_PAL, LW_SET, 15, lambda h: h.ancilla(0x1B, item=0, aux_timer=1, numspr=4),
                           C.ANCILLA_MAIN)),
    R("fx_splash", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["fx"],
      desc="Éclaboussure (objet tombé dans l'eau)",
      anims={"idle": C.sim_anim([(0, 5), (5, 6), (11, 6), (17, 6), (23, 6)])},
      custom=C.harness_sim(LW, LW_PAL, LW_SET, 29, lambda h: h.ancilla(0x3D, item=0, timer=6, numspr=8),
                           C.ANCILLA_MAIN)),
    R("fx_sparkle", None, set=LW_SET, pal=LW_PAL, world=LW, tags=["fx"], desc="Petite étincelle", foot=(-4, -20),
      anims={"idle": C.sim_anim([(0, 3), (3, 4), (7, 4), (11, 3)])},
      custom=C.harness_sim(LW, LW_PAL, LW_SET, 14, lambda h: h.garnish(0x12, countdown=15), C.GARNISH_UPPER)),
    smash("fx_grass_cut", 2, LW, LW_PAL, "Buisson coupé : feuilles qui volent"),
    smash("fx_rock_shatter", 1, LW, LW_PAL, "Pierre qui se brise"),
    smash("fx_pot_shatter", 2, "uw", UW_PAL, "Pot qui se brise"),
    smash("fx_sign_shatter", 0, LW, LW_PAL, "Panneau qui se brise"),
]
