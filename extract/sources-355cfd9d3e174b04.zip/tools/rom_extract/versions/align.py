"""Piecewise alignment of two versions of the ROM (reference JP 1.0 -> another version).

Anchors are K-byte windows of the reference that occur exactly once in both ROMs. Between
anchors, a reference offset is mapped with the delta of its surrounding anchors. Used offline
by make_profile.py; the profiles it writes hold only addresses, never ROM bytes.
"""
from __future__ import annotations

import bisect

K = 12


def _unique_windows(data: bytes, k: int) -> dict[bytes, int]:
    seen: dict[bytes, int] = {}
    dup: set[bytes] = set()
    for o in range(0, len(data) - k + 1):
        w = data[o:o + k]
        if w in seen:
            dup.add(w)
        else:
            seen[w] = o
    for w in dup:
        del seen[w]
    return seen


def _boring(w: bytes) -> bool:
    return len(set(w)) < 4  # fills / padding: not a reliable anchor


def anchors(ref: bytes, tgt: bytes, k: int = K) -> list[tuple[int, int]]:
    """Sorted (ref_offset, tgt_offset) pairs of k-byte windows unique in both. Blocks may have
    moved (another bank): order is not required, but a pair is kept only when a neighbour
    pair (within 64 bytes) has the same delta (drops coincidental matches)."""
    r = _unique_windows(ref, k)
    t = _unique_windows(tgt, k)
    pairs = sorted((o, t[w]) for w, o in r.items() if w in t and (k < K or not _boring(w)))
    keep = []
    for i, (o, to) in enumerate(pairs):
        d = to - o
        ok = False
        for j in (i - 1, i + 1, i - 2, i + 2):
            if 0 <= j < len(pairs) and abs(pairs[j][0] - o) <= 64 and pairs[j][1] - pairs[j][0] == d:
                ok = True
                break
        if ok:
            keep.append((o, to))
    return keep


def k_local(n: int) -> int:
    """Window size for a changed region of n bytes (0: too small to align)."""
    return 6 if n > 4096 else 4 if n >= 8 else 0


class Aligner:
    def __init__(self, ref: bytes, tgt: bytes, k: int = K):
        self.ref, self.tgt = ref, tgt
        self.pairs = anchors(ref, tgt, k)
        self.keys = [p[0] for p in self.pairs]

    def map(self, o: int) -> tuple[int, str]:
        """Target offset of reference offset o, and a confidence note:
        'exact' (o inside an anchor run with the same delta on both sides), 'near' (the
        closest anchor's delta), '' (no anchor)."""
        i = bisect.bisect_right(self.keys, o) - 1
        before = self.pairs[i] if i >= 0 else None
        after = self.pairs[i + 1] if i + 1 < len(self.pairs) else None
        if before and after and before[1] - before[0] == after[1] - after[0]:
            return o + before[1] - before[0], "exact"
        if before and after:
            # the shift happens somewhere between the two anchors: extend each one over the
            # bytes that still match with its own delta
            db, da = before[1] - before[0], after[1] - after[0]
            e = before[0]
            while e < after[0] and 0 <= e + db < len(self.tgt) and self.ref[e] == self.tgt[e + db]:
                e += 1
            if o < e:
                return o + db, "exact"
            b = after[0]
            while b > before[0] and 0 <= b - 1 + da < len(self.tgt) and self.ref[b - 1] == self.tgt[b - 1 + da]:
                b -= 1
            if o >= b:
                return o + da, "exact"
            # changed region (e.g. code whose operands moved): align it again with short
            # windows unique inside the region
            rs, rt = e, e + db
            te = b + da
            if 0 < te - rt < 0x10000 and b - e > 0 and k_local(b - e):
                sub = Aligner(self.ref[e:b], self.tgt[rt:te], k_local(b - e))
                if sub.pairs:
                    t, note = sub.map(o - e)
                    if note == "exact":
                        return rt + t, "exact"
            return o + (db if o - e < b - o else da), "changed"
        p = before or after
        if p is None:
            return o, ""
        return o + p[1] - p[0], "near"


def find_block(ref: bytes, tgt: bytes, o: int, n: int) -> int | None:
    """Target offset of the n reference bytes at o when they occur exactly once there."""
    w = ref[o:o + n]
    i = tgt.find(w)
    if i < 0 or tgt.find(w, i + 1) >= 0:
        return None
    return i
