#!/usr/bin/env python3
"""Make the profile of another version of the game from the reference ROM (JP 1.0).

    python3 tools/rom_extract/versions/make_profile.py <other rom (.sfc/.smc/.zip)> <id> "<name>"
        [--ref <JP 1.0 rom>]

Writes tools/rom_extract/versions/<id>.json: for every reference address the extractor uses
(A(0x......) in tools/rom_extract), where it lives in that version, plus the numbering of its
overworld blocks (map16). A profile holds only addresses and numbers, never ROM bytes.

Each address is found, in this order:
  1. the 32 bytes at that address occur exactly once in the other ROM (identical data);
  2. alignment of the two ROMs (align.py): the address sits between anchors with one delta;
  3. pointer table: its pointers, each moved like the data they point to, occur once there.
"""
from __future__ import annotations

import argparse
import difflib
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXTRACT = HERE.parent
ROOT = EXTRACT.parents[1]
sys.path.insert(0, str(EXTRACT))
sys.path.insert(0, str(HERE))

import rom as R  # noqa: E402
from align import Aligner, find_block  # noqa: E402


def used_addresses() -> list[int]:
    out = set()
    for f in list(EXTRACT.glob("*.py")) + list((EXTRACT / "steps").glob("*.py")):
        for m in re.finditer(r"\bA\(0x([0-9A-Fa-f]{6})\)", f.read_text()):
            out.add(int(m.group(1), 16))
    return sorted(out)


def pc(a: int) -> int:
    return ((a >> 16) & 0x7F) * 0x8000 + (a & 0x7FFF)


def snes(o: int) -> int:
    return (o // 0x8000) << 16 | 0x8000 | (o % 0x8000)


def pointer_table(ref: bytes, tgt: bytes, al: Aligner, o: int) -> int | None:
    """Target offset of a table of 3-byte pointers at reference offset o."""
    for n in (16, 12, 8, 6, 4):
        want = bytearray()
        for i in range(n):
            p = ref[o + i * 3] | ref[o + i * 3 + 1] << 8 | ref[o + i * 3 + 2] << 16
            if not p & 0x8000 or (p >> 16) >= 0x7E:
                return None
            t, note = al.map(pc(p))
            if note != "exact":
                break
            q = snes(t)
            want += bytes((q & 0xFF, q >> 8 & 0xFF, q >> 16))
        else:
            i = tgt.find(bytes(want))
            if i >= 0 and tgt.find(bytes(want), i + 1) < 0:
                return i
    return None


LONG_OPS = {0xAF, 0xBF, 0x22, 0x5C, 0x8F, 0x9F, 0xCF, 0xDF, 0x0F, 0x1F, 0x2F, 0x3F, 0x4F, 0x5F,
            0x6F, 0x7F, 0xEF, 0xFF}
ABS_OPS = {0xAD, 0xBD, 0xB9, 0x8D, 0x9D, 0x99, 0xAC, 0xBC, 0xAE, 0xBE, 0xCD, 0xDD, 0xD9, 0x6D,
           0x7D, 0x79, 0x0D, 0x1D, 0x19, 0x2D, 0x3D, 0x39, 0x4D, 0x5D, 0x59, 0xED, 0xFD, 0xF9}


def code_references(ref: bytes, tgt: bytes, al: Aligner, a: int, span: int = 0x1000) -> int | None:
    """Data rewritten in place (e.g. the European palettes): the code that reads the nearest
    referenced address around a (long operand, or 16-bit operand in code of a's bank) gives
    the delta, when that code aligns exactly."""
    bank = a >> 16
    from collections import Counter
    votes: Counter = Counter()
    for n, ops in ((3, LONG_OPS), (2, ABS_OPS)):
        for x_off in range(0, len(ref) - 4):
            op = ref[x_off]
            if op not in ops:
                continue
            if n == 2 and x_off // 0x8000 != bank:
                continue
            v = ref[x_off + 1] | ref[x_off + 2] << 8 | ((ref[x_off + 3] << 16) if n == 3 else (bank << 16))
            if abs(v - a) > span or v >> 16 != bank or not v & 0x8000:
                continue
            t, note = al.map(x_off)
            if note != "exact" or tgt[t] != op:
                continue
            w = tgt[t + 1] | tgt[t + 2] << 8 | ((tgt[t + 3] << 16) if n == 3 else (bank << 16))
            votes[pc(w) - pc(v)] += 1
    # many "instructions" are data bytes that happen to look like one: the delta most of the
    # references agree on wins
    if not votes:
        return None
    (delta, n), *rest = votes.most_common(2) + [(None, 0)]
    if n < 3 or n < 3 * rest[0][1]:
        return None
    return pc(a) + delta


def locate(ref: bytes, tgt: bytes, al: Aligner, a: int) -> tuple[int, str]:
    o = pc(a)
    t = find_block(ref, tgt, o, 32)
    if t is not None:
        return t, "bloc"
    t, note = al.map(o)
    if note == "exact":
        return t, "alignement"
    t2 = pointer_table(ref, tgt, al, o)
    if t2 is not None:
        return t2, "pointeurs"
    t3 = code_references(ref, tgt, al, a)
    if t3 is not None:
        return t3, "code"
    return t, "INCERTAIN"


def map16_numbering(ref: bytes, tgt: bytes, prof: dict, al: Aligner) -> None:
    """Count of map16 / map32 in the other version and map16 id -> reference id."""
    import overworld as ow
    start_r = pc(int.__int__(ow.MAP16_DEFS))
    start_t = pc(int(prof["addr"][f"{int.__int__(ow.MAP16_DEFS):06X}"], 16))
    # the other version's table ends where the reference's last block lands, once the two
    # tables are aligned (a version may add a few blocks, e.g. translated signs)
    rec = lambda d, s, n: [d[s + i * 8:s + i * 8 + 8] for i in range(n)]
    r = rec(ref, start_r, ow.MAP16_COUNT)
    t = rec(tgt, start_t, min(ow.MAP16_COUNT + 256, (len(tgt) - start_t) // 8))
    sm = difflib.SequenceMatcher(None, r, t, autojunk=False)
    last = [b for b in sm.get_matching_blocks() if b.size]
    if not last or last[-1].a + last[-1].size != ow.MAP16_COUNT:
        raise SystemExit("fin de la table map16 introuvable")
    count_t = last[-1].b + last[-1].size
    t = t[:count_t]
    to_ref = [-1] * count_t
    i0 = j0 = 0
    for i1, j1, size in sm.get_matching_blocks():
        # between two identical runs: blocks retouched in place are paired in order, the
        # surplus on one side is an inserted / removed block
        for k in range(min(i1 - i0, j1 - j0)):
            to_ref[j0 + k] = i0 + k
        for k in range(size):
            to_ref[j1 + k] = i1 + k
        i0, j0 = i1 + size, j1 + size
    prof["map16_count"] = count_t
    prof["map16_to_ref"] = to_ref
    q = [pc(int(prof["addr"][f"{int.__int__(x):06X}"], 16)) for x in ow.MAP32_QUARTERS]
    prof["map32_groups"] = (q[1] - q[0]) // 6
    missing = sorted(set(range(ow.MAP16_COUNT)) - set(to_ref))
    print(f"map16 : {count_t} blocs (référence {ow.MAP16_COUNT}), "
          f"{sum(1 for x in to_ref if x < 0)} sans équivalent, référence absente : {missing}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("rom", type=Path)
    ap.add_argument("id")
    ap.add_argument("name")
    ap.add_argument("--ref", type=Path)
    args = ap.parse_args()
    ref = R.Rom(args.ref or R.find_rom(ROOT))
    if ref.info["id"] != "jp10":
        raise SystemExit("la référence doit être la ROM JP 1.0")
    raw = args.rom.read_bytes()
    tgt = R.strip_header(R.rom_from_zip(raw) if raw[:4] == b"PK\x03\x04" else raw)
    info = R.identify(tgt)
    al = Aligner(ref.data, tgt)
    prof = {"id": args.id, "name": args.name, "sha1": info["sha1"], "base": "jp10",
            "header": {"title": info["title"], "region": info["region"], "revision": info["revision"]},
            "addr": {}}
    counts: dict[str, int] = {}
    bad = []
    for a in used_addresses():
        t, how = locate(ref.data, tgt, al, a)
        counts[how] = counts.get(how, 0) + 1
        prof["addr"][f"{a:06X}"] = f"{snes(t):06X}"
        if how == "INCERTAIN":
            bad.append(f"${a:06X}")
    print(f"{len(prof['addr'])} adresses : {counts}")
    if bad:
        print("incertaines :", ", ".join(bad))
    map16_numbering(ref.data, tgt, prof, al)
    out = HERE / f"{args.id}.json"
    out.write_text(json.dumps(prof, indent=1) + "\n")
    print(f"→ {out.relative_to(ROOT)}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
