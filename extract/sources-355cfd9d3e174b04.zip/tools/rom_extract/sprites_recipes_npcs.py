"""NPC recipes (tag "npc"). Sprites whose graphics are streamed each frame (follower
graphics, Link's sword / shield) use the custom drawers of sprites_custom_npcs."""
from sprites_recipe import Anim, dirs4, seq, D_RLDU, D_UDLR, DIRS
from sprites_custom_npcs import dma_recipe, follower_recipe


def R(id, type_, anims=None, **kw):
    """Plain sprite recipe, drawn through sprites_custom_npcs.FixedEngine (OAM regions)."""
    return dma_recipe(id, type_, 0, anims or {}, **kw)

NPC = ["npc"]
DW_FLAG = {0x7EF3CA: 0x40}          # savegame_is_darkworld


def face(d: str) -> dict:
    """Pokes placing Link on side `d` of the sprite (for NPCs that turn towards Link)."""
    x, y = {"right": (0x8C0, 0x880), "left": (0x840, 0x880),
            "down": (0x880, 0x8C0), "up": (0x880, 0x840)}[d]
    return {0x22: x & 0xFF, 0x23: x >> 8, 0x20: y & 0xFF, 0x21: y >> 8}


def fw(d, moving=True):
    """Follower walk: AnimateFollower alternates two poses with bit 3 of the frame counter."""
    return [{"dir": d, "moving": moving, "frame": 0}, {"dir": d, "moving": moving, "frame": 8}]


def follower(id, fi, desc, set=0, pal=0, world="lw", **kw):
    return follower_recipe(id, fi, {
        **dirs4("walk", lambda d, n: fw(d), dur=8, dmap=D_UDLR),
        **dirs4("idle", lambda d, n: [{"dir": d, "moving": False}], dmap=D_UDLR),
    }, set=set, pal=pal, world=world, tags=NPC, desc=desc, foot=(0, 8), **kw)


def two(var="g", a=0, b=1, **fixed):
    return [dict(fixed, **{var: a}), dict(fixed, **{var: b})]


def hop_z(v0=16, g=2):
    """Per-frame heights of a hop: z_vel -= g then z += z_vel / 16 until z < 0 (Sprite_MoveZ)."""
    out, z, v = [], 0, v0
    while True:
        v -= g
        z += v
        if z < 0:
            return out + [0]
        out.append(z >> 4)


def runs(frames: list) -> tuple:
    """Per-frame states -> (states, durations) merging identical consecutive states."""
    st, du = [], []
    for f in frames:
        if st and st[-1] == f:
            du[-1] += 1
        else:
            st.append(f)
            du.append(1)
    return st, du


def smithy_hammer(d):
    frames = []
    for i, (g, n) in enumerate(zip(SMITHY_G, SMITHY_DUR)):
        frames += [{"D": d, "g": g, "z_vel": 0}] * n
    z = hop_z()
    start = SMITHY_DUR[0]
    for i in range(len(frames)):
        k = i - start
        frames[i] = dict(frames[i], z=z[k] if 0 <= k < len(z) else 0)
    st, du = runs(frames)
    return Anim(st, du)


# smithy hammer cycle (Smithy_Main: graphics / delay tables, z jump on step 1)
SMITHY_G = [0, 1, 2, 3, 3, 2, 1, 0]
SMITHY_DUR = [25, 5, 2, 17, 17, 6, 11, 17]

# DW flute kid (aardvark) playing: kFluteAardvark gfx / delays from step 3
AARDVARK_G = [1, 2, 1, 2, 1, 2, 1, 2, 3, 2, 3, 2, 3, 2, 3, 2]
AARDVARK_DUR = [17, 3, 13, 7, 9, 11, 5, 15, 3, 11, 7, 7, 11, 3, 15, 3]

RECIPES = [
    # ---------------------------------------------------------------- Zelda
    follower("npc_zelda", 1, "Princesse Zelda (suiveuse)", set=4, pal=1, world="uw"),
    dma_recipe("npc_zelda_cell", 0x76, 1, {
        **dirs4("idle", lambda d, n: [{"D": d, "head": d, "g": 0}], dmap=D_UDLR),
        **dirs4("walk", lambda d, n: two(D=d, head=d), dmap=D_UDLR),
    }, set=4, pal=1, world="uw", tags=NPC, desc="Princesse Zelda (sprite, cellule / sanctuaire)"),

    R("npc_zelda_altar", 0xC1, set=18, pal=12, world="uw", tags=NPC,
      desc="Zelda endormie sur l'autel d'Agahnim (lévitation puis téléportation)",
      post={"A": 1, "oam_flags": 12, "flags2": 0}, anims={
          "idle_down": Anim([{"g": 0, "z": 0, "delay": 0}]),
          "special_levitate": Anim([{"g": 1, "z": z, "delay": 0} for z in range(23)], 16, loop=False),
          "special_warp": Anim(*runs([{"g": 1, "z": 22, "delay": d} for d in range(19, 0, -1)]), loop=False),
      }),

    # ---------------------------------------------------------------- uncle / priest
    dma_recipe("npc_uncle", 0x73, 0, {
        "idle_up": Anim([{"D": 0, "g": 0}]),
        "idle_down": Anim([{"D": 1, "g": 0}]),
        "idle_left": Anim([{"D": 2, "g": 0}]),
        "walk_up": Anim(two(D=0), 8),
        "walk_down": Anim(two(D=1), 8),
        "walk_left": Anim(two(D=2), 8),
        "special_wounded": Anim([{"D": 3, "g": 0}]),
        "special_wounded_disarmed": Anim([{"D": 3, "g": 1}]),
    }, set=13, pal=21, world="uw", weapons=True, post={"E": 0}, tags=NPC,
        desc="L'oncle de Link (épée et bouclier)"),
    R("npc_priest", 0x73, set=6, pal=29, world="uw", tags=NPC, desc="Le prêtre du sanctuaire",
      post={"E": 1, "subtype2": 2}, anims={
          **dirs4("idle", lambda d, n: [{"D": d, "g": 0}], dmap=D_UDLR),
          **dirs4("walk", lambda d, n: two(D=d), dmap=D_UDLR),
          "special_lying": Anim([{"D": 4, "g": 0}, {"D": 4, "g": 1}], 16),
      }),

    # ---------------------------------------------------------------- sages
    R("npc_sahasrahla", 0x16, set=16, pal=28, world="uw", tags=NPC, desc="Le sage Sahasrahla",
      anims={"idle_down": Anim(two(), 32)}),
    R("npc_aginah", 0x16, set=16, pal=7, world="uw", tags=NPC, desc="Le sage Aginah",
      post={"subtype2": 1, "oam_flags": 11}, anims={"idle_down": Anim(two(), 32)}),
    R("npc_mrs_sahasrahla", 0x78, set=5, pal=2, world="uw", tags=NPC,
      desc="Mme Sahasrahla (femme du sage)", anims={"idle_down": Anim(two(), 16)}),

    # ---------------------------------------------------------------- old man
    dma_recipe("npc_old_man", 0xAD, 4, {
        **dirs4("idle", lambda d, n: [{"D": d, "g": 0}], dmap=D_UDLR),
        **dirs4("walk", lambda d, n: two(D=d), dmap=D_UDLR),
    }, set=1, pal=7, world="uw", tags=NPC, desc="Le vieil homme perdu de la montagne"),
    R("npc_old_man_bed", 0xAD, set=1, pal=7, world="uw", tags=NPC, post={"subtype2": 2},
      desc="Le vieil homme couché dans son lit", anims={"idle_down": Anim([{"g": 0}])}),
    follower("npc_old_man_follower", 4, "Le vieil homme (suiveur)",
             set=1, pal=7, world="uw"),

    # ---------------------------------------------------------------- smithies
    R("npc_smithy", 0x1A, set=5, pal=30, world="uw", tags=NPC, desc="Le forgeron nain",
      anims={
          "idle_right": Anim([{"D": 0, "g": 0, "z": 0, "z_vel": 0}]),
          "idle_left": Anim([{"D": 1, "g": 0, "z": 0, "z_vel": 0}]),
          "idle_down": Anim([{"D": 0, "g": 4, "z": 0, "z_vel": 0}]),
          "special_hammer_right": smithy_hammer(0),
          "special_hammer_left": smithy_hammer(1),
      }),
    R("npc_smithy_frog", 0x1A, set=29, pal=0, world="dw", tags=NPC, post={"subtype2": 2},
      desc="Le partenaire du forgeron changé en grenouille (Monde des Ténèbres)",
      anims={"idle_down": Anim(*runs([{"z": z, "z_vel": 0} for z in hop_z()]))}),
    dma_recipe("npc_smithy_partner", 0x1A, 8, {
        **dirs4("idle", lambda d, n: [{"D": d, "g": 0}], dmap=D_UDLR),
        **dirs4("walk", lambda d, n: two(D=d), dmap=D_UDLR),
    }, set=5, pal=30, world="uw", post={"subtype2": 3}, tags=NPC,
        desc="Le partenaire du forgeron (de retour)"),
    follower("npc_smithy_partner_follower", 8, "Le partenaire du forgeron (suiveur)"),
    follower("npc_smithy_frog_follower", 7, "La grenouille (suiveuse, Monde des Ténèbres)",
             world="dw", set=17, pal=11),

    # ---------------------------------------------------------------- shops / games
    R("npc_shopkeeper", 0xBB, set=5, pal=31, world="uw", tags=NPC, post={"subtype2": 0},
      desc="Le marchand (Monde de la Lumière)", anims={"idle_down": Anim(two(), 16)}),
    R("npc_shopkeeper_dw", 0xBB, set=5, pal=31, world="uw", tags=NPC, pokes={0x0FFF: 1},
      post={"subtype2": 0}, desc="Le marchand (Monde des Ténèbres)",
      anims={"idle_down": Anim([{"g": 0, "oam_flags": 0x0D}, {"g": 0, "oam_flags": 0x4D}], 8)}),
    R("npc_chest_game_guy", 0xBB, set=15, pal=31, world="uw", tags=NPC, post={"subtype2": 1},
      desc="Le tenancier du jeu des coffres",
      anims={"idle_down": Anim([{"g": 1, "oam_flags": 0x0D}, {"g": 1, "oam_flags": 0x4D}], 8)}),
    R("npc_thief_friendly", 0xBB, set=42, pal=32, world="uw", tags=NPC, post={"subtype2": 2},
      desc="Voleur sympathique (cadeau / jeu des coffres)", anims={
          "idle_right": Anim([{"g": 2, "head": 0, "frame": 1}]),
          "idle_left": Anim([{"g": 2, "head": 1, "frame": 1}]),
          "idle_down": Anim([{"g": 2, "head": 2, "frame": 1}]),
      }),
    R("npc_mini_chest_game_guy", 0xBB, set=15, pal=5, world="uw", tags=NPC, post={"subtype2": 3},
      desc="Le tenancier du petit jeu des coffres",
      anims={f"idle_{d}": Anim([{"poke": face(d)}]) for d in ("down", "left", "right")}),

    # ---------------------------------------------------------------- flute kid
    R("npc_flute_kid", 0x2E, set=15, pal=1, world="lw", tags=NPC, post={"subtype2": 0},
      desc="Le gamin à la flûte (bosquet hanté)", anims={"idle_down": Anim(two(D=0), 32)}),
    R("npc_flute_kid_dw", 0x2E, set=17, pal=11, world="dw", tags=NPC, post={"subtype2": 1},
      pokes=DW_FLAG, desc="Le gamin à la flûte (créature du Monde des Ténèbres ; special_done = changé en arbre)", anims={
          "idle_down": Anim([{"g": 0}]),
          "special_listen": Anim(seq(g=AARDVARK_G), AARDVARK_DUR),
          "special_done": Anim([{"g": 3}]),
      }),

    # ---------------------------------------------------------------- Kiki
    dma_recipe("npc_kiki", 0xB6, 10, {
        **dirs4("idle", lambda d, n: [{"D": d, "g": 0}], dmap=D_UDLR),
        **dirs4("walk", lambda d, n: two(D=d), dmap=D_UDLR),
        "special": Anim([{"D": 8, "g": 0}, {"D": 8, "g": 1}], 8),
    }, set=23, pal=13, world="dw", post={"subtype2": 3}, tags=NPC, desc="Kiki le singe"),

    # ---------------------------------------------------------------- great fairy
    R("npc_great_fairy", 0xC8, set=7, pal=7, world="uw", tags=NPC, desc="La grande fée",
      anims={"idle_down": Anim(seq(g=[0, 1, 2, 3]), 6)}),

    # ---------------------------------------------------------------- cucco
    R("npc_cucco", 0x0B, set=6, pal=1, world="lw", tags=NPC, desc="Poule (cocotte)", anims={
        "idle_left": Anim([{"g": 0, "x_vel": 0xFF}]),
        "idle_right": Anim([{"g": 0, "x_vel": 1}]),
        "walk_left": Anim([{"g": 0, "x_vel": 0xFF}, {"g": 1, "x_vel": 0xFF}], 4),
        "walk_right": Anim([{"g": 0, "x_vel": 1}, {"g": 1, "x_vel": 1}], 4),
        # Cucco_Flee / carried: panic marks (Sprite_DrawDistress_custom, drawn on frames
        # with bit 3 or 4 of the frame counter set). State 10 (carried) draws them while
        # frozen but lifts the bird by 14 px: _dy puts it back on the ground.
        **{f"special_panic_{n}": Anim(*runs([
            {"state": 10, "g": (5 * f >> 4) & 1, "x_vel": v, "frame": 8 if f & 0x18 else 0, "_dy": 14}
            for f in range(32)]))
           for n, v in (("left", 0xFF), ("right", 1))},
        **{f"special_carried_{n}": Anim(*runs([
            {"state": 10, "g": (3 * f >> 4) & 1, "x_vel": v, "frame": 8 if f & 0x18 else 0}
            for f in range(32)]))
           for n, v in (("left", 0xFF), ("right", 1))},
    }),
    R("npc_cucco_angry", 0x0B, set=6, pal=1, world="lw", tags=NPC,
      desc="Poule en colère (attaque en volant)", anims={
          "attack_left": Anim([{"C": 1, "g": g, "x_vel": 0xF0, "z": 12} for g in (0, 1)], 4),
          "attack_right": Anim([{"C": 1, "g": g, "x_vel": 0x10, "z": 12} for g in (0, 1)], 4),
      }),

    # ---------------------------------------------------------------- guards
    R("npc_castle_guard", 0x3F, set=2, pal=1, world="lw", tags=NPC,
      desc="Garde du château immobile (tutoriel)",
      anims=dirs4("idle", lambda d, n: [{"D": d}], dmap=D_RLDU)),
    # ---------------------------------------------------------------- blind maiden
    dma_recipe("npc_blind_maiden", 0xB7, 6, {
        **dirs4("idle", lambda d, n: [{"D": d, "head": d, "g": 0}], dmap=D_UDLR),
        **dirs4("walk", lambda d, n: two(D=d, head=d), dmap=D_UDLR),
    }, set=27, pal=23, world="uw", tags=NPC, desc="La jeune fille captive (fausse, Blind)"),
    follower("npc_blind_maiden_follower", 6, "La jeune fille captive (suiveuse)", set=27, pal=23, world="uw"),
]
