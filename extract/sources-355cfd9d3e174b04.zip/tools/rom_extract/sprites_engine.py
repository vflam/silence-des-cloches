"""Runs the ROM's sprite code (bank 06 HandleSingleSprite) on the 65816 interpreter to get
the OAM entries a sprite draws for a given state.

A sprite is spawned in slot 0 (state 8 -> SpriteModule_Initialize: LoadProperties +
the sprite's own SpritePrep), then drawn with the global sprite freeze flag ($0FC1) set:
every sprite routine draws itself and returns before running its AI. Its state variables
(graphics $0DC0, direction $0DE0, ...) are poked before each draw.
"""
from __future__ import annotations

import sprites_common as sc
from rom import A, Rom
from sprites_cpu import Cpu

HANDLE_SINGLE_SPRITE_LONG = A(0x0684DA)   # bank 06, PHB/PHK/PLB + JSR HandleSingleSprite + RTL
RESET_OAM_REGION_BASES = A(0x0683D3)      # bank 06, RTS

# names of the per-sprite WRAM arrays (16 slots each; see zelda3 variables.h)
VARS = {
    "y_lo": 0x0D00, "x_lo": 0x0D10, "y_hi": 0x0D20, "x_hi": 0x0D30, "y_vel": 0x0D40, "x_vel": 0x0D50,
    "ai": 0x0D80, "A": 0x0D90, "B": 0x0DA0, "C": 0x0DB0, "g": 0x0DC0, "state": 0x0DD0, "D": 0x0DE0,
    "delay": 0x0DF0, "aux1": 0x0E00, "aux2": 0x0E10, "type": 0x0E20, "subtype": 0x0E30,
    "flags2": 0x0E40, "health": 0x0E50, "flags3": 0x0E60, "subtype2": 0x0E80, "E": 0x0E90,
    "F": 0x0EA0, "head": 0x0EB0, "clock": 0x0EC0, "G": 0x0ED0, "aux3": 0x0EE0, "hit": 0x0EF0,
    "pause": 0x0F00, "aux4": 0x0F10, "floor": 0x0F20, "oam_flags": 0x0F50, "flags4": 0x0F60,
    "z": 0x0F70, "z_vel": 0x0F80, "prio": 0x0B89, "unk2": 0x0BB0, "N": 0x0BC0, "flags5": 0x0BE0,
    "defl": 0x0CAA, "die": 0x0CBA,
}
SCREEN = 0x80          # sprite drawn at screen (0x80, 0x80)
WORLD_BASE = 0x0800    # sprite world coordinates (0x880, 0x880)


class Engine:
    def __init__(self, rom: Rom):
        self.rom = rom
        self.cpu = None

    def spawn(self, type_: int, indoors: bool = False, dark: bool = False, pre: dict | None = None,
              globals_: dict | None = None, link: tuple[int, int] = (0, 0x30), prep: bool = True, before=None) -> None:
        c = self.cpu = Cpu(self.rom)
        self.slot = 0
        c.w8(0x1B, 1 if indoors else 0)
        c.w8(0x0FFF, 1 if dark else 0)
        c.w16(0x8A, 0x40 if dark else 0x00)
        c.w16(0xE2, WORLD_BASE)
        c.w16(0xE8, WORLD_BASE)
        wx = WORLD_BASE + SCREEN
        c.w16(0x22, wx + link[0])   # Link
        c.w16(0x20, wx + link[1])
        c.w8(0x2F, 0)
        c.wram[0xF360] = 0
        for a, v in (globals_ or {}).items():
            c.w8(a, v)
        if before is not None:
            before(c)
        self.set(type=type_, state=8 if prep else 9, x_lo=wx & 0xFF, x_hi=wx >> 8, y_lo=wx & 0xFF, y_hi=wx >> 8)
        if pre:
            self.set(**pre)
        if prep:
            self._run()
        else:
            self._load_properties(type_)
        self.set(state=9)

    def _load_properties(self, type_: int) -> None:
        pass

    def set(self, **kw) -> None:
        for k, v in kw.items():
            if isinstance(k, str) and k in VARS:
                self.cpu.w8(VARS[k] + self.slot, v)
            else:
                raise KeyError(k)

    def poke(self, addr: int, v: int) -> None:
        self.cpu.w8(addr, v)

    def get(self, name: str) -> int:
        return self.cpu.r8(VARS[name] + self.slot)

    def _run(self) -> None:
        c = self.cpu
        for i in range(128):
            c.wram[0x0800 + i * 4 + 1] = 0xF0
            c.wram[0x0A20 + i] = 0
        for a in range(0x0FEC, 0x0FF8):   # oam_alloc_arr1
            c.wram[a] = 0
        c.p, c.s, c.d, c.dbr = 0x30, 0x1FF, 0, RESET_OAM_REGION_BASES >> 16
        c.call(RESET_OAM_REGION_BASES)
        c.p, c.x, c.s, c.d, c.dbr = 0x30, self.slot, 0x1FF, 0, 0
        c.call(HANDLE_SINGLE_SPRITE_LONG, long=True)

    def draw(self, vars_: dict | None = None, pokes: dict | None = None, frozen: bool = True,
             frame: int = 0) -> list[sc.Obj]:
        """OAM entries drawn this frame, relative to the sprite position (x, y)."""
        c = self.cpu
        if vars_:
            self.set(**vars_)
        for a, v in (pokes or {}).items():
            c.w8(a, v)
        c.w8(0x0FC1, 1 if frozen else 0)
        c.w8(0x1A, frame & 0xFF)
        self._run()
        return self.oam()

    def oam(self) -> list[sc.Obj]:
        c = self.cpu
        sx = (c.r8(VARS["x_lo"]) | c.r8(VARS["x_hi"]) << 8) - WORLD_BASE
        sy = (c.r8(VARS["y_lo"]) | c.r8(VARS["y_hi"]) << 8) - WORLD_BASE
        out = []
        for i in range(128):
            y = c.wram[0x0800 + i * 4 + 1]
            if y == 0xF0:
                continue
            x = c.wram[0x0800 + i * 4]
            ext = c.wram[0x0A20 + i]
            if ext & 1:
                x -= 256
            if y >= 0xE0:   # objects partly above the screen top wrap around
                y -= 256
            word = c.wram[0x0800 + i * 4 + 2] | c.wram[0x0800 + i * 4 + 3] << 8
            out.append(sc.Obj.from_word(x - sx, y - sy, word, bool(ext & 2)))
        return out
