"""Access to the player's ROM of A Link to the Past / Kamigami no Triforce.

All addresses in this package are SNES LoROM addresses of the reference version, JP 1.0
(disassembly github.com/spannerisms/jpdasm, whose labels are quoted in comments), written
A(0x......). Other versions are read through a profile (versions/<id>.json, made by
versions/make_profile.py) that gives where each of those addresses lives in that version and
how its overworld blocks are numbered; the extractor output is the same for every version.
"""
import bisect
import hashlib
import json
import zipfile
from pathlib import Path

VERSIONS_DIR = Path(__file__).resolve().parent / "versions"

JP10_SHA1 = "e7e852f0159ce612e3911164878a9b08b3cb9060"


class RomError(Exception):
    pass


# Versions of the game we read, by SHA-1 of the headerless ROM: the reference, plus one
# profile per other version (versions/*.json). The cartridge header (title, region, revision)
# names versions we recognise but do not read.
VERSIONS = {
    JP10_SHA1: {"id": "jp10", "name": "Zelda no Densetsu: Kamigami no Triforce (Japon) v1.0", "supported": True},
}
for _f in sorted(VERSIONS_DIR.glob("*.json")):
    _p = json.loads(_f.read_text())
    VERSIONS[_p["sha1"]] = {"id": _p["id"], "name": _p["name"], "supported": True}


class Profile:
    """Where the reference addresses live in one version, and its overworld block numbering."""

    def __init__(self, d: dict | None = None):
        d = d or {}
        self.id = d.get("id", "jp10")
        pairs = sorted((int(k, 16), int(v, 16)) for k, v in d.get("addr", {}).items())
        self._keys = [k for k, _ in pairs]
        self._vals = [v for _, v in pairs]
        self.map16_count = d.get("map16_count", 0xE9E)
        self.map32_groups = d.get("map32_groups", 0x33C0 // 6)
        # map16 id of this version -> reference id (-1: block the reference does not have)
        self.map16_to_ref = d.get("map16_to_ref")
        self.identity = not pairs

    def at(self, a: int) -> int:
        """Address in this version of reference address a (a known constant + an offset)."""
        if self.identity:
            return a
        i = bisect.bisect_right(self._keys, a) - 1
        if i < 0:
            raise KeyError(f"adresse ${a:06X} absente du profil {self.id}")
        return self._vals[i] + (a - self._keys[i])


_profile = Profile()


def profile() -> Profile:
    return _profile


def _raw(a) -> int:
    return int.__int__(a)


class Addr(int):
    """A reference (JP 1.0) ROM address. +/- stay in reference space (TABLE + i * 2); any
    other use (as an index, bit operations, int()) gives the address in the ROM being read."""

    def at(self) -> int:
        return _profile.at(_raw(self))

    def __add__(self, o):
        return Addr(_raw(self) + int(o)) if not isinstance(o, Addr) else NotImplemented

    __radd__ = __add__

    def __sub__(self, o):
        if isinstance(o, Addr):
            return _raw(self) - _raw(o)
        return Addr(_raw(self) - int(o))

    def __index__(self):
        return self.at()

    def __int__(self):
        return self.at()

    def __and__(self, o): return self.at() & int(o)
    def __rand__(self, o): return int(o) & self.at()
    def __or__(self, o): return self.at() | int(o)
    def __ror__(self, o): return int(o) | self.at()
    def __xor__(self, o): return self.at() ^ int(o)
    def __rshift__(self, o): return self.at() >> int(o)
    def __lshift__(self, o): return self.at() << int(o)
    def __mod__(self, o): return self.at() % int(o)
    def __floordiv__(self, o): return self.at() // int(o)
    def __mul__(self, o): return self.at() * int(o)
    def __repr__(self): return f"A(0x{_raw(self):06X})"
    def __format__(self, spec): return format(self.at(), spec)
    def __hash__(self): return hash(_raw(self))
    def __eq__(self, o): return _raw(self) == (_raw(o) if isinstance(o, int) else o)
    def __lt__(self, o): return _raw(self) < int.__int__(o)
    def __le__(self, o): return _raw(self) <= int.__int__(o)
    def __gt__(self, o): return _raw(self) > int.__int__(o)
    def __ge__(self, o): return _raw(self) >= int.__int__(o)


def A(a: int) -> Addr:
    return Addr(a)
REGIONS = {0x00: "Japon", 0x01: "Amérique du Nord", 0x02: "Europe", 0x06: "France",
           0x09: "Allemagne", 0x0F: "Canada"}

_current: "Rom | None" = None
_assets = Path(__file__).resolve().parents[2] / "game" / "assets" / "rom"


def assets_dir() -> Path:
    """Folder the extraction writes to (game/assets/rom unless extract.py --out says otherwise);
    the tools that read back what was extracted (mapgen, roomgen) follow it."""
    return _assets


def set_assets_dir(path: Path) -> None:
    global _assets
    _assets = Path(path)


def current() -> "Rom | None":
    """The ROM being extracted (set by extract.py), used by mapgen / roomgen when no ROM
    file sits at the project root (e.g. in the browser)."""
    return _current


def set_current(rom: "Rom | None") -> None:
    global _current
    _current = rom


def _read_rom_bytes(path: Path) -> bytes:
    if path.suffix.lower() == ".zip":
        return rom_from_zip(path.read_bytes())
    return path.read_bytes()


def rom_from_zip(blob: bytes) -> bytes:
    import io
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        names = [n for n in z.namelist() if n.lower().endswith((".sfc", ".smc"))]
        if not names:
            raise RomError("aucune ROM .sfc/.smc dans le zip")
        return z.read(names[0])


def strip_header(data: bytes) -> bytes:
    return data[0x200:] if len(data) % 0x400 == 0x200 else data  # copier header


def identify(data: bytes) -> dict:
    """{sha1, id, name, supported, title, region, revision} for headerless ROM bytes."""
    sha1 = hashlib.sha1(data).hexdigest()
    hdr = data[0x7FC0:0x7FE0] if len(data) >= 0x8000 else b""
    title = hdr[:21].decode("ascii", "replace").strip() if hdr else ""
    region = hdr[0x19] if hdr else -1
    revision = hdr[0x1B] if hdr else -1
    known = VERSIONS.get(sha1)
    info = {"sha1": sha1, "title": title, "region": REGIONS.get(region, f"région {region}"),
            "revision": revision, "zelda": "ZELDA" in title.upper()}
    if known:
        info.update(known)
    else:
        info.update({"id": "", "name": f"{title or 'ROM inconnue'} ({info['region']}, révision {revision})",
                     "supported": False})
    return info


def find_rom(root: Path) -> Path:
    """First .sfc/.smc/.zip at the project root that holds a supported version."""
    for p in sorted(root.iterdir()):
        if p.suffix.lower() in (".sfc", ".smc", ".zip"):
            try:
                Rom(p)
                return p
            except (RomError, zipfile.BadZipFile):
                continue
    names = ", ".join(v["name"] for v in VERSIONS.values() if v["supported"])
    raise RomError(f"Aucune ROM prise en charge trouvée dans {root} (versions lues : {names})")


class Rom:
    def __init__(self, src: "Path | str | bytes", name: str = ""):
        """src: path to a .sfc/.smc/.zip file, or the ROM (or zip) bytes."""
        if isinstance(src, (bytes, bytearray)):
            data = bytes(src)
            if data[:4] == b"PK\x03\x04":
                data = rom_from_zip(data)
            self.path = Path(name or "rom.sfc")
        else:
            self.path = Path(src)
            data = _read_rom_bytes(self.path)
        data = strip_header(data)
        self.info = identify(data)
        if not self.info["supported"]:
            raise RomError(f"{self.path.name}: {self.info['name']} — version non prise en charge "
                           f"(SHA-1 {self.info['sha1']})")
        self.data = data
        global _profile
        f = VERSIONS_DIR / f"{self.info['id']}.json"
        _profile = Profile(json.loads(f.read_text())) if f.exists() else Profile()
        self.profile = _profile

    @staticmethod
    def pc(addr: int) -> int:
        """SNES LoROM address -> file offset."""
        if not addr & 0x8000:
            raise ValueError(f"${addr:06X} n'est pas une adresse ROM LoROM")
        return ((addr >> 16) & 0x7F) * 0x8000 + (addr & 0x7FFF)

    def byte(self, addr: int) -> int:
        return self.data[self.pc(addr)]

    def word(self, addr: int) -> int:
        o = self.pc(addr)
        return self.data[o] | self.data[o + 1] << 8

    def long(self, addr: int) -> int:
        o = self.pc(addr)
        return self.data[o] | self.data[o + 1] << 8 | self.data[o + 2] << 16

    def bytes(self, addr: int, n: int) -> bytes:
        """n bytes from addr. LoROM banks are contiguous in the file, so data that runs
        from $xxFFFF into $(xx+1)8000 is simply the next file bytes."""
        o = self.pc(addr)
        return self.data[o:o + n]

    def words(self, addr: int, n: int) -> list[int]:
        b = self.bytes(addr, n * 2)
        return [b[i] | b[i + 1] << 8 for i in range(0, n * 2, 2)]

    def decompress(self, addr: int, offset_big_endian: bool = False) -> bytes:
        """Nintendo 'LC_LZ2' decompression as used by ALttP.

        Graphics sheets store copy offsets little-endian; overworld map data
        stores them big-endian (hence the flag).
        """
        out = bytearray()
        src = addr

        def nxt() -> int:
            nonlocal src
            b = self.byte(src)
            src += 1
            if (src & 0xFFFF) == 0:  # $xxFFFF -> $(xx+1)8000
                src += 0x8000
            return b

        while True:
            b = nxt()
            if b == 0xFF:
                return bytes(out)
            if b & 0xE0 == 0xE0:  # extended header: 111ccc ll llllllll
                cmd = (b << 3) & 0xE0
                length = ((b & 0x03) << 8 | nxt()) + 1
            else:
                cmd = b & 0xE0
                length = (b & 0x1F) + 1
            if cmd == 0x00:  # literal
                out += bytes(nxt() for _ in range(length))
            elif cmd == 0x20:  # byte fill
                out += bytes([nxt()]) * length
            elif cmd == 0x40:  # word fill
                a, c = nxt(), nxt()
                out += bytes((a, c) * ((length + 1) // 2))[:length]
            elif cmd == 0x60:  # increasing fill
                v = nxt()
                out += bytes((v + i) & 0xFF for i in range(length))
            else:  # 1xx: copy from already decompressed output
                b1, b2 = nxt(), nxt()
                offs = (b1 << 8 | b2) if offset_big_endian else (b2 << 8 | b1)
                for i in range(length):
                    out.append(out[offs + i])
