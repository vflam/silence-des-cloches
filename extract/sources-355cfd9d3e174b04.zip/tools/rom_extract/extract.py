#!/usr/bin/env python3
"""Extract Zelda3-2 assets from the player's own Kamigami no Triforce (JP 1.0) ROM.

    python3 tools/rom_extract/extract.py [--rom PATH] [--out game/assets/rom]

Nothing extracted here is committed: the output folder is git-ignored and every
player rebuilds it from their own ROM.
"""
import argparse
import importlib
import json
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gfx  # noqa: E402
import link  # noqa: E402
import options  # noqa: E402
import overworld as ow  # noqa: E402
import palettes as pal  # noqa: E402
import render as R  # noqa: E402
import rom as rom_mod  # noqa: E402
from rom import Rom, RomError, find_rom  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
VERSION = 1


def log(msg: str) -> None:
    print(msg, flush=True)


def progress(stage: str) -> None:
    """Called when a stage starts ("palettes", "gfx", "overworld", then each step name).
    No-op here; the web page replaces it to show a progress bar (docs/tech/WEB.md)."""


def write_json(path: Path, data, compact=False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        if compact:
            json.dump(data, f, separators=(",", ":"))
        else:
            json.dump(data, f, indent=1)


def extract_sheets(rom: Rom, out: Path) -> dict:
    info = {"bg": [], "spr": []}
    for kind, count, fn in (("bg", gfx.BG_SHEETS, gfx.bg_sheet), ("spr", gfx.SPR_SHEETS, gfx.spr_sheet)):
        d = out / "gfx" / kind
        d.mkdir(parents=True, exist_ok=True)
        for i in range(count):
            s = fn(rom, i)
            px = R.sheet_image(s.tiles, 16)
            # 3bpp values 0-7 (2bpp 0-3) stored as raw indices; the PNG palette is only a preview ramp.
            R.indexed_png(px, R.gray_palette(1 << s.bpp)).save(d / f"{kind}_{i:02x}.png")
            info[kind].append({"id": i, "bpp": s.bpp, "tiles": len(s.tiles)})
    return info


def extract_link(rom: Rom, out: Path, groups: dict) -> None:
    tiles = gfx.link_tiles(rom)
    px = R.sheet_image(tiles, 16)
    d = out / "gfx"
    R.indexed_png(px, R.gray_palette(16)).save(d / "link_indexed.png")
    for i, name in enumerate(("green", "blue", "red")):
        colors = [(0, 0, 0)] + [gfx.snes_color(c) for c in groups["link"][i]]
        R.indexed_png(px, colors).save(d / f"link_{name}.png")
    write_json(out / "link.json", {
        "sheet": "gfx/link_green.png",
        "sheet_columns": 16,
        "doc": "pose: head 16x16 at (x+head_x, y+head_y), body 16x16 at (x, y+8); "
               "*_tile = top-left 8x8 tile of the 16x16 block in the sheet",
        "directions": link.DIRECTIONS,
        "anim_types": link.ANIM_TYPES,
        "animations": link.animations(rom),
        "animation_indices": link.animation_indices(rom),
        "poses": link.poses(rom),
    })
    # Link's shadow: sprite sheet 1 (misc light-world sprites) tile $2C + its mirror,
    # drawn with sprite palette 4 on the right half (colours 9-15). (DrawLinksShadow)
    shadow = gfx.high_expand(gfx.spr_sheet(rom, 1).tiles[0x2C])
    row = [0] * 16
    row[1:16] = groups["sprite_main"][3]
    colors = [gfx.snes_color(c) for c in row]
    t = np.frombuffer(shadow, np.uint8).reshape(8, 8)
    R.indexed_png(np.hstack([t, t[:, ::-1]]), colors).save(d / "link_shadow.png")


def extract_overworld(rom: Rom, out: Path) -> dict:
    d = out / "overworld"
    (d / "atlases").mkdir(parents=True, exist_ok=True)
    defs = ow.map16_defs(rom)
    m32 = ow.map32_defs(rom)
    tile8_types = ow.tile8_types(rom)
    write_json(d / "map16.json", {
        "count": len(defs),
        "format": "4 tilemap words per map16 (TL, TR, BL, BR): vhopppcc cccccccc",
        "defs": defs,
        "tile8_types": tile8_types,
        "types": [[tile8_types[w & 0x1FF] for w in q] for q in defs],
    }, compact=True)

    atlases: dict[tuple, str] = {}
    atlas_px: dict[tuple, tuple[np.ndarray, np.ndarray]] = {}
    screens = []
    worlds = {0x00: np.zeros((4096, 4096, 3), np.uint8), 0x40: np.zeros((4096, 4096, 3), np.uint8)}
    for s in range(ow.SCREEN_COUNT):
        props = ow.area_props(rom, s)
        grid = ow.screen_map16(rom, s, m32)
        entry = dict(props, map16=grid, atlas=None)
        if props["aux_theme"] is not None:
            parent = props["parent"]
            mode = (2 if (parent & 0x3F) in (3, 5, 7) else 0) + (1 if parent & 0x40 else 0)
            key = (props["main_theme"], props["aux_theme"], props["palette_set"], mode)
            if key not in atlases:
                name = "ow_%02x_%02x_%02x_%d" % key
                bank = R.bg_tile_bank(rom, props["main_theme"], props["aux_theme"])
                cg = pal.overworld_bg_cgram(rom, parent, props["palette_set"])
                px = R.map16_pixels(defs, bank)
                rgb = R.cgram_rgb(cg)
                R.colorize(R.atlas(px, 64), rgb).save(d / "atlases" / f"{name}.png")
                write_json(d / "atlases" / f"{name}.json", {
                    "main_theme": key[0], "aux_theme": key[1], "palette_set": key[2], "palette_mode": mode,
                    "sheets": gfx.bg_vram_sheets(rom, key[0], key[1]),
                    "cgram": [gfx.hex_color(c) for c in cg],
                    "backdrop": gfx.hex_color(cg[0]),
                    "columns": 64, "tile_size": 16, "count": len(defs),
                })
                atlases[key] = name
                atlas_px[key] = (px, rgb)
            entry["atlas"] = atlases[key]
            px, rgb = atlas_px[key]
            if s < 0x80:
                img = px[np.array(grid).reshape(32, 32)].transpose(0, 2, 1, 3).reshape(512, 512)
                x, y = (s & 7) * 512, ((s & 0x3F) >> 3) * 512
                worlds[s & 0x40][y:y + 512, x:x + 512] = rgb[img]
        screens.append(entry)
    write_json(d / "screens.json", {"screens": screens}, compact=True)

    if not options.PREVIEWS:
        return {"screens": len(screens), "atlases": len(atlases), "map16": len(defs), "map32": len(m32)}
    prev = out / "previews"
    prev.mkdir(parents=True, exist_ok=True)
    for base, name in ((0x00, "light_world"), (0x40, "dark_world")):
        im = Image.fromarray(worlds[base])
        im.save(prev / f"{name}.png")
        im.resize((1024, 1024), Image.LANCZOS).save(prev / f"{name}_1024.png")
    return {"screens": len(screens), "atlases": len(atlases), "map16": len(defs), "map32": len(m32)}


def preview_contact_sheet(out: Path, kind: str, count: int, cols: int = 8) -> None:
    """All sheets of one kind side by side with an 8-colour ramp, for eyeballing."""
    ims = [Image.open(out / "gfx" / kind / f"{kind}_{i:02x}.png").convert("RGBA") for i in range(count)]
    w, h = 128, max(im.height for im in ims)
    rows = (count + cols - 1) // cols
    sheet = Image.new("RGBA", (cols * (w + 4), rows * (h + 4)), (40, 40, 60, 255))
    for i, im in enumerate(ims):
        sheet.alpha_composite(im, ((i % cols) * (w + 4), (i // cols) * (h + 4)))
    sheet.save(out / "previews" / f"{kind}_sheets.png")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rom", type=Path, help="ROM .sfc/.smc ou .zip (défaut : cherche à la racine du projet)")
    ap.add_argument("--out", type=Path, default=ROOT / "game" / "assets" / "rom")
    ap.add_argument("--no-previews", action="store_true",
                    help="sans les aperçus / planches (inutiles au jeu ; version web)")
    args = ap.parse_args(argv)
    options.PREVIEWS = not args.no_previews

    t0 = time.time()
    try:
        rom = Rom(args.rom) if args.rom else Rom(find_rom(ROOT))
    except RomError as e:
        print(f"Erreur : {e}", file=sys.stderr)
        return 1
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    # Loaded at runtime by RomAssets (Image.load_from_file): keep Godot's importer out.
    (out / ".gdignore").touch()
    rom_mod.set_current(rom)
    rom_mod.set_assets_dir(out)
    log(f"ROM : {rom.path.name} ({rom.info['name']})")

    progress("palettes")
    groups = pal.all_groups(rom)
    write_json(out / "palettes.json", {
        "format": "#rrggbb, converted from SNES BGR555",
        "groups": {k: [[gfx.hex_color(c) for c in p] for p in v] for k, v in groups.items()},
        "glove_colors": [gfx.hex_color(c) for c in rom.words(pal.GLOVE_COLORS, 2)],
        "ow_palette_sets": [list(pal.ow_palette_set(rom, i)) for i in range(pal.OW_PALETTE_SET_COUNT)],
    })
    log("palettes.json")

    write_json(out / "tilesets.json", {
        "main": [gfx.main_tileset(rom, i) for i in range(37)],
        "aux": [gfx.aux_tileset(rom, i) for i in range(82)],
        "sprite": [gfx.sprite_tileset(rom, i) for i in range(144)],
    })
    log("tilesets.json")

    progress("gfx")
    sheets = extract_sheets(rom, out)
    log(f"gfx : {len(sheets['bg'])} feuilles de décor, {len(sheets['spr'])} feuilles de sprites")
    extract_link(rom, out, groups)
    log("gfx/link_*.png")

    progress("overworld")
    ow_info = extract_overworld(rom, out)
    log(f"overworld : {ow_info['screens']} écrans, {ow_info['atlases']} atlas de tuiles 16x16")

    if options.PREVIEWS:
        preview_contact_sheet(out, "bg", gfx.BG_SHEETS)
        preview_contact_sheet(out, "spr", gfx.SPR_SHEETS)

    # Plug-in steps: every tools/rom_extract/steps/<name>.py exposing run(rom, out) -> dict|None,
    # in alphabetical order. Each agent / feature owns its own step file.
    steps_info = {}
    for step in sorted((Path(__file__).parent / "steps").glob("*.py")):
        if step.name.startswith("_"):
            continue
        t1 = time.time()
        progress(step.stem)
        mod = importlib.import_module(f"steps.{step.stem}")
        steps_info[step.stem] = mod.run(rom, out) or {}
        log(f"étape {step.stem} ({time.time() - t1:.1f} s)")

    write_json(out / "manifest.json", {
        "extractor_version": VERSION,
        "rom_sha1": rom.info["sha1"],
        "rom_version": rom.info["id"],
        "rom_title": rom.info["name"],
        "sheets": sheets,
        "overworld": ow_info,
        "steps": steps_info,
    })
    progress("done")
    log(f"Terminé en {time.time() - t0:.1f} s → {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
