"""Custom drawers of the "items" sprite group: pickups whose tiles the NMI streams from a
WRAM buffer, ancillae (Link's bomb / arrow, splashes, sparks), garnishes (debris,
sparkles), sprite death / poof modules and background scenery (chests, pots, bushes,
rocks, signs).

No Nintendo data here: every tile, position, palette and timing comes from the player's
ROM, either by running the game's own code on sprites_cpu.Cpu or by reading the tilemap
words the game itself uses (addresses are JP 1.0, jpdasm labels in comments).

A custom drawer is `custom(rom) -> (vram, cgram, {key: [Obj]})`; recipes reference the keys
with states `{"key": ...}` (see sprites_catalog.render_recipe).
"""
from __future__ import annotations

from collections import Counter
from typing import Callable

import numpy as np

import gfx
import overworld as ow
import palettes as pal
import render as R
import sprites_common as sc
import sprites_engine as se
from rom import A, Rom
from sprites_cpu import Cpu
from sprites_recipe import Anim

# ------------------------------------------------------------------ JP ROM addresses

LOAD_ITEM_GFX = A(0x00D271)            # LoadItemGFXIntoWRAM4BPPBuffer (RTL): fills $7E9480-$7EBxxx
ANCILLA_MAIN = A(0x088242)             # Ancilla_Main (RTL): WeaponTink + HandleAllAncilla
GARNISH_UPPER = A(0x09B06E)            # HandleUpperGarnishSlots_long (RTL): garnish slots $1D-$0F
RESET_OAM_BASES = se.RESET_OAM_REGION_BASES

# WRAM (identical in every version)
STREAM_RUPEE = 0xB280               # rupee frames ($7EB280 + RupeeTile.offset, +$60 = lower half)
STREAM_ANIM_TILE = 0xBD40           # WriteTo4BPPBuffer target, DMA'd to OBJ chars $24/$25 + $34/$35
RUPEE_STEP_OFFSETS = A(0x0085DE)       # RupeeTile.offset (dw x6, same index as RupeeTile.step)

ANC = {  # ancilla arrays (10 slots)
    "y_lo": 0x0BFA, "x_lo": 0x0C04, "y_hi": 0x0C0E, "x_hi": 0x0C18, "type": 0x0C4A, "step": 0x0C54,
    "item": 0x0C5E, "timer": 0x0C68, "dir": 0x0C72, "floor": 0x0C7C, "numspr": 0x0C90,
    "arr3": 0x039F, "aux_timer": 0x03B1, "z": 0x029E, "K": 0x0380, "L": 0x0385, "tile_attr": 0x03E4,
    "objprio": 0x0280, "arr4": 0x0BF0,
}
GAR = {  # garnish arrays (30 slots)
    "type": 0x1F800, "y_lo": 0x1F81E, "x_lo": 0x1F83C, "y_hi": 0x1F85A, "x_hi": 0x1F878,
    "countdown": 0x1F90E, "sprite": 0x1F92C, "floor": 0x1F968, "oam_flags": 0x1F9FE,
}
GARNISH_ACTIVE = 0x0FB4
FRAME_COUNTER = 0x1A
SUBMODULE = 0x11

ORIGIN = se.WORLD_BASE + se.SCREEN   # world coordinate of every drawn object's origin


def common_sheet(world: str) -> int:
    """misc_sprites_graphics_index: sheet loaded at OBJ chars $40-$7F (LoadCommonSprites).
    Overworld: kVariousPacks (1 light, $0B dark); underworld: 10 (Dungeon_LoadSpriteSheets)."""
    return {"lw": 0x01, "dw": 0x0B, "uw": 0x0A}[world]


def sprite_vram(rom: Rom, world: str, gset: int) -> sc.Vram:
    ts = gfx.sprite_tileset(rom, gset + (0x40 if world == "uw" else 0))
    return sc.Vram.for_sprites(rom, ts, common=common_sheet(world))


def _chars4(buf: bytes) -> np.ndarray:
    return np.frombuffer(b"".join(gfx.decode_planar(buf, 4)), np.uint8).reshape(-1, 8, 8)


def stream_tiles(vram: sc.Vram, wram: bytearray, rupee_step: int = 0, rom: Rom | None = None) -> None:
    """The OBJ characters the NMI (NMI_DoUpdates) copies from WRAM buffers every frame:
    the animated rupee ($0B / $1B) and the 'animated sprite tile' slot ($24-$25 / $34-$35)."""
    off = rom.word(RUPEE_STEP_OFFSETS + 2 * rupee_step) if rom is not None else 0
    top = bytes(wram[STREAM_RUPEE + off:STREAM_RUPEE + off + 0x20])
    bot = bytes(wram[STREAM_RUPEE + off + 0x60:STREAM_RUPEE + off + 0x80])
    if any(top) or any(bot):
        vram.put(0x0B, _chars4(top))
        vram.put(0x1B, _chars4(bot))
    t = bytes(wram[STREAM_ANIM_TILE:STREAM_ANIM_TILE + 0x40])
    b = bytes(wram[STREAM_ANIM_TILE + 0x40:STREAM_ANIM_TILE + 0x80])
    if any(t) or any(b):
        vram.put(0x24, _chars4(t))
        vram.put(0x34, _chars4(b))


def load_item_gfx(c: Cpu) -> None:
    p, s, d, dbr = c.p, c.s, c.d, c.dbr
    c.p, c.s, c.d, c.dbr = 0x30, 0x1FF, 0, 0
    c.call(LOAD_ITEM_GFX, long=True)
    c.p, c.s, c.d, c.dbr = p, s, d, dbr


# ------------------------------------------------------------------ bare harness (ancillae / garnishes)

class Harness:
    """A CPU set up like sprites_engine.Engine (same camera), without any sprite."""

    def __init__(self, rom: Rom, world: str = "lw"):
        self.rom = rom
        c = self.cpu = Cpu(rom)
        c.w8(0x1B, 1 if world == "uw" else 0)
        c.w8(0x0FFF, 1 if world == "dw" else 0)
        c.w16(0x8A, 0x40 if world == "dw" else 0)
        c.w16(0xE2, se.WORLD_BASE)
        c.w16(0xE8, se.WORLD_BASE)
        for a in (0x11E, 0x120, 0x122, 0x124):   # BG scroll copies used by some ancillae
            c.w16(a, se.WORLD_BASE)
        c.w16(0x22, ORIGIN)         # Link stands on the object (some routines look at him)
        c.w16(0x20, ORIGIN + 0x30)
        c.wram[0xF360] = 0

    def _begin(self, frame: int) -> None:
        c = self.cpu
        for i in range(128):
            c.wram[0x0800 + i * 4 + 1] = 0xF0
            c.wram[0x0A20 + i] = 0
        for a in range(0x0FEC, 0x0FF8):   # oam_alloc_arr1
            c.wram[a] = 0
        c.w8(FRAME_COUNTER, frame & 0xFF)
        c.p, c.s, c.d, c.dbr = 0x30, 0x1FF, 0, RESET_OAM_BASES >> 16
        c.call(RESET_OAM_BASES)
        c.p, c.x, c.y, c.s, c.d, c.dbr = 0x30, 0, 0, 0x1FF, 0, 0

    def run(self, routine: int, frame: int) -> list[sc.Obj]:
        self._begin(frame)
        self.cpu.call(routine, long=True)
        return oam(self.cpu, ORIGIN, ORIGIN)

    def ancilla(self, type_: int, **kw) -> None:
        c = self.cpu
        vals = dict(type=type_, x_lo=ORIGIN & 0xFF, x_hi=ORIGIN >> 8, y_lo=ORIGIN & 0xFF, y_hi=ORIGIN >> 8)
        vals.update(kw)
        for k, v in vals.items():
            c.w8(ANC[k], v)

    def garnish(self, type_: int, slot: int = 0x1D, **kw) -> None:
        c = self.cpu
        vals = dict(type=type_, x_lo=ORIGIN & 0xFF, x_hi=ORIGIN >> 8, y_lo=ORIGIN & 0xFF, y_hi=ORIGIN >> 8)
        vals.update(kw)
        for k, v in vals.items():
            c.w8(GAR[k] + slot, v)
        c.w8(GARNISH_ACTIVE, type_)


def oam(c: Cpu, ox: int, oy: int) -> list[sc.Obj]:
    """OAM buffer -> Obj list relative to world point (ox, oy) (camera at WORLD_BASE)."""
    out = []
    sx, sy = ox - se.WORLD_BASE, oy - se.WORLD_BASE
    for i in range(128):
        y = c.wram[0x0800 + i * 4 + 1]
        if y == 0xF0:
            continue
        x = c.wram[0x0800 + i * 4]
        ext = c.wram[0x0A20 + i]
        if ext & 1:
            x -= 256
        if y >= 0xE0:
            y -= 256
        word = c.wram[0x0800 + i * 4 + 2] | c.wram[0x0800 + i * 4 + 3] << 8
        out.append(sc.Obj.from_word(x - sx, y - sy, word, bool(ext & 2)))
    return out


# ------------------------------------------------------------------ helpers for recipes

def sim_anim(runs: list[tuple[int, int]], loop: bool = False, prefix: str = "f") -> Anim:
    """Anim whose frames are simulation frames: runs = [(first frame, duration), ...]."""
    return Anim([{"key": f"{prefix}{f}"} for f, _ in runs], [d for _, d in runs], loop)


def keys_anim(keys: list[str], durations, loop: bool = True) -> Anim:
    return Anim([{"key": k} for k in keys], durations, loop)


def sprite_states(type_: int, world: str, pal_: int, gset: int, states: dict[str, dict],
                  pre: dict | None = None, post: dict | None = None, pokes: dict | None = None,
                  rupee_step: int = 0, drop_shadow: bool = False,
                  keep: Callable | None = None) -> Callable:
    """Custom drawer: frozen draws of a ROM sprite (like the default engine path), with the
    streamed OBJ tiles and the right common sheet. states: key -> {var: value, "poke": {...}}."""

    def custom(rom: Rom):
        eng = se.Engine(rom)
        eng.spawn(type_, indoors=world == "uw", dark=world == "dw", pre=dict(pre or {}),
                  globals_=dict(pokes or {}))
        if post:
            eng.set(**post)
        load_item_gfx(eng.cpu)
        out = {}
        for key, st in states.items():
            st = dict(st)
            pk = st.pop("poke", None)
            fr = st.pop("frame", 0)
            objs = eng.draw(st, pokes=pk, frame=fr)
            if drop_shadow:
                objs = [o for o in objs if not (o.char in (0x6C, 0x38) and o.pal == 4)]
            if keep is not None:
                objs = [o for o in objs if keep(o)]
            out[key] = objs
        vram = sprite_vram(rom, world, gset)
        stream_tiles(vram, eng.cpu.wram, rupee_step, rom)
        return vram, sc.sprite_cgram(rom, world, pal_), out

    return custom


def sprite_sim(type_: int, world: str, pal_: int, gset: int, nframes: int, setup: dict,
               pre: dict | None = None, pokes: dict | None = None, without_body: bool = False,
               link: tuple = (0, 0x60), rel_flags2: int = 0) -> Callable:
    """Custom drawer: runs a sprite's code (AI included) for nframes after `setup` (vars set
    once after SpritePrep; rel_flags2 is added to $0E40). Keys "f<n>". without_body drops
    the characters the sprite draws in its normal state (keeps e.g. only the death poof)."""

    def custom(rom: Rom):
        eng = se.Engine(rom)
        eng.spawn(type_, indoors=world == "uw", dark=world == "dw", pre=dict(pre or {}),
                  globals_=dict(pokes or {}), link=link)
        load_item_gfx(eng.cpu)
        body = {(o.char, o.pal) for o in eng.draw({})} if without_body else set()
        eng.set(**setup)
        if rel_flags2:
            eng.set(flags2=(eng.get("flags2") + rel_flags2) & 0xFF)
        out = {}
        for f in range(nframes):
            objs = eng.draw(frozen=False, frame=f)
            out[f"f{f}"] = [o for o in objs if (o.char, o.pal) not in body]
        vram = sprite_vram(rom, world, gset)
        stream_tiles(vram, eng.cpu.wram)
        return vram, sc.sprite_cgram(rom, world, pal_), out

    return custom


def _oam_indexed(c: Cpu) -> list[tuple[int, sc.Obj]]:
    sx = (c.r8(se.VARS["x_lo"]) | c.r8(se.VARS["x_hi"]) << 8) - se.WORLD_BASE
    sy = (c.r8(se.VARS["y_lo"]) | c.r8(se.VARS["y_hi"]) << 8) - se.WORLD_BASE
    out = []
    for i in range(128):
        y = c.wram[0x0800 + i * 4 + 1]
        if y == 0xF0:
            continue
        x = c.wram[0x0800 + i * 4]
        ext = c.wram[0x0A20 + i]
        if ext & 1:
            x -= 256
        if y >= 0xE0:
            y -= 256
        word = c.wram[0x0800 + i * 4 + 2] | c.wram[0x0800 + i * 4 + 3] << 8
        out.append((i, sc.Obj.from_word(x - sx, y - sy, word, bool(ext & 2))))
    return out


def harness_sim(world: str, pal_: int, gset: int, nframes: int, setup: Callable[[Harness], None],
                routine: int, submodule: int = 0, keep: Callable | None = None) -> Callable:
    """Custom drawer: an ancilla / garnish placed by setup(h), run for nframes (keys f<n>)."""

    def custom(rom: Rom):
        h = Harness(rom, world)
        load_item_gfx(h.cpu)
        setup(h)
        h.cpu.w8(SUBMODULE, submodule)
        out = {}
        for f in range(nframes):
            objs = h.run(routine, f)
            out[f"f{f}"] = [o for o in objs if keep is None or keep(o)]
        vram = sprite_vram(rom, world, gset)
        stream_tiles(vram, h.cpu.wram)
        return vram, sc.sprite_cgram(rom, world, pal_), out

    return custom


def harness_states(world: str, pal_: int, gset: int, states: dict[str, Callable[[Harness], None]],
                   routine: int, submodule: int = 1) -> Callable:
    """Custom drawer: one draw per key, each on a fresh harness prepared by its setup."""

    def custom(rom: Rom):
        out = {}
        wram = None
        for key, setup in states.items():
            h = Harness(rom, world)
            load_item_gfx(h.cpu)
            setup(h)
            h.cpu.w8(SUBMODULE, submodule)
            out[key] = h.run(routine, 0)
            wram = h.cpu.wram
        vram = sprite_vram(rom, world, gset)
        if wram is not None:
            stream_tiles(vram, wram)
        return vram, sc.sprite_cgram(rom, world, pal_), out

    return custom


# ------------------------------------------------------------------ background scenery

# Subtype-3 room object data pointers (bank 01 table of RoomDrawObjectData offsets, one word
# per object id $200+n): the tilemap words the game draws for each object.
ROOM_OBJ3_DATA_PTR = A(0x0184F0)       # entry of object $200 (object $219 -> $018522, $22F -> $01854E)
ROOM_DRAW_OBJECT_DATA = A(0x009B52)    # RoomDrawObjectData (bank 00)


def room_object3_words(rom: Rom, obj: int, n: int) -> list[int]:
    """n tilemap words of subtype-3 object $2xx, read through the game's pointer table."""
    ptr = rom.word(ROOM_OBJ3_DATA_PTR + 2 * (obj - 0x200))
    return rom.words(ROOM_DRAW_OBJECT_DATA + ptr, n)


def bg_vram(bank: np.ndarray) -> sc.Vram:
    v = sc.Vram()
    v.chars[:] = bank[:512]
    return v


def words_objs(words: list[int], cols: int, rows: int, order: str = "col") -> list[sc.Obj]:
    """Tilemap words laid out as a cols x rows block ('col' = column-major, as RoomDraw
    1x3_rightwards / Rightwards2x2; 'row' = row-major, as map16 TL TR BL BR)."""
    out = []
    for i, w in enumerate(words[:cols * rows]):
        cx, cy = (i // rows, i % rows) if order == "col" else (i % cols, i // cols)
        out.append(sc.Obj(cx * 8, cy * 8, w & 0x3FF, (w >> 10) & 7, bool(w & 0x4000), bool(w & 0x8000)))
    return out


def bake(bank: np.ndarray, objs: list[sc.Obj], clear_ground) -> tuple[sc.Vram, list[sc.Obj]]:
    """Copy the characters of tilemap objects into a fresh VRAM (flips applied). clear_ground:
    the ground drawn around the object becomes transparent: pixels connected to the block's
    border whose colour is in the set clear_ground (True = the colours of the border ring,
    "corner" = the colour of the top-left pixel)."""
    x1 = max(o.x for o in objs) + 8
    y1 = max(o.y for o in objs) + 8
    idx = np.zeros((y1, x1), np.int32)
    for o in objs:
        t = bank[o.char & 0x1FF]
        if o.flip_h:
            t = t[:, ::-1]
        if o.flip_v:
            t = t[::-1, :]
        idx[o.y:o.y + 8, o.x:o.x + 8] = np.where(t != 0, t + o.pal * 16, 0)
    if clear_ground is not None and clear_ground is not False:
        if clear_ground == "corner":
            ground = {int(idx[0, 0])}
        elif clear_ground is True:
            ground = set(np.concatenate([idx[0], idx[-1], idx[:, 0], idx[:, -1]]).tolist())
        else:
            ground = set(clear_ground)
        seen = np.zeros(idx.shape, bool)
        stack = [(y, x) for y in range(y1) for x in range(x1) if y in (0, y1 - 1) or x in (0, x1 - 1)]
        while stack:
            y, x = stack.pop()
            if not (0 <= y < y1 and 0 <= x < x1) or seen[y, x] or idx[y, x] not in ground:
                continue
            seen[y, x] = True
            stack += [(y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)]
        idx[seen] = 0
    v = sc.Vram()
    out = []
    for i, o in enumerate(objs):
        cell = idx[o.y:o.y + 8, o.x:o.x + 8]
        v.chars[i] = np.where(cell != 0, cell - o.pal * 16, 0)
        out.append(sc.Obj(o.x, o.y, i, o.pal))
    return v, out


def ow_scenery(tile_attr: int, big: bool = False, world: str = "lw") -> Callable:
    """Custom drawer for an overworld liftable (tile attribute $50-$57 of OverworldTileTypes):
    the most used map16 made of that attribute (a 2x2 block of them for big rocks), drawn with
    the tiles and palette of the screen where it is most used. Key "idle"."""

    def custom(rom: Rom):
        defs = ow.map16_defs(rom)
        ty = ow.tile8_types(rom)
        m32 = ow.map32_defs(rom)
        wbit = 0x40 if world == "dw" else 0
        uses: Counter = Counter()
        where: dict[int, Counter] = {}
        grids = {}
        for s in range(wbit, wbit + 0x40):
            if ow.parent_screen(rom, s) != s:
                continue
            g = grids[s] = ow.screen_map16(rom, s, m32)
            for m in g:
                if all(ty[w & 0x1FF] == tile_attr for w in defs[m]):
                    uses[m] += 1
                    where.setdefault(m, Counter())[s] += 1
        m0 = uses.most_common(1)[0][0]
        screen = where[m0].most_common(1)[0][0]
        if big:  # find a top-left: right / below / diagonal neighbours of the same attribute
            g = grids[screen]
            is_a = lambda m: all(ty[w & 0x1FF] == tile_attr for w in defs[m])
            block = None
            for i, m in enumerate(g):
                x, y = i % 32, i // 32
                if x < 31 and y < 31 and is_a(m) and is_a(g[i + 1]) and is_a(g[i + 32]) and is_a(g[i + 33]) \
                        and (x == 0 or not is_a(g[i - 1])) and (y == 0 or not is_a(g[i - 32])):
                    block = [[m, g[i + 1]], [g[i + 32], g[i + 33]]]
                    break
        else:
            block = [[m0]]
        props = ow.area_props(rom, screen)
        bank = R.bg_tile_bank(rom, props["main_theme"], props["aux_theme"])
        cg = np.array([gfx.snes_color(c) for c in pal.overworld_bg_cgram(rom, props["parent"], props["palette_set"])], np.uint8)
        objs = []
        for by, row in enumerate(block):
            for bx, m in enumerate(row):
                for o in words_objs(defs[m], 2, 2, "row"):
                    o.x += bx * 16
                    o.y += by * 16
                    objs.append(o)
        v, objs = bake(bank, objs, "corner")
        return v, cg, {"idle": objs}

    return custom


def uw_scenery(room: int, main: int, parts: dict[str, tuple[int, int, int]], clear_ground: bool = False) -> Callable:
    """Custom drawer for dungeon objects: parts = key -> (object id $2xx, cols, rows), drawn
    column-major with the tiles / palette of `room` (main tile theme `main`)."""

    def custom(rom: Rom):
        import underworld_build as B
        import underworld_rom as U
        h = U.decode_header(U.room_header(rom, room))
        bank = B.tile_bank(rom, main, h["blockset"])
        bg_pal = U.palette_set(rom, h["palette"])[0] >> 1
        cg = R.cgram_rgb(B.dungeon_cgram(rom, bg_pal))
        vram = sc.Vram()
        out = {}
        n = 0
        for k, (o, c, r) in parts.items():
            v, objs = bake(bank, words_objs(room_object3_words(rom, o, c * r), c, r, "col"), clear_ground)
            vram.chars[n:n + len(objs)] = v.chars[:len(objs)]
            out[k] = [sc.Obj(b.x, b.y, b.char + n, b.pal) for b in objs]
            n += len(objs)
        return vram, cg, out

    return custom


RUPEE_STEPS = A(0x0085D2)              # RupeeTile.step (dw x6): frames each rupee image lasts
SPARE_CHARS = 0x1F0                 # OBJ chars free in item drawings (area sheet 4, last row)


def rupee(type_: int, world: str = "lw", pal_: int = 1, gset: int = 1) -> Callable:
    """Rupee pickup with its 3 streamed glint images. Keys "r0", "r1", "r2" = RupeeTile steps
    0-2 (RupeeTile.offset $00 / $20 / $40); steps 1 and 2 are moved to spare characters."""

    def custom(rom: Rom):
        eng = se.Engine(rom)
        eng.spawn(type_, indoors=world == "uw", dark=world == "dw")
        eng.set(E=0)
        load_item_gfx(eng.cpu)
        base = eng.draw({})
        vram = sprite_vram(rom, world, gset)
        out = {}
        for step in range(3):
            v = sprite_vram(rom, world, gset)
            stream_tiles(v, eng.cpu.wram, step, rom)
            if step == 0:
                vram.put(0x0B, v.chars[0x0B:0x0C])
                vram.put(0x1B, v.chars[0x1B:0x1C])
                out["r0"] = base
                continue
            top, bot = SPARE_CHARS + 2 * (step - 1), SPARE_CHARS + 2 * (step - 1) + 1
            vram.put(top, v.chars[0x0B:0x0C])
            vram.put(bot, v.chars[0x1B:0x1C])
            remap = {0x0B: top, 0x1B: bot}
            out[f"r{step}"] = [sc.Obj(o.x, o.y, remap.get(o.char, o.char), o.pal, o.flip_h, o.flip_v, o.big)
                               for o in base]
        return vram, sc.sprite_cgram(rom, world, pal_), out

    return custom


SPAWN_SMASHED_TERRAIN = A(0x06812D)    # SpawnImmediatelySmashedTerrain (RTL): A = object kind


def smash_sim(what: int, world: str, pal_: int, gset: int, nframes: int) -> Callable:
    """Custom drawer: a liftable (kind `what`, as Link's lift code passes it: 0 sign, 1 rock /
    skull pot, 2 bush / pot, 4 off-colour bush, 5 heavy rock) smashed on the spot by the ROM
    (SpawnImmediatelySmashedTerrain -> sprite $EC -> ScatterIntoDebris -> garnish $16), run
    for nframes with the sprite and garnish handlers. Keys "f<n>"."""

    def custom(rom: Rom):
        eng = se.Engine(rom)
        eng.spawn(0xEC, indoors=world == "uw", dark=world == "dw")
        c = eng.cpu
        load_item_gfx(c)
        eng.set(state=0)
        for k in range(1, 16):
            c.w8(se.VARS["state"] + k, 1)         # occupy the other slots: the spawn takes slot 0
        c.w8(0x0B9C, 0xFF)                        # no secret under the object
        wx = se.WORLD_BASE + se.SCREEN
        c.w8(0x00, wx & 0xFF)
        c.w8(0x01, wx >> 8)
        c.w8(0x02, wx & 0xFF)
        c.w8(0x03, wx >> 8)
        c.p, c.s, c.d, c.dbr, c.a = 0x30, 0x1FF, 0, 0, what
        c.call(SPAWN_SMASHED_TERRAIN, long=True)
        for k in range(1, 16):
            c.w8(se.VARS["state"] + k, 0)
        out = {}
        for f in range(nframes):
            eng.draw(frozen=False, frame=f)
            c.p, c.x, c.y, c.s, c.d, c.dbr = 0x30, 0, 0, 0x1FF, 0, 0
            c.call(GARNISH_UPPER, long=True)
            c.p, c.x, c.y, c.s, c.d, c.dbr = 0x30, 0, 0, 0x1FF, 0, 0
            c.call(GARNISH_UPPER + 0x11, long=True)   # HandleLowerGarnishSlots_long ($09B07F)
            out[f"f{f}"] = oam(c, ORIGIN, ORIGIN)
        vram = sprite_vram(rom, world, gset)
        stream_tiles(vram, c.wram)
        return vram, sc.sprite_cgram(rom, world, pal_), out

    return custom


def merge(*customs: Callable) -> Callable:
    """Several drawers sharing the same VRAM / CGRAM (the first one's) -> one key dict."""

    def custom(rom: Rom):
        vram, cg, out = customs[0](rom)
        out = dict(out)
        for c in customs[1:]:
            out.update(c(rom)[2])
        return vram, cg, out

    return custom
