"""Soldiers (Hyrule guards) and humanoid enemies: moblin, hinox, lynel, armos, zoras,
stalfos, gibdo, eyegore. Only sprite ids / set indices / state values (see sprites_recipe)."""
from sprites_recipe import Recipe as R, Anim, dirs4, seq, D_RLDU

# overworld sprite set / palette of the light world castle area (0x1B, after the intro)
LW_CASTLE = dict(set=1, pal=3, world="lw")

# guard body frames ($0DC0) of the walking cycle for each direction (enemy convention)
GUARD_WALK = {0: [11, 12, 13, 12], 1: [4, 5, 6, 5], 2: [0, 1, 2, 3], 3: [7, 8, 9, 10]}
# looking around: head turns while standing (ai state 2): other head directions per facing
GUARD_LOOK = {0: (3, 2), 1: (3, 2), 2: (1, 0), 3: (1, 0)}


def guard_walk(d, n, walk=GUARD_WALK):
    return [dict(D=d, head=d, g=g, aux1=0) for g in walk[d]]


def guard_look(d, n, walk=GUARD_WALK):
    a, b = GUARD_LOOK[d]
    g = walk[d][0]
    return [dict(D=d, head=h, g=g, aux1=0) for h in (d, a, d, b)]


def guard_anims(walk=GUARD_WALK, dur=8):
    out = dirs4("walk", lambda d, n: guard_walk(d, n, walk), dur=dur)
    for k, a in dirs4("idle", lambda d, n: guard_look(d, n, walk), dur=[32, 24, 8, 24]).items():
        out[k] = a
    return out


RECIPES = [
    R("soldier_green", 0x42, **LW_CASTLE, tags=["enemy"], desc="Soldat vert (épée)",
      anims=guard_anims()),
    R("soldier_blue", 0x41, **LW_CASTLE, tags=["enemy"], desc="Soldat bleu (épée)",
      anims=guard_anims()),
    R("soldier_red", 0x43, **LW_CASTLE, tags=["enemy"], desc="Soldat rouge (lance)",
      anims=guard_anims()),
]

# "psycho" trooper (0x44): 8-step cycle, 2 frames per step (observed in the simulation)
BOLT_WALK = {0: [16, 17, 18, 19], 1: [6, 7, 8, 9], 2: [0, 1, 2, 3, 0, 1, 4, 5],
             3: [10, 11, 12, 13, 10, 11, 14, 15]}

RECIPES += [
    R("soldier_charge_blue", 0x44, **LW_CASTLE, tags=["enemy"],
      desc="Soldat bleu fou (charge Link sans s'arrêter)",
      anims=dirs4("walk", lambda d, n: guard_walk(d, n, BOLT_WALK), dur=2)),
    R("soldier_charge_red", 0x45, **LW_CASTLE, tags=["enemy"],
      desc="Soldat rouge à lance qui charge Link",
      anims=dirs4("walk", lambda d, n: guard_walk(d, n), dur=4)),
]

# throwing soldiers (archer 0x46 / javelin 0x48): 2-step walk (sprite_A toggles every 16 frames),
# attack (ai 5): wind-up 8 frames then release 16 frames (projectile launched mid-way)
ARCHER_WALK = {0: [11, 12], 1: [4, 5], 2: [0, 1], 3: [7, 8]}
ARCHER_SHOT = {0: [24, 25], 1: [18, 19], 2: [15, 16], 3: [21, 22]}
JAVELIN_WALK = {0: [17, 18], 1: [7, 8], 2: [3, 4], 3: [13, 14]}
JAVELIN_SHOT = {0: [18, 20], 1: [8, 21], 2: [4, 22], 3: [15, 23]}


def thrower_anims(walk, shot):
    out = dirs4("walk", lambda d, n: [dict(D=d, head=d, g=g, A=i, aux1=0) for i, g in enumerate(walk[d])],
                dur=16)
    out.update(dirs4("idle", lambda d, n: [dict(D=d, head=h, g=walk[d][0], A=0, aux1=0)
                                           for h in (d, GUARD_LOOK[d][0], d, GUARD_LOOK[d][1])],
                     dur=[32, 24, 8, 24]))
    out.update(dirs4("attack", lambda d, n: [dict(D=d, head=d, g=g, A=0, aux1=0) for g in shot[d]],
                     dur=[8, 16], loop=False))
    return out


RECIPES += [
    R("soldier_archer", 0x46, set=4, pal=3, world="lw", tags=["enemy"], desc="Soldat archer bleu",  # bow sheet: LW set 4
      anims=thrower_anims(ARCHER_WALK, ARCHER_SHOT)),
    R("soldier_javelin", 0x48, **LW_CASTLE, tags=["enemy"], desc="Soldat rouge lanceur de javelot",
      anims=thrower_anims(JAVELIN_WALK, JAVELIN_SHOT)),
]

# bush soldiers (0x47 green archer, 0x49 red javelin): hidden in a bush (ai 0, nothing drawn:
# the bush is the background tile), pop out (ai 1), shoot (ai 2), sink back (ai 3)
BUSH_EMERGE = Anim([dict(ai=1, g=g) for g in [1, 0] * 4 + [4]], [4] * 8 + [32], loop=False)
BUSH_HIDE = Anim([dict(ai=3, g=g) for g in [4, 3, 2] + [0, 1] * 4 + [0]], [5, 4, 4] + [4] * 9, loop=False)
BUSH_ARCHER_SHOT = {0: [23, 23, 24, 25], 1: [17, 17, 18, 19], 2: [14, 14, 15, 16], 3: [20, 20, 21, 22]}
BUSH_JAVELIN_SHOT = {0: [16, 18, 20], 1: [6, 8, 21], 2: [3, 4, 22], 3: [11, 15, 23]}


def bush_anims(shot, dur):
    out = {"special_emerge": BUSH_EMERGE, "special_hide": BUSH_HIDE}
    out.update(dirs4("attack", lambda d, n: [dict(ai=2, D=d, head=d, g=g, A=0 if i == 0 else 255, aux1=0)
                                             for i, g in enumerate(shot[d])], dur=dur, loop=False))
    return out


RECIPES += [
    R("soldier_bush", 0x47, set=4, pal=3, world="lw", tags=["enemy"],
      desc="Soldat vert caché dans un buisson (archer)",
      anims=bush_anims(BUSH_ARCHER_SHOT, [8, 8, 16, 16])),
    R("soldier_bush_red", 0x49, set=1, pal=3, world="lw", tags=["enemy"],
      desc="Soldat rouge caché dans un buisson (javelot)",
      anims=bush_anims(BUSH_JAVELIN_SHOT, [8, 24, 16])),
]

# bomb soldier (0x4A): stands facing Link, raises a bomb then throws it (ai 1, 112 frames)
BOMB_THROW = {0: [16, 18, 20], 1: [6, 8, 21], 2: [3, 4, 22], 3: [11, 15, 23]}
# knife "recruit" (0x4B): the routine derives its frame from D and the step counter $0E80
# (subtype2): two-frame walk, frame changes every 8 frames
KNIFE_STEP = [0, 8]


def flail_attack(d, n):
    walk = BOLT_WALK[d]
    return [dict(ai=2, D=d, head=d, g=walk[i % len(walk)], A=(i * 64) & 0xFF, B=(i * 64) >> 8, aux2=0)
            for i in range(8)]


RECIPES += [
    R("soldier_bomb", 0x4A, **LW_CASTLE, tags=["enemy"], desc="Soldat lanceur de bombes",
      anims={**dirs4("idle", lambda d, n: [dict(ai=0, D=d, head=d, g=BOMB_THROW[d][2], subtype2=0)]),
             **dirs4("attack", lambda d, n: [dict(ai=1, D=d, head=d, g=g, subtype2=1 if i == 0 else 0)
                                             for i, g in enumerate(BOMB_THROW[d])],
                     dur=[32, 48, 32], loop=False)}),
    R("soldier_knife", 0x4B, set=2, pal=1, world="lw", tags=["enemy"], desc="Recrue verte au couteau",
      anims={**dirs4("walk", lambda d, n: [dict(ai=1, D=d, head=d, subtype2=s) for s in KNIFE_STEP], dur=8),
             **dirs4("idle", lambda d, n: [dict(ai=0, D=d, head=d, subtype2=0)])}),
    R("soldier_chain", 0x6A, set=1, pal=0, world="uw", tags=["enemy"],
      desc="Soldat au fléau (boule et chaîne)",
      anims={**dirs4("walk", lambda d, n: [dict(ai=0, D=d, head=d, g=g, A=0, B=0, aux2=0)
                                           for g in BOLT_WALK[d]], dur=4),
             **dirs4("attack", flail_attack, dur=2)}),
]

# moblin (0x12) / hinox (0x11): same frame layout: walk = base + step (toggles every 12 frames)
OGRE_WALK = {0: [6, 7], 1: [4, 5], 2: [0, 1], 3: [2, 3]}
MOBLIN_THROW = {0: [11, 7], 1: [10, 5], 2: [8, 0], 3: [9, 2]}   # wind-up, spear thrown
HINOX_THROW = {0: [11, 7], 1: [10, 5], 2: [8, 1], 3: [9, 3]}    # bomb raised, thrown
DW_WOODS = dict(set=19, pal=14, world="dw")

RECIPES += [
    R("moblin", 0x12, **DW_WOODS, tags=["enemy"], desc="Moblin (lanceur de lance)",
      anims={**dirs4("walk", lambda d, n: [dict(ai=1, D=d, head=d, g=g, aux1=0) for g in OGRE_WALK[d]],
                     dur=12),
             # after the throw the spear (small objects) is hidden while delay_aux1 runs
             **dirs4("attack", lambda d, n: [dict(ai=2, D=d, head=d, g=MOBLIN_THROW[d][0], aux1=0),
                                             dict(ai=2, D=d, head=d, g=MOBLIN_THROW[d][1], aux1=32)],
                     dur=[16, 16], loop=False)}),
    R("hinox", 0x11, **DW_WOODS, tags=["enemy"], desc="Hinox (cyclope lanceur de bombes)",
      anims={**dirs4("walk", lambda d, n: [dict(ai=1, D=d, g=g) for g in OGRE_WALK[d]], dur=12),
             **dirs4("attack", lambda d, n: [dict(ai=2, D=d, g=g) for g in HINOX_THROW[d]],
                     dur=[32, 32], loop=False)}),
]

# lynel (0xD0): walk frame toggles every 4 frames; attack pose held 32 frames (fireball at 16)
LYNEL_WALK = {0: [3, 4], 1: [0, 1], 2: [6, 7], 3: [9, 10]}
LYNEL_ATTACK = {0: 5, 1: 2, 2: 8, 3: 10}

RECIPES += [
    R("lynel", 0xD0, set=20, pal=12, world="dw", tags=["enemy"], desc="Lynel (centaure cracheur de feu)",
      anims={**dirs4("walk", lambda d, n: [dict(ai=1, D=d, g=g) for g in LYNEL_WALK[d]], dur=4),
             **dirs4("attack", lambda d, n: [dict(ai=2, D=d, g=LYNEL_ATTACK[d])], dur=32, loop=False)}),
]

# armos statue (0x51): stone while dormant (ai 0); when Link comes near it flashes for 48
# frames (palette bits of $0F50 toggled each frame) then comes alive (palette 0x0B) and hops.
ARMOS_WAKE_PAL = [5, 3, 5, 3, 5, 1, 5, 1, 5, 7, 5, 7, 5, 5, 5, 5, 5, 11, 5, 11, 5, 9, 5, 9, 5, 15, 5, 15,
                  5, 13, 5, 13, 5, 3, 5, 3, 5, 1, 5, 1, 5, 7, 5, 7, 5, 5, 5]
ARMOS_HOP_Z = [0, 1, 2, 3, 4, 3, 2, 1]          # one 17-frame hop (height in pixels)
ARMOS_HOP_DUR = [1, 2, 1, 2, 6, 2, 1, 2]

RECIPES += [
    R("armos", 0x51, set=5, pal=7, world="lw", tags=["enemy"], desc="Armos (statue qui s'anime et sautille)",
      anims={"idle": Anim([dict(ai=0, delay=0, oam_flags=5, z=0)]),
             "special_wake": Anim([dict(ai=0, delay=0, oam_flags=p, z=0) for p in ARMOS_WAKE_PAL], 1, loop=False),
             **dirs4("walk", lambda d, n: [dict(ai=1, delay=0, oam_flags=0x0B, z=z) for z in ARMOS_HOP_Z],
                     dur=ARMOS_HOP_DUR)}),
]

# river zora (0x55): surfaces (ai 1, 127 frames), spits a fireball (ai 2), dives (ai 3).
# It always faces the screen: the same frames are given for every direction.
def same4(prefix, states, dur, loop=True):
    return {f"{prefix}_{d}": Anim(list(states), dur, loop) for d in ("up", "down", "left", "right")}


ZORA_EMERGE = [0] + [1, 2] * 6 + [3, 4]
ZORA_EMERGE_DUR = [15] + [8] * 12 + [8, 8]
ZORA_DIVE = [0, 7, 8, 9, 11, 12]
ZORA_DIVE_DUR = [3, 4, 4, 4, 4, 3]

RECIPES += [
    R("zora", 0x55, set=4, pal=3, world="lw", tags=["enemy"],
      desc="Zora de rivière (sort de l'eau et crache une boule de feu)",
      anims={"special_emerge": Anim([dict(ai=1, g=g) for g in ZORA_EMERGE], ZORA_EMERGE_DUR, loop=False),
             **same4("idle", [dict(ai=2, g=5)], 8),
             # fireball launched when the mouth opens wide (2nd frame)
             **same4("attack", [dict(ai=2, g=g) for g in (6, 10, 6)], [16, 16, 16], loop=False),
             "special_dive": Anim([dict(ai=3, g=g) for g in ZORA_DIVE], ZORA_DIVE_DUR, loop=False)}),
]

# walking zora (0x56): surfaces like the river zora ($0DA0 "B" = 1), leaps out of the water
# (B = 2, z arc of 48 frames) then walks (frame from D and step counter $0E80, every 8 frames)
WZ_JUMP_Z = [0, 8, 16, 22, 27, 31, 34, 36, 37, 36, 34, 31, 27, 22, 16, 8, 0]
WZ_JUMP_DUR = [3, 3, 3, 3, 3, 3, 3, 3, 6, 3, 3, 3, 2, 2, 2, 3, 1]

RECIPES += [
    R("zora_walking", 0x56, set=14, pal=8, world="lw", tags=["enemy"],
      desc="Zora marcheur (sort de l'eau d'un bond puis marche)",
      anims={"special_emerge": Anim([dict(B=1, g=g, z=0) for g in ZORA_EMERGE]
                                    + [dict(B=2, D=2, head=2, z=z, subtype2=0 if i % 2 == 0 else 8)
                                       for i, z in enumerate(WZ_JUMP_Z)],
                                    ZORA_EMERGE_DUR + WZ_JUMP_DUR, loop=False),
             **dirs4("walk", lambda d, n: [dict(B=2, D=d, head=d, z=0, subtype2=s) for s in (0, 8)], dur=8)}),
]

# stalfos (0xA7): the routine picks the frame from D and the step counter $0E80 (toggles every
# 12 frames); it jumps back (z arc, pose 8 + D) when Link attacks.
STALFOS_JUMP_Z = [3, 8, 12, 15, 17, 18, 17, 15, 12, 8, 3, 0]
STALFOS_JUMP_DUR = [2, 2, 3, 2, 3, 2, 3, 3, 2, 3, 2, 1]
UW_STALFOS = dict(set=19, pal=13, world="uw")

# yellow stalfos (0x85): drops from the ceiling, faces Link, shakes and throws its head
# ($0DA0 = head x offset, $0DB0 = head height, head hidden when x offset = 0x80)
YSTAL_IDLE = {0: 6, 1: 3, 2: 1, 3: 1}
YSTAL_THROW = {0: (7, 8), 1: (4, 5), 2: (2, 1), 3: (2, 1)}
YSTAL_SHAKE = [(0, 10, 19), (1, 10, 4), (0, 10, 4), (255, 10, 4), (0, 10, 4), (1, 10, 4), (0, 10, 4),
               (255, 10, 4), (0, 10, 4), (0, 11, 4), (0, 12, 4), (0, 13, 20)]
YSTAL_FALL_Z = [64, 62, 58, 53, 46, 38, 28, 16, 4, 0]
YSTAL_FALL_DUR = [3, 3, 3, 3, 3, 3, 3, 3, 2, 1]
# knocked down by the sword: collapses into a pile of bones then stands up
YSTAL_COLLAPSE = [(9, 7, 16), (10, 0, 176), (9, 7, 16), (1, 10, 48)]


def ystal_attack(d, n):
    a, b = YSTAL_THROW[d]
    st = [dict(ai=2, D=d, head=d, g=a, B=x, C=y, z=0) for x, y, _ in YSTAL_SHAKE]
    st.append(dict(ai=2, D=d, head=d, g=b, B=0x80, C=13, z=0))
    return st


# gibdo (0x8B): walk frame toggles every 15 frames; facing in $0D90 ("A")
GIBDO_WALK = {0: [9, 11], 1: [2, 3], 2: [0, 1], 3: [4, 5]}
# eyegore (0x83 green / 0x84 red): eye closed (g 0) until Link comes near, opens, chases
EYEGORE_WALK = {0: [7, 8], 1: [5, 6], 2: [2, 3, 2, 4], 3: [9, 10, 9, 11]}


def eyegore_anims():
    return {
        "idle": Anim([dict(ai=0, g=0)]),
        "special_open": Anim([dict(ai=1, g=g) for g in (0, 1, 2)], [16, 16, 32], loop=False),
        "special_close": Anim([dict(ai=3, g=g) for g in (2, 1, 0)], [32, 16, 16], loop=False),
        **dirs4("walk", lambda d, n: [dict(ai=2, D=d, g=g) for g in EYEGORE_WALK[d]], dur=4),
    }


RECIPES += [
    R("stalfos", 0xA7, **UW_STALFOS, tags=["enemy"], desc="Stalfos (squelette qui esquive en sautant)",
      anims={**dirs4("walk", lambda d, n: [dict(ai=1, D=d, head=d, subtype2=s, z=0, E=0, A=0)
                                           for s in (0, 1)], dur=12),
             **dirs4("special_jump", lambda d, n: [dict(ai=1, D=d, head=d, z=z, E=0, A=0)
                                                   for z in STALFOS_JUMP_Z],
                     dur=STALFOS_JUMP_DUR, loop=False)}),
    R("stalfos_yellow", 0x85, set=25, pal=15, world="uw", tags=["enemy"],
      desc="Stalfos jaune (tombe du plafond et lance sa tête)",
      anims={"special_descend": Anim([dict(ai=0, g=0, head=2, B=0, C=10, z=z) for z in YSTAL_FALL_Z],
                                     YSTAL_FALL_DUR, loop=False),
             **dirs4("idle", lambda d, n: [dict(ai=1, D=d, head=d, g=YSTAL_IDLE[d], B=0, C=10, z=0)]),
             **dirs4("attack", ystal_attack, dur=[s[2] for s in YSTAL_SHAKE] + [47], loop=False),
             **dirs4("special_headless", lambda d, n: [dict(ai=3, D=d, head=d, g=YSTAL_IDLE[d], B=0x80,
                                                         C=13, z=0)]),
             "special_collapse": Anim([dict(ai=5, D=2, head=2, g=g, B=0, C=c, z=0)
                                       for g, c, _ in YSTAL_COLLAPSE],
                                      [t for _, _, t in YSTAL_COLLAPSE], loop=False)}),
    R("gibdo", 0x8B, set=19, pal=13, world="uw", tags=["enemy"], desc="Gibdo (momie)",
      anims=dirs4("walk", lambda d, n: [dict(ai=1, A=d, g=g) for g in GIBDO_WALK[d]], dur=15)),
    R("eyegore_green", 0x83, set=10, pal=9, world="uw", tags=["enemy"],
      desc="Eyegore vert (statue à œil unique qui s'éveille)", anims=eyegore_anims()),
    R("eyegore_red", 0x84, set=10, pal=9, world="uw", tags=["enemy"],
      desc="Eyegore rouge (statue à œil unique qui s'éveille)", anims=eyegore_anims()),
]

# ---------------------------------------------------------------------------------------------
# enemy projectiles (tags fx)
# 0x1B "enemy arrow": $0D90 (A) selects the object: 0 arrow, 1 javelin, 2 arrow stuck in a wall,
# 3 moblin spear; D = flight direction (0 right, 1 left, 2 down, 3 up)
def arrow_anims(a, stuck=False):
    out = dirs4("idle", lambda d, n: [dict(A=a, D=d, E=0)])
    if stuck:
        out.update(dirs4("special_stuck", lambda d, n: [dict(A=2, D=d, E=0)]))
    return out


# enemy bomb (0x4A with $0DB0 = 1, like Sprite_TransmuteToBomb): its palette bits cycle while
# the fuse ends ($0F50 = (aux1 >> 1) & 0x0E when aux1 < 64); C >= 2 draws the explosion whose
# frame is (aux1 >> 1) & 0x0C (aux1 counts 31 -> 0)
BOMB_FUSE_AUX1 = list(range(62, 0, -4))

RECIPES += [
    R("proj_arrow", 0x1B, set=4, pal=3, world="lw", tags=["fx"], desc="Flèche d'archer ennemi",
      anims=arrow_anims(0, stuck=True)),
    R("proj_javelin", 0x1B, **LW_CASTLE, tags=["fx"], desc="Javelot de soldat", anims=arrow_anims(1)),
    R("proj_moblin_spear", 0x1B, **DW_WOODS, tags=["fx"], desc="Lance de Moblin", anims=arrow_anims(3)),
    R("proj_zora_fireball", 0x55, set=4, pal=3, world="lw", tags=["fx"],
      desc="Boule de feu crachée par un Zora (ou un Lynel)",
      post=dict(E=0x54, oam_flags=6, g=0), anims={"idle": Anim([dict(delay=0)])}),
    R("proj_enemy_bomb", 0x4A, **LW_CASTLE, tags=["fx"], desc="Bombe ennemie (soldat, Hinox) et son explosion",
      post=dict(C=1, flags3=0x18, health=0, g=0),   # spawned bombs have frame 0
      anims={"idle": Anim([dict(C=1, aux1=255, oam_flags=8, g=0)]),
             # end of the fuse: palette flashing (sampled every 4 frames)
             "special_fuse": Anim([dict(C=1, g=0, aux1=a, oam_flags=8 & ~0x0E | (a >> 1) & 0x0E)
                                   for a in BOMB_FUSE_AUX1], 4, loop=False),
             "die": Anim([dict(C=3, aux1=a, oam_flags=2) for a in (31, 23, 15, 7)], 8, loop=False)}),
    R("proj_bone", 0xA7, **UW_STALFOS, tags=["fx"], desc="Os lancé par un Stalfos (tourne)",
      post=dict(A=1, oam_flags=7), anims={"idle": Anim([dict(A=1, subtype2=s) for s in (0, 4, 8, 12)], 4)}),
    R("proj_stalfos_head", 0x02, set=25, pal=15, world="uw", tags=["fx"],
      desc="Tête volante de Stalfos jaune",
      anims={"idle": Anim([dict(subtype2=s, aux1=0) for s in (0, 8, 16, 24)], 8)}),
]
