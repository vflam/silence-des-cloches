"""A small 65C816 interpreter used to run the ROM's own sprite drawing routines.

Instead of re-implementing the drawing code of every sprite (and copying its tables), we
execute the routines of the player's ROM (banks 05/06/1D/1E) on an emulated WRAM and read
back the OAM buffer they fill ($7E0800 / $7E0A20). Native mode only, no decimal mode
arithmetic beyond binary (the sprite drawing code does not use it), hardware multiply /
divide registers emulated, every other I/O register reads 0.
"""
from __future__ import annotations

from rom import Rom


class CpuError(Exception):
    pass


class Cpu:
    def __init__(self, rom: Rom):
        self.rom = rom.data
        self.rom_len = len(rom.data)
        self.wram = bytearray(0x20000)
        self.sram = bytearray(0x8000)
        self.io = {}
        self.a = self.x = self.y = 0
        self.s = 0x1FF
        self.d = 0
        self.dbr = 0
        self.pbr = 0
        self.pc = 0
        self.p = 0x30  # m and x set (8-bit)
        self.steps = 0
        self.trace = None
        self._build()

    # ------------------------------------------------------------ memory
    def read(self, addr: int) -> int:
        bank = (addr >> 16) & 0xFF
        off = addr & 0xFFFF
        if bank == 0x7E or bank == 0x7F:
            return self.wram[(bank - 0x7E) << 16 | off]
        b = bank & 0x7F
        if off >= 0x8000:
            return self.rom[(b * 0x8000 + off - 0x8000) % self.rom_len]
        if b < 0x40:
            if off < 0x2000:
                return self.wram[off]
            return self._io_read(off)
        if 0x70 <= b < 0x7E:
            return self.sram[off]
        return 0

    def write(self, addr: int, v: int) -> None:
        bank = (addr >> 16) & 0xFF
        off = addr & 0xFFFF
        v &= 0xFF
        if bank == 0x7E or bank == 0x7F:
            self.wram[(bank - 0x7E) << 16 | off] = v
            return
        b = bank & 0x7F
        if off >= 0x8000:
            return  # ROM
        if b < 0x40:
            if off < 0x2000:
                self.wram[off] = v
            else:
                self._io_write(off, v)
        elif 0x70 <= b < 0x7E:
            self.sram[off] = v

    def _io_read(self, off: int) -> int:
        return self.io.get(off, 0)

    def _io_write(self, off: int, v: int) -> None:
        self.io[off] = v
        if off == 0x4203:  # WRMPYB -> RDMPY
            r = self.io.get(0x4202, 0) * v
            self.io[0x4216], self.io[0x4217] = r & 0xFF, r >> 8
        elif off == 0x4206:  # WRDIVB -> RDDIV / RDMPY (remainder)
            n = self.io.get(0x4204, 0) | self.io.get(0x4205, 0) << 8
            if v == 0:
                q, r = 0xFFFF, n
            else:
                q, r = n // v, n % v
            self.io[0x4214], self.io[0x4215] = q & 0xFF, q >> 8
            self.io[0x4216], self.io[0x4217] = r & 0xFF, r >> 8

    def read16(self, addr: int) -> int:
        return self.read(addr) | self.read((addr + 1) & 0xFFFFFF) << 8

    def read16_b0(self, addr: int) -> int:  # wraps inside bank 0 (direct page, stack)
        return self.read(addr & 0xFFFF) | self.read((addr + 1) & 0xFFFF) << 8

    def write16(self, addr: int, v: int) -> None:
        self.write(addr, v & 0xFF)
        self.write((addr + 1) & 0xFFFFFF, v >> 8)

    # WRAM helpers for the harness
    def w8(self, addr: int, v: int) -> None:
        self.wram[addr & 0x1FFFF] = v & 0xFF

    def w16(self, addr: int, v: int) -> None:
        self.wram[addr & 0x1FFFF] = v & 0xFF
        self.wram[(addr + 1) & 0x1FFFF] = (v >> 8) & 0xFF

    def r8(self, addr: int) -> int:
        return self.wram[addr & 0x1FFFF]

    # ------------------------------------------------------------ fetch / stack
    def fetch8(self) -> int:
        v = self.read(self.pbr << 16 | self.pc)
        self.pc = (self.pc + 1) & 0xFFFF
        return v

    def fetch16(self) -> int:
        lo = self.fetch8()
        return lo | self.fetch8() << 8

    def fetch24(self) -> int:
        lo = self.fetch16()
        return lo | self.fetch8() << 16

    def push8(self, v: int) -> None:
        self.write(self.s, v)
        self.s = (self.s - 1) & 0xFFFF

    def pull8(self) -> int:
        self.s = (self.s + 1) & 0xFFFF
        return self.read(self.s)

    def push16(self, v: int) -> None:
        self.push8(v >> 8)
        self.push8(v)

    def pull16(self) -> int:
        lo = self.pull8()
        return lo | self.pull8() << 8

    # ------------------------------------------------------------ flags
    @property
    def m8(self) -> bool:
        return bool(self.p & 0x20)

    @property
    def x8(self) -> bool:
        return bool(self.p & 0x10)

    def nz8(self, v: int) -> None:
        self.p = (self.p & 0x7D) | (v & 0x80) | (0 if v & 0xFF else 2)

    def nz16(self, v: int) -> None:
        self.p = (self.p & 0x7D) | ((v >> 8) & 0x80) | (0 if v & 0xFFFF else 2)

    def set_p(self, v: int) -> None:
        self.p = v & 0xFF
        if self.p & 0x10:
            self.x &= 0xFF
            self.y &= 0xFF

    # ------------------------------------------------------------ addressing modes
    # each returns an effective 24-bit address (data)
    def am_dp(self):
        return (self.d + self.fetch8()) & 0xFFFF

    def am_dpx(self):
        return (self.d + self.fetch8() + self.x) & 0xFFFF

    def am_dpy(self):
        return (self.d + self.fetch8() + self.y) & 0xFFFF

    def am_ind(self):  # (dp)
        return self.dbr << 16 | self.read16_b0(self.d + self.fetch8())

    def am_indx(self):  # (dp,X)
        return self.dbr << 16 | self.read16_b0(self.d + self.fetch8() + self.x)

    def am_indy(self):  # (dp),Y
        return ((self.dbr << 16 | self.read16_b0(self.d + self.fetch8())) + self.y) & 0xFFFFFF

    def am_indl(self):  # [dp]
        p = (self.d + self.fetch8()) & 0xFFFF
        return self.read16_b0(p) | self.read((p + 2) & 0xFFFF) << 16

    def am_indly(self):  # [dp],Y
        p = (self.d + self.fetch8()) & 0xFFFF
        return ((self.read16_b0(p) | self.read((p + 2) & 0xFFFF) << 16) + self.y) & 0xFFFFFF

    def am_abs(self):
        return self.dbr << 16 | self.fetch16()

    def am_absx(self):
        return ((self.dbr << 16 | self.fetch16()) + self.x) & 0xFFFFFF

    def am_absy(self):
        return ((self.dbr << 16 | self.fetch16()) + self.y) & 0xFFFFFF

    def am_long(self):
        return self.fetch24()

    def am_longx(self):
        return (self.fetch24() + self.x) & 0xFFFFFF

    def am_sr(self):
        return (self.s + self.fetch8()) & 0xFFFF

    def am_sry(self):
        return ((self.dbr << 16 | self.read16_b0(self.s + self.fetch8())) + self.y) & 0xFFFFFF

    # ------------------------------------------------------------ operations
    def _load_m(self, ea):
        return self.read(ea) if self.m8 else self.read16(ea)

    def _store_m(self, ea, v):
        if self.m8:
            self.write(ea, v)
        else:
            self.write16(ea, v)

    def _imm_m(self):
        return self.fetch8() if self.m8 else self.fetch16()

    def _imm_x(self):
        return self.fetch8() if self.x8 else self.fetch16()

    def _nz_m(self, v):
        if self.m8:
            self.nz8(v)
        else:
            self.nz16(v)

    def _nz_x(self, v):
        if self.x8:
            self.nz8(v)
        else:
            self.nz16(v)

    def _get_acc(self):
        return self.a & 0xFF if self.m8 else self.a

    def _set_acc(self, v):
        if self.m8:
            self.a = (self.a & 0xFF00) | (v & 0xFF)
        else:
            self.a = v & 0xFFFF

    def op_ora(self, v):
        r = self._get_acc() | v
        self._set_acc(r)
        self._nz_m(r)

    def op_and(self, v):
        r = self._get_acc() & v
        self._set_acc(r)
        self._nz_m(r)

    def op_eor(self, v):
        r = self._get_acc() ^ v
        self._set_acc(r)
        self._nz_m(r)

    def op_adc(self, v):
        a = self._get_acc()
        c = self.p & 1
        if self.m8:
            r = a + v + c
            ov = (~(a ^ v) & (a ^ r) & 0x80)
            self.p = (self.p & ~0x41) | (1 if r > 0xFF else 0) | (0x40 if ov else 0)
            r &= 0xFF
        else:
            r = a + v + c
            ov = (~(a ^ v) & (a ^ r) & 0x8000)
            self.p = (self.p & ~0x41) | (1 if r > 0xFFFF else 0) | (0x40 if ov else 0)
            r &= 0xFFFF
        self._set_acc(r)
        self._nz_m(r)

    def op_sbc(self, v):
        self.op_adc(v ^ (0xFF if self.m8 else 0xFFFF))

    def _cmp(self, reg, v, eight):
        mask = 0xFF if eight else 0xFFFF
        r = (reg - v) & mask
        self.p = (self.p & ~1) | (1 if reg >= v else 0)
        if eight:
            self.nz8(r)
        else:
            self.nz16(r)

    def op_cmp(self, v):
        self._cmp(self._get_acc(), v, self.m8)

    def op_bit(self, v, imm=False):
        a = self._get_acc()
        if self.m8:
            self.p = (self.p & ~2) | (0 if a & v & 0xFF else 2)
            if not imm:
                self.p = (self.p & 0x3F) | (v & 0xC0)
        else:
            self.p = (self.p & ~2) | (0 if a & v & 0xFFFF else 2)
            if not imm:
                self.p = (self.p & 0x3F) | ((v >> 8) & 0xC0)

    # read-modify-write
    def rmw(self, ea, fn):
        if self.m8:
            v = fn(self.read(ea), 8)
            self.write(ea, v)
        else:
            v = fn(self.read16(ea), 16)
            self.write16(ea, v)

    def f_asl(self, v, bits):
        top = 1 << (bits - 1)
        self.p = (self.p & ~1) | (1 if v & top else 0)
        v = (v << 1) & ((1 << bits) - 1)
        self.nz8(v) if bits == 8 else self.nz16(v)
        return v

    def f_lsr(self, v, bits):
        self.p = (self.p & ~1) | (v & 1)
        v >>= 1
        self.nz8(v) if bits == 8 else self.nz16(v)
        return v

    def f_rol(self, v, bits):
        top = 1 << (bits - 1)
        c = self.p & 1
        self.p = (self.p & ~1) | (1 if v & top else 0)
        v = ((v << 1) | c) & ((1 << bits) - 1)
        self.nz8(v) if bits == 8 else self.nz16(v)
        return v

    def f_ror(self, v, bits):
        c = self.p & 1
        self.p = (self.p & ~1) | (v & 1)
        v = (v >> 1) | (c << (bits - 1))
        self.nz8(v) if bits == 8 else self.nz16(v)
        return v

    def f_inc(self, v, bits):
        v = (v + 1) & ((1 << bits) - 1)
        self.nz8(v) if bits == 8 else self.nz16(v)
        return v

    def f_dec(self, v, bits):
        v = (v - 1) & ((1 << bits) - 1)
        self.nz8(v) if bits == 8 else self.nz16(v)
        return v

    def f_tsb(self, v, bits):
        a = self._get_acc()
        self.p = (self.p & ~2) | (0 if a & v else 2)
        return v | a

    def f_trb(self, v, bits):
        a = self._get_acc()
        self.p = (self.p & ~2) | (0 if a & v else 2)
        return v & ~a & ((1 << bits) - 1)

    def acc_rmw(self, fn):
        bits = 8 if self.m8 else 16
        self._set_acc(fn(self._get_acc(), bits))

    def branch(self, cond):
        off = self.fetch8()
        if cond:
            self.pc = (self.pc + (off - 256 if off & 0x80 else off)) & 0xFFFF

    # ------------------------------------------------------------ opcode table
    def _build(self):
        ops = [None] * 256
        modes = {
            "dp": self.am_dp, "dpx": self.am_dpx, "dpy": self.am_dpy, "ind": self.am_ind,
            "indx": self.am_indx, "indy": self.am_indy, "indl": self.am_indl, "indly": self.am_indly,
            "abs": self.am_abs, "absx": self.am_absx, "absy": self.am_absy, "long": self.am_long,
            "longx": self.am_longx, "sr": self.am_sr, "sry": self.am_sry,
        }
        # group 1: ORA AND EOR ADC STA LDA CMP SBC
        g1 = {0x00: self.op_ora, 0x20: self.op_and, 0x40: self.op_eor, 0x60: self.op_adc,
              0x80: None, 0xA0: None, 0xC0: self.op_cmp, 0xE0: self.op_sbc}
        g1_modes = {0x01: "indx", 0x03: "sr", 0x05: "dp", 0x07: "indl", 0x0D: "abs", 0x0F: "long",
                    0x11: "indy", 0x12: "ind", 0x13: "sry", 0x15: "dpx", 0x17: "indly", 0x19: "absy",
                    0x1D: "absx", 0x1F: "longx"}
        for base, fn in g1.items():
            for lo, mname in g1_modes.items():
                am = modes[mname]
                if base == 0x80:
                    ops[base | lo] = (lambda am=am: self._store_m(am(), self.a))
                elif base == 0xA0:
                    def lda(am=am):
                        v = self._load_m(am())
                        self._set_acc(v)
                        self._nz_m(v)
                    ops[base | lo] = lda
                else:
                    ops[base | lo] = (lambda am=am, fn=fn: fn(self._load_m(am())))
            if base == 0xA0:
                def lda_imm():
                    v = self._imm_m()
                    self._set_acc(v)
                    self._nz_m(v)
                ops[0xA9] = lda_imm
            elif base != 0x80:
                ops[base | 0x09] = (lambda fn=fn: fn(self._imm_m()))
        # RMW: ASL ROL LSR ROR (00/20/40/60), DEC (C0), INC (E0)
        rmw = {0x00: self.f_asl, 0x20: self.f_rol, 0x40: self.f_lsr, 0x60: self.f_ror}
        for base, fn in rmw.items():
            ops[base | 0x06] = (lambda fn=fn: self.rmw(self.am_dp(), fn))
            ops[base | 0x0E] = (lambda fn=fn: self.rmw(self.am_abs(), fn))
            ops[base | 0x16] = (lambda fn=fn: self.rmw(self.am_dpx(), fn))
            ops[base | 0x1E] = (lambda fn=fn: self.rmw(self.am_absx(), fn))
            ops[base | 0x0A] = (lambda fn=fn: self.acc_rmw(fn))
        ops[0xC6] = lambda: self.rmw(self.am_dp(), self.f_dec)
        ops[0xCE] = lambda: self.rmw(self.am_abs(), self.f_dec)
        ops[0xD6] = lambda: self.rmw(self.am_dpx(), self.f_dec)
        ops[0xDE] = lambda: self.rmw(self.am_absx(), self.f_dec)
        ops[0xE6] = lambda: self.rmw(self.am_dp(), self.f_inc)
        ops[0xEE] = lambda: self.rmw(self.am_abs(), self.f_inc)
        ops[0xF6] = lambda: self.rmw(self.am_dpx(), self.f_inc)
        ops[0xFE] = lambda: self.rmw(self.am_absx(), self.f_inc)
        ops[0x1A] = lambda: self.acc_rmw(self.f_inc)
        ops[0x3A] = lambda: self.acc_rmw(self.f_dec)
        ops[0x04] = lambda: self.rmw(self.am_dp(), self.f_tsb)
        ops[0x0C] = lambda: self.rmw(self.am_abs(), self.f_tsb)
        ops[0x14] = lambda: self.rmw(self.am_dp(), self.f_trb)
        ops[0x1C] = lambda: self.rmw(self.am_abs(), self.f_trb)
        # BIT
        ops[0x24] = lambda: self.op_bit(self._load_m(self.am_dp()))
        ops[0x2C] = lambda: self.op_bit(self._load_m(self.am_abs()))
        ops[0x34] = lambda: self.op_bit(self._load_m(self.am_dpx()))
        ops[0x3C] = lambda: self.op_bit(self._load_m(self.am_absx()))
        ops[0x89] = lambda: self.op_bit(self._imm_m(), imm=True)
        # STZ
        ops[0x64] = lambda: self._store_m(self.am_dp(), 0)
        ops[0x74] = lambda: self._store_m(self.am_dpx(), 0)
        ops[0x9C] = lambda: self._store_m(self.am_abs(), 0)
        ops[0x9E] = lambda: self._store_m(self.am_absx(), 0)

        # X / Y loads, stores, compares
        def ld(reg, am):
            def f():
                ea = am()
                v = self.read(ea) if self.x8 else self.read16(ea)
                setattr(self, reg, v)
                self._nz_x(v)
            return f

        def ldi(reg):
            def f():
                v = self._imm_x()
                setattr(self, reg, v)
                self._nz_x(v)
            return f

        def st(reg, am):
            def f():
                ea = am()
                v = getattr(self, reg)
                if self.x8:
                    self.write(ea, v)
                else:
                    self.write16(ea, v)
            return f

        def cp(reg, am):
            def f():
                if am is None:
                    v = self._imm_x()
                else:
                    ea = am()
                    v = self.read(ea) if self.x8 else self.read16(ea)
                self._cmp(getattr(self, reg), v, self.x8)
            return f
        ops[0xA0], ops[0xA2] = ldi("y"), ldi("x")
        ops[0xA4], ops[0xAC], ops[0xB4], ops[0xBC] = ld("y", self.am_dp), ld("y", self.am_abs), ld("y", self.am_dpx), ld("y", self.am_absx)
        ops[0xA6], ops[0xAE], ops[0xB6], ops[0xBE] = ld("x", self.am_dp), ld("x", self.am_abs), ld("x", self.am_dpy), ld("x", self.am_absy)
        ops[0x84], ops[0x8C], ops[0x94] = st("y", self.am_dp), st("y", self.am_abs), st("y", self.am_dpx)
        ops[0x86], ops[0x8E], ops[0x96] = st("x", self.am_dp), st("x", self.am_abs), st("x", self.am_dpy)
        ops[0xC0], ops[0xC4], ops[0xCC] = cp("y", None), cp("y", self.am_dp), cp("y", self.am_abs)
        ops[0xE0], ops[0xE4], ops[0xEC] = cp("x", None), cp("x", self.am_dp), cp("x", self.am_abs)

        def incx(reg, d):
            def f():
                v = (getattr(self, reg) + d) & (0xFF if self.x8 else 0xFFFF)
                setattr(self, reg, v)
                self._nz_x(v)
            return f
        ops[0xE8], ops[0xCA], ops[0xC8], ops[0x88] = incx("x", 1), incx("x", -1), incx("y", 1), incx("y", -1)

        # branches
        ops[0x10] = lambda: self.branch(not self.p & 0x80)
        ops[0x30] = lambda: self.branch(self.p & 0x80)
        ops[0x50] = lambda: self.branch(not self.p & 0x40)
        ops[0x70] = lambda: self.branch(self.p & 0x40)
        ops[0x90] = lambda: self.branch(not self.p & 0x01)
        ops[0xB0] = lambda: self.branch(self.p & 0x01)
        ops[0xD0] = lambda: self.branch(not self.p & 0x02)
        ops[0xF0] = lambda: self.branch(self.p & 0x02)
        ops[0x80] = lambda: self.branch(True)

        def brl():
            off = self.fetch16()
            self.pc = (self.pc + (off - 0x10000 if off & 0x8000 else off)) & 0xFFFF
        ops[0x82] = brl

        # jumps / calls
        def jmp_abs():
            self.pc = self.fetch16()

        def jml():
            t = self.fetch24()
            self.pbr, self.pc = t >> 16, t & 0xFFFF

        def jmp_ind():
            p = self.fetch16()
            self.pc = self.read16(p)

        def jmp_indx():
            p = self.fetch16()
            self.pc = self.read16(self.pbr << 16 | ((p + self.x) & 0xFFFF))

        def jml_ind():
            p = self.fetch16()
            t = self.read16(p) | self.read(p + 2) << 16
            self.pbr, self.pc = t >> 16, t & 0xFFFF

        def jsr():
            t = self.fetch16()
            self.push16((self.pc - 1) & 0xFFFF)
            self.pc = t

        def jsr_indx():
            p = self.fetch16()
            self.push16((self.pc - 1) & 0xFFFF)
            self.pc = self.read16(self.pbr << 16 | ((p + self.x) & 0xFFFF))

        def jsl():
            t = self.fetch24()
            self.push8(self.pbr)
            self.push16((self.pc - 1) & 0xFFFF)
            self.pbr, self.pc = t >> 16, t & 0xFFFF

        def rts():
            self.pc = (self.pull16() + 1) & 0xFFFF

        def rtl():
            self.pc = (self.pull16() + 1) & 0xFFFF
            self.pbr = self.pull8()

        def rti():
            self.set_p(self.pull8())
            self.pc = self.pull16()
            self.pbr = self.pull8()
        ops[0x4C], ops[0x5C], ops[0x6C], ops[0x7C], ops[0xDC] = jmp_abs, jml, jmp_ind, jmp_indx, jml_ind
        ops[0x20], ops[0xFC], ops[0x22], ops[0x60], ops[0x6B], ops[0x40] = jsr, jsr_indx, jsl, rts, rtl, rti

        # stack
        def pha():
            if self.m8:
                self.push8(self.a)
            else:
                self.push16(self.a)

        def pla():
            v = self.pull8() if self.m8 else self.pull16()
            self._set_acc(v)
            self._nz_m(v)

        def phr(reg):
            def f():
                v = getattr(self, reg)
                if self.x8:
                    self.push8(v)
                else:
                    self.push16(v)
            return f

        def plr(reg):
            def f():
                v = self.pull8() if self.x8 else self.pull16()
                setattr(self, reg, v)
                self._nz_x(v)
            return f

        def plb():
            self.dbr = self.pull8()
            self.nz8(self.dbr)

        def pld():
            self.d = self.pull16()
            self.nz16(self.d)

        def pea():
            self.push16(self.fetch16())

        def pei():
            self.push16(self.read16_b0(self.d + self.fetch8()))

        def per():
            off = self.fetch16()
            self.push16((self.pc + off) & 0xFFFF)
        ops[0x48], ops[0x68] = pha, pla
        ops[0xDA], ops[0xFA], ops[0x5A], ops[0x7A] = phr("x"), plr("x"), phr("y"), plr("y")
        ops[0x8B] = lambda: self.push8(self.dbr)
        ops[0xAB] = plb
        ops[0x4B] = lambda: self.push8(self.pbr)
        ops[0x0B] = lambda: self.push16(self.d)
        ops[0x2B] = pld
        ops[0x08] = lambda: self.push8(self.p)
        ops[0x28] = lambda: self.set_p(self.pull8())
        ops[0xF4], ops[0xD4], ops[0x62] = pea, pei, per

        # flags
        ops[0x18] = lambda: setattr(self, "p", self.p & ~0x01)
        ops[0x38] = lambda: setattr(self, "p", self.p | 0x01)
        ops[0x58] = lambda: setattr(self, "p", self.p & ~0x04)
        ops[0x78] = lambda: setattr(self, "p", self.p | 0x04)
        ops[0xB8] = lambda: setattr(self, "p", self.p & ~0x40)
        ops[0xD8] = lambda: setattr(self, "p", self.p & ~0x08)
        ops[0xF8] = lambda: setattr(self, "p", self.p | 0x08)
        ops[0xC2] = lambda: self.set_p(self.p & ~self.fetch8())
        ops[0xE2] = lambda: self.set_p(self.p | self.fetch8())
        ops[0xFB] = lambda: None  # XCE: stay native
        ops[0xEA] = lambda: None
        ops[0x42] = lambda: self.fetch8()

        # transfers
        def t_to_acc(src):
            def f():
                v = getattr(self, src)
                if self.m8:
                    self.a = (self.a & 0xFF00) | (v & 0xFF)
                    self.nz8(v)
                else:
                    self.a = v & 0xFFFF
                    self.nz16(v)
            return f

        def t_to_idx(src, dst):
            def f():
                v = getattr(self, src)
                if self.x8:
                    v &= 0xFF
                setattr(self, dst, v)
                self._nz_x(v)
            return f
        ops[0x8A], ops[0x98] = t_to_acc("x"), t_to_acc("y")
        ops[0xAA], ops[0xA8] = t_to_idx("a", "x"), t_to_idx("a", "y")
        ops[0x9B], ops[0xBB] = t_to_idx("x", "y"), t_to_idx("y", "x")
        ops[0xBA] = t_to_idx("s", "x")

        def txs():
            self.s = self.x

        def tcs():
            self.s = self.a

        def tsc():
            self.a = self.s
            self.nz16(self.a)

        def tcd():
            self.d = self.a
            self.nz16(self.d)

        def tdc():
            self.a = self.d
            self.nz16(self.a)

        def xba():
            self.a = ((self.a >> 8) | (self.a << 8)) & 0xFFFF
            self.nz8(self.a & 0xFF)
        ops[0x9A], ops[0x1B], ops[0x3B], ops[0x5B], ops[0x7B], ops[0xEB] = txs, tcs, tsc, tcd, tdc, xba

        # block moves
        def mv(step):
            def f():
                dst = self.fetch8()
                src = self.fetch8()
                self.dbr = dst
                while True:
                    self.write(dst << 16 | self.y, self.read(src << 16 | self.x))
                    self.x = (self.x + step) & (0xFF if self.x8 else 0xFFFF)
                    self.y = (self.y + step) & (0xFF if self.x8 else 0xFFFF)
                    self.a = (self.a - 1) & 0xFFFF
                    if self.a == 0xFFFF:
                        break
            return f
        ops[0x54], ops[0x44] = mv(1), mv(-1)

        def bad():
            raise CpuError(f"unsupported opcode at ${self.pbr:02X}{(self.pc - 1) & 0xFFFF:04X}")
        for i in range(256):
            if ops[i] is None:
                ops[i] = bad
        ops[0x00] = ops[0x02] = ops[0xDB] = ops[0xCB] = bad
        self.ops = ops

    # ------------------------------------------------------------ running
    def call(self, addr: int, long: bool = False, max_steps: int = 2_000_000) -> None:
        """Call the routine at 24-bit addr as JSR (same bank, ends with RTS) or JSL (RTL).
        Returns when the routine returns to our sentinel."""
        self.pbr = addr >> 16
        sentinel_s = self.s
        if long:
            self.push8(0x00)
            self.push16(0xFFFE)  # returns to $00:FFFF
            stop = (0x00, 0xFFFF)
        else:
            self.push16(0xFFFE)  # returns to $bb:FFFF
            stop = (self.pbr, 0xFFFF)
        self.pc = addr & 0xFFFF
        ops = self.ops
        n = 0
        while True:
            if self.pc == stop[1] and self.pbr == stop[0] and self.s == sentinel_s:
                return
            if self.trace is not None:
                self.trace(self)
            op = self.fetch8()
            ops[op]()
            n += 1
            if n > max_steps:
                raise CpuError(f"routine ${addr:06X} did not return (pc ${self.pbr:02X}{self.pc:04X})")
