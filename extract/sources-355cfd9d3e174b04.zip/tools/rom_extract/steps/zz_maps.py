"""Last extraction step: compile every map source (content/maps/*.py) with tools/mapgen, and
draw the stamp contact sheets (game/assets/rom/maps/stamps/). Owned by MAPTOOLS."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "tools" / "mapgen"))


def run(rom, out: Path) -> dict:
    import data as D
    D.set_assets(out)
    D.set_rom(rom)
    import build
    import options
    import stamps
    info = {}
    if options.PREVIEWS:
        try:
            stamps.sheets()
            info["stamps"] = len(stamps.names())
        except Exception as e:  # sheets are a convenience: never block the extraction
            print(f"  zz_maps : planches de tampons non produites ({e})")
    rep = build.build(None, quiet=True, preview=options.PREVIEWS)
    info["maps"] = rep["built"]
    if rep["errors"]:
        info["errors"] = rep["errors"]
        for mid, errs in rep["errors"].items():
            for e in errs:
                print(f"  carte {mid} : {e}")
    return info
