"""Extraction step: all music and sound effects of the original game.

The sound driver (N-SPC) data is uploaded from the ROM to the SPC700's 64 KiB RAM in
transfer blocks (size, ARAM address, bytes...). We rebuild the three RAM images the game
uses (overworld, underworld and credits song banks, see jpdasm resources/music.txt) and
hand them to tools/spc_render (C, zelda3's MIT sound driver + S-DSP emulation), which plays
one song / one sound effect and writes the audio:

  game/assets/rom/audio/music/<id>.qoa   QOA (played natively by Godot's AudioStreamWAV)
  game/assets/rom/audio/sfx/<id>.wav     16-bit PCM
  game/assets/rom/audio/catalog.json     id -> file, duration, loop points (in frames)

Only this step:  python3 tools/rom_extract/run_step.py audio
Docs: docs/tech/AUDIO.md
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import native
from rom import A

ROOT = Path(__file__).resolve().parents[3]
RENDER_DIR = ROOT / "tools" / "spc_render"
RENDER_BIN = RENDER_DIR / "build" / "spc_render"
RATE = 32000
VERSION = 1
# Music container: "qoa" (default, ~1/5 of PCM, ~34-40 dB SNR) or "wav" (lossless 16-bit PCM,
# about 210 MB): ZELDA3_MUSIC_FORMAT=wav python3 tools/rom_extract/run_step.py audio
MUSIC_EXT = "wav" if os.environ.get("ZELDA3_MUSIC_FORMAT", "").lower() == "wav" else "qoa"

# SNES addresses (JP 1.0) of the SPC transfer chains (jpdasm resources/music.txt).
UPLOAD_BASE = A(0x198000)       # samples, instruments, engine, SFX, overworld songs
UPLOAD_UNDERWORLD = A(0x1B8000)  # replaces the song banks at $D000 / $2B00
UPLOAD_CREDITS = A(0x1AD380)     # replaces the song banks at $D000 / $2900

# Contract ids (docs/tech/CONTRACT.md §7), in the game's song-number order (1..34).
# (id, bank, original name)
MUSIC = [
    ("title", "ow", "Triforce opening"),
    ("overworld", "ow", "Light World"),
    ("rain", "ow", "Rain (beginning)"),
    ("bunny", "ow", "Bunny Link"),
    ("forest", "ow", "Lost Woods"),
    ("legend", "ow", "Legend theme (attract mode)"),
    ("village", "ow", "Kakariko Village"),
    ("warp", "ow", "Mirror warp"),
    ("dark_world", "ow", "Dark World"),
    ("sacred_sword", "ow", "Restoring the Master Sword"),
    ("file_select", "ow", "Fairy theme (file select)"),
    ("chase", "ow", "Chase theme (soldiers)"),
    ("dark_mountain", "ow", "Skull Woods / Dark Death Mountain"),
    ("minigame", "ow", "Game theme (shops, minigames)"),
    ("intro_theme", "ow", "Intro (no Triforce)"),
    ("castle", "uw", "Hyrule Castle"),
    ("dungeon", "uw", "Light World dungeon"),
    ("cave", "uw", "Caves"),
    ("fanfare", "uw", "Fanfare (pendant, crystal...)"),
    ("sanctuary", "uw", "Sanctuary"),
    ("boss", "uw", "Boss battle"),
    ("dungeon_dark", "uw", "Dark World dungeon"),
    ("fortune", "uw", "Fortune teller"),
    ("cave_secret", "uw", "Caves (secret passage)"),
    ("princess", "uw", "Zelda rescue"),
    ("crystal", "uw", "Crystal theme"),
    ("fairy_fountain", "uw", "Fairy fountain (arpeggio)"),
    ("villain", "uw", "Pre-Agahnim theme"),
    ("villain_escape", "uw", "Agahnim defeated / escape"),
    ("pre_final", "uw", "Pre-Ganon theme"),
    ("final_boss", "uw", "Ganon (Ganondorf the Thief)"),
    ("triforce_room", "cr", "Triforce room"),
    ("ending", "cr", "Grabbing the Triforce and epilogue"),
    ("credits", "cr", "Credits (staff roll)"),
]

# Sound effect names from jpdasm resources/sfx.txt. Port 1 = $012D (ambient, 2 channels),
# port 2 = $012E, port 3 = $012F. None = empty slot.
SFX1 = [
    "Rain / Zora area", "Rain / Zora area (2nd channel)", "Rain", "Rain (2nd channel)",
    None, None, "The rumbling", "The rumbling (2nd channel)", "Wind", "Wind (2nd channel)",
    "Flute song by flute boy", "Flute song by flute boy (2nd channel)", "Magic jingle",
    "Magic jingle (2nd channel)", "Crystal / save and quit", "Crystal / save and quit (2nd channel)",
    "Choir melody", "Choir countermelody", "Large boss swoosh", "Large boss swoosh (2nd channel)",
    "Triforce door / pyramid hole opening", "Vomp", "Flute song for weathervane",
    "Flute song for weathervane (2nd channel)",
]
SFX2 = [
    "Slash (fighter sword)", "Slash (master sword)", "Slash (tempered sword)", "Slash (gold sword)",
    "Clink", "Shield clink / bombable door", "Fwoosh", "Arrow smash", "Boomerang", "Hookshot clink",
    "Placing bomb", "Explosion", "Powder", "Fire rod shot", "Ice rod shot", "Hammer use",
    "Hammering peg", "Digging", "Flute", "Cape on", "Cape off / wallmaster grab", "Staircase",
    "Staircase 2", "Staircase 3", "Staircase 4", "Tall grass / hammer hitting bush",
    "Shallow water", "Mire shallow water", "Lifting object", "Cutting grass", "Item breaking",
    "Link jumping / item falling in pit", "Bomb hitting ground / thud", "Pushing object",
    "Boots dust", "Splashing", "Mire shallow water 2", "Link taking damage", "Fainting",
    "Item splash", "Rupee refill", "Fire splash / Bombos", "Heart beep / text box",
    "Sword up", "Magic drain", "GT opening", "GT opening / water drain", "Cucco", "Fairy",
    "Bug net", "Teleport", "Teleport 2", "Shaking", "Mire entrance", "Spin charged",
    "Water sound", "Thunder", "Sword up 2", "Rupee refill 2", "Error beep", "Big splash",
    "Flute 2", "Powder 2",
]
SFX3 = [
    "Sword beam", "TR opening", "Bonk / pyramid hole", "Angry soldier", "Lynel shot / javelin",
    "Swoosh", "Cannon fire", "Damage to enemy", "Enemy death", "Collecting rupee",
    "Collecting heart", "Text character", "HUD heart", "Opening chest", "Item get jingle",
    "Map", "Opening item menu", "Closing item menu", "Throwing object", "Key door",
    "Door / chest", "Armos Knight thud", "Rat squeak", "Dragging", "Fireball / laser shot",
    "Chest reveal jingle", "Puzzle solved jingle", "Damage to enemy 2", "Magic meter",
    "Wing flapping", "Link falling", "Menu / text cursor", "Damage to boss", "Boss dying",
    "Spin attack", "Text done / map change", "Pressure switch", "Lightning / game over",
    "Agahnim charge", "Agahnim / Ganon teleport", "Agahnim shot", "Somaria / Byrna / Ether",
    "Electrocution", "Bees", "Milestone jingle", "Heart container jingle", "Key jingle",
    "Magic zap / plop", "Sprite falling", "Boing", "Key jingle 2", "Heart container jingle 2",
    "Heart container jingle 3", "Magic attack", "Milestone jingle 2", "Chest reveal jingle 2",
    "Swish", "Puzzle jingle 2", "Map 2", "Item jingle 2", "Item jingle 3", "Item jingle 4",
    "Item jingle 5",
]

# Stable ids used by the engine (CONTRACT §7) and extras -> (port, index).
# Identified from zelda3's src/*.c (who writes which value to $012E/$012F) and sfx.txt.
SFX_ALIASES = {
    "sword_swing": (2, 0x01),     # HandleSwordSfxAndBeam, kFireBeamSounds[fighter sword]
    "sword_tink": (2, 0x05),      # Sprite_PlaceWeaponTink
    "sword_hit": (3, 0x08),       # Sprite_GiveDamage (ordinary enemy)
    "enemy_hit": (3, 0x08),
    "enemy_hit_alt": (3, 0x1C),   # Sprite_GiveDamage (flags5 & 0x10 enemies)
    "enemy_die": (3, 0x09),
    "hero_hurt": (2, 0x26),       # Link_ControlHandler
    "hero_die": (2, 0x27),        # Death_PrepFaint
    "low_health": (2, 0x2B),      # Hud_RefillLogic heart beep
    "item_get": (3, 0x0F),        # Ancilla22_ItemReceipt (chains 3C-3F)
    "small_item": (3, 0x0B),      # kAbsorptionSfx (hearts, bombs, arrows, magic)
    "rupee": (3, 0x0A),
    "heart": (3, 0x0B),
    "heart_refill": (3, 0x0D),    # HUD heart filling
    "key": (3, 0x2F),             # kAbsorptionSfx (keys)
    "chest_open": (3, 0x0E),      # OpenChestForItem
    "door_open": (3, 0x15),       # OperateShutterDoors, Overworld_UseEntrance
    "door_unlock": (3, 0x14),     # key door
    "stairs": (2, 0x16),
    "text_letter": (3, 0x0C),     # VWF_RenderSingle
    "text_done": (3, 0x24),       # RenderText_Draw_Terminate / Waitkey
    "menu_cursor": (3, 0x20),
    "menu_select": (2, 0x2B),     # RenderText_Draw_Choose*
    "menu_open": (3, 0x11),       # Hud_ClearTileMap
    "menu_close": (3, 0x12),
    "bomb_place": (2, 0x0B),
    "explosion": (2, 0x0C),
    "lift": (2, 0x1D),            # Ancilla_HandleLiftLogic
    "throw": (3, 0x13),           # CarriedSprite_CheckForThrow
    "shatter": (2, 0x1F),         # item breaking
    "bush_cut": (2, 0x1E),
    "grass": (2, 0x1A),
    "arrow_shoot": (2, 0x07),     # AncillaAdd_Arrow
    "arrow_hit": (2, 0x08),       # Ancilla09_Arrow
    "boomerang": (2, 0x09),       # Ancilla05_Boomerang
    "hookshot": (2, 0x0A),
    "hammer": (2, 0x10),
    "fire_rod": (2, 0x0E),
    "ice_rod": (2, 0x0F),
    "fall": (3, 0x1F),            # LinkState_Pits
    "splash": (2, 0x24),          # Sprite_SpawnBigSplash
    "splash_small": (2, 0x28),
    "secret": (3, 0x1B),          # Overworld_RevealSecret, puzzles
    "spin_charge": (2, 0x37),     # Player_Sword_SpinAttackJerks_HoldDown
    "spin_attack": (3, 0x23),     # LinkState_SpinAttack
    "sword_beam": (3, 0x01),
    "error": (2, 0x3C),
    "shield_block": (2, 0x06),    # Sprite_CheckDamageToLink (deflected)
    "jump": (2, 0x20),            # LinkHop_*
    "land": (2, 0x21),
    "heart_container": (3, 0x2E), # Link_ReceiveItem
    "heart_piece": (3, 0x2D),     # Sprite_HeartPiece (milestone jingle)
    "fairy": (2, 0x31),
    "boss_hit": (3, 0x21),        # Sprite_GiveDamage (boss flag)
    "boss_die": (3, 0x22),
    "warp": (2, 0x33),            # Mirror_SaveRoomData
    "push": (2, 0x22),            # InitializePushBlock
    "switch": (3, 0x25),          # RoomTag_SwitchTrigger_*
    "magic": (3, 0x2A),           # Somaria / Byrna / Ether
    "torch_light": (2, 0x2A),     # Dungeon_LightTorch (fire splash)
    "magic_refill": (2, 0x2D),    # Hud_RefillLogic
    "rupee_refill": (2, 0x29),
    "chest_reveal": (3, 0x1A),
    "bonk": (3, 0x03),
    "dash": (2, 0x23),
    "swim": (2, 0x25),
    "soldier_alert": (3, 0x04),
    "cucco": (2, 0x30),
    "map_open": (3, 0x10),
    "lightning": (3, 0x26),
    "laser": (3, 0x19),
    "flute": (2, 0x13),
    "sword_up": (2, 0x2C),
    "thud": (2, 0x21),
    "save_quit": (1, 0x0F),       # crystal / save and quit (port 1 pair)
    "magic_jingle": (1, 0x0D),
}

# Looping ambient sounds (port 1 pairs whose two channels loop with different periods are
# kept as two layers the player starts together).
AMBIENT = {
    "ambient_rain": 0x01,
    "ambient_rain_light": 0x03,
    "ambient_rumble": 0x07,
    "ambient_wind": 0x09,
    "ambient_flute_boy": 0x0B,
}


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")


def _sfx_id(port: int, idx: int, name: str) -> str:
    return f"sfx{port}_{idx:02x}_{_slug(name)}"


def build_aram(rom, chains: list[int]) -> bytes:
    """Apply SPC transfer chains (size, dest, data..., terminated by size 0) to a 64 KiB RAM."""
    ram = bytearray(65536)
    for addr in chains:
        o = rom.pc(addr)
        data = rom.data
        for _ in range(64):
            n = data[o] | data[o + 1] << 8
            dest = data[o + 2] | data[o + 3] << 8
            o += 4
            if n == 0:
                break
            if dest + n > 65536:
                raise ValueError(f"transfer ${addr:06X}: block ${dest:04X}+{n} overflows ARAM")
            ram[dest:dest + n] = data[o:o + n]
            o += n  # LoROM banks are contiguous in the file
    return bytes(ram)


_exe: Path = RENDER_BIN


def ensure_renderer() -> Path:
    """tools/spc_render, built if needed (in the browser: the WebAssembly build, native.py)."""
    global _exe
    _exe = native.binary("spc_render", _build_renderer)
    return _exe


def _build_renderer() -> Path:
    """Build tools/spc_render if needed (needs a C compiler and make)."""
    if shutil.which("make") is None or (shutil.which("cc") is None and shutil.which("gcc") is None):
        raise RuntimeError(
            "audio : 'make' et un compilateur C (gcc/cc) sont nécessaires pour produire la "
            "musique (tools/spc_render). Installez-les (ex. « sudo apt install build-essential ») "
            "puis relancez : python3 tools/rom_extract/run_step.py audio")
    r = subprocess.run(["make", "-s", "-C", str(RENDER_DIR)], capture_output=True, text=True)
    if r.returncode != 0 or not RENDER_BIN.exists():
        raise RuntimeError(f"audio : échec de compilation de tools/spc_render :\n{r.stdout}{r.stderr}")
    return RENDER_BIN


def _render(args: list[str], bank: Path, out: Path) -> dict:
    """spc_render <args> (reads the ARAM image `bank`, writes `out`)."""
    r = native.run(_exe, args, inputs=[bank], outputs=[out])
    if r.returncode != 0:
        raise RuntimeError(f"spc_render {' '.join(args)} : {r.stderr.strip()}")
    return native.last_json_line(r.stdout)


def run(rom, out: Path) -> dict:
    out = Path(out)
    try:
        ensure_renderer()
        return _run(rom, out)
    except (RuntimeError, OSError, ValueError) as e:
        # Never break the whole extraction: the game runs without sound (Audio warns).
        print(f"  ATTENTION {e}", file=sys.stderr)
        return {"error": str(e)}


def _run(rom, out: Path) -> dict:

    adir = out / "audio"
    if adir.exists():
        shutil.rmtree(adir)
    (adir / "music").mkdir(parents=True)
    (adir / "sfx").mkdir(parents=True)

    catalog: dict = {"version": VERSION, "rate": RATE, "music": {}, "sfx": {}}
    with tempfile.TemporaryDirectory(prefix="zelda3_2_audio_") as tmp:
        tmp = Path(tmp)
        banks = {
            "ow": build_aram(rom, [UPLOAD_BASE]),
            "uw": build_aram(rom, [UPLOAD_BASE, UPLOAD_UNDERWORLD]),
            "cr": build_aram(rom, [UPLOAD_BASE, UPLOAD_CREDITS]),
        }
        bank_files = {}
        for k, v in banks.items():
            bank_files[k] = tmp / f"aram_{k}.bin"
            bank_files[k].write_bytes(v)
        base_ram = banks["ow"]

        def word(ram, a):
            return ram[a] | ram[a + 1] << 8

        # ---- music -------------------------------------------------------------------
        jobs = []
        seen_ptr: dict[tuple, str] = {}
        aliases = {}
        for num, (mid, bank, name) in enumerate(MUSIC, 1):
            ptr = word(banks[bank], 0xD000 + (num - 1) * 2)
            key = (bank, ptr)
            if key in seen_ptr:  # e.g. song 0x18 plays the same data as 0x12 (caves)
                aliases[mid] = seen_ptr[key]
                continue
            seen_ptr[key] = mid
            jobs.append((num, mid, bank, name))

        def do_music(job):
            num, mid, bank, name = job
            dest = adir / "music" / f"{mid}.{MUSIC_EXT}"
            info = _render(["music", str(bank_files[bank]), str(num), str(dest)], bank_files[bank], dest)
            return job, info

        music_results = native.pmap(do_music, jobs)
        for (num, mid, bank, name), info in music_results:
            catalog["music"][mid] = {
                "file": f"music/{mid}.{MUSIC_EXT}", "format": MUSIC_EXT, "song": num, "name": name,
                "frames": info["frames"], "duration": round(info["frames"] / RATE, 3),
                "loop": info["loop"], "loop_begin": info["loop_begin"], "loop_end": info["loop_end"],
            }
            if not info["loop"] and info["song_end"] >= 0:
                # where the song data ends (the file also keeps the release/echo tail)
                catalog["music"][mid]["song_end"] = info["song_end"] - info["lead_in"]
        for mid, src in aliases.items():
            num = [i for i, m in enumerate(MUSIC, 1) if m[0] == mid][0]
            catalog["music"][mid] = dict(catalog["music"][src], song=num,
                                         name=MUSIC[num - 1][2], alias_of=src)
        catalog["music"] = {m[0]: catalog["music"][m[0]] for m in MUSIC}

        # ---- sound effects -----------------------------------------------------------
        tables = {1: (SFX1, 0x17C0), 2: (SFX2, 0x1820), 3: (SFX3, 0x191C)}
        sfx_jobs = []
        by_index: dict[tuple, str] = {}
        for port, (names, table) in tables.items():
            for i, name in enumerate(names, 1):
                if name is None or word(base_ram, table + (i - 1) * 2) == 0:
                    continue
                sid = _sfx_id(port, i, name)
                by_index[(port, i)] = sid
                sfx_jobs.append((sid, port, i, name, False))

        def do_sfx(job):
            sid, port, i, name, no_pair = job
            dest = adir / "sfx" / f"{sid}.wav"
            args = ["sfx", str(bank_files["ow"]), str(port), str(i), str(dest)]
            if no_pair:
                args.append("--no-pair")
            return job, _render(args, bank_files["ow"], dest)

        sfx_results = native.pmap(do_sfx, sfx_jobs)

        # Port-1 loops whose channels drift apart: split into single-channel layers.
        layer_jobs = []
        for (sid, port, i, name, _), info in sfx_results:
            if port == 1 and info["loop"] and info["loop_mismatch"]:
                layer_jobs.append((f"{sid}_ch7", port, i, name + " (layer 1)", True))
                pair = base_ram[0x1800 + i - 1]
                if pair and (1, pair) in by_index:
                    layer_jobs.append((f"{sid}_ch6", port, pair, name + " (layer 2)", True))
        layer_results = native.pmap(do_sfx, layer_jobs)

        for (sid, port, i, name, no_pair), info in sfx_results + layer_results:
            e = {
                "file": f"sfx/{sid}.wav", "format": "wav", "port": port, "index": i, "name": name,
                "frames": info["frames"], "duration": round(info["frames"] / RATE, 3),
                "loop": info["loop"], "loop_begin": info["loop_begin"], "loop_end": info["loop_end"],
            }
            if info["peak"] == 0:
                e["silent"] = True
            catalog["sfx"][sid] = e
        for (sid, port, i, name, _), info in sfx_results:
            if port == 1 and info["loop"] and info["loop_mismatch"]:
                layers = [f"{sid}_ch7"] + ([f"{sid}_ch6"] if f"{sid}_ch6" in catalog["sfx"] else [])
                catalog["sfx"][sid]["layers"] = layers

        for alias, (port, i) in list(SFX_ALIASES.items()) + [(a, (1, i)) for a, i in AMBIENT.items()]:
            src = by_index[(port, i)]
            catalog["sfx"][alias] = dict(catalog["sfx"][src], alias_of=src)

    with open(adir / "catalog.json", "w") as f:
        json.dump(catalog, f, indent=1)
    total = sum(p.stat().st_size for p in adir.rglob("*") if p.is_file())
    n_orig = sum(1 for v in catalog["sfx"].values() if "alias_of" not in v)
    return {
        "music": len(catalog["music"]),
        "music_seconds": round(sum(v["duration"] for k, v in catalog["music"].items() if "alias_of" not in v)),
        "sfx": n_orig,
        "sfx_aliases": len(catalog["sfx"]) - n_orig,
        "bytes": total,
    }
