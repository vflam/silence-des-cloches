"""Extraction step: every original underworld room (0x000-0x127) as tile8 screens.

Output (game/assets/rom/underworld/, see docs/tech/INTERIORS.md):
  rooms/<id>.json    bg / fg / types grids (64x64), doors, stairs, original chests & sprites
  tilesets/<id>.png  atlases (8 palette rows x 512 tiles) for each graphics/palette combination
  previews/<id>.png  each room drawn; previews/index.png contact sheet
  rooms.json         index: id -> name, category, dungeon, tileset, size, doors
"""
import json
import sys
from collections import Counter, deque
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import options  # noqa: E402
import underworld_build as B  # noqa: E402
import underworld_names as N  # noqa: E402
import underworld_render as UR  # noqa: E402
import underworld_rom as U  # noqa: E402
from rom import Rom  # noqa: E402

# Stair-like room objects (ids as in underworld_rom.decode_object) -> (kind, direction)
STAIR_OBJECTS = {
    0x021: ("mini_stairs", ""),
    0xF9B: ("inroom_stairs", ""), 0xF9C: ("inroom_stairs_layer", "down"),
    0xF9D: ("inroom_stairs_wet", "down"), 0xFB3: ("inroom_stairs_submerged", "down"),
    0xF9E: ("spiral_stairs", "up"), 0xF9F: ("spiral_stairs", "down"),
    0xFA0: ("spiral_stairs", "up"), 0xFA1: ("spiral_stairs", "down"),
    0xFA6: ("spiral_stairs", "up"), 0xFA7: ("spiral_stairs", "up"),
    0xFA8: ("spiral_stairs", "down"), 0xFA9: ("spiral_stairs", "down"),
    0xFAB: ("spiral_stairs", "down"),
    0x12D: ("floor_stairs", "up"), 0x12E: ("floor_stairs", "down"), 0x12F: ("floor_stairs", "down"),
    0x130: ("inroom_stairs_north", "up"), 0x131: ("inroom_stairs_north", "up"),
    0x132: ("inroom_stairs_north", "up"), 0x133: ("inroom_stairs_north_submerged", "up"),
    0x135: ("water_ladder", ""), 0x136: ("water_ladder", ""),
    0x138: ("straight_stairs", "up"), 0x139: ("straight_stairs", "down"),
    0x13A: ("straight_stairs", "up"), 0x13B: ("straight_stairs", "down"),
}
INTER_ROOM = {"spiral_stairs", "floor_stairs", "straight_stairs"}
TWO_LEVEL_COLLISIONS = (1, 2)


def write_json(path: Path, data, compact=True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        if compact:
            json.dump(data, f, separators=(",", ":"), ensure_ascii=False)
        else:
            json.dump(data, f, indent=1, ensure_ascii=False)


def room_mains(rom: Rom, headers: dict, ents: list, dmap: dict) -> dict[int, int]:
    """Main tile theme of each room. The game takes it from the entrance used (EntranceData
    .main_GFX); rooms of a dungeon share their entrances' theme; other rooms: aux = main."""
    by_room: dict[int, Counter] = {}
    by_dungeon: dict[int, Counter] = {}
    for e in ents:
        by_room.setdefault(e["room"], Counter())[e["main"]] += 1
        if e["dungeon"] != 0xFF:
            by_dungeon.setdefault(e["dungeon"] // 2, Counter())[e["main"]] += 1
    out = {}
    for room in range(U.NUM_ROOMS):
        aux = headers[room]["blockset"]
        cands = by_room.get(room)
        if not cands and room in dmap:
            cands = by_dungeon.get(dmap[room][0])
        if cands:
            out[room] = aux if aux in cands else cands.most_common(1)[0][0]
        else:
            out[room] = aux if aux < 0x20 else 0
    return out


def stairs_of(objs_layers, header: dict) -> list[dict]:
    out = []
    dests = [d[0] for d in header["stair_dests"]]
    inter = 0
    for layer, (objs, _doors) in enumerate(objs_layers):
        for o in objs:
            ob = U.decode_object(o)
            k = STAIR_OBJECTS.get(ob["id"])
            if not k:
                continue
            s = {"x": ob["x"], "y": ob["y"], "kind": k[0], "layer": layer + 1}
            if k[1]:
                s["dir"] = k[1]
            if k[0] in INTER_ROOM:
                if inter < 4:
                    s["to"] = dests[inter]
                inter += 1
            out.append(s)
    return out


def chests_of(state: bytes, items: list) -> list[dict]:
    """dung_chest_locations ($06E0): tilemap offset * 2, $8000 = big chest, $2000/$1000 = BG1."""
    out, n = [], 0
    for i in range(6):
        v = B._w(state, 0x6E0 + i * 2)
        if not v:
            continue
        pos = (v & 0x1FFF) >> 1
        c = {"x": pos % 64, "y": pos // 64, "big": bool(v & 0x8000)}
        if n < len(items):
            c["item"], c["big"] = items[n][0], items[n][1] or c["big"]
        n += 1
        out.append(c)
    for item, big in items[n:]:  # chests revealed by events have no position until drawn
        out.append({"item": item, "big": big, "hidden": True})
    return out


_NOT_WALK = np.array([UR.type_class(t) == "wall" for t in range(256)])


def used_quadrants(types: np.ndarray, seeds: list[tuple[int, int]]) -> list[int]:
    """256x256 quadrants (0 NW, 1 NE, 2 SW, 3 SE) reached by a flood fill over non-wall tiles
    from the doors / stairs / chests of the room."""
    g = _NOT_WALK[types.reshape(64, 64)]
    seen = np.zeros((64, 64), bool)
    q = deque()
    for x, y in seeds:
        for dx in range(-2, 4):
            for dy in range(-2, 4):
                xx, yy = x + dx, y + dy
                if 0 <= xx < 64 and 0 <= yy < 64 and not g[yy, xx] and not seen[yy, xx]:
                    seen[yy, xx] = True
                    q.append((xx, yy))
    while q:
        x, y = q.popleft()
        for xx, yy in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= xx < 64 and 0 <= yy < 64 and not g[yy, xx] and not seen[yy, xx]:
                seen[yy, xx] = True
                q.append((xx, yy))
    return [i for i in range(4) if seen[(i // 2) * 32 + 4:(i // 2) * 32 + 28, (i % 2) * 32 + 4:(i % 2) * 32 + 28].sum() > 8]


def contact_sheet(out: Path, ids: list[int], names: dict[int, str]) -> None:
    cell, label, cols = 128, 12, 16
    rows = (len(ids) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell, rows * (cell + label)), (24, 24, 24))
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 9)
    except OSError:
        font = None
    for i, rid in enumerate(ids):
        x, y = (i % cols) * cell, (i // cols) * (cell + label)
        im = Image.open(out / "previews" / f"{rid:03x}.png").convert("RGB").resize((cell, cell), Image.NEAREST)
        sheet.paste(im, (x, y + label))
        d.text((x + 2, y), f"{rid:03X} {names[rid][:18]}", fill=(255, 255, 160), font=font)
    sheet.save(out / "previews" / "index.png", optimize=True)


def run(rom: Rom, out: Path) -> dict:
    out = out / "underworld"
    for sub in ("rooms", "tilesets") + (("previews",) if options.PREVIEWS else ()):
        (out / sub).mkdir(parents=True, exist_ok=True)

    raw = B.run_harness(rom)
    headers = {r: U.decode_header(U.room_header(rom, r)) for r in range(U.NUM_ROOMS)}
    ents = U.entrances(rom)
    dmap = U.dungeon_map_rooms(rom)
    mains = room_mains(rom, headers, ents, dmap)
    chest_items = U.chests(rom)
    ents_by_room: dict[int, list] = {}
    for e in ents:
        ents_by_room.setdefault(e["room"], []).append(e["index"])

    tilesets: dict[str, dict] = {}
    sig_names: dict[tuple, str] = {}
    banks: dict[tuple, tuple] = {}
    index = {}
    stats = Counter()

    for room in range(U.NUM_ROOMS):
        h = headers[room]
        aux, main = h["blockset"], mains[room]
        bg_pal = U.palette_set(rom, h["palette"])[0] >> 1
        sig = B.gfx_signature(rom, main, aux)
        if sig not in banks:
            bank = B.tile_bank(rom, main, aux)
            banks[sig] = (bank, B.empty_tiles(bank), B.opaque_tiles(bank))
        bank, empty, opaque = banks[sig]
        # Name the graphics by the aux blockset; "m<main>" only when the main theme changes tiles.
        gname = sig_names.get(sig)
        if gname is None:
            base = f"{aux:02x}" if B.gfx_signature(rom, aux if aux < 0x20 else main, aux) == sig else f"{aux:02x}m{main:02x}"
            gname = base
            while gname in sig_names.values():
                gname += "b"
            sig_names[sig] = gname
        ts_id = f"uw_{gname}_{bg_pal:02x}"
        if ts_id not in tilesets:
            B.atlas_pixels(bank, B.dungeon_cgram(rom, bg_pal)).save(out / "tilesets" / f"{ts_id}.png", optimize=True)
            tilesets[ts_id] = {"main": main, "blockset": aux, "bg_palette": bg_pal, "sheets": list(sig[:8]),
                               "anim_sheet": sig[8], "rooms": []}
        tilesets[ts_id]["rooms"].append(room)

        r = raw[room]
        bg, fg, lossy = B.merge_layers(r["bg2"], r["bg1"], h["bg2"], empty, opaque)
        types = r["attr"][:4096]
        two_level = h["collision"] in TWO_LEVEL_COLLISIONS or h["bg2"] == 3
        layout = {
            "id": 0, "bg_mode": B.BG_MODES[h["bg2"]], "collision": B.COLLISIONS[min(h["collision"], 4)],
            "two_levels": two_level, "lights_out": bool(h["lights_out"]), "merge_lossy_cells": lossy,
        }
        ro = U.room_objects(rom, room)
        if ro:
            layout["id"] = ro[1] >> 2
            layout["start_quadrant"] = ro[1] & 3
            layout["floor1"], layout["floor2"] = ro[0] & 0xF, ro[0] >> 4

        # names / roles
        dung = dmap.get(room)
        dung_id = N.DUNGEONS_FR[dung[0]][0] if dung else ""
        roles = []
        if room in ents_by_room:
            roles.append("entrance")
        if room in N.BOSS_ROOMS:
            roles.append("boss")
        items = chest_items.get(room, [])
        if any(big for _, big in items):
            roles.append("big_chest")
        if room in N.MISC:
            category, name = N.MISC[room]
        elif dung:
            category = "dungeon"
            dname = N.DUNGEONS_FR[dung[0]][1]
            role_txt = N.SPECIAL.get(room, (None, None))[1]
            if not role_txt:
                bits = []
                if "boss" in roles:
                    bits.append(f"boss ({N.BOSS_ROOMS[room]})")
                if "big_chest" in roles:
                    bits.append("grand coffre")
                if "entrance" in roles and not bits:
                    bits.append("entrée")
                role_txt = ", ".join(bits) or f"salle {room:03X}"
            name = f"{dname} – {role_txt}"
        elif room in N.SPECIAL:
            category = "dungeon" if N.SPECIAL[room][0] in ("ganon",) else "cave"
            name = N.SPECIAL[room][1]
        else:
            category, name = "unused", f"Salle {room:03X} (inutilisée)"
        if room in (0x00, 0x10):
            dung_id = "ganons_pyramid"
        if category == "unused" and room in ents_by_room:
            category = "cave"

        doors = B.room_doors(r["state"])
        stairs = stairs_of(ro[2], h) if ro else []
        sprites = U.room_sprites(rom, room)
        data = {
            "id": room, "name": name, "category": category, "dungeon": dung_id,
            "blockset": aux, "main": main, "palette": h["palette"], "bg_palette": bg_pal,
            "layout": layout,
            "tileset": ts_id,
            "bg": bg.tolist(), "fg": fg.tolist(), "types": types.tolist(),
            "doors": [{k: d[k] for k in ("dir", "x", "y", "kind", "type", "lower")} for d in doors],
            "stairs": stairs,
            "original": {
                "name": name,
                "roles": roles,
                "chests": chests_of(r["state"], items),
                "sprites": sprites,
                "pots": [{"x": x, "y": y, "item": it} for x, y, it in U.pot_items(rom, room)],
                "entrances": ents_by_room.get(room, []),
                "header": h,
                "dungeon_map": list(dung) if dung else None,
            },
        }
        if two_level:
            data["types_lower"] = r["attr"][4096:].tolist()
        if h["bg2"] in (4, 7) or (lossy and h["bg2"] != 0):
            data["layers"] = {"bg2": r["bg2"].tolist(), "bg1": r["bg1"].tolist()}

        if options.PREVIEWS:
            UR.render_words(data["bg"], ts_id, fg=data["fg"], base=out).save(out / "previews" / f"{room:03x}.png", optimize=True)
        seeds = [(d["x"], d["y"]) for d in doors] + [(st["x"], st["y"]) for st in stairs] \
            + [(c["x"], c["y"]) for c in data["original"]["chests"] if "x" in c]
        quads = used_quadrants(types, seeds) or [0, 1, 2, 3]
        qx = [q % 2 for q in quads]
        qy = [q // 2 for q in quads]
        box = [min(qx) * 32, min(qy) * 32, (max(qx) - min(qx) + 1) * 32, (max(qy) - min(qy) + 1) * 32]
        data["layout"]["used_quadrants"] = quads
        write_json(out / "rooms" / f"{room:03x}.json", data)
        index[f"{room:03x}"] = {
            "id": room, "name": name, "category": category, "dungeon": dung_id, "roles": roles,
            "blockset": aux, "main": main, "palette": h["palette"], "tileset": ts_id,
            "bbox": box, "size": [box[2] * 8, box[3] * 8], "used_quadrants": quads, "layout": layout["id"],
            "bg_mode": layout["bg_mode"], "two_levels": two_level,
            "doors": [f"{d['dir']}:{d['kind']}" for d in doors],
        }
        stats[category] += 1
        if lossy:
            stats["lossy_rooms"] += 1

    write_json(out / "rooms.json", {"format": 1, "rooms": index,
                                    "tilesets": {k: {kk: vv for kk, vv in v.items()} for k, v in tilesets.items()}},
               compact=False)
    if options.PREVIEWS:
        contact_sheet(out, list(range(U.NUM_ROOMS)), {r: index[f"{r:03x}"]["name"] for r in range(U.NUM_ROOMS)})
    return {"rooms": U.NUM_ROOMS, "tilesets": len(tilesets), **stats}
