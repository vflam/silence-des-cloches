"""Extraction step: our own rooms (tools/roomgen/rooms/) drawn with the original room code.
Runs after `underworld` (it reuses its atlases). See docs/tech/ROOMGEN.md."""
import importlib.util
import sys
from pathlib import Path

from rom import Rom

ROOMGEN = Path(__file__).resolve().parents[2] / "roomgen"


def run(rom: Rom, out: Path) -> dict:
    sys.path.insert(0, str(ROOMGEN))
    import roomgen as G  # noqa: E402

    spec = importlib.util.spec_from_file_location("roomgen_build", ROOMGEN / "build.py")
    build = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(build)
    G._rom = rom
    names = build.build_all(out_dir=out / "underworld" / "custom")
    return {"rooms": len(names)}
