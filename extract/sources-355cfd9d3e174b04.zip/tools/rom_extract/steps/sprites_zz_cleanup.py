"""The pot sprite is cut out of a dungeon room with its floor tile behind it (grey slab):
remove the slab so the pot sits cleanly on grass too. The slab colours are read from the
frame border; the pot outline shares the darkest slab colour, so dark pixels are kept only
where they touch the pot itself. Runs after steps/sprites.py (alphabetical order)."""
import json
from pathlib import Path

from PIL import Image

FLOOR_BACKED = ["pot", "pot_lifted"]
CLEAR = (0, 0, 0, 0)


def _clean_frame(px, x0, y0, w, h) -> int:
    border = [(x, y) for x in range(x0, x0 + w) for y in range(y0, y0 + h)
              if x in (x0, x0 + w - 1) or y in (y0, y0 + h - 1)]
    ring2 = [(x, y) for x in range(x0, x0 + w) for y in range(y0, y0 + h)
             if x < x0 + 2 or y < y0 + 2 or x >= x0 + w - 2 or y >= y0 + h - 2]
    cx0, cy0 = x0 + w // 4, y0 + h // 4
    core = {px[x, y] for x in range(cx0, x0 + w - w // 4) for y in range(cy0, y0 + h - h // 4)}
    edge = {px[c] for c in border if px[c][3] > 0}
    if not edge:
        return 0
    dark = min(edge, key=lambda c: sum(c[:3]))
    # slab = colours of the outer ring that the object itself does not use, + the dark border
    slab = {px[c] for c in ring2 if px[c][3] > 0 and px[c] not in core} | {dark}
    inside = [(x, y) for x in range(x0, x0 + w) for y in range(y0, y0 + h)]
    n = 0
    for c in inside:  # slab colours other than the outline colour, and the outer ring
        if px[c] in slab and (px[c] != dark or c in border):
            px[c] = CLEAR
            n += 1
    changed = True
    while changed:  # dark pixels that no longer touch the pot
        changed = False
        for (x, y) in inside:
            if px[x, y] != dark:
                continue
            near = [px[x + dx, y + dy] for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
                    if x0 <= x + dx < x0 + w and y0 <= y + dy < y0 + h]
            if not any(p[3] > 0 and p != dark and p not in slab for p in near):
                px[x, y] = CLEAR
                n += 1
                changed = True
    return n


def run(rom, out: Path):
    cat_path = out / "sprites" / "catalog.json"
    if not cat_path.exists():
        return {"skipped": True}
    cat = json.load(open(cat_path))
    cleared = {}
    for sid in FLOOR_BACKED:
        e = cat.get(sid)
        if not e:
            continue
        p = out / e["png"]
        img = Image.open(p).convert("RGBA")
        px = img.load()
        n = sum(_clean_frame(px, f["x"], f["y"], f["w"], f["h"]) for f in e["frames"])
        if n:
            img.save(p)
            cleared[sid] = n
    return {"cleared_px": cleared}
