"""UI step: the 2bpp HUD / menu tiles of the ROM, pre-coloured with the 8 HUD palettes.

Output (game/assets/rom/ui/):
  hud_tiles.png   RGBA atlas, 16 tiles per row. For each HUD palette p (0-7) a block of
                  384 tiles (24 rows) = BG3 character numbers 0x000-0x17F as the game loads
                  them outside of dialogues: sheet 0x6A -> 0x000, 0x6B -> 0x080, 0x69 -> 0x100
                  (zelda3 load_gfx.c: DecompAndUpload2bpp to VRAM $7000/$7400/$7800).
                  Tile t with palette p is at (t % 16 * 8, (p * 24 + t // 16) * 8).
                  Colour 0 is transparent.
  hud_tiles.json  layout description.

The game draws BG3 tilemap words `vhopppcc cccccccc` (same values as zelda3 src/hud.c)
with game/scripts/ui/hud_tiles.gd.
"""
import json
from pathlib import Path

from PIL import Image

import gfx
import palettes as pal
from rom import Rom

SHEETS = (0x6A, 0x6B, 0x69)
TILES = 128 * len(SHEETS)
ROWS = TILES // 16


def _rgb(c: int) -> tuple[int, int, int]:
    return gfx.snes_color(c)


def run(rom: Rom, out: Path) -> dict:
    d = out / "ui"
    d.mkdir(parents=True, exist_ok=True)
    tiles: list[bytes] = []
    for s in SHEETS:
        sheet = gfx.spr_sheet(rom, s)
        assert sheet.bpp == 2, f"sheet {s:02x} is not 2bpp"
        tiles += sheet.tiles[:128]
    hud = pal.group(rom, "hud")[0]  # 32 colours = 8 palettes x 4
    img = Image.new("RGBA", (128, ROWS * 8 * 8), (0, 0, 0, 0))
    px = img.load()
    for p in range(8):
        cols = [None] + [_rgb(hud[p * 4 + i]) + (255,) for i in range(1, 4)]
        for t, tile in enumerate(tiles):
            ox, oy = t % 16 * 8, (p * ROWS + t // 16) * 8
            for i, v in enumerate(tile):
                if v:
                    px[ox + i % 8, oy + i // 8] = cols[v]
    img.save(d / "hud_tiles.png")
    info = {"tile": 8, "columns": 16, "tiles_per_palette": TILES, "rows_per_palette": ROWS,
            "palettes": 8, "sheets": [f"{s:02x}" for s in SHEETS],
            "colors": ["#%02x%02x%02x" % _rgb(c) for c in hud]}
    with open(d / "hud_tiles.json", "w", encoding="utf-8") as f:
        json.dump(info, f, indent=1)
    return {"tiles": TILES, "palettes": 8}
