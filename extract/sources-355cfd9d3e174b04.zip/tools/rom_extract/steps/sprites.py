"""SPRITES step: Link's weapons, objects, enemies, NPCs -> game/assets/rom/sprites/.
    python3 tools/rom_extract/run_step.py sprites
See docs/tech/SPRITES.md."""
from __future__ import annotations

import json
from pathlib import Path

import options
import sprites_common as sc
import sprites_link
import sprites_preview
from rom import Rom


def _write_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")))


def _derive_big_key_doors(catalog: dict, d: Path) -> None:
    """The ROM only has a big-key door on the north wall. The other sides are derived the way
    the small-key doors relate in the ROM: down = vertical flip, left = transpose, right =
    transpose + horizontal flip (checked on door_*_key: identical to 99.8 %)."""
    import numpy as np
    from PIL import Image
    src = catalog.get("door_up_big_key")
    if not src:
        return
    up = np.array(Image.open(d / "door_up_big_key.png").convert("RGBA"))
    for dname, img in (("down", up[::-1]), ("left", up.transpose(1, 0, 2)),
                       ("right", up.transpose(1, 0, 2)[:, ::-1])):
        cid = f"door_{dname}_big_key"
        if cid in catalog:
            continue
        Image.fromarray(np.ascontiguousarray(img), "RGBA").save(d / f"{cid}.png")
        h, w = img.shape[:2]
        e = dict(src)
        e.update({"png": f"sprites/{cid}.png", "frames": [{"x": 0, "y": 0, "w": w, "h": h, "ox": 0, "oy": 0}],
                  "source": "derived from door_up_big_key (flip / transpose)",
                  "desc": f"Porte à grande clé ({dname}), dérivée de la porte du haut"})
        catalog[cid] = e


def run(rom: Rom, out: Path) -> dict:
    d = out / "sprites"
    d.mkdir(parents=True, exist_ok=True)
    if options.PREVIEWS:
        (d / "previews").mkdir(parents=True, exist_ok=True)

    # 1. Link's sword and shield
    atlas = sc.Atlas(width=256)
    lw = sprites_link.extract(rom, atlas)
    img = atlas.image()
    img.save(d / "link_weapons.png")
    _write_json(d / "link_weapons.json", lw)
    if options.PREVIEWS:
        sprites_preview.link_weapons_sheet(rom, lw, img, d / "previews" / "link_weapons.png")

    info = {"link_weapons": len(lw["sword"])}

    # 2+. catalogue (objects, enemies, NPCs)
    try:
        import sprites_catalog
    except ImportError:
        return info
    catalog = sprites_catalog.build(rom, d, previews=options.PREVIEWS)
    _derive_big_key_doors(catalog, d)
    _write_json(d / "catalog.json", catalog)
    info["sprites"] = len(catalog)
    return info
