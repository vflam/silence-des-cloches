"""Draw underworld rooms from the extracted files (no ROM needed).

Usable by any tool (MAPTOOLS...) once `extract.py` has produced game/assets/rom/underworld/:

    import sys; sys.path.insert(0, "tools/rom_extract")
    import underworld_render as UR
    room = UR.load_room(0x104)                      # dict of rooms/104.json
    img = UR.render_room(room)                      # PIL RGBA 512x512, bg then fg
    img = UR.render_words(room["bg"], "uw_03_0a", fg=room["fg"], rect=(0, 0, 32, 32))
    img = UR.render_types(room["types"])            # collision overlay (debug colours)

Tilemap words are SNES words `vhopppcc cccccccc` (tile 0-511, palette row 0-7, priority,
mirrors). Atlases: tilesets/<id>.png, 512x512, cell (palette * 512 + tile) at
((cell % 64) * 8, (cell // 64) * 8), colour 0 transparent.
"""
import json
from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
UW_DIR = ROOT / "game" / "assets" / "rom" / "underworld"  # default; see _uw()


def _uw() -> Path:
    import rom
    return rom.assets_dir() / "underworld"

EMPTY = 0  # a cell whose word is 0 is empty/transparent in bg / fg


def load_room(room_id: int, base: Path | None = None) -> dict:
    base = base or _uw()
    with open(base / "rooms" / f"{room_id:03x}.json", encoding="utf-8") as f:
        return json.load(f)


@lru_cache(maxsize=64)
def atlas_array(tileset: str, base: Path | None = None) -> np.ndarray:
    """(8 * 512, 8, 8, 4) RGBA tiles of an atlas, indexed by palette * 512 + tile."""
    base = base or _uw()
    a = np.asarray(Image.open(base / "tilesets" / f"{tileset}.png").convert("RGBA"))
    return a.reshape(64, 8, 64, 8, 4).transpose(0, 2, 1, 3, 4).reshape(4096, 8, 8, 4)


def tiles_rgba(words: np.ndarray, atlas: np.ndarray) -> np.ndarray:
    """(H, W) tilemap words -> (H*8, W*8, 4) RGBA."""
    words = np.asarray(words, dtype=np.int64)
    h, w = words.shape
    cells = ((words >> 10) & 7) * 512 + (words & 0x1FF)
    t = atlas[cells]                                   # (h, w, 8, 8, 4)
    hf = (words & 0x4000) != 0
    vf = (words & 0x8000) != 0
    t = np.where(hf[..., None, None, None], t[:, :, :, ::-1], t)
    t = np.where(vf[..., None, None, None], t[:, :, ::-1, :], t)
    return t.transpose(0, 2, 1, 3, 4).reshape(h * 8, w * 8, 4)


def _over(dst: np.ndarray, src: np.ndarray) -> np.ndarray:
    m = src[..., 3:4] > 0
    return np.where(m, src, dst)


def render_words(bg, tileset: str, fg=None, rect=None, base: Path | None = None,
                 background=(0, 0, 0, 255)) -> Image.Image:
    """Draw 64x64 word grids (lists of 4096) with an atlas. rect = (x, y, w, h) in 8x8 cells.
    `background` fills where both layers are transparent (None = keep transparent)."""
    atlas = atlas_array(tileset, base)
    x, y, w, h = rect or (0, 0, 64, 64)
    grid = lambda words: np.asarray(words, dtype=np.int64).reshape(64, 64)[y:y + h, x:x + w]
    out = np.zeros((h * 8, w * 8, 4), np.uint8)
    if background is not None:
        out[...] = background
    out = _over(out, tiles_rgba(grid(bg), atlas))
    if fg is not None:
        out = _over(out, tiles_rgba(grid(fg), atlas))
    return Image.fromarray(out.astype(np.uint8), "RGBA")


def render_room(room: dict, rect=None, base: Path | None = None) -> Image.Image:
    """Room json -> RGBA image (bg under fg, black where nothing is drawn)."""
    return render_words(room["bg"], room["tileset"], fg=room["fg"], rect=rect, base=base)


# Debug colours for render_types (type -> RGBA); anything else walkable = transparent.
TYPE_COLORS = {
    "wall": (255, 0, 0, 110), "pit": (0, 0, 0, 170), "deep_water": (0, 64, 255, 120),
    "shallow_water": (0, 180, 255, 80), "stairs": (255, 220, 0, 120), "door": (0, 255, 0, 110),
    "ledge": (255, 128, 0, 120), "slope": (255, 0, 255, 90), "special": (180, 0, 255, 90),
}


def type_class(t: int) -> str:
    """Class of an ALttP *underworld* tile type (TileDetect_ExecuteInner, indoors).
    See the table in docs/tech/INTERIORS.md."""
    if t in (0x01, 0x02, 0x03, 0x04, 0x0B, 0x26, 0x27, 0x42, 0x43, 0x57, 0x63, 0x67) \
            or 0x4C <= t <= 0x4F or 0x58 <= t <= 0x5D or 0x6C <= t <= 0x7F or 0xC0 <= t <= 0xCF or t >= 0xF0:
        return "wall"      # 0x58-0x5D chests, 0x70-0x7F pots/blocks, 0xC0-0xCF torches, 0xF0+ key doors
    if 0x10 <= t <= 0x13 or 0x18 <= t <= 0x1B:
        return "slope"
    if t == 0x20 or 0xB0 <= t <= 0xBD:
        return "pit"
    if t == 0x08:
        return "deep_water"
    if t == 0x09:
        return "shallow_water"
    if t in (0x1D, 0x1E, 0x1F, 0x22, 0x3D, 0x3E, 0x3F, 0x5E, 0x5F) or 0x30 <= t <= 0x37:
        return "stairs"
    if 0x28 <= t <= 0x2F:
        return "ledge"
    if 0x80 <= t <= 0xAF:
        return "door"
    if t in (0x0C, 0x0D, 0x0E, 0x0F, 0x1C, 0x3A, 0x3B, 0x44, 0x4B, 0x60, 0x62, 0x66) or 0x68 <= t <= 0x6B:
        return "special"   # overlays, spikes, ice, star tiles, warp, rupee, bomb floor, conveyors
    return "floor"


def render_types(types, rect=None) -> Image.Image:
    x, y, w, h = rect or (0, 0, 64, 64)
    g = np.asarray(types, dtype=np.int64).reshape(64, 64)[y:y + h, x:x + w]
    lut = np.zeros((256, 4), np.uint8)
    for t in range(256):
        lut[t] = TYPE_COLORS.get(type_class(t), (0, 0, 0, 0))
    px = lut[g].repeat(8, 0).repeat(8, 1)
    return Image.fromarray(px, "RGBA")
