"""Custom drawers of the NPC group (sprites_recipes_npcs.py).

1. "Follower graphics" sprites (Zelda 0x76, the lost old man 0xAD, Kiki 0xB6, the returning
   smithy 0x1A...). Their drawing routine only emits OAM characters 0x20 / 0x22 (16x16) and
   writes two DMA selectors ($0AE8 head, $0AEA body); every frame the NMI copies the matching
   16x16 blocks of the follower buffer $7EB940 (built by LoadFollowerGraphics) into those
   characters. We run the ROM's LoadFollowerGraphics to build the buffer, run the sprite code
   as usual, and redirect characters 0x20-0x23 / 0x30-0x33 of each frame to copies of the
   selected blocks placed in free VRAM blocks (BlockPool).

2. The follower itself (Follower_Main, not a sprite): we run the ROM's AnimateFollower
   ($09A943) on the 65816 interpreter for each (direction, animation step) and read the OAM
   entries and DMA selectors it produces.

No table is copied: everything comes from the ROM code / data.
"""
from __future__ import annotations

import numpy as np

import sprites_common as sc
from rom import A, Rom
from sprites_cpu import Cpu
import sprites_engine
from sprites_engine import Engine
from sprites_recipe import Anim, Recipe

LOAD_FOLLOWER_GRAPHICS = A(0x00D463)   # LoadFollowerGraphics (RTL)
ANIMATE_FOLLOWER = A(0x09A943)         # AnimateFollower_preserved (RTS, bank 09)
FOLLOWER_BUF = 0xB940               # $7EB940: 32 4bpp tiles (2 rows of 16)
DMA_HEAD, DMA_BODY = 0x0AE8, 0x0AEA
FOLLOWER = 0xF3CC                   # $7EF3CC follower indicator


def _tile4(b: bytes) -> np.ndarray:
    t = np.zeros((8, 8), np.uint8)
    for r in range(8):
        p0, p1, p2, p3 = b[2 * r], b[2 * r + 1], b[16 + 2 * r], b[17 + 2 * r]
        for x in range(8):
            s = 7 - x
            t[r, x] = (p0 >> s & 1) | (p1 >> s & 1) << 1 | (p2 >> s & 1) << 2 | (p3 >> s & 1) << 3
    return t


def load_follower_buffer(cpu: Cpu, fi: int) -> np.ndarray:
    """Runs LoadFollowerGraphics for follower `fi`; -> (32, 8, 8) tiles of $7EB940."""
    old = cpu.r8(FOLLOWER)
    cpu.w8(FOLLOWER, fi)
    s = cpu.s
    cpu.p, cpu.d, cpu.dbr = 0x30, 0, 0
    cpu.call(LOAD_FOLLOWER_GRAPHICS, long=True)
    cpu.s = s
    cpu.w8(FOLLOWER, old)
    raw = bytes(cpu.wram[FOLLOWER_BUF:FOLLOWER_BUF + 0x400])
    return np.stack([_tile4(raw[i * 32:(i + 1) * 32]) for i in range(32)])


class BlockPool:
    """Per-frame streamed 16x16 blocks (4 characters c, c+1, c+16, c+17) placed in free VRAM
    blocks of characters 0x000-0x03F (Link's sheet, unused by NPC sprites); identical blocks
    share a slot."""
    SLOTS = [r + c for r in (0x00, 0x20) for c in range(0, 16, 2)]

    def __init__(self, vram: sc.Vram):
        self.vram = vram
        self.used: dict[bytes, int] = {}

    def slot(self, tiles4: np.ndarray) -> int:
        k = tiles4.tobytes()
        if k not in self.used:
            if len(self.used) >= len(self.SLOTS):
                raise RuntimeError("BlockPool: plus de place en VRAM")
            c = self.SLOTS[len(self.used)]
            for i, off in enumerate((0, 1, 16, 17)):
                self.vram.chars[c + off] = tiles4[i]
            self.used[k] = c
        return self.used[k]

    def remap(self, objs: list[sc.Obj], groups: dict[int, np.ndarray]) -> list[sc.Obj]:
        """groups: {base char: (4, 8, 8) tiles}; objects using a character of a group are
        redirected to the slot of that group's content."""
        slots = {b: self.slot(t) for b, t in groups.items()}
        out = []
        for o in objs:
            c = o.char
            if c < 0x100:
                for b, sl in slots.items():
                    d = c - b
                    if d in (0, 1, 16, 17):
                        o = sc.Obj(o.x, o.y, sl + d, o.pal, o.flip_h, o.flip_v, o.big)
                        break
            out.append(o)
        return out


def follower_groups(buf: np.ndarray, head: int, body: int) -> dict[int, np.ndarray]:
    """NMI follower DMA: chars 0x20/0x21 + 0x30/0x31 <- buffer at head*2 (+0x200),
    chars 0x22/0x23 + 0x32/0x33 <- buffer at body*2 (+0x200)."""
    def blk(v):
        t = v >> 4
        return np.stack([buf[t], buf[t + 1], buf[t + 16], buf[t + 17]])
    return {0x20: blk(head), 0x22: blk(body)}


class FixedEngine(Engine):
    """Engine whose ResetOAMRegionBases runs with DBR = $06 (the routine reads its table
    with LDA.w .addresses,Y; with DBR = 0 the OAM region bases get garbage and sprites that
    allocate from a region (uncle, flute kid...) overflow into the rotating fallback slots,
    losing entries after a few frames)."""

    def _run(self) -> None:
        c = self.cpu
        for i in range(128):
            c.wram[0x0800 + i * 4 + 1] = 0xF0
            c.wram[0x0A20 + i] = 0
        c.p, c.s, c.d, c.dbr = 0x30, 0x1FF, 0, 0x06
        c.call(sprites_engine.RESET_OAM_REGION_BASES)
        for i in range(12):
            c.wram[0x0FEC + i] = 0
        c.p, c.x, c.s, c.d, c.dbr = 0x30, self.slot, 0x1FF, 0, 0
        c.call(sprites_engine.HANDLE_SINGLE_SPRITE_LONG, long=True)


def _vram_cgram(rom, world, set_, pal, tileset=None):
    import gfx
    ts = tileset or gfx.sprite_tileset(rom, set_ + (0x40 if world == "uw" else 0))
    return sc.Vram.for_sprites(rom, ts, common=0x0B if world == "dw" else 0x01), sc.sprite_cgram(rom, world, pal)


def _keyed(anims: dict) -> tuple[dict, list]:
    """Replace the states of anims by {"key": i}; -> (new anims, [original states])."""
    states, new = [], {}
    for name, a in anims.items():
        ks = []
        for st in a.states:
            ks.append({"key": len(states)})
            states.append(st)
        new[name] = Anim(ks, a.durations, a.loop)
    return new, states


def link_weapon_groups(rom: Rom, sword: int = 1, shield: int = 1):
    """-> fn(cpu) giving the blocks streamed by the NMI into Link's characters 0x05 (sword,
    SwordGfxPointers[$0107 / 2]) and 0x07 (shield, ShieldGfxPointers[$0108 / 2]), as the
    uncle's drawing routine selects them."""
    import sprites_link as sl
    buf = sl._wram_buffers(rom, sword, shield)
    sword_ptrs = rom.words(sl.SWORD_GFX_PTRS, 8)
    shield_ptrs = rom.words(sl.SHIELD_GFX_PTRS, 3)
    z = np.zeros((8, 8), np.uint8)

    def get(a):
        return buf.get(a & 0xFFFF, z)

    def fn(cpu: Cpu) -> dict:
        v3, v4 = cpu.r8(0x0107), cpu.r8(0x0108)
        g = {}
        if (v3 >> 1) < len(sword_ptrs):
            a = sword_ptrs[v3 >> 1]
            g[0x05] = np.stack([get(a), get(a + 0x20), get(a + 0x180), get(a + 0x1A0)])
        if (v4 >> 1) < len(shield_ptrs):
            a = shield_ptrs[v4 >> 1]
            g[0x07] = np.stack([get(a), get(a + 0x20), get(a + 0xC0), get(a + 0xE0)])
        return g
    return fn


def dma_recipe(id, type_, follower, anims, set=0, pal=0, world="lw", pre=None, post=None,
               pokes=None, link=(0, 0x30), weapons=False, **kw) -> Recipe:
    """A sprite drawn with streamed graphics: follower graphics (follower = indicator used
    by LoadFollowerGraphics) and / or Link's sword and shield (weapons=True)."""
    new, states = _keyed(anims)

    def custom(rom: Rom):
        vram, cg = _vram_cgram(rom, world, set, pal)
        eng = FixedEngine(rom)
        eng.spawn(type_, indoors=world == "uw", dark=world == "dw", pre=dict(pre or {}),
                  globals_=dict(pokes or {}), link=link)
        if post:
            eng.set(**post)
        buf = load_follower_buffer(eng.cpu, follower) if follower else None
        wfn = link_weapon_groups(rom) if weapons else None
        pool = BlockPool(vram)
        drawn = {}
        for i, st in enumerate(states):
            st = dict(st)
            pk = st.pop("poke", None)
            fr = st.pop("frame", 0)
            dy = st.pop("_dy", 0)     # move every non-shadow object (undo a forced height)
            objs = eng.draw(st, pokes=pk, frame=fr)
            if dy:
                objs = [o if (o.char, o.pal) == (0x6C, 4) else
                        sc.Obj(o.x, o.y + dy, o.char, o.pal, o.flip_h, o.flip_v, o.big) for o in objs]
            groups = {}
            if buf is not None:
                groups.update(follower_groups(buf, eng.cpu.r8(DMA_HEAD), eng.cpu.r8(DMA_BODY)))
            if wfn:
                groups.update(wfn(eng.cpu))
            drawn[i] = pool.remap(objs, groups)
        return vram, cg, drawn

    return Recipe(id, type_, set=set, pal=pal, world=world, anims=new, custom=custom, **kw)


def follower_recipe(id, follower, anims, set=0, pal=0, world="lw", **kw) -> Recipe:
    """The follower (Follower_Main / AnimateFollower). anims states: {"dir": 0-3 (up, down,
    left, right), "moving": bool, "frame": frame counter, "bits": extra layer bits}."""
    new, states = _keyed(anims)

    def custom(rom: Rom):
        vram, cg = _vram_cgram(rom, world, set, pal)
        c = Cpu(rom)
        c.w8(0x1B, 1 if world == "uw" else 0)
        buf = load_follower_buffer(c, follower)
        pool = BlockPool(vram)
        c.w8(FOLLOWER, follower)
        drawn = {}

        def draw(st: dict, frame: int) -> list:
            for j in range(128):
                c.wram[0x0800 + j * 4 + 1] = 0xF0
                c.wram[0x0A20 + j] = 0
            x = y = 0x80
            c.w16(0xE2, 0)
            c.w16(0xE8, 0)
            c.w16(0x00, y)
            c.w16(0x02, x)
            c.w16(0x20, y + 0x10)     # Link below the follower
            c.w16(0x22, x)
            c.w8(0x10, 0x07)
            c.w8(0x11, 0x00)
            mv = 1 if st.get("moving") else 0
            c.w8(0x30, mv)
            c.w8(0x31, 0)
            c.w8(0x0372, 0)
            c.w8(0x02E4, 0)
            c.w8(0x0ABD, 0)
            c.w8(0x0FB3, 0)
            c.w8(0x65, 0x20)
            c.w8(0x75, 0)
            c.w8(0x1A, frame & 0xFF)
            c.p, c.d, c.dbr, c.s = 0x30, 0, 0x09, 0x1FF
            c.a = (st.get("dir", 1) & 3) | st.get("bits", 0)
            c.call(ANIMATE_FOLLOWER)
            objs = []
            for j in range(128):
                oy = c.wram[0x0800 + j * 4 + 1]
                if oy == 0xF0:
                    continue
                ox = c.wram[0x0800 + j * 4]
                ext = c.wram[0x0A20 + j]
                if ext & 1:
                    ox -= 256
                word = c.wram[0x0800 + j * 4 + 2] | c.wram[0x0800 + j * 4 + 3] << 8
                objs.append(sc.Obj.from_word(ox - x, oy - y, word, bool(ext & 2)))
            return objs

        # A walk step changes every 8 frames. The European versions time it with a counter of
        # their own (50 Hz) instead of the frame counter: run 32 consecutive frames and take
        # the distinct poses in order; "frame" F asks for step F // 8.
        seqs: dict = {}
        for i, st in enumerate(states):
            key = (st.get("dir", 1), bool(st.get("moving")), st.get("bits", 0))
            if key not in seqs:
                poses: list = []
                for f in range(32):
                    objs = draw(st, f)
                    dma = (c.r8(DMA_HEAD), c.r8(DMA_BODY))   # graphics streamed for this pose
                    sig = ([(o.x, o.y, o.char, o.pal, o.flip_h, o.flip_v, o.big) for o in objs], dma)
                    if all(sig != q[0] for q in poses):
                        poses.append((sig, objs, dma))
                seqs[key] = [q[1:] for q in poses]
            poses = seqs[key]
            objs, dma = poses[(st.get("frame", 0) // 8) % len(poses)]
            drawn[i] = pool.remap(objs, follower_groups(buf, *dma))
        return vram, cg, drawn

    return Recipe(id, None, set=set, pal=pal, world=world, anims=new, custom=custom, **kw)
