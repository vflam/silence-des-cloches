"""Custom drawers of the boss group (sprites_recipes_bosses.py).

The multi-part bosses (Lanmola, Giant Moldorm...) draw their body segments from a history of
past head positions kept in WRAM ($7FFC00.. x_lo, $7FFD00.. y_lo, $7FFE00.., $7FFF00..). We run
the ROM's own sprite routine (sprites_engine.Engine) with that history filled by us, then keep
only some of the OAM entries (by OAM slot order) to cut the boss into pieces that the game
engine re-assembles itself. Composite frames are also produced by letting the ROM AI run
(Engine.draw(frozen=False)). No Nintendo table is copied: only WRAM addresses / state values.
"""
from __future__ import annotations

import math

import gfx
import sprites_common as sc
import sprites_engine as se
from rom import Rom
from sprites_engine import Engine

# WRAM (zelda3 variables.h names)
MOLDORM_X_LO = 0x1FC00    # moldorm_x_lo[128]  (Lanmola: 64 per slot)
MOLDORM_Y_LO = 0x1FD00    # moldorm_y_lo[128]
HIST_2 = 0x1FE00          # beamos_x_hi (Lanmola: segment z) / moldorm_x_hi (Moldorm)
HIST_3 = 0x1FF00          # beamos_y_hi (Lanmola: segment angle) / moldorm_y_hi (Moldorm)
MOLDORM_X_HI = 0x1FC80
MOLDORM_Y_HI = 0x1FD80
LANMOLA_NSEG = 0x1F81E    # garnish_y_lo[k]: Lanmola visible segment count - 1 (7 = full)
WALLCOLL = 0x0E70         # sprite_wallcoll[k]: Lanmola emergence point y_lo (x_lo in D)

POS = se.WORLD_BASE + se.SCREEN     # the sprite is at world (0x880, 0x880)


def vram_cgram(rom: Rom, world: str, set_: int, pal: int):
    ts = gfx.sprite_tileset(rom, set_ + (0x40 if world == "uw" else 0))
    return sc.Vram.for_sprites(rom, ts, common=0x0B if world == "dw" else 0x01), sc.sprite_cgram(rom, world, pal)


def oam_slots(e: Engine) -> list[tuple[int, sc.Obj]]:
    """Like Engine.oam() but keeps the OAM slot index (slot order = draw order)."""
    c = e.cpu
    sx = (c.r8(se.VARS["x_lo"]) | c.r8(se.VARS["x_hi"]) << 8) - se.WORLD_BASE
    sy = (c.r8(se.VARS["y_lo"]) | c.r8(se.VARS["y_hi"]) << 8) - se.WORLD_BASE
    out = []
    for i in range(128):
        y = c.wram[0x0800 + i * 4 + 1]
        if y == 0xF0:
            continue
        x = c.wram[0x0800 + i * 4]
        ext = c.wram[0x0A20 + i]
        if ext & 1:
            x -= 256
        if y >= 0xE0:
            y -= 256
        word = c.wram[0x0800 + i * 4 + 2] | c.wram[0x0800 + i * 4 + 3] << 8
        out.append((i, sc.Obj.from_word(x - sx, y - sy, word, bool(ext & 2))))
    return out


def shifted(objs, dx, dy):
    return [sc.Obj(o.x + dx, o.y + dy, o.char, o.pal, o.flip_h, o.flip_v, o.big) for o in objs]


def angle_vel(a: int, r: int = 32) -> tuple[int, int]:
    """(x_vel, y_vel) pointing at angle a (0 = right, 4 = down, clockwise, 16 steps)."""
    t = a * math.pi / 8
    return round(r * math.cos(t)) & 0xFF, round(r * math.sin(t)) & 0xFF


def pos_vars(dx=0, dy=0) -> dict:
    x, y = POS + dx, POS + dy
    return dict(x_lo=x & 0xFF, x_hi=x >> 8, y_lo=y & 0xFF, y_hi=y >> 8)


# ------------------------------------------------------------------------------ Lanmola 0x54
LANMOLA_LEAP_N = 56      # composite samples of one surfacing (every LANMOLA_LEAP_STEP frames)
LANMOLA_LEAP_STEP = 3
LANMOLA_DIE_N = 48
LANMOLA_DIE_STEP = 4


def _lan_hist(e: Engine, entries: dict) -> None:
    """entries {index: (x_lo, y_lo, z, angle)} of slot 0's 64-entry history."""
    for j, (x, y, z, a) in entries.items():
        e.poke(MOLDORM_X_LO + j, x)
        e.poke(MOLDORM_Y_LO + j, y)
        e.poke(HIST_2 + j, z)
        e.poke(HIST_3 + j, a)


def lanmola(rom: Rom, set_=11, pal=4, world="uw"):
    vram, cg = vram_cgram(rom, world, set_, pal)
    drawn = {}
    e = Engine(rom)
    e.spawn(0x54, indoors=world == "uw", link=(0x40, 0x40))
    lo = POS & 0xFF

    def segs(n, vx, vy, hist, ai=0):
        # subtype2 = 8: head = history[8] (written by the draw from the sprite itself),
        # segment i behind the head = history[(8 - 8 i) & 63]
        e.poke(LANMOLA_NSEG, n)
        _lan_hist(e, hist)
        e.draw(dict(ai=ai, aux1=0, subtype2=8, z=0, x_vel=vx, y_vel=vy, z_vel=0, **pos_vars()))
        return oam_slots(e)

    for a in range(16):
        vx, vy = angle_vel(a)
        # head alone: 1 segment + its shadow (segment first in OAM order)
        s = segs(0, vx, vy, {})
        assert e.get("g") == a, (a, e.get("g"))
        drawn[f"head_{a}"] = [s[0][1]]
        # head + 7 segments all at the sprite position; the tail (last of the 8) angle = a
        hist = {(8 - 8 * i) & 63: (lo, lo, 0, a) for i in range(1, 8)}
        s = segs(7, 32, 0, hist)          # y_vel >= 0: OAM order head .. tail
        drawn[f"tail_{a}"] = [s[7][1]]
        drawn[f"body_{a}"] = [s[3][1]]
    drawn["shadow"] = [segs(0, 32, 0, {})[1][1]]

    # emergence: sand mound (ai 1, delay 127 -> 0) then debris (ai 2, delay_aux1 74 -> 0);
    # the worm itself is hidden (z < 0 everywhere: segments are not written to OAM)
    hide = {j: (lo, lo, 0xFF, 0) for j in range(64)}
    _lan_hist(e, hide)
    e.poke(LANMOLA_NSEG, 7)
    e.poke(WALLCOLL, lo)
    for i in range(16):
        e.draw(dict(ai=1, delay=127 - 8 * i, aux1=0, z=0xFF, subtype2=8, D=lo, **pos_vars()))
        drawn[f"mound_{i}"] = [o for _, o in oam_slots(e)]
    for i in range(19):
        e.draw(dict(ai=2, delay=0, aux1=74 - 4 * i, z=0xFF, subtype2=8, D=lo, **pos_vars()))
        drawn[f"debris_{i}"] = [o for _, o in oam_slots(e)]

    # one complete surfacing, run by the ROM AI, relative to the emergence point
    e = Engine(rom)
    e.spawn(0x54, indoors=world == "uw", link=(0x40, 0x40))
    f = 0
    while e.get("ai") != 2:
        e.draw(frozen=False, frame=f)
        f += 1
    ex, ey = e.get("D"), e.cpu.r8(WALLCOLL)
    ehx, ehy = e.get("x_hi"), e.get("y_hi")
    ox, oy = (ehx << 8 | ex) - POS, (ehy << 8 | ey) - POS
    for i in range(LANMOLA_LEAP_N):
        for _ in range(LANMOLA_LEAP_STEP):
            objs = e.draw(frozen=False, frame=f)
            f += 1
        sx = (e.get("x_hi") << 8 | e.get("x_lo")) - POS
        sy = (e.get("y_hi") << 8 | e.get("y_lo")) - POS
        drawn[f"leap_{i}"] = shifted(objs, sx - ox, sy - oy)
    # death: freeze a mid-leap worm (ai 5): segments vanish one by one from the tail
    e = Engine(rom)
    e.spawn(0x54, indoors=world == "uw", link=(0x40, 0x40))
    f = 0
    while e.get("ai") != 2:
        e.draw(frozen=False, frame=f)
        f += 1
    for _ in range(16 * LANMOLA_LEAP_STEP):
        e.draw(frozen=False, frame=f)
        f += 1
    e.set(state=6, ai=5, delay=0xC0, hit=0xC0)   # as the ROM does when its health runs out
    for i in range(LANMOLA_DIE_N):
        for k in range(LANMOLA_DIE_STEP):
            o = e.draw(frozen=False, frame=f)
            f += 1
            if k == i % LANMOLA_DIE_STEP:   # vary the phase so that the hit flash shows
                objs = o
        drawn[f"die_{i}"] = objs
        if e.get("state") == 0:
            drawn[f"die_{i}"] = []
    return vram, cg, drawn


# ------------------------------------------------------------------------------ Giant Moldorm 0x09
MOLDORM_SPEED = 1.5       # px / frame (x_vel 24 = 24/16 px)


def _mold_hist(e: Engine, sub: int, dx: float, dy: float, straight=True) -> None:
    """History of a worm that went straight in direction (dx, dy) (unit vector) at the
    normal speed; the head (age 0) is at the sprite position."""
    for age in range(128):
        j = (sub - age) & 0x7F
        d = age * MOLDORM_SPEED if straight else 0
        x = POS + round(-dx * d)
        y = POS + round(-dy * d)
        e.poke(MOLDORM_X_LO + j, x & 0xFF)
        e.poke(MOLDORM_X_HI + j, x >> 8)
        e.poke(MOLDORM_Y_LO + j, y & 0xFF)
        e.poke(MOLDORM_Y_HI + j, y >> 8)


def moldorm(rom: Rom, set_=12, pal=6, world="uw"):
    """Keys: head_<d>_<t> (t = head wiggle 0/1), stun_<d>_<f>, segA_<t>, segC_<t4>, tail_<t4>,
    walk_<d>_<s> (composite, straight body), die_<b>_<p>."""
    vram, cg = vram_cgram(rom, world, set_, pal)
    drawn = {}
    e = Engine(rom)
    e.spawn(0x09, indoors=world == "uw", link=(0x40, 0x40))

    def dr(**v):
        v.setdefault("prio", 0)
        pokes = v.pop("pokes", None)
        frame = v.pop("frame", 0)
        if v.pop("tail_flags", False):
            # the eyes use the OAM flags left by the previous frame: those of the tail
            # (the routine sets them for the head only after drawing the eyes)
            e.draw(dict(v, B=0), pokes=pokes, frame=frame)
        else:
            e.draw(v, pokes=pokes, frame=frame)
        e.draw(v, pokes=pokes, frame=frame)
        return [o for _, o in oam_slots(e)]

    _mold_hist(e, 0, 1, 0, straight=False)
    for d in range(16):
        for t in range(2):
            drawn[f"head_{d}_{t}"] = dr(D=d, B=4, F=0, subtype2=2 * t, aux1=0, tail_flags=True)
    for d in (0, 4, 8, 12):
        for fr in range(8):
            drawn[f"stun_{d}_{fr}"] = dr(D=d, B=4, F=1, subtype2=0, aux1=0, frame=2 * fr,
                                         prio=(0xE, 0xA, 0x6, 0x2, 0xC, 0x8, 0x4, 0x0)[fr], tail_flags=True)
    # pieces: all segments at the sprite position; OAM order = eyes(2) head(4) A(4) B(4) C(1) tail(1)
    for t4 in range(4):
        objs = dr(D=0, B=0, F=0, subtype2=2 * t4, aux1=0)
        assert len(objs) == 16, len(objs)
        if t4 < 2:
            drawn[f"segA_{t4}"] = objs[6:10]
        drawn[f"segC_{t4}"] = [objs[14]]
        drawn[f"tail_{t4}"] = [objs[15]]
    # composite: straight worm, 4 directions, subtype2 cycle 0,2,4,6 (8 frames)
    for d in (0, 4, 8, 12):
        t = d * math.pi / 8
        ux, uy = round(math.cos(t)), round(math.sin(t))
        for s in range(4):
            _mold_hist(e, 2 * s, ux, uy)
            drawn[f"walk_{d}_{s}"] = dr(D=d, B=0, F=0, subtype2=2 * s, aux1=0)
    # death: segments removed from the tail (B = 0..4) while flashing (hit timer | 224)
    _mold_hist(e, 0, 0, 1)
    for b in range(5):
        for p in range(4):
            drawn[f"die_{b}_{p}"] = dr(D=4, B=b, F=0, subtype2=0, aux1=0, prio=(2 * p + 8) * 2 & 0xE,
                                       pokes=None)
    return vram, cg, drawn


# ------------------------------------------------------------------------------ generic AI capture
def run(e: Engine, frames: int, force: dict | None = None, pokes: dict | None = None, f0: int = 0,
        rel: tuple | None = None) -> list:
    """Runs the ROM AI for `frames` frames (vars `force` / WRAM `pokes` re-applied every frame);
    -> objs of every frame. rel = (x, y) screen point the objs are made relative to
    (default: the sprite position of that frame)."""
    out = []
    for i in range(frames):
        if force:
            e.set(**force)
        for a, v in (pokes or {}).items():
            e.poke(a, v)
        objs = e.draw(frozen=False, frame=f0 + i)
        if rel is not None:
            sx = (e.get("x_hi") << 8 | e.get("x_lo")) - POS
            sy = (e.get("y_hi") << 8 | e.get("y_lo")) - POS
            objs = shifted(objs, sx - rel[0], sy - rel[1])
        out.append(objs)
    return out


# ------------------------------------------------------------------------------ Helmasaur King 0x92
OV_X_LO, OV_GEN1, OV_GEN2 = 0x0B08, 0x0B28, 0x0B30
HK_TAIL_FIRST = OV_GEN2 + 3       # overlord_gen2[3]: first tail ball drawn (16 = no tail)
HK_HEALTH = {0: 0x30, 1: 0x28, 2: 0x20, 3: 0x10}   # health giving mask state sprite_C = 0..3
HK_N = 16                         # samples per composite animation
HK_STEP = 6
HK_DIE_N = 31                     # death: delay 255 -> 0, sampled every 8 frames


def helmasaur_king(rom: Rom, set_=21, pal=16, world="uw"):
    vram, cg = vram_cgram(rom, world, set_, pal)
    drawn = {}

    def new():
        e = Engine(rom)
        e.spawn(0x92, indoors=world == "uw", link=(0, 0x70))
        return e

    # composites without the tail, legs walking (ai 1), per mask state
    for c, hp in HK_HEALTH.items():
        e = new()
        fr = run(e, HK_N * HK_STEP, force=dict(ai=1, delay=40, health=hp, C=c, E=c, aux1=0, aux2=0),
                 pokes={HK_TAIL_FIRST: 16})
        for i in range(HK_N):
            drawn[f"walk{c}_{i}"] = fr[i * HK_STEP + HK_STEP - 1]
        if c == 3:
            for i, p in enumerate((0xE, 0xC, 0xA, 0x8, 0x6, 0x4, 0x2, 0x0)):
                drawn[f"hurt_{i}"] = e.draw(dict(prio=p, hit=0))
    # idle with its tail (standing still, tail swaying), as the ROM draws it
    e = new()
    fr = run(e, 32 * 4, force=dict(ai=0, delay=40, health=0x30, C=0, E=0, aux1=0, aux2=0, subtype=0))
    for i in range(32):
        drawn[f"idle_{i}"] = fr[i * 4 + 3]
    # fireball spit: mouth opening (delay_aux2 127 -> 0), tail hidden
    e = new()
    e.set(aux2=127)
    fr = run(e, 128, force=dict(ai=0, delay=40, health=0x30, C=0, E=0, aux1=0, subtype=0),
             pokes={HK_TAIL_FIRST: 16})
    for i in range(16):
        drawn[f"spit_{i}"] = fr[i * 8 + 7]
    # tail pieces: first ball drawn = the mace (char differs), then plain balls
    e = new()
    run(e, 1, force=dict(ai=0, delay=40, health=0x30, C=0, E=0))
    for n in (15, 14):
        e.poke(HK_TAIL_FIRST, n)
        objs = e.draw({})
        # tail balls are the first OAM entries drawn (slot order) - keep the n..15 ones
        tail = objs[:16 - n]
        o = tail[-1] if n == 15 else tail[1]
        key = "tail_mace" if n == 15 else "tail_ball"
        drawn[key] = [sc.Obj(0, 0, o.char, o.pal, o.flip_h, o.flip_v, o.big)]
    # death: flashing, tail shrinking from its tip (boss explosions are other sprites)
    e = new()
    run(e, 2, force=dict(ai=0, delay=40, health=0x10, C=3, E=3))   # killed unmasked
    e.set(state=6, delay=0xFF)
    fr = run(e, HK_DIE_N * 8)
    for i in range(HK_DIE_N):
        drawn[f"die_{i}"] = fr[i * 8 + i % 8]    # varying phase: the hit flash shows
    return vram, cg, drawn
