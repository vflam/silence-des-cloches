"""Villagers: Kakariko NPCs and assorted friendly characters (tags "npc", ids npc_*).

Only sprite ids, set / palette indices and state values here; every pixel comes from the
ROM (sprites_engine runs the game's own drawing code). Durations come from the sprites'
AI (frame_counter shifts / delay tables) in zelda3 sprite_main.c."""
from sprites_recipe import Recipe as R, Anim, dirs4, seq, D_UDLR, D_RLDU

DIRS4 = ("up", "down", "left", "right")
LR = ("left", "right")


def idle4(g=0, dmap=D_UDLR, only=DIRS4, extra=None):
    """idle_<dir> one frame per direction (D = body direction)."""
    return dirs4("idle", lambda d, n: [dict(D=d, g=g, **(extra or {}))], dur=8, dmap=dmap, only=only)


def walk4(dur, gs=(0, 1), dmap=D_UDLR, key="D", only=DIRS4, prefix="walk"):
    return dirs4(prefix, lambda d, n: [{key: d, "g": g} for g in gs], dur=dur, dmap=dmap, only=only)


def npc(id_, type_, set_, pal, world, desc, anims, **kw):
    return R(id_, type_, set=set_, pal=pal, world=world, anims=anims, tags=["npc"], desc=desc, **kw)


RECIPES = [
    # ---------------------------------------------------------------- 0x29 "Human" (by room)
    # subtype2 0 (room 0x103, tavern back room): flute boy's father.
    # g = frame<48 ? 2 : (frame>>7)&1
    npc("npc_flute_boy_father", 0x29, 15, 5, "uw", "Père du garçon à la flûte (taverne de Cocorico)",
        {"idle": Anim(seq(g=[0, 1]), 128),
         "special_talk": Anim([{"g": 2}], 8)},
        post={"subtype2": 0}),
    # subtype2 1 (room 0xE1): man in the thieves' hideout; body fixed (g=2), head turns
    # toward Link (head: 0 right, 1 left, 2 down; drawn only when frame&3 != 0).
    npc("npc_thief_hideout_guy", 0x29, 40, 7, "uw", "Homme du repaire des voleurs (Cocorico)",
        dirs4("idle", lambda d, n: [dict(head=d, g=2, frame=1)], dmap=D_RLDU,
              only=("down", "left", "right")),
        post={"subtype2": 1}),
    # subtype2 2 (room 0x119): the man in Blind's hideout (LW house).
    npc("npc_blind_hideout_guy", 0x29, 15, 35, "uw", "Homme de la cachette d'Aveugle (Cocorico)",
        idle4(), post={"subtype2": 2}),

    # ---------------------------------------------------------------- Kakariko outdoors
    npc("npc_sweeping_lady", 0x2A, 6, 1, "lw", "Balayeuse de Cocorico",
        {"idle": Anim(seq(g=[0, 1]), 16)}),
    # hobo under the bridge: sleeps (g0); wake-up sequence when talked to
    npc("npc_hobo", 0x2B, 12, 8, "lw", "Clochard sous le pont",
        {"idle": Anim([{"g": 0}], 8),
         "special_wake": Anim(seq(g=[0, 1, 0, 1, 0, 1, 2]), [6, 2, 6, 6, 2, 100, 30], loop=False)},
        post={"subtype2": 0}),
    npc("npc_lumberjacks", 0x2C, 26, 6, "lw", "Bûcherons sciant l'arbre",
        {"idle": Anim(seq(g=[0, 1]), 32)}),
    npc("npc_maze_game_lady", 0x2F, 6, 1, "lw", "Dame du jeu du labyrinthe",
        idle4()),
    npc("npc_maze_game_guy", 0x30, 6, 1, "lw", "Gars de l'arrivée du jeu du labyrinthe",
        idle4()),
    npc("npc_young_snitch_lady", 0x34, 6, 1, "lw", "Jeune femme qui dénonce Link aux gardes",
        {**walk4(16), **idle4()}),
    npc("npc_old_snitch_lady", 0x3D, 6, 1, "lw", "Vieille femme qui dénonce Link aux gardes",
        {**walk4(16), **idle4()}),
    # 0x3D with a subtype: the chicken lady (always faces down, g = frame>>4 & 1)
    npc("npc_chicken_lady", 0x3D, 6, 1, "lw", "Dame aux cocottes (maison de Cocorico)",
        {"idle_down": Anim(seq(g=[0, 1], D=1), 16)}, post={"subtype": 1}),
    npc("npc_trough_boy", 0x3C, 6, 1, "lw", "Garçon près de l'abreuvoir",
        idle4()),
    # running man: walks (g every 8 frames) then sprints (every 4 frames)
    npc("npc_running_man", 0x74, 6, 1, "lw", "Homme qui court (Cocorico)",
        {**walk4(8), **walk4(4, prefix="special_run"), **idle4()}),
    # bottle vendor: g1 (20 frames) at random
    npc("npc_bottle_vendor", 0x75, 6, 1, "lw", "Marchand de bouteilles",
        {"idle": Anim(seq(g=[0, 1]), [180, 20])}),
    npc("npc_locksmith", 0x39, 10, 1, "lw", "Serrurier (homme d'âge mûr, coffre violet)",
        {"idle": Anim([{"g": 0}], 8)}),

    # ---------------------------------------------------------------- interiors
    # fortune teller: the sprite sits on the table; her body is drawn 24-48 px above it
    npc("npc_fortune_teller", 0x31, 5, 30, "uw", "Diseuse de bonne aventure (monde de la lumière)",
        {"idle": Anim([{"g": 0}], 8),
         "special_reading": Anim(seq(g=[0, 1]), 16)},
        foot=(0, -40)),
    npc("npc_fortune_teller_dark", 0x31, 5, 30, "uw", "Diseuse de bonne aventure (monde des ténèbres)",
        {"idle": Anim([{"g": 0}], 8),
         "special_reading": Anim(seq(g=[0, 1]), 16)},
        pokes={0x7EF3CA: 0x40}, foot=(0, -40)),
    npc("npc_quarrel_bro", 0x32, 15, 2, "uw", "Frère qui se dispute (maison coupée en deux)",
        idle4()),
    npc("npc_innkeeper", 0x35, 15, 5, "uw", "Aubergiste (taverne de Cocorico)",
        {"idle": Anim([{"g": 0}], 8)}),
    # drunkard: g1 for 32 frames at random
    npc("npc_drunkard", 0xBC, 15, 5, "uw", "Ivrogne de la taverne",
        {"idle": Anim(seq(g=[0, 1]), [160, 32])}),
    # sick kid in bed: g0 sick, g1 after getting the bug net; perk-up sequence
    npc("npc_sick_kid", 0x1F, 13, 21, "uw", "Enfant malade au lit (filet à insectes)",
        {"idle": Anim([{"g": 0}], 8),
         "special_healed": Anim([{"g": 1}], 8),
         "special_perk": Anim(seq(g=[0, 1, 0, 1, 0, 1, 2]), [8, 12, 8, 12, 8, 96, 16], loop=False)}),
    npc("npc_witch", 0x36, 13, 6, "lw", "Sorcière du magasin de potions (chaudron)",
        {"idle": Anim(seq(g=list(range(8))), 8)}),
    npc("npc_potion_shop_assistant", 0xE9, 5, 5, "uw", "Assistante du magasin de potions",
        {"idle": Anim(seq(g=[0, 1]), 32)}, post={"subtype2": 0}),
    # bomb shop clerk: breathing (kBombShopGuy delays)
    npc("npc_bomb_shop_clerk", 0xB5, 5, 31, "uw", "Marchand de bombes",
        {"idle": Anim(seq(g=[0, 1, 0, 1, 0, 1, 0, 1]), [255, 32, 255, 24, 15, 24, 255, 15])},
        post={"subtype2": 0}),
    npc("npc_dig_game_guy", 0xD5, 27, 18, "lw", "Gars du jeu de fouille",
        {"idle": Anim([{"g": 0}], 8),
         "walk_left": Anim(seq(g=[1, 2]), 5)}),

    # ---------------------------------------------------------------- Dark World hint NPCs (0x28)
    npc("npc_dw_hint_bush", 0x28, 5, 7, "uw", "PNJ indices du monde des ténèbres (buisson)",
        {"idle": Anim(seq(g=[0, 1]), 16)}, post={"subtype2": 0}),
    npc("npc_dw_hint_hand", 0x28, 5, 7, "uw", "PNJ indices du monde des ténèbres (main)",
        {"idle": Anim(seq(g=[0, 1]), 16)}, post={"subtype2": 1}),
    npc("npc_dw_hint_ghost", 0x28, 5, 7, "uw", "PNJ indices du monde des ténèbres (fantôme)",
        {"idle": Anim(seq(g=[0, 1]), 16)}, post={"subtype2": 2}),
    npc("npc_dw_hint_tree", 0x28, 5, 28, "uw", "PNJ indices du monde des ténèbres (arbre)",
        {"idle": Anim(seq(g=[0, 1]), 16)}, post={"subtype2": 3}),
    npc("npc_dw_hint_bug", 0x28, 7, 7, "uw", "PNJ indices du monde des ténèbres (insecte volant)",
        {"idle": Anim([dict(g=0, z=1), dict(g=1, z=2), dict(g=0, z=3), dict(g=1, z=4),
                       dict(g=0, z=3), dict(g=1, z=2)], 2)},
        post={"subtype2": 4}),

    # ---------------------------------------------------------------- Haunted grove animals
    npc("npc_grove_ostrich", 0x9E, 15, 1, "lw", "Autruche du bosquet hanté",
        {"idle_left": Anim(seq(g=[0, 3]), [8, 24]),
         "walk_left": Anim(seq(g=[0, 1, 0, 2]), 8)}),
    npc("npc_grove_rabbit", 0x9F, 15, 1, "lw", "Lapin du bosquet hanté",
        {"idle_left": Anim([{"D": 1, "g": 3}], 8),
         "idle_right": Anim([{"D": 0, "g": 3}], 8),
         "walk_left": Anim(seq(D=1, g=[0, 1, 2]), [4, 4, 8]),
         "walk_right": Anim(seq(D=0, g=[0, 1, 2]), [4, 4, 8])}),
    npc("npc_grove_bird", 0xA0, 15, 1, "lw", "Oiseau du bosquet hanté",
        {"idle_left": Anim([dict(D=1, g=0, oam_flags=0x09), dict(D=1, g=3, oam_flags=0x09)], [24, 8]),
         "idle_right": Anim([dict(D=0, g=0, oam_flags=0x49), dict(D=0, g=3, oam_flags=0x49)], [24, 8]),
         "walk_left": Anim(seq(D=1, g=[1, 2], oam_flags=0x09), 2),
         "walk_right": Anim(seq(D=0, g=[1, 2], oam_flags=0x49), 2)}),

    # ---------------------------------------------------------------- Lost Woods animals
    # facing from the sign of x_vel (negative = no flip)
    npc("npc_lost_woods_bird", 0x59, 12, 1, "lw", "Oiseau des Bois perdus",
        {"walk_left": Anim(seq(x_vel=0xF0, z=0, g=[0, 1]), 4),
         "walk_right": Anim(seq(x_vel=0x10, z=0, g=[0, 1]), 4)}),
    npc("npc_lost_woods_squirrel", 0x5A, 12, 1, "lw", "Écureuil des Bois perdus",
        {"walk_left": Anim(seq(x_vel=0xF0, z=0, g=[0, 1]), [16, 12]),
         "walk_right": Anim(seq(x_vel=0x10, z=0, g=[0, 1]), [16, 12])}),

    # ---------------------------------------------------------------- Village of Outcasts kids (0xB9)
    npc("npc_pink_ball_kid", 0xB9, 20, 12, "dw", "Enfant-boule rose (village des Parias)",
        {"walk_down": Anim(seq(g=[0, 1]), 8)}, post={"subtype2": 0}),
    npc("npc_bully", 0xB9, 20, 12, "dw", "Petite brute (village des Parias)",
        {"walk_right": Anim(seq(D=0, g=[0, 1]), 8),
         "walk_left": Anim(seq(D=1, g=[0, 1]), 8)},
        post={"subtype2": 2}),
]
