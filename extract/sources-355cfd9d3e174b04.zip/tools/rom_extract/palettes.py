"""Palette groups (PaletteData, bank 1B) and CGRAM composition for overworld areas."""
from rom import A, Rom

# name: (address, number of palettes, colours per palette)   -- PaletteData.<name>
GROUPS = {
    "sprite_main":   (A(0x1BD218), 8, 15),   # 4 rows light world, then 4 rows dark world
    "link":          (A(0x1BD308), 5, 15),   # green / blue / red mail (+ bunny variants)
    "sprite_pal0":   (A(0x1BD39E), 12, 7),
    "environment":   (A(0x1BD446), 11, 7),
    "sprite_aux":    (A(0x1BD4E0), 24, 7),
    "sword":         (A(0x1BD630), 4, 3),
    "shield":        (A(0x1BD648), 3, 4),
    "hud":           (A(0x1BD660), 2, 32),
    "dungeon_map_sprites": (A(0x1BD70A), 3, 7),
    "dungeon":       (A(0x1BD734), 20, 90),  # 6 rows x 15 colours per dungeon palette
    "dungeon_map_bg": (A(0x1BE544), 1, 96),
    "ow_anim":       (A(0x1BE604), 14, 7),   # "aux3", row 7 left
    "ow_main":       (A(0x1BE6C8), 6, 35),   # 5 rows x 7 colours
    "ow_aux":        (A(0x1BE86C), 20, 21),  # 3 rows x 7 colours
}
GLOVE_COLORS = A(0x1BEDF5)  # 2 colours

# OverworldPaletteSet (bank 0C): 31 entries x 4 bytes (aux1, aux2, aux3, pad); $FF = keep.
OW_PALETTE_SET = A(0x0CFE74)
OW_PALETTE_SET_COUNT = 31
# OverworldSpritesPaletteSet: 20 entries x 2 bytes (sp5l, sp6l); $FF = keep.
OW_SPRITE_PALETTE_SET = A(0x0CFEF0)

LW_BACKDROP, DW_BACKDROP = 0x2669, 0x2A32


def group(rom: Rom, name: str) -> list[list[int]]:
    addr, count, n = GROUPS[name]
    flat = rom.words(addr, count * n)
    return [flat[i * n:(i + 1) * n] for i in range(count)]


def all_groups(rom: Rom) -> dict[str, list[list[int]]]:
    return {k: group(rom, k) for k in GROUPS}


def ow_palette_set(rom: Rom, i: int) -> tuple[int, int, int]:
    b = rom.bytes(OW_PALETTE_SET + i * 4, 3)
    return b[0], b[1], b[2]


def overworld_bg_cgram(rom: Rom, screen: int, palette_set: int,
                       aux_defaults=(3, 3, 0)) -> list[int]:
    """128 BGR555 colours (palette rows 0-7) as loaded for an overworld screen.

    Mirrors Overworld_LoadAreaPalettesEx + OverworldPalettesLoader:
      rows 0-1   HUD
      rows 2-6   ow_main  (cols 1-7)
      rows 2-4   ow_aux #1 (cols 9-15)   rows 5-7  ow_aux #2 (cols 9-15)
      row 7      ow_anim  (cols 1-7)
    Colour 0 of every row is the backdrop.
    """
    cg = [0] * 128
    hud = group(rom, "hud")[0]
    cg[0:32] = hud
    sc = screen & 0x3F
    mode = (2 if sc in (3, 5, 7) else 0) + (1 if screen & 0x40 else 0)
    main = group(rom, "ow_main")[mode]
    for r in range(5):
        cg[(2 + r) * 16 + 1:(2 + r) * 16 + 8] = main[r * 7:(r + 1) * 7]
    a1, a2, a3 = aux_defaults
    s1, s2, s3 = ow_palette_set(rom, palette_set)
    a1 = a1 if s1 == 0xFF else s1
    a2 = a2 if s2 == 0xFF else s2
    a3 = a3 if s3 == 0xFF else s3
    aux = group(rom, "ow_aux")
    for r in range(3):
        cg[(2 + r) * 16 + 9:(2 + r) * 16 + 16] = aux[a1][r * 7:(r + 1) * 7]
        cg[(5 + r) * 16 + 9:(5 + r) * 16 + 16] = aux[a2][r * 7:(r + 1) * 7]
    cg[7 * 16 + 1:7 * 16 + 8] = group(rom, "ow_anim")[a3]
    backdrop = DW_BACKDROP if screen & 0x40 else LW_BACKDROP
    for r in range(8):
        cg[r * 16] = backdrop
    return cg
