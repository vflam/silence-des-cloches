"""numpy renderers: sheets, 8x8 tile banks, map16 atlases, whole screens."""
import numpy as np
from PIL import Image

import gfx
from rom import Rom

_bg_cache: dict[int, gfx.Sheet] = {}


def bg_sheet_cached(rom: Rom, i: int) -> gfx.Sheet:
    if i not in _bg_cache:
        _bg_cache[i] = gfx.bg_sheet(rom, i)
    return _bg_cache[i]


def tiles_to_array(tiles: list[bytes]) -> np.ndarray:
    return np.frombuffer(b"".join(tiles), dtype=np.uint8).reshape(-1, 8, 8)


def sheet_image(tiles: list[bytes], columns: int = 16) -> np.ndarray:
    """Arrange 8x8 tiles in a grid -> 2D array of palette indices."""
    t = tiles_to_array(tiles)
    rows = (len(t) + columns - 1) // columns
    pad = rows * columns - len(t)
    if pad:
        t = np.concatenate([t, np.zeros((pad, 8, 8), np.uint8)])
    return t.reshape(rows, columns, 8, 8).transpose(0, 2, 1, 3).reshape(rows * 8, columns * 8)


def indexed_png(pixels: np.ndarray, palette_rgb: list[tuple[int, int, int]], transparent0=True) -> Image.Image:
    img = Image.fromarray(pixels.astype(np.uint8), "P")
    flat = [c for rgb in palette_rgb for c in rgb]
    img.putpalette(flat + [0] * (768 - len(flat)))
    if transparent0:
        img.info["transparency"] = 0
    return img


def gray_palette(n: int = 16) -> list[tuple[int, int, int]]:
    """Preview ramp for raw indices: 0 = black (transparent), 1..n-1 = dark to white."""
    return [(0, 0, 0)] + [(int(60 + 195 * (i - 1) / max(1, n - 2)),) * 3 for i in range(1, n)]


def bg_tile_bank(rom: Rom, main: int, aux: int) -> np.ndarray:
    """(512, 8, 8) colour indices 0-15 for BG tiles 0-511 of a (main, aux) theme."""
    banks = []
    for sheet_id, high in gfx.bg_vram_sheets(rom, main, aux):
        s = bg_sheet_cached(rom, sheet_id)
        t = tiles_to_array(s.tiles[:64])
        if high:
            t = np.where(t != 0, t | 8, 0).astype(np.uint8)
        banks.append(t)
    return np.concatenate(banks)


def cgram_rgb(cgram: list[int]) -> np.ndarray:
    return np.array([gfx.snes_color(c) for c in cgram], dtype=np.uint8)


def draw_tile8(word: int, bank: np.ndarray) -> np.ndarray:
    """Tilemap word -> (8,8) CGRAM indices (0 stays 0 = transparent)."""
    t = bank[word & 0x1FF]
    if word & 0x4000:
        t = t[:, ::-1]
    if word & 0x8000:
        t = t[::-1, :]
    pal = (word >> 10) & 7
    return np.where(t != 0, t + pal * 16, 0)


def map16_pixels(defs: list[list[int]], bank: np.ndarray) -> np.ndarray:
    """(N, 16, 16) CGRAM indices for every map16."""
    out = np.zeros((len(defs), 16, 16), np.uint16)
    for i, (tl, tr, bl, br) in enumerate(defs):
        out[i, :8, :8] = draw_tile8(tl, bank)
        out[i, :8, 8:] = draw_tile8(tr, bank)
        out[i, 8:, :8] = draw_tile8(bl, bank)
        out[i, 8:, 8:] = draw_tile8(br, bank)
    return out


def atlas(map16_px: np.ndarray, columns: int = 64) -> np.ndarray:
    n = len(map16_px)
    rows = (n + columns - 1) // columns
    t = np.zeros((rows * columns, 16, 16), map16_px.dtype)
    t[:n] = map16_px
    return t.reshape(rows, columns, 16, 16).transpose(0, 2, 1, 3).reshape(rows * 16, columns * 16)


def colorize(indices: np.ndarray, rgb: np.ndarray, transparent_index0=True) -> Image.Image:
    """CGRAM indices -> RGBA image (index 0 transparent)."""
    img = rgb[indices]
    alpha = np.where(indices == 0, 0, 255).astype(np.uint8) if transparent_index0 else np.full(indices.shape, 255, np.uint8)
    return Image.fromarray(np.dstack([img, alpha]), "RGBA")
