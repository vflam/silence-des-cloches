"""Options shared by the extraction steps (set by extract.py)."""

# Previews / contact sheets / debug images (previews/, sprites/previews/, maps/previews/,
# underworld/previews/, maps/stamps/...): never read by the game. False with
# `extract.py --no-previews` (the web version, docs/tech/WEB.md).
PREVIEWS = True
