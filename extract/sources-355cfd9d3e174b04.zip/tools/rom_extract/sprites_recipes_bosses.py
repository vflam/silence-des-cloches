"""Boss sprites (tag "boss"). See sprites_custom_bosses.py for the multi-part bosses."""
from sprites_recipe import Recipe as R, Anim, seq
import sprites_custom_bosses as cb

K = lambda *keys: [{"key": k} for k in keys]

# hit flash: the ROM xors (hit_timer * 2) & 0xE into the OAM palette bits (sprite_obj_prio)
FLASH = [0xE, 0xC, 0xA, 0x8, 0x6, 0x4, 0x2, 0x0]

# ---------------------------------------------------------------- Armos Knights (0x53)
_HOP = [0, 5, 10, 14, 17, 18, 19, 19, 18, 17, 14, 10, 5]          # z_vel 48, -4 / frame
_CRUSH_UP = [0, 4, 9, 14, 18, 22, 25, 27, 29]                   # last knight: z_vel 32, +3...
_CRUSH_DOWN = [23, 16, 9, 2, 0]                                  # z_vel -104


def _armos(oam_flags):
    st = lambda **v: {"prio": 0, "oam_flags": oam_flags, "g": 0, "z": 0, **v}
    return {
        "idle_down": Anim([st()], 8),
        "hurt_down": Anim([st(prio=p) for p in FLASH], 1),
        "special_hop": Anim([st(z=z) for z in _HOP], 2, loop=False),
        "special_crush": Anim([st(z=z) for z in _CRUSH_UP] + [st(z=29)] + [st(z=z) for z in _CRUSH_DOWN],
                              [2] * len(_CRUSH_UP) + [16] + [1] * len(_CRUSH_DOWN), loop=False),
        "die": Anim([st(g=g) for g in (1, 2, 3, 4, 5)], 8, loop=False),
    }


# ---------------------------------------------------------------- Lanmola (0x54)
def _lanmola_anims():
    a = {}
    for n in range(16):
        a[f"special_head_{n}"] = Anim(K(f"head_{n}"), 8)
        a[f"special_body_{n}"] = Anim(K(f"body_{n}"), 8)
        a[f"special_tail_{n}"] = Anim(K(f"tail_{n}"), 8)
    a["special_shadow"] = Anim(K("shadow"), 8)
    a["special_emerge"] = Anim(K(*[f"mound_{i}" for i in range(16)], *[f"debris_{i}" for i in range(19)]),
                               [8] * 16 + [4] * 19, loop=False)
    a["special_debris"] = Anim(K(*[f"debris_{i}" for i in range(19)]), 4, loop=False)
    a["special_leap"] = Anim(K(*[f"leap_{i}" for i in range(cb.LANMOLA_LEAP_N)]), cb.LANMOLA_LEAP_STEP, loop=False)
    a["die"] = Anim(K(*[f"die_{i}" for i in range(cb.LANMOLA_DIE_N)]), cb.LANMOLA_DIE_STEP, loop=False)
    return a


# ---------------------------------------------------------------- Giant Moldorm (0x09)
_D4 = {"right": 0, "down": 4, "left": 8, "up": 12}


def _moldorm_anims():
    a = {}
    for d in range(16):
        a[f"special_head_{d}"] = Anim(K(f"head_{d}_0", f"head_{d}_1"), 2)
    for name, d in _D4.items():
        a[f"walk_{name}"] = Anim(K(*[f"walk_{d}_{s}" for s in range(4)]), 2)
        a[f"hurt_{name}"] = Anim(K(*[f"stun_{d}_{f}" for f in range(8)]), 2)
    a["special_segment_a"] = Anim(K("segA_0", "segA_1"), 2)
    a["special_segment_c"] = Anim(K(*[f"segC_{t}" for t in range(4)]), 2)
    a["special_tail"] = Anim(K(*[f"tail_{t}" for t in range(4)]), 2)
    a["die"] = Anim(K(*[f"die_{b}_{p}" for b in range(5) for p in range(4)]), 4, loop=False)
    return a


RECIPES = [
    R("boss_armos_knight", 0x53, set=9, pal=11, world="uw", tags=["boss"],
      desc="Chevaliers Armos (boss du Palais de l'Est)", anims=_armos(0x09)),
    R("boss_armos_knight_red", 0x53, set=9, pal=11, world="uw", tags=["boss"],
      desc="Dernier chevalier Armos (rouge, écrasement)", anims=_armos(0x07)),
    R("boss_lanmola", 0x54, set=11, pal=4, world="uw", tags=["boss"],
      desc="Lanmolas, ver des sables (pièces + sortie du sable)",
      custom=lambda rom: cb.lanmola(rom), anims=_lanmola_anims()),
    R("boss_moldorm", 0x09, set=12, pal=6, world="uw", tags=["boss"],
      desc="Moldorm géant (tête 16 directions + anneaux + queue)",
      custom=lambda rom: cb.moldorm(rom), anims=_moldorm_anims()),
]


# ---------------------------------------------------------------- Helmasaur King (0x92)
def _hk_anims():
    N = cb.HK_N
    a = {
        "idle_down": Anim(K(*[f"idle_{i}" for i in range(32)]), 4),
        "walk_down": Anim(K(*[f"walk0_{i}" for i in range(N)]), cb.HK_STEP),
        "special_walk_mask_cracked": Anim(K(*[f"walk1_{i}" for i in range(N)]), cb.HK_STEP),
        "special_walk_mask_broken": Anim(K(*[f"walk2_{i}" for i in range(N)]), cb.HK_STEP),
        "special_walk_unmasked": Anim(K(*[f"walk3_{i}" for i in range(N)]), cb.HK_STEP),
        "hurt_down": Anim(K(*[f"hurt_{i}" for i in range(8)]), 1),
        "attack_down": Anim(K(*[f"spit_{i}" for i in range(16)]), 8, loop=False),
        "special_tail_ball": Anim(K("tail_ball"), 8),
        "special_tail_mace": Anim(K("tail_mace"), 8),
        "die": Anim(K(*[f"die_{i}" for i in range(cb.HK_DIE_N)]), 8, loop=False),
    }
    return a


RECIPES.append(
    R("boss_helmasaur_king", 0x92, set=21, pal=16, world="uw", tags=["boss"],
      desc="Roi Helmasaure (boss du Palais des Ténèbres)",
      custom=lambda rom: cb.helmasaur_king(rom), anims=_hk_anims()))


# ---------------------------------------------------------------- Mothula (0x88) + projectiles
_FLAP = [0, 1, 2, 1]          # Mothula_FlapWings: sprite_subtype2 >> 2 & 3 -> graphics


def _mothula_anims():
    st = lambda i, **v: {"g": _FLAP[i % 4], "z": 24, "prio": 0, "frame": 4 * i, **v}
    return {
        "idle_down": Anim([st(i) for i in range(8)], 4),
        "special_ascend": Anim([st(i, z=2 * i) for i in range(13)], 4, loop=False),
        "hurt_down": Anim([st(i // 2, prio=p) for i, p in enumerate(FLASH)], 1),
        "die": Anim([st(i, prio=FLASH[(3 * i) % 8]) for i in range(24)], 4, loop=False),
    }


RECIPES += [
    R("boss_mothula", 0x88, set=26, pal=14, world="uw", tags=["boss"],
      desc="Mothula, papillon géant (boss du Palais des Bois)", anims=_mothula_anims()),
    R("boss_mothula_beam", 0x89, set=26, pal=14, world="uw", tags=["boss", "fx"],
      desc="Anneau de feu tiré par Mothula",
      anims={"idle": Anim([{"g": 0, "oam_flags": 0x03}, {"g": 0, "oam_flags": 0x83}], 2)}),
    R("boss_helmasaur_fireball", 0x70, set=21, pal=16, world="uw", tags=["boss", "fx"],
      desc="Boule de feu du roi Helmasaure (grosse puis petites)",
      anims={"idle": Anim(seq(g=[2, 2], subtype2=[3, 7]), 4),
             "special_small": Anim(seq(g=[0, 0], subtype2=[3, 7]), 4)}),
]


# ---------------------------------------------------------------- Kholdstare (0xA2) + falling ice (0xA4)
# (its ice shell 0xA3 is drawn on BG layer 1 by the room, not by sprites)
def _kholdstare_anims():
    st = lambda a, g, **v: {"A": a, "g": g, "prio": 0, **v}
    an = {f"idle_{d}": Anim([st(a, g) for g in range(4)], 11)
          for d, a in {"right": 0, "down": 4, "left": 8, "up": 12}.items()}
    for a in range(16):
        an[f"special_look_{a}"] = Anim([st(a, g) for g in range(4)], 11)
    an["hurt_down"] = Anim([st(4, i // 2 % 4, prio=p) for i, p in enumerate(FLASH)], 1)
    an["die"] = Anim([st(4, (i // 3) % 4, prio=FLASH[(3 * i) % 8]) for i in range(24)], 4, loop=False)
    return an


RECIPES += [
    R("boss_kholdstare", 0xA2, set=22, pal=20, world="uw", tags=["boss"],
      desc="Kholdstare, oeil-nuage (boss du Palais de Glace), sans sa coquille",
      anims=_kholdstare_anims()),
    R("boss_kholdstare_ice", 0xA4, set=22, pal=20, world="uw", tags=["boss", "fx"],
      desc="Bloc de glace qui tombe (Kholdstare) et ses éclats",
      post={"C": 0xE0},
      # flags3 0x5D: the frame where the (flickering, every other frame) shadow is drawn
      anims={"idle": Anim([{"g": 0, "z": 0, "flags3": 0x5D}], 8),
             "special_fall": Anim([{"g": 0, "z": z, "flags3": 0x5D} for z in (96, 72, 48, 28, 12, 0)],
                                  3, loop=False),
             "special_small": Anim([{"g": 1, "z": 0, "flags3": 0x5D}], 8)}),
]


# ---------------------------------------------------------------- Arrghus (0x8C) + Arrghi puffs (0x8D)
_ARRGHUS_G = [1, 1, 1, 2, 2, 1, 1, 0, 0]      # sprite_G cycle (one step every 4 frames)


def _arrghus_anims():
    st = lambda i, **v: {"g": _ARRGHUS_G[i % 9], "subtype2": 4 * i, "ai": 0, "z": 24, "prio": 0,
                         "frame": 4 * i, **v}
    return {
        "idle_down": Anim([st(i) for i in range(18)], 4),
        "special_jump": Anim([st(i, z=z) for i, z in enumerate(range(24, 125, 25))], 4, loop=False),
        "special_swim": Anim([st(i, ai=5, z=0) for i in range(18)], 4),
        "hurt_down": Anim([st(i // 2, prio=p) for i, p in enumerate(FLASH)], 1),
        "die": Anim([st(i, prio=FLASH[(3 * i) % 8]) for i in range(24)], 4, loop=False),
    }


RECIPES += [
    R("boss_arrghus", 0x8C, set=20, pal=8, world="uw", tags=["boss"],
      desc="Arrghus, méduse géante (boss du Palais des Marais)", anims=_arrghus_anims()),
    R("boss_arrghi", 0x8D, set=20, pal=8, world="uw", tags=["boss"],
      desc="Arrghi, boule de mousse qui entoure Arrghus",
      post={"x_lo": 0x80, "x_hi": 0x08, "y_lo": 0x80, "y_hi": 0x08},
      anims={"idle": Anim(seq(g=[0, 1, 2, 2, 2, 2, 2, 1], oam_flags=0x0D), 8),
             "special_hooked": Anim(seq(g=[0, 1, 2, 2, 2, 2, 2, 1], oam_flags=0x05), 8)}),
]


# ---------------------------------------------------------------- Agahnim (0x7A) + energy ball (0x7B)
_AGA_D = {"down": 3, "up": 0, "left": 4, "right": 2}    # sprite_D -> graphics 0 / 2 / 4 / 8 (+1 = casting)
_AGA_G = {"down": 0, "up": 2, "left": 4, "right": 8}
_AGA_CHARGE = {"down": 0, "up": 30, "left": 6, "right": 12}   # sprite_head_dir base (1..6 added)


def _agahnim_anims():
    st = lambda d, **v: {"D": _AGA_D[d], "g": _AGA_G[d], "head": 0, "A": 0, "prio": 0, "frame": 0, **v}
    a = {}
    for d in _AGA_D:
        a[f"idle_{d}"] = Anim([st(d)], 8)
        # casting: arms up (graphics + 1) while the energy grows between the hands (16 frames each),
        # the charge flickers (palette alternates with bit 2 of the frame counter)
        a[f"attack_{d}"] = Anim([st(d, g=_AGA_G[d] + 1, head=_AGA_CHARGE[d] + t, frame=2 * i)
                                 for i, t in enumerate(n for n in range(1, 7) for _ in range(4))], 4, loop=False)
        a[f"hurt_{d}"] = Anim([st(d, prio=p) for p in FLASH], 1)
    a["special_diagonal_downleft"] = Anim([st("down", D=5, g=6)], 8)
    a["special_diagonal_downright"] = Anim([st("down", D=1, g=10)], 8)
    a["special_warp_out"] = Anim([st("down", g=g) for g in (12, 13, 14, 15, 16)], 8, loop=False)
    a["special_warp_in"] = Anim([st("down", g=g) for g in (16, 15, 14, 13, 12)], 8, loop=False)
    a["special_glide"] = Anim([st("down", g=12)], 8)
    a["die"] = Anim([st("down", prio=FLASH[(3 * i) % 8]) for i in range(24)] + [st("down", g=17)],
                    [4] * 24 + [64], loop=False)
    return a


RECIPES += [
    R("boss_agahnim", 0x7A, set=24, pal=27, world="uw", tags=["boss"],
      desc="Agahnim, le sorcier (tour du château d'Hyrule)", anims=_agahnim_anims()),
    R("boss_agahnim_dw", 0x7A, set=24, pal=27, world="uw", tags=["boss"], post={"oam_flags": 0x07},
      desc="Agahnim, palette du Monde des Ténèbres (tour de Ganon)", anims=_agahnim_anims()),
    R("boss_agahnim_ball", 0x7B, set=24, pal=27, world="uw", tags=["boss", "fx"],
      desc="Boule d'énergie d'Agahnim (renvoyable à l'épée)",
      anims={"idle": Anim([{"g": 0, "frame": 0}, {"g": 0, "frame": 4}], 2)}),
]


# ---------------------------------------------------------------- Blind (0xCE)
# body graphics 0..14 (7 OAM entries, the head entry replaced by one of 16 head directions,
# sprite_head_dir: 4 = facing the camera, 12 = seen from behind), 15..20 = transformation cloud


def _blind_anims():
    st = lambda g, head=4, **v: {"g": g, "head": head, "C": 1, "prio": 0, "poke": {0x0E70: 0}, **v}   # $0E70: sprite_wallcoll
    a = {
        # D = 2 (bottom wall, robe frames 7 8 9 8) / D = 3 (top wall, robe frames 0 1 2 1)
        "walk_down": Anim([st(g) for g in (7, 8, 9, 8)], 8),
        "walk_up": Anim([st(g) for g in (0, 1, 2, 1)], 8),
        "special_look_around": Anim([st((7, 8, 9, 8)[i % 4], head=h) for i, h in enumerate(
            [0, 1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 3, 2, 1])], 8),
        "special_whirl": Anim([st(g) for g in range(10)], 4, loop=False),
        "special_behind_curtain": Anim([st(g, head=12) for g in (14, 13, 12, 10)], 8, loop=False),
        "special_rerobe": Anim([st(g, head=12) for g in (10, 11, 12, 13, 14)], 8, loop=False),
        "special_transform": Anim([st(g) for g in (20, 19, 18, 17, 16, 15, 15)], 8, loop=False),
        "hurt_down": Anim([st(7, prio=p) for p in FLASH], 1),
        "die": Anim([st((7, 8, 9, 8)[(i // 2) % 4], prio=FLASH[(3 * i) % 8]) for i in range(32)], 4,
                    loop=False),
    }
    for h in range(16):
        a[f"special_head_{h}"] = Anim([st(7, head=h)], 8)
    return a


RECIPES += [
    R("boss_blind", 0xCE, set=32, pal=23, world="uw", tags=["boss"],
      desc="Blind le voleur (boss de la Ville des Voleurs)",
      post={"D": 2, "A": 0}, anims=_blind_anims()),
    R("boss_blind_head", 0xCE, set=32, pal=23, world="uw", tags=["boss"],
      desc="Tête volante de Blind (tourne sur elle-même)",
      post={"A": 2, "oam_flags": 0x0B, "D": 2},
      anims={"idle": Anim([{"head": h, "prio": 0} for h in range(16)], 3),
             "hurt": Anim([{"head": 4, "prio": p} for p in FLASH], 1)}),
]
