#!/usr/bin/env python3
"""Original sprites (NOT from the ROM), drawn procedurally in the ALttP style and versioned in
game/assets/custom/sprites/ (PNG + catalog.json merged by the engine over the ROM catalog).
    python3 tools/rom_extract/sprites_art_custom.py
Ids: bell (32x32 bronze bell: idle, ring), clapper (16x16 held clapper), bell_small (16x16)."""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from PIL import Image

OUT = Path(__file__).resolve().parents[2] / "game" / "assets" / "custom" / "sprites"

# palette (ALttP-like ramps)
T = (0, 0, 0, 0)
OUTLINE = (40, 24, 16, 255)
BRONZE = [(96, 48, 16, 255), (152, 88, 32, 255), (200, 128, 48, 255), (232, 176, 80, 255), (248, 224, 144, 255)]
IRON = [(48, 48, 64, 255), (96, 96, 120, 255), (160, 160, 184, 255), (216, 216, 232, 255)]
WOOD = [(72, 40, 24, 255), (128, 80, 40, 255), (176, 120, 64, 255)]
SHADOW = (0, 0, 0, 96)


def outline(img: np.ndarray) -> np.ndarray:
    """Add a 1-px dark outline around opaque pixels (4-neighbourhood), like ALttP sprites."""
    a = img[..., 3] > 0
    grow = np.zeros_like(a)
    grow[1:, :] |= a[:-1, :]
    grow[:-1, :] |= a[1:, :]
    grow[:, 1:] |= a[:, :-1]
    grow[:, :-1] |= a[:, 1:]
    out = img.copy()
    out[grow & ~a] = OUTLINE
    return out


def shade(c: int, x: float, y: float, half: float, ramp) -> tuple:
    """Pick a ramp colour: light from the upper left, darker toward the right edge."""
    t = (x / max(half, 1))            # -1 (left) .. 1 (right)
    v = 0.62 - 0.55 * t - 0.12 * y
    i = int(round(v * (len(ramp) - 1)))
    return ramp[max(0, min(len(ramp) - 1, i))]


def bell_profile(y: int) -> float:
    """Half-width of the big bell body at row y (0 = top of the dome)."""
    if y < 0:
        return 0
    if y < 3:
        return 5 + y * 1.5
    if y < 16:
        return 8 + (y - 3) * 0.22
    if y < 22:
        return 11 + (y - 16) * 0.5
    return 14.0


def draw_big_bell(shear: float = 0.0, clapper_dx: float = 0.0) -> np.ndarray:
    """36x32 canvas, bell box 32x32 at (2, 0). shear = horizontal displacement at the lip
    (pivot at the top), for the swing."""
    W, H = 36, 32
    img = np.zeros((H, W, 4), np.uint8)
    cx = W / 2 - 0.5
    top = 5                            # dome starts at row 5 (rows 1-4: hanger)

    def sx(y):                          # swing offset of row y
        return shear * max(0, y - 1) / (H - 1)

    # hanger (iron loop + yoke)
    for y in range(1, top):
        for x in range(W):
            dx = x - (cx + sx(y))
            if y <= 2 and 1.5 <= abs(dx) <= 3.5:
                img[y, x] = IRON[2 if dx < 0 else 1]
            if y == 1 and abs(dx) < 1.5:
                img[y, x] = IRON[3]
            if y >= 3 and abs(dx) <= 4.5:
                img[y, x] = WOOD[2 if dx < -1 else 1 if dx < 2 else 0]
    # body
    for y in range(top, 28):
        hw = bell_profile(y - top)
        c = cx + sx(y)
        for x in range(W):
            dx = x - c
            if abs(dx) <= hw:
                img[y, x] = shade(0, dx, (y - top) / 23, hw, BRONZE)
        # decorative bands
        if y in (top + 4, top + 16):
            for x in range(W):
                dx = x - c
                if abs(dx) <= hw - 0.5:
                    img[y, x] = BRONZE[0] if dx > 2 else BRONZE[1]
        if y == top + 5:
            for x in range(W):
                dx = x - c
                if abs(dx) <= hw - 1 and dx < 1:
                    img[y, x] = BRONZE[4]
    # lip (thicker bright rim)
    for y in (26, 27):
        c = cx + sx(y)
        for x in range(W):
            dx = x - c
            if abs(dx) <= 14.5:
                img[y, x] = BRONZE[3] if (dx < 4 and y == 26) else BRONZE[1] if y == 27 else BRONZE[2]
    # inner shadow + clapper ball under the lip
    c = cx + sx(28)
    for x in range(W):
        dx = x - c
        if abs(dx) <= 12.5:
            img[28, x] = BRONZE[0]
    bx = cx + sx(30) + clapper_dx
    for y in (28, 29, 30):
        for x in range(W):
            dx = x - bx
            r = 2.2 if y != 28 else 1.2
            if dx * dx + (y - 29.3) ** 2 <= r * r:
                img[y, x] = IRON[2 if dx < 0 else 1]
    # highlight streak
    for y in range(top + 6, top + 15):
        c = cx + sx(y)
        x = int(round(c - bell_profile(y - top) + 3))
        img[y, x] = BRONZE[4]
    return outline(img)


def draw_clapper() -> np.ndarray:
    """16x16 held clapper: iron rod with a heavy ball, diagonal."""
    img = np.zeros((16, 16, 4), np.uint8)
    for t in range(0, 9):
        x, y = 3 + t, 2 + t
        img[y, x] = IRON[3]
        img[y, x + 1] = IRON[2]
        img[y + 1, x + 1] = IRON[1]
    img[1, 2] = img[1, 3] = img[2, 2] = WOOD[2]    # ring at the top
    img[0, 3] = WOOD[1]
    for y in range(8, 16):
        for x in range(8, 16):
            d = (x - 11.5) ** 2 + (y - 11.5) ** 2
            if d <= 11:
                img[y, x] = IRON[3] if (x < 11 and y < 11) else IRON[2] if d < 3 else IRON[1]
    return outline(img)


def draw_small_bell(swing: int = 0) -> np.ndarray:
    """16x16 hand bell: wooden handle + bronze cup."""
    img = np.zeros((16, 16, 4), np.uint8)
    cx = 7.5
    for y in range(0, 6):
        for x in range(16):
            dx = x - cx - swing * (y - 1) / 14
            if abs(dx) <= (2.0 if y <= 1 else 1.1):
                img[y, x] = WOOD[2] if dx < 0 else WOOD[1]
    for y in range(6, 14):
        hw = 2.5 + 4.3 * math.sqrt((y - 6) / 7)
        c = cx + swing * (y - 1) / 14
        for x in range(16):
            dx = x - c
            if abs(dx) <= hw:
                img[y, x] = shade(0, dx, (y - 6) / 8, hw, BRONZE)
    c = cx + swing * 13 / 14
    for x in range(16):
        if abs(x - c) <= 7.2:
            img[13, x] = BRONZE[3] if x < c else BRONZE[1]
    img[14, int(round(c))] = IRON[2]
    return outline(img)


def build() -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    catalog = {}

    # big bell: frames 36x32 (bell box 32x32 at x=2); anchor = top-left of the bell box
    swings = [0, 2, 4, 2, 0, -2, -4, -2]
    frames = [draw_big_bell(s, clapper_dx=-s * 0.6) for s in swings]
    sheet = np.concatenate(frames, axis=1)
    Image.fromarray(sheet, "RGBA").save(OUT / "bell.png")
    catalog["bell"] = {
        "png": "sprites/bell.png",
        "frames": [{"x": 36 * i, "y": 0, "w": 36, "h": 32, "ox": 2, "oy": 0} for i in range(len(frames))],
        "anims": {"idle": {"frames": [0], "durations": [60], "loop": True},
                  "ring": {"frames": list(range(8)), "durations": [5] * 8, "loop": True}},
        "tags": ["item"], "palette": "custom", "source": "original (Zelda3-2)",
        "desc": "Grande cloche de bronze (32x32, ancrage = coin haut-gauche de la cloche)",
    }

    Image.fromarray(draw_clapper(), "RGBA").save(OUT / "clapper.png")
    catalog["clapper"] = {
        "png": "sprites/clapper.png",
        "frames": [{"x": 0, "y": 0, "w": 16, "h": 16, "ox": 0, "oy": 0}],
        "anims": {"idle": {"frames": [0], "durations": [60], "loop": True}},
        "tags": ["item"], "palette": "custom", "source": "original (Zelda3-2)",
        "desc": "Battant de cloche (objet tenu)",
    }

    small = [draw_small_bell(s) for s in (0, 2, 0, -2)]
    Image.fromarray(np.concatenate(small, axis=1), "RGBA").save(OUT / "bell_small.png")
    catalog["bell_small"] = {
        "png": "sprites/bell_small.png",
        "frames": [{"x": 16 * i, "y": 0, "w": 16, "h": 16, "ox": 0, "oy": 0} for i in range(4)],
        "anims": {"idle": {"frames": [0], "durations": [60], "loop": True},
                  "ring": {"frames": [0, 1, 2, 3], "durations": [4, 4, 4, 4], "loop": True}},
        "tags": ["item"], "palette": "custom", "source": "original (Zelda3-2)",
        "desc": "Petite cloche à main",
    }

    path = OUT / "catalog.json"
    old = json.loads(path.read_text()) if path.exists() else {}
    old.update(catalog)
    path.write_text(json.dumps(old, ensure_ascii=False, indent=1))
    return catalog


if __name__ == "__main__":
    print(list(build()))
