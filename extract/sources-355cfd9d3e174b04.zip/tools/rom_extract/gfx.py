"""Graphics sheets, SNES tile formats and palettes."""
from dataclasses import dataclass

from rom import A, Rom

# GFXSheetPointers (bank 00): three split tables (bank / high / low bytes).
BG_SHEETS = 0x73      # background sheets 0x00-0x72
SPR_SHEETS = 0x6C     # sprite sheets 0x00-0x6B ("global" sheet id 0x73 + n)
PTR_BG_BANK, PTR_SPR_BANK = A(0x00CFC0), A(0x00D033)
PTR_BG_HIGH, PTR_SPR_HIGH = A(0x00D09F), A(0x00D112)
PTR_BG_LOW, PTR_SPR_LOW = A(0x00D17E), A(0x00D1F1)
SPR_UNCOMPRESSED = 12  # sprite sheets 0x00-0x0B are stored raw (0x600 bytes)

LINK_GFX = A(0x108000)    # 4bpp, 0x7000 bytes (bin/gfx/link.4bpp)
LINK_GFX_SIZE = 0x7000

# Sheets tables (bank 00)
MAIN_TILESETS = A(0x00E0B3)   # SheetsTable_AA1: 37 x 8 background sheets
AUX_TILESETS = A(0x00DDD7)    # SheetsTable_AA2: 82 x 4
SPRITE_TILESETS = A(0x00DB97)  # SheetsTable_AA3: 144 x 4


@dataclass
class Sheet:
    """A decoded sheet: tiles of 8x8 palette indices (0-7 for 3bpp)."""
    kind: str        # "bg" | "spr"
    index: int
    bpp: int
    tiles: list[bytes]  # each tile: 64 bytes, row-major pixel values


def _ptr(rom: Rom, bank_t: int, high_t: int, low_t: int, i: int) -> int:
    return rom.byte(bank_t + i) << 16 | rom.byte(high_t + i) << 8 | rom.byte(low_t + i)


def decode_planar(data: bytes, bpp: int) -> list[bytes]:
    """SNES planar tiles -> list of 64-byte pixel arrays.

    2bpp: 16 bytes/tile (planes 0,1 interleaved per row).
    3bpp: 24 bytes/tile = 2bpp block + 8 bytes of plane 2 (ALttP storage format).
    4bpp: 32 bytes/tile = two 2bpp blocks (planes 0,1 then 2,3).
    """
    size = {2: 16, 3: 24, 4: 32}[bpp]
    tiles = []
    for t in range(len(data) // size):
        d = data[t * size:(t + 1) * size]
        px = bytearray(64)
        for y in range(8):
            p0, p1 = d[y * 2], d[y * 2 + 1]
            p2 = d[16 + y] if bpp == 3 else d[16 + y * 2] if bpp == 4 else 0
            p3 = d[16 + y * 2 + 1] if bpp == 4 else 0
            for x in range(8):
                s = 7 - x
                px[y * 8 + x] = ((p0 >> s) & 1) | ((p1 >> s) & 1) << 1 | ((p2 >> s) & 1) << 2 | ((p3 >> s) & 1) << 3
        tiles.append(bytes(px))
    return tiles


def bg_sheet(rom: Rom, i: int) -> Sheet:
    data = rom.decompress(_ptr(rom, PTR_BG_BANK, PTR_BG_HIGH, PTR_BG_LOW, i))
    if len(data) >= 0x800:  # sheets 0x71-0x72 are 2bpp
        return Sheet("bg", i, 2, decode_planar(data[:0x800], 2))
    return Sheet("bg", i, 3, decode_planar(data[:0x600], 3))


def spr_sheet(rom: Rom, i: int) -> Sheet:
    addr = _ptr(rom, PTR_SPR_BANK, PTR_SPR_HIGH, PTR_SPR_LOW, i)
    data = rom.bytes(addr, 0x600) if i < SPR_UNCOMPRESSED else rom.decompress(addr)
    if len(data) >= 0x800:  # HUD / font / attract sheets are 2bpp (128 tiles)
        return Sheet("spr", i, 2, decode_planar(data[:0x800], 2))
    return Sheet("spr", i, 3, decode_planar(data[:0x600], 3))


def link_tiles(rom: Rom) -> list[bytes]:
    return decode_planar(rom.bytes(LINK_GFX, LINK_GFX_SIZE), 4)


def high_expand(tile: bytes) -> bytes:
    """ALttP 'Do3To4High': non-zero pixels use the right half (colours 8-15) of a palette row."""
    return bytes(p | 8 if p else 0 for p in tile)


def main_tileset(rom: Rom, i: int) -> list[int]:
    return list(rom.bytes(MAIN_TILESETS + i * 8, 8))


def aux_tileset(rom: Rom, i: int) -> list[int]:
    return list(rom.bytes(AUX_TILESETS + i * 4, 4))


def sprite_tileset(rom: Rom, i: int) -> list[int]:
    return list(rom.bytes(SPRITE_TILESETS + i * 4, 4))


def bg_vram_sheets(rom: Rom, main: int, aux: int) -> list[tuple[int, bool]]:
    """The 8 background sheets loaded in VRAM for (main, aux) tile themes, in tile order
    (tile n lives in entry n // 64), with the 'high' (colours 8-15) flag of each slot.
    Mirrors InitializeTilesets / LoadBackgroundGraphics."""
    mt = main_tileset(rom, main)
    at = aux_tileset(rom, aux)
    ids = [mt[0], mt[1], mt[2],
           at[0] or mt[3], at[1] or mt[4], at[2] or mt[5], at[3] or mt[6],
           mt[7]]
    slots = [7, 6, 5, 4, 3, 2, 1, 0]
    if main >= 0x20:
        high = [s in (7, 2, 3, 4) for s in slots]
    else:
        high = [s >= 4 for s in slots]
    return list(zip(ids, high))


# ---------------------------------------------------------------- palettes

def snes_color(c: int) -> tuple[int, int, int]:
    r, g, b = c & 0x1F, (c >> 5) & 0x1F, (c >> 10) & 0x1F
    return (r << 3 | r >> 2, g << 3 | g >> 2, b << 3 | b >> 2)


def hex_color(c: int) -> str:
    return "#%02x%02x%02x" % snes_color(c)
