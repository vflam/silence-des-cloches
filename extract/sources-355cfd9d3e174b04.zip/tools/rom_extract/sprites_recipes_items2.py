"""Second batch of the "items" group: boomerangs, received-item icons (`item_<id>`) and
dungeon objects (torch, crystal switch, pegs, block, floor switch, rollers, locked doors).
See sprites_custom_items2.py. Durations come from the ROM code (animation timers)."""
from sprites_recipe import Recipe as R
import sprites_custom_items as C
import sprites_custom_items2 as C2
from rom import A

LW, LW_PAL, LW_SET = "lw", 1, 1
EP_ROOM, EP_MAIN = 0xC9, 5              # Eastern Palace (tile theme 5)
POD_ROOM, POD_MAIN = 0x0B, 7            # Palace of Darkness (pegs, crystal switch)
POD_SPR_SET, POD_PAL = 25, 15           # its sprite set / palette set
TR_SPR_SET, TR_PAL = 38, 24             # Turtle Rock room $04 (rollers)


def boomerang(id_, level, desc):
    """Ancilla $05: 4 orientations, each held Boomerang_Draw's timer + 1 frames (4 / 3)."""
    st = {f"r{j}": (lambda h, j=j: [h.ancilla(5, numspr=4, aux_timer=1), h.cpu.w8(0x03A4, j),
                                     h.cpu.w8(0x0394, level)]) for j in range(4)}
    return R(id_, None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"], desc=desc,
             anims={"idle": C.keys_anim(["r0"], 8), "fly": C.keys_anim(["r0", "r1", "r2", "r3"], 4 - level)},
             custom=C.harness_states(LW, LW_PAL, LW_SET, st, C.ANCILLA_MAIN, submodule=1))


def icon(id_, receipt, desc, **pal):
    return R(id_, None, set=LW_SET, pal=LW_PAL, world=LW, tags=["item"], desc=desc,
             anims={"idle": C.keys_anim(["idle"], 8)}, custom=C2.item_icon(receipt, **pal))


def dobj(fn, cols, rows, **opts):
    return (fn, cols, rows, opts)


O = C2.obj_data
TORCH_UNLIT = lambda r: C2.operand(r, A(0x01B51B))   # DrawObjects_LightableTorch: LDX #obj0EC2
TORCH_LIT = lambda r: C2.operand(r, A(0x01B523))     #                              LDX #obj0ECA
SWITCH_UP = lambda r: r.word(A(0x01E7A1))            # UpdateTilemapWithCommonObject.replacement_tiles $0E
SWITCH_DOWN = lambda r: r.word(A(0x01E7A3))          #                                                 $10
BLUE_PEG, ORANGE_PEG = (lambda r: O(r, 0x252)), (lambda r: O(r, 0x253))   # Single Blue / Red Peg
PEG_UP, PEG_DOWN = 0, 3                           # peg images ($B340 + $80 * i) raised / lowered


def door(side, kind):
    cols, rows = (4, 3) if side in ("up", "down") else (3, 4)
    size = f"{cols * 8}x{rows * 8}"
    what = "à petite clé" if kind == "key" else "à grande clé"
    return R(f"door_{side}_{kind}", None, world="uw", tags=["item"], shadow=False,
             desc=f"Porte verrouillée {what}, mur {side} ({size}, ancrage coin haut-gauche)",
             anims={"idle": C.keys_anim(["idle"], 8)},
             custom=C2.dungeon_objects(EP_ROOM, EP_MAIN, {"idle": dobj(lambda r: C2.door_data(r, side, kind), cols, rows)}))


def roller(id_, D, desc):
    return R(id_, None, set=TR_SPR_SET, pal=TR_PAL, world="uw", tags=["enemy"], desc=desc,
             anims={"roll": C.keys_anim(["a", "b"], 2)},    # graphics = subtype2 >> 1 & 1
             custom=C.sprite_states(0x5D, "uw", TR_PAL, TR_SPR_SET,
                                    {"a": {"D": D, "subtype2": 0, "ai": 0}, "b": {"D": D, "subtype2": 2, "ai": 0}}))


RECIPES = [
    boomerang("boomerang", 0, "Boomerang lancé (tourne)"),
    boomerang("boomerang_magic", 1, "Boomerang magique lancé (tourne)"),

    # ------------------------------------------------------------------ received items
    icon("item_sword", 0x00, "Épée de combattant (objet reçu)", sword=1),
    icon("item_sword_2", 0x01, "Épée de légende", sword=2),
    icon("item_sword_3", 0x02, "Épée trempée", sword=3),
    icon("item_sword_4", 0x03, "Épée d'or", sword=4),
    icon("item_shield", 0x04, "Bouclier de combattant", shield=1),
    icon("item_shield_2", 0x05, "Bouclier de feu", shield=2),
    icon("item_shield_3", 0x06, "Bouclier miroir", shield=3),
    icon("item_bow", 0x0B, "Arc"),
    icon("item_boomerang", 0x0C, "Boomerang"),
    icon("item_boomerang_2", 0x2A, "Boomerang magique"),
    icon("item_bombs", 0x28, "Bombes"),
    icon("item_lantern", 0x12, "Lanterne"),
    icon("item_hookshot", 0x0A, "Grappin"),
    icon("item_hammer", 0x09, "Marteau"),
    icon("item_rod_fire", 0x07, "Baguette de feu"),
    icon("item_rod_ice", 0x08, "Baguette de glace"),
    icon("item_flippers", 0x1E, "Palmes"),
    icon("item_gloves", 0x1B, "Gant de puissance"),
    icon("item_gloves_2", 0x1C, "Gant du titan"),
    icon("item_boots", 0x4B, "Bottes de Pégase"),
    icon("item_flute", 0x14, "Flûte"),
    icon("item_book", 0x1D, "Livre de Mudora"),
    icon("item_mirror", 0x1A, "Miroir magique"),
    icon("item_net", 0x21, "Filet à papillons"),
    icon("item_bottle", 0x16, "Flacon vide"),
    icon("item_armor_1", 0x22, "Tunique bleue"),
    icon("item_armor_2", 0x23, "Tunique rouge"),
    icon("item_map", 0x33, "Carte du donjon"),
    icon("item_compass", 0x25, "Boussole"),
    icon("item_heart_container", 0x26, "Réceptacle de cœur"),
    icon("item_heart_piece", 0x17, "Quart de cœur"),
    icon("item_big_key", 0x32, "Grande clé"),
    icon("item_key", 0x24, "Petite clé"),

    # ------------------------------------------------------------------ dungeon objects
    R("torch", None, world="uw", tags=["item"], shadow=False, desc="Torche de donjon (unlit / lit animée)",
      anims={"unlit": C.keys_anim(["unlit"], 8), "lit": C.keys_anim(["lit0", "lit1", "lit2"], 9)},
      custom=C2.dungeon_objects(EP_ROOM, EP_MAIN, {
          "unlit": dobj(TORCH_UNLIT, 2, 2), **{f"lit{f}": dobj(TORCH_LIT, 2, 2, frame=f) for f in range(3)}})),
    R("crystal_switch", None, set=POD_SPR_SET, pal=POD_PAL, world="uw", tags=["item"],
      desc="Interrupteur cristal (blue / orange)",
      anims={"blue": C.keys_anim(["blue"], 8), "orange": C.keys_anim(["orange"], 8)},
      custom=C.sprite_states(0x1E, "uw", POD_PAL, POD_SPR_SET,
                             {"orange": {"poke": {0xC172: 0}}, "blue": {"poke": {0xC172: 1}}})),
    R("peg_blue", None, world="uw", tags=["item"], shadow=False, desc="Plot bleu (up levé, down baissé)",
      anims={"up": C.keys_anim(["up"], 8), "down": C.keys_anim(["down"], 8)},
      custom=C2.dungeon_objects(POD_ROOM, POD_MAIN, {
          "up": dobj(BLUE_PEG, 2, 2, pegs=(PEG_UP, PEG_DOWN)), "down": dobj(BLUE_PEG, 2, 2, pegs=(PEG_DOWN, PEG_UP))})),
    R("peg_orange", None, world="uw", tags=["item"], shadow=False, desc="Plot orange (up levé, down baissé)",
      anims={"up": C.keys_anim(["up"], 8), "down": C.keys_anim(["down"], 8)},
      custom=C2.dungeon_objects(POD_ROOM, POD_MAIN, {
          "up": dobj(ORANGE_PEG, 2, 2, pegs=(PEG_DOWN, PEG_UP)), "down": dobj(ORANGE_PEG, 2, 2, pegs=(PEG_UP, PEG_DOWN))})),
    R("block", None, world="uw", tags=["item"], shadow=False, desc="Bloc poussable",
      anims={"idle": C.keys_anim(["idle"], 8)},
      custom=C2.dungeon_objects(EP_ROOM, EP_MAIN, {"idle": dobj(lambda r: O(r, 0x134), 2, 2)})),
    R("switch_floor", None, world="uw", tags=["item"], shadow=False, desc="Interrupteur au sol (up / down enfoncé)",
      anims={"up": C.keys_anim(["up"], 8), "down": C.keys_anim(["down"], 8)},
      custom=C2.dungeon_objects(EP_ROOM, EP_MAIN, {"up": dobj(SWITCH_UP, 2, 2), "down": dobj(SWITCH_DOWN, 2, 2)})),
    roller("roller", 2, "Cylindre à pointes roulant, horizontal (64x16)"),
    roller("roller_v", 0, "Cylindre à pointes roulant, vertical (16x64)"),
] + [door(s, "key") for s in ("up", "down", "left", "right")] + [door("up", "big_key")]
