#!/usr/bin/env python3
"""Sanity checks of the ROM decoders (needs the JP 1.0 ROM at the project root).
    python3 tools/rom_extract/test_extract.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gfx  # noqa: E402
import link  # noqa: E402
import overworld as ow  # noqa: E402
import palettes as pal  # noqa: E402
from rom import Rom, find_rom  # noqa: E402

rom = Rom(find_rom(Path(__file__).resolve().parents[2]))

# every graphics sheet decompresses to a whole sheet
for i in range(gfx.BG_SHEETS):
    s = gfx.bg_sheet(rom, i)
    assert len(s.tiles) == (128 if s.bpp == 2 else 64), (i, s.bpp, len(s.tiles))
for i in range(gfx.SPR_SHEETS):
    s = gfx.spr_sheet(rom, i)
    assert len(s.tiles) == (128 if s.bpp == 2 else 64), (i, s.bpp, len(s.tiles))
assert len(gfx.link_tiles(rom)) == 896

# tileset tables match the values the game hard-codes elsewhere
assert gfx.main_tileset(rom, 0) == [0, 1, 16, 6, 14, 31, 24, 15]
assert gfx.aux_tileset(rom, 0) == [6, 0, 31, 24]
assert gfx.sprite_tileset(rom, 1) == [70, 73, 12, 29]

# map data: every screen decodes to 256 map32 that exist, which point to existing map16
m32 = ow.map32_defs(rom)
assert len(m32) == 8832
for s in range(ow.SCREEN_COUNT):
    ids = ow.screen_map32(rom, s)
    assert len(ids) == 256 and max(ids) < len(m32), s
    assert max(ow.screen_map16(rom, s, m32)) < ow.MAP16_COUNT, s

# big areas: the 4 screens of Hyrule castle share parent $1B
assert [ow.parent_screen(rom, s) for s in (0x1B, 0x1C, 0x23, 0x24)] == [0x1B] * 4
assert not ow.screen_is_small(rom, 0x1B)

# light world grass colour (overworld main palette, first colour)
assert gfx.hex_color(pal.group(rom, "ow_main")[0][0]) != "#000000"
# Link: 4 directions x 9 walking steps; left is the mirrored right pose
anims = link.animations(rom)
assert all(len(anims[d]["walk"]) == 9 for d in link.DIRECTIONS)
p = link.poses(rom)
assert len(p) == 303
left = p[anims["left"]["walk"][0]]
assert left["head"]["flip_h"] and left["body"]["flip_h"]

print("OK")
