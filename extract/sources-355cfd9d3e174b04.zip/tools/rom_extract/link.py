"""Link's animation data: how each pose is assembled from two 16x16 pieces of link.4bpp.

In the game (DrawLink, bank 0D) an animation frame is looked up as
    r2   = LinkAnimationDataOffsets[dir * 40 + type] + step
    pose = LinkAnimationPose[r2]
and the pose gives the head / body graphics DMA'd to VRAM (LinkOAM_Head/BodyAddresses)
plus the head offset and the flip / hide flags of both 16x16 sprites
(LinkPoseData: y, x, flags). The head is drawn at (x + hx, y + hy), the body at (x, y + 8).
"""
from rom import A, Rom

POSE_DATA = A(0x0D8000)      # LinkPoseData: 303 x (int8 y, int8 x, flags)
POSE_COUNT = 303
ANIM_POSE = A(0x0D85FB)      # LinkAnimationPose: 511 words
ANIM_POSE_COUNT = 511
ANIM_OFFSETS = A(0x0D9EF0)   # LinkAnimationDataOffsets: 4 directions x 40 types
HEAD_ADDR = A(0x009396)      # LinkOAM_HeadAddresses: 303 words (bank $10)
BODY_ADDR = A(0x0095F4)      # LinkOAM_BodyAddresses
LINK_GFX_BASE = 0x8000    # LinkGraphics = $108000; 32 bytes per 8x8 tile

DIRECTIONS = ["up", "down", "left", "right"]
ANIM_TYPES = [
    "walk", "powder_unused", "sword_ready", "sword_poke", "fall", "bonk", "rod", "bow",
    "powder", "boomerang", "slosh", "prayer", "shovel", "carry", "throw", "spin_attack",
    "lift", "tread_water", "swim_stroke", "swim", "zapped", "medallion", "push", "switch_pull",
    "grab", "stairs_diag_up", "stairs_diag_down", "spin_and_die", "arm_swing", "item_get",
    "item_get_2hands", "sleep", "hookshot", "bunny", "cane", "bug_net", "sword_up", "book",
    "tree_pull", "sword_slash",
]


def _int8(b: int) -> int:
    return b - 256 if b >= 128 else b


def _flags(nibble: int) -> dict:
    if nibble == 0xF:
        return {"hidden": True, "flip_h": False, "flip_v": False}
    return {"hidden": False, "flip_h": bool(nibble & 4), "flip_v": bool(nibble & 8)}


def poses(rom: Rom) -> list[dict]:
    raw = rom.bytes(POSE_DATA, POSE_COUNT * 3)
    heads = rom.words(HEAD_ADDR, POSE_COUNT)
    bodies = rom.words(BODY_ADDR, POSE_COUNT)
    out = []
    for i in range(POSE_COUNT):
        y, x, f = raw[i * 3:i * 3 + 3]
        out.append({
            "head_tile": (heads[i] - LINK_GFX_BASE) // 32,  # top-left 8x8 of a 16x16 block
            "body_tile": (bodies[i] - LINK_GFX_BASE) // 32,
            "head_x": _int8(x),
            "head_y": _int8(y),
            "head": _flags(f >> 4),
            "body": _flags(f & 0xF),
        })
    return out


def animation_indices(rom: Rom) -> dict:
    """Same shape as animations() but with the animation-table index r2 of each step
    (the key used by the sword / shield tables)."""
    offsets = rom.words(ANIM_OFFSETS, 160)
    starts = sorted(set(offsets) | {ANIM_POSE_COUNT})
    out = {}
    for d, dname in enumerate(DIRECTIONS):
        out[dname] = {}
        for t, tname in enumerate(ANIM_TYPES):
            o = offsets[d * 40 + t]
            n = next(s for s in starts if s > o) - o
            out[dname][tname] = list(range(o, o + n))
    return out


def animations(rom: Rom) -> dict:
    offsets = rom.words(ANIM_OFFSETS, 160)
    table = rom.words(ANIM_POSE, ANIM_POSE_COUNT)
    starts = sorted(set(offsets) | {ANIM_POSE_COUNT})

    def length(o: int) -> int:
        return next(s for s in starts if s > o) - o

    anims = {}
    for d, dname in enumerate(DIRECTIONS):
        anims[dname] = {}
        for t, tname in enumerate(ANIM_TYPES):
            o = offsets[d * 40 + t]
            anims[dname][tname] = [table[o + k] for k in range(length(o))]
    return anims
