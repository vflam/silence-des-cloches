"""Declarative sprite recipes: which ROM sprite to run, in which graphics / palette set, and
which state variables give each animation frame. Recipes contain no Nintendo data: only
sprite ids, set indices and state values; every pixel and OAM layout comes from the ROM
(sprites_engine runs the game's own drawing code).

Direction conventions of ALttP sprites ($0DE0 "D"): 0 = right, 1 = left, 2 = down, 3 = up
(most enemies); Link / some NPCs use 0 = up, 1 = down, 2 = left, 3 = right.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

DIRS = ("up", "down", "left", "right")
D_RLDU = {"right": 0, "left": 1, "down": 2, "up": 3}   # enemy convention
D_UDLR = {"up": 0, "down": 1, "left": 2, "right": 3}   # Link / NPC convention


@dataclass
class Anim:
    states: list          # one dict per frame: sprite vars (see sprites_engine.VARS) and/or
                          # raw WRAM pokes under the key "poke": {addr: value}
    durations: list | int = 8
    loop: bool = True


@dataclass
class Recipe:
    id: str
    type: int | None                      # ROM sprite id (None = custom drawer)
    set: int = 0                          # sprite graphics set (SheetsTable_AA3 index; +0x40 underworld)
    pal: int = 0                          # palette set (overworld sprite set / underworld palette set)
    world: str = "lw"                     # "lw" | "dw" | "uw"
    anims: dict = field(default_factory=dict)
    tags: list = field(default_factory=list)
    desc: str = ""
    pre: dict = field(default_factory=dict)     # sprite vars before SpritePrep
    post: dict = field(default_factory=dict)    # sprite vars after SpritePrep (e.g. oam_flags)
    pokes: dict = field(default_factory=dict)   # global WRAM before spawning
    prep: bool = True
    link: tuple = (0, 0x30)               # Link's position relative to the sprite
    foot: tuple = (0, 0)                  # footprint top-left relative to the sprite position
    shadow: bool = True                   # keep the shadow drawn by the sprite routine
    tileset: list | None = None           # explicit 4 sprite sheets instead of `set`
    drop_chars: tuple = ()                # OAM characters to ignore (e.g. held items)
    custom: Callable | None = None        # custom(rom) -> (vram, cgram, {state_key: [Obj]})


def dirs4(prefix: str, fn: Callable[[int, str], list], dur=8, dmap=D_RLDU, loop=True,
          only=DIRS) -> dict:
    """{prefix_<dir>: Anim(fn(D value, dir name))} for the 4 directions."""
    return {f"{prefix}_{d}": Anim(fn(dmap[d], d), dur, loop) for d in only if d in dmap}


def seq(**ranges) -> list:
    """seq(g=[0,1,2]) -> [{'g':0},{'g':1},{'g':2}]; several keys zip together."""
    keys = list(ranges)
    n = max(len(v) if isinstance(v, (list, tuple, range)) else 1 for v in ranges.values())
    out = []
    for i in range(n):
        d = {}
        for k in keys:
            v = ranges[k]
            d[k] = v[i] if isinstance(v, (list, tuple, range)) else v
        out.append(d)
    return out
