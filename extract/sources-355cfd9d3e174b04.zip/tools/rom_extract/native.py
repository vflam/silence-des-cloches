"""Running the project's small C tools (tools/room_render, tools/spc_render) from the extractor.

- Desktop: the tools are compiled with the local C compiler and run with subprocess, several
  at a time with threads (as before).
- Browser (Pyodide, sys.platform == "emscripten", docs/tech/WEB.md): the same C sources are
  compiled to WebAssembly (web/build.py) and loaded by the extraction worker, which exposes
  `zelda3Native(tool, args, inputs, outputs)` to Python. The tool runs synchronously in its
  own virtual file system: `inputs` are copied into it before the run, `outputs` copied back.
  No threads there: pmap is a plain map.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

IN_BROWSER = sys.platform == "emscripten"


@dataclass
class Result:
    returncode: int
    stdout: str
    stderr: str


def binary(name: str, build: Callable[[], Path]) -> Path:
    """The executable of tool `name`: built on the desktop by `build()`, provided by the page
    in the browser."""
    return Path(name) if IN_BROWSER else build()


def run(exe: Path, args: Iterable, inputs: Iterable = (), outputs: Iterable = (),
        capture: bool = True) -> Result:
    """Run tool `exe` with `args`. `inputs` / `outputs`: files it reads / writes (only needed
    in the browser, where the tool has its own file system). capture=False lets the tool's
    output go to our stdout / stderr."""
    args = [str(a) for a in args]
    if not IN_BROWSER:
        r = subprocess.run([str(exe)] + args, capture_output=capture, text=True)
        return Result(r.returncode, r.stdout or "", r.stderr or "")
    import js  # Pyodide
    from pyodide.ffi import to_js
    files_in = {str(p): Path(p).read_bytes() for p in inputs}
    res = js.zelda3Native(Path(exe).name, to_js(args),
                          to_js(files_in, dict_converter=js.Object.fromEntries),
                          to_js([str(p) for p in outputs]))
    res = res.to_py()
    for path, data in (res.get("files") or {}).items():
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(bytes(data))
    out, err = str(res.get("stdout", "")), str(res.get("stderr", ""))
    if not capture:
        if out:
            print(out, end="" if out.endswith("\n") else "\n")
        if err:
            print(err, end="" if err.endswith("\n") else "\n", file=sys.stderr)
    return Result(int(res.get("code", 1)), out, err)


def pmap(fn: Callable, items: Iterable) -> list:
    """map(fn, items), on several threads on the desktop (the tools are separate processes)."""
    items = list(items)
    if IN_BROWSER or len(items) < 2:
        return [fn(x) for x in items]
    workers = max(1, min(16, os.cpu_count() or 1))
    with ThreadPoolExecutor(workers) as ex:
        return list(ex.map(fn, items))


def last_json_line(text: str) -> dict:
    return json.loads(text.strip().splitlines()[-1])
