"""Shared helpers of the SPRITES extraction step: sprite VRAM / CGRAM emulation, OAM
rendering and PNG atlases.

The game draws every sprite as a list of OAM entries (x, y, character, palette, flips,
8x8 or 16x16). We rebuild the object VRAM (characters 0x000-0x1FF) and the sprite half
of CGRAM (rows 8-15) the way the game loads them (zelda3 `load_gfx.c`, jpdasm bank 00),
then rasterise OAM lists into RGBA frames.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from PIL import Image

import gfx
import palettes as pal
from rom import A, Rom


def int8(b: int) -> int:
    return b - 256 if b >= 128 else b


def int8s(rom: Rom, addr: int, n: int) -> list[int]:
    return [int8(b) for b in rom.bytes(addr, n)]


def bytes_(rom: Rom, addr: int, n: int) -> list[int]:
    return list(rom.bytes(addr, n))


# ------------------------------------------------------------------ sheets / VRAM

_spr_cache: dict[int, np.ndarray] = {}


def spr_tiles(rom: Rom, i: int) -> np.ndarray:
    """Sprite sheet i as (64, 8, 8) 3bpp values (0-7)."""
    if i not in _spr_cache:
        s = gfx.spr_sheet(rom, i)
        _spr_cache[i] = np.frombuffer(b"".join(s.tiles[:64]), np.uint8).reshape(-1, 8, 8).copy()
    return _spr_cache[i]


def hi(t: np.ndarray) -> np.ndarray:
    """Do3To4High: non-zero pixels use colours 8-15 of the palette row."""
    return np.where(t != 0, t | 8, 0).astype(np.uint8)


# Sprite sheets that LoadSpriteGraphics expands "high" (colours 8-15).
HIGH_SHEETS = {0x52, 0x53, 0x5A, 0x5B, 0x5C, 0x5E, 0x5F}


class Vram:
    """Object VRAM: 512 characters of 8x8 4bpp values."""

    def __init__(self):
        self.chars = np.zeros((512, 8, 8), np.uint8)

    def put(self, char: int, tiles: np.ndarray) -> None:
        self.chars[char:char + len(tiles)] = tiles

    def load_sheet(self, char: int, sheet: int, rom: Rom, high: bool = False) -> None:
        t = spr_tiles(rom, sheet)
        self.put(char, hi(t) if high else t)

    @staticmethod
    def for_sprites(rom: Rom, tileset: tuple[int, int, int, int] | list[int],
                    common: int = 0x01) -> "Vram":
        """VRAM as set by InitializeTilesets for a sprite graphics set:
        0x000-0x03F sheet 0 (high, Link's default area), 0x040-0x07F common sheet
        (misc_sprites_graphics_index: 1 light world, 0x0B dark world, high),
        0x080-0x0FF sheets 6 and 7 (LoadCommonSprites), 0x100-0x1FF the 4 area sheets."""
        v = Vram()
        v.load_sheet(0x000, 0x00, rom, high=True)
        v.load_sheet(0x040, common, rom, high=True)
        v.load_sheet(0x080, 0x06, rom)
        v.load_sheet(0x0C0, 0x07, rom)
        for k, s in enumerate(tileset):
            if s:
                v.load_sheet(0x100 + 0x40 * k, s, rom, high=s in HIGH_SHEETS)
        return v


OW_SPRITE_PALETTE_SET = A(0x0CFEF0)   # OverworldSpritesPaletteSet: (sp5l, sp6l) x 20
UW_PALETTE_SETS = A(0x0CFDD0)         # UnderworldPaletteSets: (main, sp0l, sp5l, sp6l) x 41


def sprite_cgram(rom: Rom, world: str = "lw", palset: int = 0, sword: int = 1, shield: int = 1,
                 mail: int = 0) -> np.ndarray:
    """Sprite palette rows 8-15 (128 RGB colours, row r at index (r-8)*16) as loaded for
    an overworld ("lw" / "dw") or underworld ("uw") palette set. Mirrors Palette_Load_Sp0L /
    SpriteMain / Sp5L / Sp6L / Sword / Shield / SpriteEnvironment / LinkArmorAndGloves."""
    cg = [0] * 128
    aux3 = pal.group(rom, "sprite_pal0")     # kPalette_SpriteAux3 (7 colours)
    main = pal.group(rom, "sprite_main")     # kPalette_MainSpr (15 colours x 8)
    aux1 = pal.group(rom, "sprite_aux")      # kPalette_SpriteAux1 (7 colours)
    env = pal.group(rom, "environment")      # kPalette_MiscSprite (7 colours)
    dark = world == "dw"
    if world == "uw":
        mainpal, sp0l, sp5l, sp6l = rom.bytes(UW_PALETTE_SETS + 4 * palset, 4)
        sp0r = pal.group(rom, "dungeon")[mainpal // 2][:7]
        sp6r = env[10]
    else:
        sp5l, sp6l = rom.bytes(OW_SPRITE_PALETTE_SET + 2 * palset, 2)
        # $FF = "keep the previous palette": use the first one
        sp5l, sp6l = (0 if sp5l == 0xFF else sp5l), (0 if sp6l == 0xFF else sp6l)
        sp0l = 3 if dark else 1
        sp0r = env[9 if dark else 7]
        sp6r = env[8 if dark else 6]
    cg[1:8] = aux3[sp0l]
    cg[9:16] = sp0r
    base = 4 if dark else 0
    for r in range(4):
        cg[(1 + r) * 16 + 1:(1 + r) * 16 + 16] = main[base + r]
    cg[5 * 16 + 1:5 * 16 + 8] = aux1[sp5l]
    cg[6 * 16 + 1:6 * 16 + 8] = aux1[sp6l]
    cg[6 * 16 + 9:6 * 16 + 16] = sp6r
    cg[5 * 16 + 9:5 * 16 + 12] = pal.group(rom, "sword")[max(sword, 1) - 1]
    cg[5 * 16 + 12:5 * 16 + 16] = pal.group(rom, "shield")[max(shield, 1) - 1]
    cg[7 * 16 + 1:7 * 16 + 16] = pal.group(rom, "link")[mail]
    return np.array([gfx.snes_color(c) for c in cg], np.uint8)


# ------------------------------------------------------------------ OAM rendering

@dataclass
class Obj:
    """One OAM entry. x, y relative to the sprite origin; char 0-511; pal 0-7 (row 8+pal)."""
    x: int
    y: int
    char: int
    pal: int
    flip_h: bool = False
    flip_v: bool = False
    big: bool = False

    @staticmethod
    def from_word(x: int, y: int, word: int, big: bool) -> "Obj":
        """OAM attribute word vhoopppc cccccccc (as in SNES OAM bytes 2-3)."""
        return Obj(x, y, word & 0x1FF, (word >> 9) & 7, bool(word & 0x4000), bool(word & 0x8000), big)


def char_block(vram: Vram, c: int, big: bool) -> np.ndarray:
    if not big:
        return vram.chars[c & 0x1FF]
    out = np.zeros((16, 16), np.uint8)
    for dy in range(2):
        for dx in range(2):
            cc = (c & 0x100) | ((((c >> 4) + dy) & 0xF) << 4) | ((c + dx) & 0xF)
            out[dy * 8:dy * 8 + 8, dx * 8:dx * 8 + 8] = vram.chars[cc]
    return out


def obj_pixels(vram: Vram, o: Obj) -> np.ndarray:
    t = char_block(vram, o.char, o.big)
    if o.flip_h:
        t = t[:, ::-1]
    if o.flip_v:
        t = t[::-1, :]
    return t


@dataclass
class Frame:
    """An RGBA frame with the position of its top-left corner in sprite coordinates."""
    img: np.ndarray            # (h, w, 4) uint8
    x0: int
    y0: int
    tag: str = ""

    @property
    def w(self) -> int:
        return self.img.shape[1]

    @property
    def h(self) -> int:
        return self.img.shape[0]


def render_objs(vram: Vram, cgram: np.ndarray, objs: list[Obj], bounds=None) -> Frame:
    """Rasterise OAM entries. The FIRST entry of the list is drawn on top (OAM order).
    bounds = (x0, y0, x1, y1) to force the frame rectangle, else the union of the entries."""
    if not objs and bounds is None:
        return Frame(np.zeros((1, 1, 4), np.uint8), 0, 0)
    if bounds is None:
        x0 = min(o.x for o in objs)
        y0 = min(o.y for o in objs)
        x1 = max(o.x + (16 if o.big else 8) for o in objs)
        y1 = max(o.y + (16 if o.big else 8) for o in objs)
    else:
        x0, y0, x1, y1 = bounds
    img = np.zeros((y1 - y0, x1 - x0, 4), np.uint8)
    for o in reversed(objs):
        px = obj_pixels(vram, o)
        s = px.shape[0]
        for yy in range(s):
            ty = o.y - y0 + yy
            if not 0 <= ty < img.shape[0]:
                continue
            for xx in range(s):
                v = px[yy, xx]
                tx = o.x - x0 + xx
                if v and 0 <= tx < img.shape[1]:
                    img[ty, tx, :3] = cgram[o.pal * 16 + v]
                    img[ty, tx, 3] = 255
    return Frame(img, x0, y0)


def crop(f: Frame) -> Frame:
    a = f.img[:, :, 3]
    ys, xs = np.nonzero(a)
    if len(xs) == 0:
        return Frame(np.zeros((1, 1, 4), np.uint8), f.x0, f.y0, f.tag)
    return Frame(f.img[ys.min():ys.max() + 1, xs.min():xs.max() + 1], int(f.x0 + xs.min()), int(f.y0 + ys.min()), f.tag)


# ------------------------------------------------------------------ atlases

class Atlas:
    """Shelf packer: frames are placed left to right in rows; identical frames are shared."""

    def __init__(self, width: int = 256, pad: int = 1):
        self.width = width
        self.pad = pad
        self.rects: list[tuple[int, int, int, int]] = []
        self._imgs: list[np.ndarray] = []
        self._seen: dict[bytes, int] = {}
        self._x = self._y = self._row_h = 0

    def add(self, img: np.ndarray) -> int:
        key = bytes(img.shape[:2]) + img.tobytes()
        if key in self._seen:
            return self._seen[key]
        h, w = img.shape[:2]
        if self._x + w > self.width:
            self._x = 0
            self._y += self._row_h + self.pad
            self._row_h = 0
        self.rects.append((self._x, self._y, w, h))
        self._imgs.append(img)
        self._x += w + self.pad
        self._row_h = max(self._row_h, h)
        self._seen[key] = len(self.rects) - 1
        return len(self.rects) - 1

    def image(self) -> Image.Image:
        H = max([y + h for (x, y, w, h) in self.rects] + [1])
        W = max([x + w for (x, y, w, h) in self.rects] + [1])
        out = np.zeros((H, W, 4), np.uint8)
        for (x, y, w, h), im in zip(self.rects, self._imgs):
            out[y:y + h, x:x + w] = im
        return Image.fromarray(out, "RGBA")


def blit(dst: np.ndarray, src: np.ndarray, x: int, y: int) -> None:
    """Alpha-blit src (RGBA) into dst at (x, y), clipped."""
    h, w = src.shape[:2]
    H, W = dst.shape[:2]
    sx0, sy0 = max(0, -x), max(0, -y)
    dx0, dy0 = max(0, x), max(0, y)
    sx1, sy1 = min(w, W - x), min(h, H - y)
    if sx1 <= sx0 or sy1 <= sy0:
        return
    s = src[sy0:sy1, sx0:sx1]
    d = dst[dy0:dy0 + (sy1 - sy0), dx0:dx0 + (sx1 - sx0)]
    m = s[:, :, 3] > 0
    d[m] = s[m]
