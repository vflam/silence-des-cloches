"""Control sheets (game/assets/rom/sprites/previews/): Link with sword / shield, and one
sheet per sprite of the catalog with its animations."""
from __future__ import annotations

import numpy as np
from PIL import Image, ImageDraw

import gfx
import link
import palettes as pal
import sprites_common as sc
from rom import Rom

BG = (72, 104, 72, 255)


def _link_block(tiles: np.ndarray, t: int) -> np.ndarray:
    out = np.zeros((16, 16), np.uint8)
    out[:8, :8], out[:8, 8:] = tiles[t], tiles[t + 1]
    out[8:, :8], out[8:, 8:] = tiles[t + 16], tiles[t + 17]
    return out


def link_pose_image(rom: Rom, pose: dict, tiles: np.ndarray, colors: np.ndarray) -> dict[str, tuple]:
    """{'head'|'body': (rgba 16x16, x, y)} relative to Link.pos."""
    out = {}
    for part, t, x, y in (("body", pose["body_tile"], 0, 8), ("head", pose["head_tile"], pose["head_x"], pose["head_y"])):
        fl = pose[part]
        if fl["hidden"]:
            continue
        b = _link_block(tiles, t)
        if fl["flip_h"]:
            b = b[:, ::-1]
        if fl["flip_v"]:
            b = b[::-1, :]
        img = np.zeros((16, 16, 4), np.uint8)
        img[..., :3] = colors[b]
        img[..., 3] = np.where(b != 0, 255, 0)
        out[part] = (img, x, y)
    return out


def link_weapons_sheet(rom: Rom, lw: dict, atlas_img: Image.Image, path, scale: int = 3) -> None:
    tiles = np.frombuffer(b"".join(gfx.link_tiles(rom)), np.uint8).reshape(-1, 8, 8)
    colors = np.array([(0, 0, 0)] + [gfx.snes_color(c) for c in pal.group(rom, "link")[0]], np.uint8)
    poses = link.poses(rom)
    anim_pose = rom.words(link.ANIM_POSE, link.ANIM_POSE_COUNT)
    atl = np.array(atlas_img)
    offsets = rom.words(link.ANIM_OFFSETS, 160)

    def sub(r):
        return atl[r["y"]:r["y"] + r["h"], r["x"]:r["x"] + r["w"]]

    cell = 56
    rows = []  # (label, [(r2, level, shield_level, tip)])
    for d, dn in enumerate(link.DIRECTIONS):
        for lv in (1, 2, 4):
            rows.append((f"{dn} slash L{lv}", [(e["r2"], lv, 2, e["tip"], e["hitbox"][str(lv)]) for e in lw["attacks"][dn]["sword_slash"]]))
        walk = [(offsets[d * 40] + k, 1, 1, None, None) for k in range(9)]
        rows.append((f"{dn} walk S1", walk))
        rows.append((f"{dn} poke/spin", [(e["r2"], 1, 3, None, e["hitbox"]["1"]) for e in lw["attacks"][dn]["sword_poke"]]
                     + [(r, 1, 3, None, None) for r in lw["attacks"][dn]["spin_attack"]["r2"][:6]]))
    W = 90 + 12 * cell
    H = len(rows) * cell
    img = np.zeros((H, W, 4), np.uint8)
    img[:] = BG
    boxes = []
    for ri, (label, items) in enumerate(rows):
        for ci, (r2, lv, sl, tip, hb) in enumerate(items):
            ox, oy = 90 + ci * cell + 20, ri * cell + 18
            parts = link_pose_image(rom, poses[anim_pose[r2]], tiles, colors)
            layer_imgs = dict(parts)
            s = lw["sword"].get(str(r2))
            if s:
                g = lw["sword_gfx"][str(lv)][s["g"]]
                layer_imgs["sword"] = (sub(g), s["x"] + g["ox"], s["y"] + g["oy"])
            s = lw["shield"].get(str(r2))
            if s:
                g = lw["shield_gfx"][str(sl)][s["g"]]
                layer_imgs["shield"] = (sub(g), s["x"] + g["ox"], s["y"] + g["oy"])
            order = lw["layers"].get(str(r2), ["body", "head"])
            for name in order:
                if name in layer_imgs:
                    im, x, y = layer_imgs[name]
                    sc.blit(img, im, ox + x, oy + y)
            if tip and lv >= 2:
                g = lw["tip_gfx"][str(lv)][tip["t"]]
                sc.blit(img, sub(g), ox + tip["x"] + g["ox"], oy + tip["y"] + g["oy"])
            if hb:
                boxes.append((ox + hb[0], oy + hb[1], hb[2], hb[3]))
    im = Image.fromarray(img, "RGBA").resize((W * scale, H * scale), Image.NEAREST)
    dr = ImageDraw.Draw(im)
    for (x, y, w, h) in boxes:
        dr.rectangle([x * scale, y * scale, (x + w) * scale - 1, (y + h) * scale - 1], outline=(255, 0, 0, 255))
    for ri, (label, _) in enumerate(rows):
        dr.text((4, ri * cell * scale + 4), label, fill=(255, 255, 255, 255))
    im.save(path)


def sprite_sheet(entry: dict, png: Image.Image, path, scale: int = 3, title: str = "") -> None:
    """One row per animation: frames placed on a 16x16 footprint grid (anchor ox, oy)."""
    frames = entry["frames"]
    anims = entry["anims"]
    names = list(anims)
    maxw = max(f["w"] for f in frames)
    maxh = max(f["h"] for f in frames)
    cw, ch = max(32, maxw + 8), max(32, maxh + 8)
    ncol = max(len(a["frames"]) for a in anims.values()) if anims else 1
    W, H = 64 + ncol * cw, 14 + max(1, len(names)) * ch
    img = np.zeros((H, W, 4), np.uint8)
    img[:] = BG
    src = np.array(png.convert("RGBA"))
    marks = []
    for ri, n in enumerate(names):
        for ci, fi in enumerate(anims[n]["frames"]):
            f = frames[fi]
            # footprint origin in the cell
            fx = 64 + ci * cw + (cw - 16) // 2
            fy = 14 + ri * ch + ch - 16 - 4
            marks.append((fx, fy))
            sc.blit(img, src[f["y"]:f["y"] + f["h"], f["x"]:f["x"] + f["w"]], fx - f["ox"], fy - f["oy"])
    im = Image.fromarray(img, "RGBA").resize((W * scale, H * scale), Image.NEAREST)
    dr = ImageDraw.Draw(im)
    for (x, y) in marks:
        dr.rectangle([x * scale, y * scale, (x + 16) * scale - 1, (y + 16) * scale - 1], outline=(255, 255, 0, 90))
    dr.text((4, 2), title, fill=(255, 255, 255, 255))
    for ri, n in enumerate(names):
        a = anims[n]
        dr.text((4, (14 + ri * ch) * scale + 4), f"{n}", fill=(255, 255, 255, 255))
        dr.text((4, (14 + ri * ch) * scale + 18), ",".join(str(d) for d in a["durations"])[:18], fill=(200, 200, 200, 255))
    im.save(path)
