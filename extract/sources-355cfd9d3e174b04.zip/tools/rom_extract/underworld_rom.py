"""Underworld (dungeons, houses, caves) data tables of the JP 1.0 ROM.

Addresses are SNES LoROM addresses taken from the jpdasm labels quoted in comments.
Everything here is read from the player's ROM at extraction time.
"""
import struct

from rom import A, Rom

NUM_ROOMS = 0x128          # rooms 0x000-0x127 exist; the tables have 320 slots
TABLE_ROOMS = 320

ROOM_OBJECT_POINTERS = A(0x1F8000)   # RoomData_ObjectDataPointers: 320 x long
ROOM_HEADER_POINTERS = A(0x04F1E2)   # RoomHeaderPointers: 320 x word (bank 04), 14 bytes each
ROOM_LAYOUT_POINTERS = A(0x04EC0F)   # RoomLayoutPointers: 8 x long ("default rooms")
OVERLAY_POINTERS = A(0x04E9A0)       # OverlayDataPointers: 19 x long
PUSHABLE_BLOCKS = A(0x04EEBE)        # PushableBlocks: 99 x (room, tilemap) words
LIGHTABLE_TORCHES = A(0x04F04A)      # LightableTorches: 144 words (+48 words of junk after)
ROOM_DRAW_OBJECT_DATA = A(0x009B52)  # RoomDrawObjectData: 6438 tilemap words
CHEST_ITEMS = A(0x01E96C)            # RoomData_ChestItems: 168 x (room word, item byte)
CHEST_COUNT = 168
POT_ITEM_POINTERS = A(0x01DB67)      # RoomData_PotItems_Pointers: 320 x word (bank 01)
ROOMS_WITH_PIT_DAMAGE = A(0x00990C)  # RoomsWithPitDamage: 57 words
TILE_TYPES_OFFSETS = A(0x0FF780)     # CustomTileTypesOffset: 21 words (by aux tileset)
UNDERWORLD_TILE_TYPES = A(0x0FF7AA)  # UnderworldTileTypes: 0x180 bytes
CUSTOM_TILE_TYPES = A(0x0FF92A)      # CustomUnderworldTileTypes: 0x400 bytes
UW_PALETTE_SETS = A(0x0CFDD0)        # UnderworldPaletteSets: 4 bytes (bg main*2, sp0l, sp5l, sp6l)
SPRITE_POINTERS = A(0x09D62E)        # RoomData_SpritePointers: 320 x word (bank 09)
DUNGEON_MAP_ROOMS = A(0x0AF615)      # DungeonMapRoomPointers: 14 x word (bank 0A), 25 bytes per floor
DUNGEON_MAP_SIZES = [75, 125, 50, 75, 175, 75, 50, 75, 50, 200, 150, 75, 100, 200]

# EntranceData (bank 02), 133 entrances
ENTRANCES = 133
ENT_ROOM = A(0x02C577)
ENT_MAIN_GFX = A(0x02D0E5)
ENT_FLOOR = A(0x02D16A)
ENT_DUNGEON = A(0x02D1EF)
ENT_LAYER = A(0x02D2F9)
ENT_Y = A(0x02CCBD)
ENT_X = A(0x02CDC7)
# SpawnPointData (bank 02), 7 starting points
SPAWNS = 7
SPAWN_ROOM = A(0x02D8D2)
SPAWN_MAIN_GFX = A(0x02D96C)
SPAWN_DUNGEON = A(0x02D97A)

# zelda3/src/assets.h indices
A_ROOM, A_ROOM_OFFS, A_DOOR_OFFS, A_HEADERS, A_HEADER_OFFS = 3, 4, 5, 6, 7
A_CHESTS, A_TELE_MSG, A_PITS = 8, 9, 10
A_DEFAULT, A_DEFAULT_OFFS, A_OVERLAY, A_OVERLAY_OFFS, A_SECRETS = 46, 47, 48, 49, 50
A_ATTR_OFFS, A_ATTR, A_MOVABLE, A_TORCH, A_TORCH_JUNK = 51, 52, 53, 54, 55
A_TILE_DATA = 69
A_DEFAULT_ATTR = 1000  # room_render.c private index
# room_render.c private indices 1001-1007: dungeon.c tables read from the ROM
# (object subtype 1/2/3 data offsets, door data offsets up/down/left/right), words
ROM_TABLES = ((A(0x018000), 256), (A(0x0183F0), 64), (A(0x0184F0), 128),
              (A(0x00CD9E), 52), (A(0x00CE06), 48), (A(0x00CE66), 48), (A(0x00CEC6), 47))

DUNGEON_NAMES = ["sewers", "hyrule_castle", "eastern_palace", "desert_palace", "agahnims_tower",
                 "swamp_palace", "palace_of_darkness", "misery_mire", "skull_woods", "ice_palace",
                 "tower_of_hera", "thieves_town", "turtle_rock", "ganons_tower"]


# ------------------------------------------------------------------ room objects

def parse_layer(rom: Rom, addr: int, limit: int = 0x1000):
    """One object layer: 3-byte objects until $FFFF, doors (2 bytes) after $FFF0.
    Returns (objects, doors or None, next address)."""
    objs, doors = [], None
    end = addr + limit
    while addr < end:
        w = rom.word(addr)
        if w == 0xFFFF:
            return objs, doors, addr + 2
        if w == 0xFFF0:
            addr += 2
            doors = []
            while addr < end:
                d = rom.word(addr)
                if d == 0xFFFF:
                    return objs, doors, addr + 2
                doors.append(d)
                addr += 2
            break
        objs.append(bytes(rom.bytes(addr, 3)))
        addr += 3
    raise ValueError(f"room data at ${addr:06X} is not terminated")


def room_objects(rom: Rom, room: int):
    """(floor byte, layout byte, [ (objects, doors) x 3 ]) or None for unused slots."""
    if room >= NUM_ROOMS:
        return None
    addr = rom.long(ROOM_OBJECT_POINTERS + room * 3)
    floor, layout = rom.byte(addr), rom.byte(addr + 1)
    addr += 2
    layers = []
    for _ in range(3):
        objs, doors, addr = parse_layer(rom, addr)
        layers.append((objs, doors))
    return floor, layout, layers


def decode_object(o: bytes) -> dict:
    """Decode a 3-byte room object (same rules as RoomDraw_RoomObject)."""
    p0, p1, p2 = o
    if (p0 & 0xFC) != 0xFC:
        x, y = p0 >> 2, p1 >> 2
        if p2 < 0xF8:
            return {"type": 1, "id": p2, "x": x, "y": y, "w": p0 & 3, "h": p1 & 3}
        return {"type": 3, "id": 0xF80 + ((p2 & 7) << 4 | (p1 & 3) << 2 | (p0 & 3)), "x": x, "y": y}
    x = ((p0 & 3) << 4 | p1 >> 4) & 0x3F
    y = ((p1 & 0xF) << 2 | p2 >> 6) & 0x3F
    return {"type": 2, "id": 0x100 + (p2 & 0x3F), "x": x, "y": y}


def _encode_layer(out: bytearray, objs, doors, force_doors=False):
    """Same byte layout as zelda3's compile_resources.print_layer. Returns door list offset."""
    for o in objs:
        out += o
    door_offset = None
    if doors is not None or force_doors:
        out += b"\xF0\xFF"
        door_offset = len(out)
        for d in doors or []:
            out += struct.pack("<H", d)
    out += b"\xFF\xFF"
    return door_offset


def room_header(rom: Rom, room: int) -> bytes:
    if room >= NUM_ROOMS:
        return bytes(14)
    p = 0x040000 | rom.word(ROOM_HEADER_POINTERS + room * 2)
    return bytes(rom.bytes(p, 14))


def decode_header(h: bytes) -> dict:
    return {
        "bg2": h[0] >> 5, "collision": (h[0] >> 2) & 7, "lights_out": h[0] & 1,
        "palette": h[1], "blockset": h[2], "sprite_set": h[3], "effect": h[4],
        "tag0": h[5], "tag1": h[6],
        "hole_dest": [h[9], h[7] & 3],
        "stair_dests": [[h[10], (h[7] >> 2) & 3], [h[11], (h[7] >> 4) & 3],
                        [h[12], (h[7] >> 6) & 3], [h[13], h[8] & 3]],
    }


def _object_list(rom: Rom, ptr_table: int, count: int):
    data, offsets = bytearray(), []
    for i in range(count):
        offsets.append(len(data))
        objs, doors, _ = parse_layer(rom, rom.long(ptr_table + i * 3))
        _encode_layer(data, objs, doors)
    return bytes(data), offsets


def pot_items(rom: Rom, room: int) -> list[tuple[int, int, int]]:
    """RoomData_PotItems: (x8, y8, item) for each secret under a pot / block."""
    if room >= NUM_ROOMS:
        return []
    p = 0x010000 | rom.word(POT_ITEM_POINTERS + room * 2)
    out = []
    for _ in range(64):
        pos = rom.word(p)
        if pos == 0xFFFF:
            break
        out.append(((pos >> 1) & 63, (pos >> 1) >> 6 & 63, rom.byte(p + 2)))
        p += 3
    return out


def chests(rom: Rom) -> dict[int, list[tuple[int, bool]]]:
    """room -> [(item, big)] in chest order (RoomData_ChestItems)."""
    out: dict[int, list] = {}
    for i in range(CHEST_COUNT):
        room = rom.word(CHEST_ITEMS + i * 3)
        out.setdefault(room & 0x7FFF, []).append((rom.byte(CHEST_ITEMS + i * 3 + 2), bool(room & 0x8000)))
    return out


def room_sprites(rom: Rom, room: int) -> list[dict]:
    """RoomData_Sprites: {x, y (16 px units), layer, id, subtype, drop}."""
    if room >= NUM_ROOMS:
        return []
    p = 0x090000 | rom.word(SPRITE_POINTERS + room * 2)
    p += 1  # sort mode
    out = []
    for _ in range(64):
        y = rom.byte(p)
        if y == 0xFF:
            break
        x, t = rom.byte(p + 1), rom.byte(p + 2)
        p += 3
        if t == 0xE4 and y in (0xFE, 0xFD):
            if out:
                out[-1]["drop"] = "key" if y == 0xFE else "big_key"
            continue
        if x >= 0xE0:  # overlord
            out.append({"x": x & 0x1F, "y": y & 0x1F, "layer": y >> 7, "id": 0x100 + t, "overlord": True})
            continue
        sub = (x >> 5) | ((y >> 5) & 3) << 3
        s = {"x": x & 0x1F, "y": y & 0x1F, "layer": y >> 7, "id": t}
        if sub:
            s["subtype"] = sub
        out.append(s)
    return out


def palette_set(rom: Rom, i: int) -> tuple[int, int, int, int]:
    b = rom.bytes(UW_PALETTE_SETS + i * 4, 4)
    return b[0], b[1], b[2], b[3]


def entrances(rom: Rom) -> list[dict]:
    out = []
    for i in range(ENTRANCES):
        out.append({"index": i, "room": rom.word(ENT_ROOM + i * 2), "main": rom.byte(ENT_MAIN_GFX + i),
                    "dungeon": rom.byte(ENT_DUNGEON + i), "floor": rom.byte(ENT_FLOOR + i),
                    "x": rom.word(ENT_X + i * 2), "y": rom.word(ENT_Y + i * 2)})
    for i in range(SPAWNS):
        out.append({"index": 0x100 + i, "room": rom.word(SPAWN_ROOM + i * 2), "main": rom.byte(SPAWN_MAIN_GFX + i),
                    "dungeon": rom.byte(SPAWN_DUNGEON + i), "spawn": True})
    return out


def dungeon_map_rooms(rom: Rom) -> dict[int, tuple[int, int, int, int]]:
    """room -> (dungeon index, floor index from the bottom, grid x, grid y), from the pause-menu maps."""
    out = {}
    for d, size in enumerate(DUNGEON_MAP_SIZES):
        p = 0x0A0000 | rom.word(DUNGEON_MAP_ROOMS + d * 2)
        b = rom.bytes(p, size)
        for i, r in enumerate(b):
            if r != 0x0F:
                out.setdefault(r, (d, i // 25, i % 5, (i % 25) // 5))
    return out


def default_tile_types(rom: Rom) -> bytes:
    return bytes(rom.bytes(UNDERWORLD_TILE_TYPES, 0x180))


def custom_tile_types(rom: Rom, blockset: int) -> bytes:
    off = rom.word(TILE_TYPES_OFFSETS + min(blockset, 20) * 2)
    return bytes(rom.bytes(CUSTOM_TILE_TYPES + off, 0x80))


def tile_types(rom: Rom, blockset: int) -> bytes:
    """Type of each of the 512 BG tiles in a room of this aux blockset (before objects)."""
    d = default_tile_types(rom)
    t = bytearray(0x200)
    t[0:0x140] = d[0:0x140]
    t[0x140:0x1C0] = custom_tile_types(rom, blockset)
    t[0x1C0:0x200] = d[0x140:0x180]
    return bytes(t)


# ------------------------------------------------------------------ asset pack for room_render

def custom_blocks(blocks) -> bytes:
    """PushableBlocks layout: 99 x (room, tilemap word); unused entries get room $7FFF."""
    if len(blocks) > 99:
        raise ValueError("99 blocs poussables au plus")
    ent = list(blocks) + [(0x7FFF, 0)] * (99 - len(blocks))
    return b"".join(struct.pack("<HH", r, w) for r, w in ent)


def custom_torches(torches: dict) -> bytes:
    """LightableTorches layout: room, tilemap words..., $FFFF, ... in 144 words (0x120 bytes)."""
    words = []
    for room, ws in torches.items():
        words += [room, *ws, 0xFFFF]
    rem = 144 - len(words)
    if rem % 2 and rem >= 3:
        words += [0x7FFF, 0, 0xFFFF]
    while len(words) < 144:
        words += [0x7FFF, 0xFFFF]
    if len(words) != 144:
        raise ValueError("trop de torches (144 mots au plus pour toutes les salles)")
    return struct.pack("<144H", *words)


def asset_pack(rom: Rom, custom: dict | None = None) -> bytes:
    """Asset blob read by tools/room_render (same layouts as zelda3's zelda3_assets.dat).

    custom (tools/roomgen): replace the whole room set by our own rooms:
      {"rooms": {slot: (floor byte, layout byte, [(objects, doors) x 3])},
       "headers": {slot: 14 header bytes},
       "blocks": [(slot, tilemap word)], "torches": {slot: [tilemap words]}}
    Every other slot is empty; chest and pot tables are empty."""
    assets: dict[int, bytes] = {}

    data, offsets, door_offsets = bytearray(), [], []
    for room in range(TABLE_ROOMS):
        offsets.append(len(data))
        ro = custom["rooms"].get(room) if custom else room_objects(rom, room)
        if ro is None:
            data += b"\x00\x00"
            _encode_layer(data, [], None)
            _encode_layer(data, [], None)
            door_offsets.append(_encode_layer(data, [], None, force_doors=True))
            continue
        floor, layout, layers = ro
        data += bytes((floor, layout))
        _encode_layer(data, *layers[0])
        _encode_layer(data, *layers[1])
        door_offsets.append(_encode_layer(data, *layers[2], force_doors=True))
    assets[A_ROOM] = bytes(data)
    assets[A_ROOM_OFFS] = struct.pack(f"<{TABLE_ROOMS}H", *offsets)
    assets[A_DOOR_OFFS] = struct.pack(f"<{TABLE_ROOMS}H", *door_offsets)

    if custom:
        headers = b"".join(bytes(custom["headers"].get(r, bytes(14))) for r in range(TABLE_ROOMS))
    else:
        headers = b"".join(room_header(rom, r) for r in range(TABLE_ROOMS))
    assets[A_HEADERS] = headers
    assets[A_HEADER_OFFS] = struct.pack(f"<{TABLE_ROOMS}H", *[r * 14 for r in range(TABLE_ROOMS)])

    ch = bytearray()
    for i in range(0 if custom else CHEST_COUNT):
        ch += rom.bytes(CHEST_ITEMS + i * 3, 3)
    assets[A_CHESTS] = bytes(ch)
    assets[A_TELE_MSG] = bytes(TABLE_ROOMS * 2)
    assets[A_PITS] = bytes(rom.bytes(ROOMS_WITH_PIT_DAMAGE, 57 * 2))

    d, offs = _object_list(rom, ROOM_LAYOUT_POINTERS, 8)
    assets[A_DEFAULT], assets[A_DEFAULT_OFFS] = d, struct.pack("<8H", *offs)
    d, offs = _object_list(rom, OVERLAY_POINTERS, 19)
    assets[A_OVERLAY], assets[A_OVERLAY_OFFS] = d, struct.pack("<19H", *offs)

    # kDungeonSecrets: 320 word offsets (from the start of the asset), then the lists.
    sec = bytearray(TABLE_ROOMS * 2)
    for room in range(TABLE_ROOMS):
        struct.pack_into("<H", sec, room * 2, len(sec))
        for x, y, item in ([] if custom else pot_items(rom, room)):
            sec += struct.pack("<HB", (y * 64 + x) * 2, item)
        sec += b"\xFF\xFF"
    assets[A_SECRETS] = bytes(sec)

    assets[A_ATTR_OFFS] = bytes(rom.bytes(TILE_TYPES_OFFSETS, 21 * 2))
    assets[A_ATTR] = bytes(rom.bytes(CUSTOM_TILE_TYPES, 0x400))
    if custom:
        assets[A_MOVABLE] = custom_blocks(custom.get("blocks", []))
        assets[A_TORCH] = custom_torches(custom.get("torches", {}))
    else:
        assets[A_MOVABLE] = bytes(rom.bytes(PUSHABLE_BLOCKS, 198 * 2))
        assets[A_TORCH] = bytes(rom.bytes(LIGHTABLE_TORCHES, 144 * 2))
    assets[A_TORCH_JUNK] = bytes(rom.bytes(LIGHTABLE_TORCHES + 144 * 2, 48 * 2))
    assets[A_TILE_DATA] = bytes(rom.bytes(ROOM_DRAW_OBJECT_DATA, 6438 * 2))
    assets[A_DEFAULT_ATTR] = default_tile_types(rom)
    for i, (addr, n) in enumerate(ROM_TABLES):
        assets[A_DEFAULT_ATTR + 1 + i] = bytes(rom.bytes(addr, n * 2))

    out = bytearray(b"UWAS" + struct.pack("<I", len(assets)))
    for k, v in assets.items():
        out += struct.pack("<II", k, len(v)) + v
        out += bytes(-len(v) % 4)  # entries are 4-byte aligned
    return bytes(out)
