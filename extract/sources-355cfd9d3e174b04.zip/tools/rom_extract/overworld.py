"""Overworld: map16/map32 definitions, per-screen map data, area properties."""
from rom import A, Rom

MAP16_DEFS = A(0x0F8000)       # Map16Definitions: 4 tilemap words per map16
MAP16_COUNT = 0xE9E         # MAP16 0000-0E9D in the JP ROM
MAP32_QUARTERS = (A(0x038000), A(0x03B3C0), A(0x048000), A(0x04B3C0))  # Map32_TopLeft/TopRight/BottomLeft/BottomRight
MAP32_GROUPS = 0x33C0 // 6  # 6 bytes encode 4 map32 entries
MAP32_HI_PTRS = A(0x02F6B1)    # OverworldLoad_Map32HPointers (dl x 160)
MAP32_LO_PTRS = A(0x02F891)    # OverworldLoad_Map32LPointers
SCREEN_COUNT = 160          # 0x00-0x3F light world, 0x40-0x7F dark world, 0x80-0x9F special
PARENT_SCREEN = A(0x02A4E3)    # ActualOverworldScreenID (64): screen -> parent screen of its area
SCREEN_IS_SMALL = A(0x02F5F1)  # OverworldScreenSize (64): nonzero = 1 screen, 0 = 2x2 screens
AREA_GFX = A(0x00FC9C)         # GFXAA2ValsOW (128): aux tile theme per screen
AREA_PALETTE = A(0x00FD1C)     # OverworldPalettesScreenToSet (136)
TILE8_TYPES = A(0x0FFD94)      # OverworldTileTypes: collision/behaviour type per 8x8 tile number
LW_MAIN_THEME, DW_MAIN_THEME = 0x20, 0x21


def _map16_order(rom: Rom) -> list[int]:
    """Reference id of each map16 of this ROM. Other versions number their blocks differently
    (a few inserted / removed): our maps use the reference numbering, blocks the reference
    does not have get ids after its last one."""
    prof = rom.profile
    if not prof.map16_to_ref:
        return list(range(MAP16_COUNT))
    order, extra = [], MAP16_COUNT
    for r in prof.map16_to_ref:
        if r < 0:
            r, extra = extra, extra + 1
        order.append(r)
    return order


def map16_defs(rom: Rom) -> list[list[int]]:
    """Each map16 = 4 tilemap words (TL, TR, BL, BR): vhopppcc cccccccc, reference numbering."""
    n = rom.profile.map16_count
    flat = rom.words(MAP16_DEFS, n * 4)
    own = [flat[i * 4:i * 4 + 4] for i in range(n)]
    order = _map16_order(rom)
    out: list = [None] * max(max(order) + 1, MAP16_COUNT)
    for i, r in enumerate(order):
        out[r] = own[i]
    for r in range(len(out)):
        if out[r] is None:  # a reference block this version dropped: its neighbour in place
            out[r] = own[min(r, n - 1)]
    return out


def map32_defs(rom: Rom) -> list[list[int]]:
    """Each map32 = 4 map16 ids (TL, TR, BL, BR), reference numbering."""
    order = _map16_order(rom)
    quarters = []
    for base in MAP32_QUARTERS:
        vals = []
        for g in range(rom.profile.map32_groups):
            b = rom.bytes(base + g * 6, 6)
            vals += [b[0] | (b[4] >> 4) << 8, b[1] | (b[4] & 0xF) << 8,
                     b[2] | (b[5] >> 4) << 8, b[3] | (b[5] & 0xF) << 8]
        quarters.append([order[v] if v < len(order) else v for v in vals])
    return [list(q) for q in zip(*quarters)]


def screen_map32(rom: Rom, screen: int) -> list[int]:
    """16x16 map32 ids of one 512x512 screen."""
    hi = rom.decompress(rom.long(MAP32_HI_PTRS + screen * 3), offset_big_endian=True)
    lo = rom.decompress(rom.long(MAP32_LO_PTRS + screen * 3), offset_big_endian=True)
    return [lo[i] | hi[i] << 8 for i in range(256)]


def screen_map16(rom: Rom, screen: int, m32: list[list[int]]) -> list[int]:
    """32x32 map16 ids of one screen (row-major)."""
    ids = screen_map32(rom, screen)
    out = [0] * (32 * 32)
    for i, m in enumerate(ids):
        x, y = (i % 16) * 2, (i // 16) * 2
        tl, tr, bl, br = m32[m]
        out[y * 32 + x], out[y * 32 + x + 1] = tl, tr
        out[(y + 1) * 32 + x], out[(y + 1) * 32 + x + 1] = bl, br
    return out


def parent_screen(rom: Rom, screen: int) -> int:
    if screen >= 0x80:
        return screen
    return rom.byte(PARENT_SCREEN + (screen & 0x3F)) | (screen & 0x40)


def screen_is_small(rom: Rom, screen: int) -> bool:
    return screen >= 0x80 or rom.byte(SCREEN_IS_SMALL + (screen & 0x3F)) != 0


def area_props(rom: Rom, screen: int) -> dict:
    p = parent_screen(rom, screen)
    return {
        "screen": screen,
        "parent": p,
        "small": screen_is_small(rom, screen),
        "main_theme": DW_MAIN_THEME if screen & 0x40 else LW_MAIN_THEME,
        "aux_theme": rom.byte(AREA_GFX + p) if p < 0x80 else None,
        "palette_set": rom.byte(AREA_PALETTE + p) if p < 0x80 else None,
    }


def tile8_types(rom: Rom) -> list[int]:
    return list(rom.bytes(TILE8_TYPES, 512))
