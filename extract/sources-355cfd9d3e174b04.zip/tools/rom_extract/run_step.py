#!/usr/bin/env python3
"""Run only some extraction steps (tools/rom_extract/steps/<name>.py) without redoing the rest.
    python3 tools/rom_extract/run_step.py audio sprites
"""
import importlib
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from rom import Rom, find_rom  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]

if __name__ == "__main__":
    rom = Rom(find_rom(ROOT))
    out = ROOT / "game" / "assets" / "rom"
    for name in sys.argv[1:]:
        t = time.time()
        info = importlib.import_module(f"steps.{name}").run(rom, out)
        print(f"{name}: {info} ({time.time() - t:.1f} s)")
