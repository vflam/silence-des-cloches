#!/usr/bin/env python3
"""Offline helper (for MAPTOOLS maintainers): learn marching-squares transition tiles between
two ground tiles from the original worlds, by classifying the 4 corners of every map16 seen
next to the 'inner' ground, by colour against the two pure tiles.

    python3 tools/mapgen/learn_terrain.py lw 0xc6 0x34 [--atlas ow_20_23_08_0] [-o out.png]

Prints, for each corner signature (TL, TR, BL, BR; 1 = inner terrain), the candidate map16 ids
by frequency. The chosen tables are then written by hand into autotile.py.
"""
import argparse
import collections
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
import data as D  # noqa: E402
TOL = 40.0


def corner_sig(tiles, t, inner, outer, k=4, tol=None):
    tol = TOL if tol is None else tol
    a = tiles[t].astype(np.float32)
    ti, to = tiles[inner].astype(np.float32), tiles[outer].astype(np.float32)
    sig = []
    for (ys, xs) in ((slice(0, k), slice(0, k)), (slice(0, k), slice(16 - k, 16)),
                     (slice(16 - k, 16), slice(0, k)), (slice(16 - k, 16), slice(16 - k, 16))):
        di = np.abs(a[ys, xs] - ti[ys, xs]).mean()
        do = np.abs(a[ys, xs] - to[ys, xs]).mean()
        if min(di, do) > tol:
            return None
        sig.append(1 if di < do else 0)
    return tuple(sig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("world")
    ap.add_argument("inner", type=lambda v: int(v, 0))
    ap.add_argument("outer", type=lambda v: int(v, 0))
    ap.add_argument("--atlas", default="ow_20_23_08_0")
    ap.add_argument("--radius", type=int, default=2)
    ap.add_argument("--tol", type=float, default=40.0)
    ap.add_argument("-o", "--out", default="/tmp/learn.png")
    a = ap.parse_args()
    global TOL
    TOL = a.tol
    g = D.world_grid(a.world)
    tiles = D.atlas_px_cache(a.atlas)
    near = collections.Counter()
    ys, xs = np.nonzero(g == a.inner)
    r = a.radius
    for y, x in zip(ys, xs):
        near.update(g[max(0, y - r):y + r + 1, max(0, x - r):x + r + 1].ravel().tolist())
    by_sig = collections.defaultdict(list)
    for t, n in near.most_common():
        s = corner_sig(tiles, t, a.inner, a.outer)
        if s is not None:
            by_sig[s].append((t, n))
    rows = []
    for s in sorted(by_sig):
        print(s, [(hex(t), n) for t, n in by_sig[s][:8]])
        rows.append((s, by_sig[s][:10]))
    W = 10 * 40 + 80
    im = Image.new("RGB", (W, len(rows) * 44 + 4), (30, 30, 40))
    dr = ImageDraw.Draw(im)
    for i, (s, lst) in enumerate(rows):
        dr.text((2, i * 44 + 12), "".join(map(str, s)), fill=(255, 255, 150))
        for j, (t, n) in enumerate(lst):
            tile = Image.fromarray(tiles[t]).resize((32, 32), Image.NEAREST)
            im.paste(tile, (80 + j * 40, i * 44 + 2))
            dr.text((80 + j * 40, i * 44 + 34), hex(t)[2:], fill=(200, 200, 255))
    im.save(a.out)
    print(a.out)


if __name__ == "__main__":
    main()
