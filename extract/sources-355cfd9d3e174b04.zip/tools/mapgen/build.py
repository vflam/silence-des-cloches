#!/usr/bin/env python3
"""Compile map sources content/maps/<id>.py into game/assets/rom/maps/<id>.json (+ previews).

    python3 tools/mapgen/build.py                 # every map
    python3 tools/mapgen/build.py demo_village    # some maps (the others are still loaded to
                                                  # check links between maps)
    python3 tools/mapgen/build.py demo_village --grid     # preview with a cell grid
    python3 tools/mapgen/build.py --list          # list the sources

Output: game/assets/rom/maps/<id>.json, previews/<id>.png (and composite atlases in
game/assets/rom/overworld/atlases/map_<id>_<n>.png). Exit code 1 on any error.
"""
from __future__ import annotations

import argparse
import json
import runpy
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import data as D  # noqa: E402
import mapdsl  # noqa: E402
from data import MapError  # noqa: E402


def sources(content: Path | None = None) -> dict[str, Path]:
    content = content or D.CONTENT
    return {p.stem: p for p in sorted(content.glob("*.py")) if not p.name.startswith("_")}


def load(path: Path):
    """Run a map source; returns its Map."""
    before = len(mapdsl._REGISTRY)
    try:
        runpy.run_path(str(path), run_name=f"map_{path.stem}")
    except MapError as e:
        tb = traceback.extract_tb(sys.exc_info()[2])
        line = next((f"{Path(f.filename).name}:{f.lineno}" for f in reversed(tb) if f.filename == str(path)), path.name)
        raise MapError(f"{line}: {e}") from None
    except Exception as e:
        tb = traceback.extract_tb(sys.exc_info()[2])
        line = next((f"{Path(f.filename).name}:{f.lineno}" for f in reversed(tb) if f.filename == str(path)), path.name)
        raise MapError(f"{line}: {type(e).__name__}: {e}") from None
    maps = mapdsl._REGISTRY[before:]
    if len(maps) != 1:
        raise MapError(f"{path.name}: {len(maps)} cartes créées (une seule Map(...) par fichier)")
    m = maps[0]
    if m.id != path.stem:
        raise MapError(f"{path.name}: l'id de la carte ({m.id!r}) doit être le nom du fichier ({path.stem!r})")
    m.source_file = str(path)
    return m


def build(ids: list[str] | None = None, grid: bool = False, preview: bool = True, quiet: bool = False,
          content: Path | None = None) -> dict:
    import compiler
    import validate as V
    from preview import save_preview
    srcs = sources(content)
    if ids:
        unknown = [i for i in ids if i not in srcs]
        if unknown:
            raise MapError(f"carte(s) inconnue(s) : {', '.join(unknown)} (sources : {', '.join(srcs)})")
    targets = ids or list(srcs)
    loaded, errors = {}, {}
    for mid, p in srcs.items():
        try:
            loaded[mid] = load(p)
        except MapError as e:
            errors[mid] = [str(e)]
    all_spawns = {mid: m.spawns for mid, m in loaded.items()}
    out_dir = D.MAPS_OUT
    out_dir.mkdir(parents=True, exist_ok=True)
    report = {"built": [], "errors": {}, "warnings": {}}
    for mid in targets:
        if mid in errors:
            report["errors"][mid] = errors[mid]
            continue
        m = loaded[mid]
        t = time.time()
        try:
            compiled, composites = m.compile()
        except MapError as e:
            report["errors"][mid] = [str(e)]
            continue
        # layout lock (locks.py): written with the reference ROM, reused with the others
        import locks
        if locks.is_reference():
            locks.save(mid, srcs[mid], compiled, composites)
        else:
            composites = locks.apply(mid, srcs[mid], compiled, composites)
        # composite atlases first: validation and the seam detector read them
        for name, c in composites.items():
            compiler.write_composite(name, c["base"], c["mapping"])
        errs, warns = V.validate(compiled, all_spawns)
        errs = m.shape_errors() + errs
        if compiled["kind"] == "overworld":
            import seams  # visual joins (QA-CH1): pasted grass, cut trees, broken edges
            errs = errs + seams.describe(seams.find(compiled))
        warns = m.warnings + warns
        import bake  # collisions baked into the map (no original tables needed at runtime)
        bake.bake(compiled)
        with open(out_dir / f"{mid}.json", "w") as f:
            json.dump(compiled, f, separators=(",", ":"), ensure_ascii=False)
        if preview:
            save_preview(compiled, out_dir / "previews" / f"{mid}.png", grid=grid)
        if errs:
            report["errors"][mid] = errs
        if warns:
            report["warnings"][mid] = warns
        report["built"].append(mid)
        if not quiet:
            print(f"{mid}: {compiled['screens_w']}×{compiled['screens_h']} écrans, "
                  f"{len(compiled['entities'])} entités, {len(compiled['warps'])} liaisons, "
                  f"{len(composites)} atlas composite(s) ({time.time() - t:.1f} s)")
    if not quiet:
        for mid, ws in report["warnings"].items():
            for w in ws:
                print(f"  avertissement [{mid}] {w}")
        for mid, es in report["errors"].items():
            for e in es:
                print(f"  ERREUR [{mid}] {e}")
        if preview and report["built"]:
            print(f"aperçus : {out_dir / 'previews'}")
    return report


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("ids", nargs="*")
    ap.add_argument("--grid", action="store_true", help="grille de cellules sur l'aperçu")
    ap.add_argument("--no-preview", action="store_true")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for mid, p in sources().items():
            print(mid, p)
        return 0
    try:
        rep = build(a.ids or None, grid=a.grid, preview=not a.no_preview)
    except MapError as e:
        print(f"ERREUR : {e}", file=sys.stderr)
        return 1
    if rep["errors"]:
        return 1
    # Directive: no map may resemble the original game (tools/mapgen/originality.py).
    import originality
    built = [m for m in (rep.get("built") or []) if not str(m).startswith(("test_", "core_", "demo_"))]
    if built and originality.main([str(m) for m in built]) != 0:
        print("ERREUR : carte trop proche du jeu d'origine (voir ci-dessus).", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
