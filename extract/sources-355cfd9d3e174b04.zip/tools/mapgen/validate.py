"""Checks on a compiled map (plus cross-map links)."""
from __future__ import annotations

import numpy as np

import data as D

# Port of game/scripts/world/tile_types.gd (kind()).
SOLID_TYPES = {0x01, 0x02, 0x03, 0x0B, 0x26, 0x27, 0x42, 0x43, 0x46, 0x4C, 0x4D, 0x4E, 0x4F}


def kind(t: int) -> str:
    if t in SOLID_TYPES:
        return "solid"
    if t == 0x08:
        return "deep_water"
    if t == 0x09:
        return "shallow_water"
    if t in (0x04, 0x40):
        return "grass"
    if t == 0x20:
        return "pit"
    if t in (0x22, 0x1D, 0x1E, 0x1F, 0x3D, 0x3E, 0x3F):
        return "stairs"
    if t in (0x8E, 0x8F):
        return "entrance"
    if 0x10 <= t <= 0x13 or 0x18 <= t <= 0x1B:
        return "slope"
    if 0x28 <= t <= 0x2F:
        return "ledge"
    if 0x30 <= t <= 0x37:
        return "stairs"
    if 0x50 <= t <= 0x5D or t == 0x63:
        return "solid"
    if 0x80 <= t <= 0x8D:
        return "entrance"
    if 0xB0 <= t <= 0xBD:
        return "pit"
    return "floor"


BLOCKING = {"solid", "deep_water", "ledge", "entrance", "pit", "slope"}


def type_grid(compiled: dict) -> np.ndarray:
    """(H8, W8) behaviour types of the whole map (8x8 px), outside = solid."""
    sw, sh = compiled["screens_w"], compiled["screens_h"]
    g = np.full((sh * 64, sw * 64), 0x01, np.uint8)
    defs = D.map16()["defs"] if compiled["kind"] == "overworld" else None
    t8 = np.array(D.map16()["tile8_types"], np.uint8) if defs else None
    for si, s in enumerate(compiled["screens"]):
        if s is None:
            continue
        sx, sy = si % sw, si // sw
        if s["format"] == "map16":
            ids = np.array(s["tiles"]).reshape(32, 32)
            words = np.array(defs, np.int64)[ids]  # 32,32,4
            q = t8[words & 0x1FF]
            slope = (q >= 0x10) & (q < 0x1C)
            q = np.where(slope, q | ((words >> 14) & 1), q)
            blk = np.zeros((64, 64), np.uint8)
            blk[0::2, 0::2] = q[..., 0]
            blk[0::2, 1::2] = q[..., 1]
            blk[1::2, 0::2] = q[..., 2]
            blk[1::2, 1::2] = q[..., 3]
        else:
            blk = np.array(s["types"], np.uint8).reshape(64, 64)
        g[sy * 64:(sy + 1) * 64, sx * 64:(sx + 1) * 64] = blk
    return g


def footprint_blocked(tg: np.ndarray, x: int, y: int, w: int = 16, h: int = 16) -> list[str]:
    kinds = []
    for yy in range(y // 8, (y + h - 1) // 8 + 1):
        for xx in range(x // 8, (x + w - 1) // 8 + 1):
            if not (0 <= yy < tg.shape[0] and 0 <= xx < tg.shape[1]):
                kinds.append("hors carte")
                continue
            k = kind(int(tg[yy, xx]))
            if k in BLOCKING:
                kinds.append(k)
    return kinds


WALL_CHECKED = {"npc", "enemy", "chest", "pickup", "switch", "block", "boss"}


def validate(compiled: dict, all_spawns: dict[str, dict]) -> tuple[list[str], list[str]]:
    """-> (errors, warnings). all_spawns: map id -> spawns dict of every known map."""
    errs, warns = [], []
    sw, sh = compiled["screens_w"], compiled["screens_h"]
    Wp, Hp = sw * 512, sh * 512
    # areas
    cover = np.zeros((sh, sw), np.int32)
    pxs = []
    for a in compiled["areas"]:
        if "rect_px" in a:
            x, y, w, h = a["rect_px"]
            if x < 0 or y < 0 or x + w > Wp or y + h > Hp:
                errs.append(f"zone {a['name']!r} rect_px {a['rect_px']} hors carte")
            for o in pxs:
                if x < o[0] + o[2] and o[0] < x + w and y < o[1] + o[3] and o[1] < y + h:
                    errs.append(f"zones qui se chevauchent : {a['rect_px']} et {list(o)}")
            pxs.append((x, y, w, h))
            for sy in range(y // 512, (y + h - 1) // 512 + 1):
                for sx in range(x // 512, (x + w - 1) // 512 + 1):
                    if 0 <= sx < sw and 0 <= sy < sh:
                        cover[sy, sx] = max(cover[sy, sx], 1)
            continue
        x, y, w, h = a["rect"]
        if x < 0 or y < 0 or x + w > sw or y + h > sh:
            errs.append(f"zone {a['name']!r} {a['rect']} hors de la grille {sw}×{sh}")
            continue
        cover[y:y + h, x:x + w] += 1
        if not a.get("music"):
            warns.append(f"zone {a['name']!r} sans musique")
    for sy in range(sh):
        for sx in range(sw):
            s = compiled["screens"][sy * sw + sx]
            if s is not None and cover[sy, sx] == 0:
                errs.append(f"écran ({sx},{sy}) couvert par aucune zone")
            if cover[sy, sx] > 1:
                errs.append(f"écran ({sx},{sy}) couvert par {cover[sy, sx]} zones")
    tg = type_grid(compiled)
    # entities
    seen = set()
    for e in compiled["entities"]:
        eid = e.get("id")
        if not eid:
            errs.append(f"entité sans id : {e}")
        elif eid in seen:
            errs.append(f"id d'entité en double : {eid}")
        seen.add(eid)
        x, y = e.get("x", 0), e.get("y", 0)
        if not (0 <= x < Wp and 0 <= y < Hp):
            errs.append(f"entité {eid} hors carte ({x},{y})")
            continue
        if compiled["screens"][(y // 512) * sw + x // 512] is None:
            errs.append(f"entité {eid} sur un écran vide")
        if e["type"] in WALL_CHECKED:
            bad = footprint_blocked(tg, x, y)
            if bad:
                errs.append(f"entité {eid} ({e['type']}) dans un obstacle en ({x},{y}) : {', '.join(sorted(set(bad)))}")
        if e["type"] == "trigger" and ("w" not in e or "h" not in e):
            errs.append(f"trigger {eid} sans w/h")
    # spawns
    for name, (x, y, d) in compiled["spawns"].items():
        if not (0 <= x < Wp and 0 <= y < Hp):
            errs.append(f"spawn {name} hors carte ({x},{y})")
            continue
        bad = footprint_blocked(tg, x, y)
        if bad:
            errs.append(f"spawn {name} ({x},{y}) sur un sol non praticable : {', '.join(sorted(set(bad)))}")
    if pxs:
        def inside(x, y):
            return any(a[0] <= x + 8 < a[0] + a[2] and a[1] <= y + 8 < a[1] + a[3] for a in pxs)
        for name, (x, y, d) in compiled["spawns"].items():
            if not inside(x, y):
                errs.append(f"spawn {name} ({x},{y}) hors de toute zone")
    if not compiled["spawns"]:
        warns.append("aucun spawn : la carte est inatteignable")
    # warps
    for w in compiled["warps"]:
        x, y, ww, hh = w["rect"]
        if x < 0 or y < 0 or x + ww > Wp or y + hh > Hp:
            errs.append(f"liaison vers {w['to']} : rectangle {w['rect']} hors carte")
        tgt = all_spawns.get(w["to"])
        if tgt is None:
            errs.append(f"liaison vers une carte inconnue {w['to']!r}")
        elif w["spawn"] not in tgt:
            errs.append(f"liaison vers {w['to']}:{w['spawn']} : spawn inexistant (connus : {', '.join(tgt) or 'aucun'})")
    return errs, warns
