#!/usr/bin/env python3
"""Originality check: our maps must not LOOK like the original overworld screens or rooms.

    python3 tools/mapgen/originality.py [map ids…] [--sheet]   (all compiled maps by default)

Every screen of our maps is rendered, reduced to a structure thumbnail (8 px blocks,
local mean removed: shapes, masses, contrasts) and compared by normalised
cross-correlation, at every offset, with the thumbnails of all original overworld
screens (overworld maps) or all original rooms (interiors). The same is done for each
256x256 quarter (catches partial copies). Calibration: a copied screen/room scores 1.0,
our invented layouts built from the same tiles and stamps score 0.15-0.55.
Screens above the limits fail (exit code 1). --sheet writes side-by-side comparisons of
the closest originals into game/assets/rom/maps/originality/ (git-ignored) for review.
Maps whose id starts with test_ / core_ are ignored (technical test maps).
"""
import json
import sys
from pathlib import Path

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
ROM = ROOT / "game" / "assets" / "rom"
sys.path.insert(0, str(ROOT / "tools" / "rom_extract"))

BLOCK = 8
LIMITS = {"ow": 0.50, "uw": 0.72}          # whole screen
QUARTER_LIMITS = {"ow": 0.60, "uw": 0.85}  # any 256x256 quarter
CACHE = ROM / "maps" / "_originality_cache.npz"

_atlases: dict = {}


def render_map16(atlas: str, tiles: list) -> Image.Image:
    a = _atlases.get(atlas)
    if a is None:
        a = np.asarray(Image.open(ROM / "overworld" / "atlases" / f"{atlas}.png").convert("RGBA"))
        _atlases[atlas] = a
    cols = a.shape[1] // 16
    out = np.zeros((512, 512, 4), np.uint8)
    for i, m in enumerate(tiles):
        y, x = (i // 32) * 16, (i % 32) * 16
        out[y:y + 16, x:x + 16] = a[(m // cols) * 16:(m // cols) * 16 + 16, (m % cols) * 16:(m % cols) * 16 + 16]
    return Image.fromarray(out)


def render_tile8(s: dict) -> Image.Image:
    import underworld_render as U
    return U.render_words(s["bg"], s["tileset"], fg=s.get("fg"))


def thumb(img: Image.Image) -> np.ndarray:
    a = np.asarray(img.convert("L"), dtype=np.float32)
    h, w = a.shape
    a = a[:h // BLOCK * BLOCK, :w // BLOCK * BLOCK].reshape(h // BLOCK, BLOCK, w // BLOCK, BLOCK).mean(axis=(1, 3))
    p = np.pad(a, 2, mode="edge")
    return a - sliding_window_view(p, (5, 5)).mean(axis=(2, 3))


def originals() -> tuple[list[str], np.ndarray, list[str]]:
    if CACHE.exists():
        z = np.load(CACHE, allow_pickle=False)
        return list(z["names"]), z["thumbs"], list(z["kinds"])
    names, thumbs, kinds = [], [], []
    for i, s in enumerate(json.load(open(ROM / "overworld" / "screens.json"))["screens"]):
        if s.get("atlas"):
            names.append("écran d'origine $%02X" % i)
            thumbs.append(thumb(render_map16(s["atlas"], s["map16"])))
            kinds.append("ow")
    for f in sorted((ROM / "underworld" / "previews").glob("[0-9a-f][0-9a-f][0-9a-f].png")):
        names.append("salle d'origine %s" % f.stem)
        thumbs.append(thumb(Image.open(f)))
        kinds.append("uw")
    t = np.stack(thumbs)
    np.savez_compressed(CACHE, names=np.array(names), thumbs=t, kinds=np.array(kinds))
    return names, t, kinds


def ncc_best(a: np.ndarray, b: np.ndarray, step=2, min_overlap=0.5) -> float:
    """Best normalised cross-correlation of a (h×w) against b (64×64) over offsets."""
    ha, wa = a.shape
    hb, wb = b.shape
    best = -1.0
    for dy in range(-((ha - 1) // step) * step, hb, step):      # multiples of step: 0 included
        for dx in range(-((wa - 1) // step) * step, wb, step):
            y0, x0 = max(0, dy), max(0, dx)
            y1, x1 = min(hb, dy + ha), min(wb, dx + wa)
            if (y1 - y0) * (x1 - x0) < min_overlap * ha * wa:
                continue
            B = b[y0:y1, x0:x1]
            A = a[y0 - dy:y1 - dy, x0 - dx:x1 - dx]
            va = A - A.mean()
            vb = B - B.mean()
            d = np.sqrt((va * va).sum() * (vb * vb).sum())
            if d > 1e-6:
                best = max(best, float((va * vb).sum() / d))
    return best


def check_screen(img: Image.Image, kind: str, names, thumbs, kinds):
    t = thumb(img)
    lum = np.asarray(img.convert("L"), dtype=np.float32)[:512, :512]
    full = lum.reshape(64, BLOCK, 64, BLOCK).mean(axis=(1, 3)) > 12  # blocks with content
    if t.std() < 1.0:
        return 0.0, "", 0.0, ""
    best, best_name, qbest, qname = -1.0, "", -1.0, ""
    for n, o, k in zip(names, thumbs, kinds):
        if k != kind:
            continue
        s = ncc_best(t, o, step=4, min_overlap=0.6)
        if s > best:
            best, best_name = s, n
    for qy in (0, 32):
        for qx in (0, 32):
            q = t[qy:qy + 32, qx:qx + 32]
            if q.std() < 2.0 or full[qy:qy + 32, qx:qx + 32].mean() < 0.7:
                continue  # mostly empty quarter: nothing to compare
            for n, o, k in zip(names, thumbs, kinds):
                if k != kind:
                    continue
                s = ncc_best(q, o, step=4, min_overlap=0.9)
                if s > qbest:
                    qbest, qname = s, n
    return best, best_name, qbest, qname


def check_map(path: Path, names, thumbs, kinds, sheet=False) -> int:
    m = json.load(open(path))
    mid = m.get("id", path.stem)
    if mid.startswith(("test_", "core_", "demo_")):  # technical / demo maps, not in the game
        return 0
    bad = 0
    for i, s in enumerate(m.get("screens", [])):
        if not s:
            continue
        kind = "ow" if s.get("format") == "map16" else "uw"
        img = render_map16(s["atlas"], s["tiles"]) if kind == "ow" else render_tile8(s)
        best, bn, qbest, qn = check_screen(img, kind, names, thumbs, kinds)
        ok = best <= LIMITS[kind] and qbest <= QUARTER_LIMITS[kind]
        bad += 0 if ok else 1
        print("%s %-22s écran %2d  ressemblance %.2f (%s) · quart %.2f (%s)" % (
            "OK   " if ok else "COPIE", mid, i, best, bn, qbest, qn))
        if sheet or not ok:
            _sheet(mid, i, img, [bn, qn])
    return bad


def _sheet(mid: str, i: int, img: Image.Image, originals_named: list[str]) -> None:
    out = ROM / "maps" / "originality"
    out.mkdir(parents=True, exist_ok=True)
    tiles = [img.convert("RGB").resize((256, 256))]
    for n in dict.fromkeys(originals_named):
        if n.startswith("salle"):
            p = ROM / "underworld" / "previews" / f"{n.split()[-1]}.png"
            if p.exists():
                tiles.append(Image.open(p).convert("RGB").resize((256, 256)))
        elif n.startswith("écran"):
            sid = int(n.split("$")[-1], 16)
            s = json.load(open(ROM / "overworld" / "screens.json"))["screens"][sid]
            tiles.append(render_map16(s["atlas"], s["map16"]).convert("RGB").resize((256, 256)))
    sheet = Image.new("RGB", (260 * len(tiles), 256))
    for k, t in enumerate(tiles):
        sheet.paste(t, (k * 260, 0))
    sheet.save(out / f"{mid}_{i}.png")


def main(argv: list[str]) -> int:
    sheet = "--sheet" in argv
    ids = [a for a in argv if not a.startswith("--")]
    names, thumbs, kinds = originals()
    files = [ROM / "maps" / f"{i}.json" for i in ids] if ids else sorted((ROM / "maps").glob("*.json"))
    bad = sum(check_map(f, names, thumbs, kinds, sheet) for f in files if f.exists())
    if bad:
        print(f"\n{bad} écran(s) ressemblent trop au jeu d'origine : inventer une autre disposition "
              f"(comparaisons dans game/assets/rom/maps/originality/).")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
