"""Zelda3-2 map DSL. A map source (content/maps/<id>.py) looks like:

    from mapdsl import *

    m = Map("demo_village", "Village de démo", size=(2, 2))
    m.area(0, 0, 2, 2, name="Village de démo", music="village", atlas=KAKARIKO)
    m.fill("grass")
    m.terrain(4, 10, [
        "......####......",
        "......#..#......",
    ], {"#": "path"})
    house = m.stamp("house_red_m", 10, 4)
    m.warp_door(house, to="demo_house", spawn="entry")
    m.spawn("from_house", *house.outside, "down")
    m.npc("ael", cell=(12, 12), sprite="npc_old_man", dialogue="demo_old_1")

Units: decor positions in **cells** (map16 = 16x16 px; a screen is 32x32 cells);
entities / warps / spawns in **pixels** (or `cell=(cx, cy)` for convenience).
Interiors (kind="interior"/"dungeon") use tile8 units (8x8 px; a screen is 64x64).

Build: python3 tools/mapgen/build.py <id>   ->  game/assets/rom/maps/<id>.json + previews/<id>.png
Full reference: docs/tech/MAPS.md
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import data as D  # noqa: E402
import stamps as S  # noqa: E402
import tiles as T  # noqa: E402
from data import MapError  # noqa: E402

__all__ = ["Map", "MapError", "Placed", "W", "LIGHT", "KAKARIKO", "LOST_WOODS", "POND_ATLAS",
           "DEATH_MOUNTAIN", "DARK", "DESERT", "atlas", "screen_origin", "TILES"]

TILES = T.TILES

# Convenient base atlases (graphics + palette). Any "ow_<main>_<aux>_<palette>_<mode>" works
# and is generated on demand; composite atlases are made automatically when stamps from
# other atlases are used (so a stamp always looks like in its original place).
LIGHT = "ow_20_20_00_0"        # Link's house / south fields
KAKARIKO = "ow_20_23_08_0"     # Kakariko village
LOST_WOODS = "ow_20_21_06_0"   # Lost Woods (darker, bluish greens)
POND_ATLAS = "ow_20_27_04_0"   # swamp / Hylia shores (grass-water edges)
DEATH_MOUNTAIN = "ow_20_22_07_2"
DESERT = "ow_20_2b_09_0"
DARK = "ow_21_30_10_1"         # dark world fields


def atlas(main: int, aux: int, palette_set: int, mode: int = 0) -> str:
    """Atlas name for any (main theme, aux theme, palette set, palette mode) combination."""
    return D.atlas_name(main, aux, palette_set, mode)


def screen_origin(screen: int) -> tuple[int, int]:
    """World cell coordinates of the top-left of original screen $SS (light or dark)."""
    return (screen & 7) * 32, ((screen & 0x3F) >> 3) * 32


def _world_of(screen: int) -> str:
    return "dw" if screen & 0x40 else "lw"


DIRS = ("up", "down", "left", "right")
WARP_STYLES = ("door", "stairs", "fade", "hole", "edge")
ENTITY_TYPES = ("npc", "enemy", "chest", "sign", "pot", "bush", "rock", "pickup", "trigger", "door",
                "switch", "block", "boss", "spawner", "torch", "crystal", "peg")


@dataclass
class Placed:
    """Result of m.stamp / m.strip / m.box / m.forest: where it landed (cells)."""
    name: str
    x: int
    y: int
    w: int
    h: int
    door_cell: tuple | None = None
    door_w: int = 1

    @property
    def rect(self) -> tuple:
        return (self.x, self.y, self.w, self.h)

    @property
    def door(self) -> tuple:
        """Cell of the door (absolute), for stamps that have one."""
        if self.door_cell is None:
            raise MapError(f"le tampon {self.name} n'a pas de porte")
        return self.door_cell

    @property
    def outside(self) -> tuple:
        """Pixel position (x, y) just below the door, facing down: use it as a spawn."""
        dx, dy = self.door
        return dx * 16 + (self.door_w - 1) * 8, (dy + 1) * 16 + 6

    @property
    def center(self) -> tuple:
        return (self.x + self.w // 2, self.y + self.h // 2)


@dataclass
class Area:
    rect: tuple                # screens (x, y, w, h)
    name: str
    music: str
    atlas: str
    dark: bool = False
    px: tuple | None = None    # pixel rectangle (sub-screen zones, interiors)


@dataclass
class Screen8:
    tileset: str
    bg: np.ndarray      # (64, 64) uint16 words
    fg: np.ndarray
    types: np.ndarray   # (64, 64) uint8


_REGISTRY: list["Map"] = []


class Map:
    def __init__(self, id: str, name: str, kind: str = "overworld", size: tuple = (1, 1),
                 dungeon: str = "", default: str | int | None = "grass"):
        if kind not in ("overworld", "interior", "dungeon"):
            raise MapError(f"kind {kind!r} invalide (overworld | interior | dungeon)")
        self.id, self.name, self.kind, self.dungeon = id, name, kind, dungeon
        self.sw, self.sh = size
        self.W, self.H = self.sw * 32, self.sh * 32
        self.areas: list[Area] = []
        self.entities: list[dict] = []
        self.warps: list[dict] = []
        self.spawns: dict[str, list] = {}
        self.on_enter: str | None = None
        self.warnings: list[str] = []
        self.null_screens: set = set()
        self.source_file: str | None = None
        # map16 layer
        self.ids = np.full((self.H, self.W), -1, np.int32)
        self.src = np.zeros((self.H, self.W), np.int16)     # 0 = area atlas, n = self._atlases[n]
        self._atlases: list[str | None] = [None]
        self.terr = np.zeros((self.H, self.W), np.uint8)
        # owner of each cell: 0 = ground (grass, terrain, single tiles), n = self._owners[n]
        # (a stamp / strip / forest): used to refuse a stamp laid over another element
        self.owner = np.zeros((self.H, self.W), np.int32)
        self._owners: list[str] = [""]
        # tile8 layer (interiors)
        self.s8: dict[tuple, Screen8] = {}
        if kind == "overworld" and default is not None:
            self._default = default
        else:
            self._default = None
        _REGISTRY.append(self)

    # ================================================================ helpers
    def _warn(self, msg: str) -> None:
        self.warnings.append(msg)

    def _error(self, msg: str) -> None:
        """Error reported by build.py after the whole source ran (so every problem is listed and
        the map still loads for the links of the other maps). Prefixed with the source line."""
        import inspect
        where = ""
        for fr in inspect.stack()[1:]:
            if "/content/" in fr.filename.replace("\\", "/") or fr.filename.endswith(f"{self.id}.py"):
                where = f"{Path(fr.filename).name}:{fr.lineno}: "
                break
        if not hasattr(self, "errors"):
            self.errors = []
        self.errors.append(where + msg)

    def _atlas_index(self, name: str | None) -> int:
        if name is None:
            return 0
        D.ensure_atlas(name)
        if name not in self._atlases:
            self._atlases.append(name)
        return self._atlases.index(name)

    def _resolve_tile(self, spec) -> tuple[int, int]:
        """tile spec -> (map16 id, atlas index). Spec: name | id | Tile | ('lw', x, y)."""
        if isinstance(spec, T.Tile):
            return spec.id, self._atlas_index(spec.atlas)
        if isinstance(spec, str):
            return self._resolve_tile(T.tile(spec))
        if isinstance(spec, (int, np.integer)):
            if not 0 <= spec < D.map16_count():
                raise MapError(f"map16 {spec:#x} hors limites (0-{D.map16_count() - 1:#x})")
            return int(spec), 0
        if isinstance(spec, tuple) and len(spec) == 3 and isinstance(spec[0], str):
            w, x, y = spec
            g = D.world_grid(w)
            return int(g[y, x]), self._atlas_index(D.screen_atlas(w, x // 32, y // 32))
        raise MapError(f"tuile invalide : {spec!r}")

    def _check_rect(self, x, y, w, h, what="rectangle") -> None:
        if x < 0 or y < 0 or x + w > self.W or y + h > self.H or w <= 0 or h <= 0:
            raise MapError(f"{what} ({x},{y}) {w}×{h} sort de la carte ({self.W}×{self.H} cellules)")

    def _put(self, x, y, ids: np.ndarray, mask: np.ndarray, atlas_idx, owner: str | None = None,
             over: bool = False) -> None:
        """Write a block of ids (clipped to the map). atlas_idx: int or array.
        owner = description of the element (stamps, strips): its cells are recorded and an
        element laid over the drawn cells of another one is an error (unless over=True)."""
        h, w = ids.shape
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(self.W, x + w), min(self.H, y + h)
        if x0 >= x1 or y0 >= y1:
            self._warn(f"bloc en ({x},{y}) {w}×{h} entièrement hors carte")
            return
        if (x0, y0, x1, y1) != (x, y, x + w, y + h):
            self._warn(f"bloc en ({x},{y}) {w}×{h} rogné au bord de la carte")
        sub = (slice(y0 - y, y1 - y), slice(x0 - x, x1 - x))
        m = mask[sub]
        tgt = (slice(y0, y1), slice(x0, x1))
        if owner is not None:
            clash = m & (self.owner[tgt] > 0)
            if over == "plateau":   # cliff stamps (stairs, cave) are cut into plateau walls
                clash &= ~np.isin(self.owner[tgt], getattr(self, "_plateau_owners", []))
                over = False
            if clash.any() and not over:
                yy, xx = np.nonzero(clash)
                cx, cy = x0 + int(xx[0]), y0 + int(yy[0])
                other = self._owners[int(self.owner[cy, cx])]
                self._error(f"{owner} chevauche {other} ({int(clash.sum())} cellule(s), dont ({cx},{cy})) : "
                            f"déplacez-le (un tampon se pose sur le sol, jamais sur un autre élément)")
            self._owners.append(owner)
            self.owner[tgt] = np.where(m, len(self._owners) - 1, self.owner[tgt])
        self.ids[tgt] = np.where(m, ids[sub], self.ids[tgt])
        a = atlas_idx[sub] if isinstance(atlas_idx, np.ndarray) else np.full(m.shape, atlas_idx, np.int16)
        self.src[tgt] = np.where(m, a, self.src[tgt])

    def _test_only(self, op: str, big: bool) -> None:
        """Game maps must be new: copying original landscape is reserved to test_* maps."""
        if big and not self.id.startswith("test_"):
            raise MapError(f"{op} : recopier le décor d'origine (plus de 6×6 cellules) est interdit hors des cartes "
                           f"de test (id 'test_*') ; utilisez les tampons et les outils de terrain (MAPS.md §0)")

    def _need_ow(self, op):
        if self.kind != "overworld":
            raise MapError(f"{op} : opération map16 réservée aux cartes overworld (utilisez les opérations *8)")

    # ================================================================ structure
    def area(self, sx: int = 0, sy: int = 0, w: int = 1, h: int = 1, *, name: str = "", music: str = "",
             atlas: str = LIGHT, dark: bool = False, px: tuple | None = None) -> Area:
        """A zone of w×h screens starting at screen (sx, sy): the camera stays inside a zone;
        crossing its border scrolls to the next zone. `atlas` = graphics + palette of the zone.
        px=(x, y, w, h) instead: a zone in pixels, smaller than a screen (a 256×256 room quadrant,
        a 512×256 half...); overworld zones should stay whole screens."""
        if px is not None:
            x, y, pw, ph = px
            if x < 0 or y < 0 or x + pw > self.sw * 512 or y + ph > self.sh * 512 or pw < 256 or ph < 224:
                raise MapError(f"zone px {px} invalide (dans la carte, au moins 256×224)")
            rect = (x // 512, y // 512, (x + pw - 1) // 512 - x // 512 + 1, (y + ph - 1) // 512 - y // 512 + 1)
            a = Area(rect, name or self.name, music, atlas, dark, tuple(px))
            self.areas.append(a)
            return a
        if sx < 0 or sy < 0 or sx + w > self.sw or sy + h > self.sh:
            raise MapError(f"zone ({sx},{sy}) {w}×{h} hors de la grille {self.sw}×{self.sh}")
        if self.kind == "overworld":
            D.ensure_atlas(atlas)
        a = Area((sx, sy, w, h), name or self.name, music, atlas, dark)
        self.areas.append(a)
        return a

    def empty_screen(self, sx: int, sy: int) -> None:
        """Mark a screen as outside the map (null in the compiled file)."""
        self.null_screens.add((sx, sy))

    def area_at_cell(self, x: int, y: int) -> Area | None:
        sx, sy = x // 32, y // 32
        for a in self.areas:
            ax, ay, aw, ah = a.rect
            if ax <= sx < ax + aw and ay <= sy < ay + ah:
                return a
        return None

    # ================================================================ map16 painting
    def fill(self, tile="grass", rect: tuple | None = None) -> None:
        """Fill the whole map (or rect = (x, y, w, h) in cells) with one tile."""
        self._need_ow("fill")
        x, y, w, h = rect or (0, 0, self.W, self.H)
        self._check_rect(x, y, w, h)
        i, a = self._resolve_tile(tile)
        own = self.owner[y:y + h, x:x + w]
        if (own > 0).any():
            yy, xx = np.nonzero(own > 0)
            cx, cy = x + int(xx[0]), y + int(yy[0])
            self._error(f"tuile {tile!r} en ({cx},{cy}) posée sur {self._owners[int(own[yy[0], xx[0]])]} : "
                        f"choisissez une cellule libre (ou m.erase(...) d'abord)")
        self.ids[y:y + h, x:x + w] = i
        self.src[y:y + h, x:x + w] = a
        self.terr[y:y + h, x:x + w] = 0

    def erase(self, x: int, y: int, w: int = 1, h: int = 1, tile="grass") -> None:
        """Remove whatever is in the rectangle (stamps, forest cells...) and put `tile` instead."""
        self._check_rect(x, y, w, h, "erase")
        self.owner[y:y + h, x:x + w] = 0
        if getattr(self, "_forest_cells", None) is not None:
            self._forest_cells[y:y + h, x:x + w] = False
        self.fill(tile, (x, y, w, h))

    def rect(self, x, y, w, h, tile) -> None:
        self.fill(tile, (x, y, w, h))

    def tile(self, x: int, y: int, tile) -> None:
        """One cell."""
        self.fill(tile, (x, y, 1, 1))

    def tiles(self, points, tile) -> None:
        """Same tile on several cells: m.tiles([(3, 4), (5, 4)], "bush")."""
        for x, y in points:
            self.tile(x, y, tile)

    def copy(self, world: str, sx: int, sy: int, w: int, h: int, dx: int, dy: int,
             ground: str | None = None) -> None:
        """Copy the original world rectangle (sx, sy, w, h) (world cells, see look.py) to (dx, dy),
        each cell keeping the atlas of its original screen. ground = 'grass' (etc.) makes those
        cells transparent (like a stamp)."""
        self._need_ow("copy")
        self._test_only("copy", w * h > 36)
        g = D.world_grid(world)
        if sx < 0 or sy < 0 or sx + w > 256 or sy + h > 256:
            raise MapError(f"copy : source ({sx},{sy}) {w}×{h} hors du monde (256×256)")
        ids = g[sy:sy + h, sx:sx + w]
        idx = np.zeros((h, w), np.int16)
        for yy in range(h):
            for xx in range(w):
                idx[yy, xx] = self._atlas_index(D.screen_atlas(world, (sx + xx) // 32, (sy + yy) // 32))
        mask = ~np.isin(ids, list(S.GROUNDS[ground])) if ground else np.ones_like(ids, bool)
        self._put(dx, dy, ids, mask, idx)

    def copy_screen(self, screen: int, sx: int, sy: int) -> None:
        """Copy a whole original overworld screen ($00-$7F) into map screen (sx, sy)."""
        ox, oy = screen_origin(screen)
        self.copy(_world_of(screen), ox, oy, 32, 32, sx * 32, sy * 32)

    def original_world(self, world: str = "lw", music: str = "overworld", names: dict | None = None) -> None:
        """Copy a whole original world (8x8 screens, map size must be (8, 8)) with its original
        zones (1x1 / 2x2) and atlases. names = {parent screen: zone name}."""
        self._test_only("original_world", True)
        if (self.sw, self.sh) != (8, 8):
            raise MapError("original_world : la carte doit faire 8×8 écrans")
        base = D.world_base(world)
        sc = D.screens()
        for s in range(64):
            self.copy_screen(base + s, s & 7, s >> 3)
        for s in range(64):
            e = sc[base + s]
            if e["parent"] != base + s:
                continue
            n = 1 if e["small"] else 2
            name = (names or {}).get(s, f"{'Ténèbres' if base else 'Lumière'} ${base + s:02X}")
            self.area(s & 7, s >> 3, n, n, name=name, music=music, atlas=e["atlas"], dark=bool(base))

    def paint(self, x: int, y: int, rows: list[str], legend: dict) -> None:
        """ASCII painting. Each character of `rows` is one cell; legend maps a character to a
        tile spec (name, id, Tile, ('lw', x, y)) or None = leave as is. ' ' and '.' default to
        None unless given in the legend."""
        self._need_ow("paint")
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                spec = legend.get(ch, None) if ch in legend else (None if ch in " ." else KeyError)
                if spec is KeyError:
                    raise MapError(f"paint : caractère {ch!r} absent de la légende (ligne {j}, colonne {i})")
                if spec is None:
                    continue
                cx, cy = x + i, y + j
                if not (0 <= cx < self.W and 0 <= cy < self.H):
                    raise MapError(f"paint : cellule ({cx},{cy}) hors carte")
                if self.owner[cy, cx] > 0:
                    self._error(f"paint : cellule ({cx},{cy}) occupée par {self._owners[int(self.owner[cy, cx])]}")
                tid, a = self._resolve_tile(spec)
                self.ids[cy, cx] = tid
                self.src[cy, cx] = a

    # ---------------------------------------------------------------- terrain (autotile)
    TERRAINS = {"path": 1, "water": 2, "shallow": 3, "tall_grass": 4, "grass": 0}

    def terrain(self, x: int, y: int, rows: list[str], legend: dict | None = None) -> None:
        """Autotiled ground painting on grass: 'path' (dirt), 'water' (pond: shallow rim + deep
        centre), 'shallow' (wading water), 'grass' (erase). Default legend:
        '#' path, '~' water, 's' shallow, 'g' grass, '.' / ' ' unchanged.
        Painted areas grow by half a cell on each side (rounded borders drawn on the
        neighbouring cells): paint terrain BEFORE placing stamps."""
        self._need_ow("terrain")
        legend = legend or {"#": "path", "~": "water", "s": "shallow", "t": "tall_grass", "g": "grass"}
        painted = np.zeros((self.H, self.W), bool)
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch in " ." and ch not in legend:
                    continue
                if ch not in legend:
                    raise MapError(f"terrain : caractère {ch!r} absent de la légende")
                kind = legend[ch]
                if kind is None:
                    continue
                if kind not in self.TERRAINS:
                    raise MapError(f"terrain {kind!r} inconnu ({', '.join(self.TERRAINS)})")
                cx, cy = x + i, y + j
                if not (0 <= cx < self.W and 0 <= cy < self.H):
                    raise MapError(f"terrain : cellule ({cx},{cy}) hors carte")
                self.terr[cy, cx] = self.TERRAINS[kind]
                painted[cy, cx] = True
        self._resolve_terrain(painted)

    def terrain_rect(self, x, y, w, h, kind="path") -> None:
        self.terrain(x, y, ["#" * w] * h, {"#": kind})

    def _resolve_terrain(self, painted: np.ndarray, forced: np.ndarray | None = None,
                         dilate: bool = True) -> None:
        """Re-tile the cells around `painted` from the terrain kinds of their four corners.
        forced = (H+1, W+1) bool: corners that must stay plain grass (next to an object drawn
        on grass, see _merge_grounds)."""
        H, W = self.H, self.W
        t = self.terr
        tp = np.pad(t, 1, mode="edge")
        # vertex (j, i) = corner at top-left of cell (j, i); neighbours cells (j-1..j, i-1..i)
        quad = [tp[0:H + 1, 0:W + 1], tp[0:H + 1, 1:W + 2], tp[1:H + 2, 0:W + 1], tp[1:H + 2, 1:W + 2]]
        path_v = np.zeros((H + 1, W + 1), bool)
        wat_v = np.zeros((H + 1, W + 1), bool)
        deep_v = np.ones((H + 1, W + 1), bool)
        tall_v = np.ones((H + 1, W + 1), bool)
        for q in quad:
            path_v |= q == 1
            wat_v |= (q == 2) | (q == 3)
            deep_v &= q == 2
            tall_v &= q == 4
        if forced is not None:
            path_v &= ~forced
            wat_v &= ~forced
            tall_v &= ~forced
            deep_v &= ~forced
        # deep water only between cells drawn as full water (not a shore tile)
        cw = wat_v[:-1, :-1] & wat_v[:-1, 1:] & wat_v[1:, :-1] & wat_v[1:, 1:]
        cwp = np.pad(cw, 1, constant_values=True)
        deep_v &= cwp[:-1, :-1] & cwp[:-1, 1:] & cwp[1:, :-1] & cwp[1:, 1:]
        deep_v = _fix_deep(deep_v)
        # affected cells = painted dilated by 1
        aff = painted.copy()
        if dilate:
            aff[1:, :] |= painted[:-1, :]
            aff[:-1, :] |= painted[1:, :]
            aff[:, 1:] |= aff[:, :-1].copy()
            aff[:, :-1] |= aff[:, 1:].copy()
        aff &= self.owner == 0          # never re-tile a stamp / forest cell
        pond = self._atlas_index(T.POND)
        for cy, cx in zip(*np.nonzero(aff)):
            def corners(v):
                return (int(v[cy, cx]), int(v[cy, cx + 1]), int(v[cy + 1, cx]), int(v[cy + 1, cx + 1]))
            wc = corners(wat_v)
            pc = corners(path_v)
            if self.terr[cy, cx] == 4 and not any(wc) and not any(pc):
                # tall grass: hard edges, rounded outer corners (shrink rule)
                tid = T.TALL.get(T._sig(*corners(tall_v)), 0x37D)
                self.ids[cy, cx] = tid
                self.src[cy, cx] = 0
                continue
            if any(wc):
                if all(wc):
                    dc = corners(deep_v)
                    sig = T._sig(*dc)
                    tid = T.DEEP.get(sig, 0x2CC)
                    a = 0
                else:
                    sig = T._sig(*wc)
                    tid = T.SHORE.get(sig, 0x2C6)
                    a = pond
            elif any(pc):
                sig = T._sig(*pc)
                tid = T.PATH.get(sig, 0xC6)
                a = 0
            else:
                if not painted[cy, cx] and self.terr[cy, cx] == 0:
                    # neighbour of an erased terrain: only rewrite if it was a terrain tile
                    if self.ids[cy, cx] not in _TERRAIN_IDS:
                        continue
                tid, a = 0x34, 0
            self.ids[cy, cx] = tid
            self.src[cy, cx] = a

    def shape_errors(self) -> list[str]:
        """Shape rules checked after compilation: tall grass patches without one-cell strips
        or single-cell steps (each tall grass cell belongs to a 2×2 block of tall grass)."""
        errs = list(getattr(self, "errors", []))
        if self.kind != "overworld":
            return errs
        t = self.terr == 4
        ok = np.zeros_like(t)
        blk = t[:-1, :-1] & t[:-1, 1:] & t[1:, :-1] & t[1:, 1:]
        ok[:-1, :-1] |= blk
        ok[:-1, 1:] |= blk
        ok[1:, :-1] |= blk
        ok[1:, 1:] |= blk
        bad = t & ~ok
        for cy, cx in list(zip(*np.nonzero(bad)))[:10]:
            errs.append(f"herbes hautes : cellule ({cx},{cy}) isolée ou en bande d'une cellule "
                        f"(contour en escalier) : chaque cellule doit faire partie d'un carré 2×2 d'herbes hautes")
        for x, y, d in getattr(self, "_forest_approx", [])[:10]:
            if d > 3000:
                errs.append(f"forêt : raccord approché en ({x},{y}) (écart {d}) : élargir / aligner les rectangles de forêt")
        return errs

    def _merge_grounds(self) -> None:
        """Objects drawn on grass (stamps, forest, bushes, signs, flowers...) keep plain grass
        around them: every corner of such a cell on a grassy side is forced to grass and the
        terrain cells around (path, water, tall grass) are re-tiled with their original
        transitions, so the path / shore curves around the object instead of meeting a
        square of grass. Called by the compiler."""
        if self.kind != "overworld":
            return
        import seams
        H, W = self.H, self.W
        resolvable = np.isin(self.ids, list(_RESOLVABLE)) & (self.owner == 0)
        near = self.terr > 0
        n2 = near.copy()
        n2[1:, :] |= near[:-1, :]
        n2[:-1, :] |= near[1:, :]
        n2[:, 1:] |= n2[:, :-1].copy()
        n2[:, :-1] |= n2[:, 1:].copy()
        resolvable &= n2
        if not resolvable.any():
            return
        forced = np.zeros((H + 1, W + 1), bool)
        cache: dict = {}
        for cy, cx in zip(*np.nonzero(~resolvable)):
            # only objects that touch a terrain cell matter
            y0, y1, x0, x1 = max(0, cy - 1), min(H, cy + 2), max(0, cx - 1), min(W, cx + 2)
            if not resolvable[y0:y1, x0:x1].any():
                continue
            tid = int(self.ids[cy, cx])
            if tid in _RESOLVABLE:
                continue
            atl = self._atlases[int(self.src[cy, cx])] or (self.area_at_cell(cx, cy).atlas
                                                           if self.area_at_cell(cx, cy) else LIGHT)
            key = (tid, atl)
            if key not in cache:
                px = seams._pack(D.atlas_px_cache(atl)[tid])
                mat = seams.materials(atl)
                g = np.vectorize(lambda v: mat.get(int(v)) == seams.GRASS)(px)
                cache[key] = (g[0].sum() >= 3, g[-1].sum() >= 3, g[:, 0].sum() >= 3, g[:, -1].sum() >= 3)
            t, b, l, r = cache[key]
            if t:
                forced[cy, cx] = forced[cy, cx + 1] = True
            if b:
                forced[cy + 1, cx] = forced[cy + 1, cx + 1] = True
            if l:
                forced[cy, cx] = forced[cy + 1, cx] = True
            if r:
                forced[cy, cx + 1] = forced[cy + 1, cx + 1] = True
        if not forced.any():
            return
        aff = np.zeros((H, W), bool)
        f = forced
        aff |= f[:-1, :-1] | f[:-1, 1:] | f[1:, :-1] | f[1:, 1:]
        aff |= (self.terr == 2) | (self.terr == 3)      # deep water may shrink: re-tile ponds
        aff &= resolvable
        self._resolve_terrain(aff, forced, dilate=False)
        bites = (self.terr == 1) & (self.owner == 0) & (self.ids != 0xC6) & aff
        for cy, cx in list(zip(*np.nonzero(bites)))[:12]:
            self._warn(f"chemin ({cx},{cy}) grignoté par un objet voisin posé sur l'herbe "
                       f"(éloigner l'objet d'une cellule, ou élargir le chemin)")

    # ---------------------------------------------------------------- stamps
    def stamp(self, name: str, x: int, y: int, anchor: str = "topleft", atlas: str | None = None,
              over: bool = False) -> Placed:
        """Place a fixed stamp with its top-left cell at (x, y) (anchor='bottom' : (x, y) = bottom-
        centre cell, handy for trees / houses standing on a line)."""
        self._need_ow("stamp")
        st = S.get(name)
        if st.kind != "fixed":
            raise MapError(f"{name} est un tampon {st.kind} : utilisez m.strip / m.box")
        if anchor == "bottom":
            x, y = x - st.w // 2, y - st.h + 1
        elif anchor == "center":
            x, y = x - st.w // 2, y - st.h // 2
        self._put(x, y, st.ids, st.mask, self._atlas_index(atlas or st.atlas), owner=f"le tampon {name} ({x},{y})",
                  over=over or ("plateau" if "cliff" in st.tags else False))
        door = None
        if "door" in st.extra:
            door = (x + st.extra["door"][0], y + st.extra["door"][1])
        if "tree" in st.tags and name not in NOT_FOLIAGE and st.h >= 2:
            # canopy = every row but the trunk row: walkable, drawn over the hero behind it
            cells = [[x + cx, y + cy] for cy in range(st.h - 1) for cx in range(st.w)
                     if st.mask is None or bool(st.mask[cy][cx])]
            if not hasattr(self, "foliage"):
                self.foliage = []
            self.foliage.append({"x": x * 16, "y": y * 16, "w": st.w * 16, "h": (st.h - 1) * 16,
                                 "base": (y + st.h - 1) * 16, "cells": cells})
        return Placed(name, x, y, st.w, st.h, door, st.extra.get("door_w", 1))

    def strip(self, name: str, x: int, y: int, length: int, atlas: str | None = None, over: bool = False) -> Placed:
        """Stretchable stamp (fence, hedge, cliff...): length in cells along its axis."""
        self._need_ow("strip")
        st = S.get(name)
        if st.kind == "hstrip":
            ids, mask = S.expand(st, w=length)
        elif st.kind == "vstrip":
            ids, mask = S.expand(st, h=length)
        else:
            raise MapError(f"{name} n'est pas un tampon étirable (kind={st.kind})")
        self._put(x, y, ids, mask, self._atlas_index(atlas or st.atlas), owner=f"le tampon {name} ({x},{y})",
                  over=over or ("plateau" if "cliff" in st.tags else False))
        return Placed(name, x, y, ids.shape[1], ids.shape[0])

    def box(self, name: str, x: int, y: int, w: int, h: int, atlas: str | None = None) -> Placed:
        """9-slice stamp (plaza, pond, plateau...) stretched to w×h cells."""
        self._need_ow("box")
        st = S.get(name)
        if st.kind != "box":
            raise MapError(f"{name} n'est pas un tampon 'box' (kind={st.kind})")
        ids, mask = S.expand(st, w, h)
        self._put(x, y, ids, mask, self._atlas_index(atlas or st.atlas))
        return Placed(name, x, y, w, h)

    def forest(self, x: int, y: int, w: int, h: int, edges: str = "nsew") -> Placed:
        """Dense forest made of WHOLE trees of the original canopy (tools/mapgen/forest.py).

        The rectangle is added to the map's forest region (union of every m.forest rectangle);
        the trees drawn are the trees of one global lattice that fit entirely inside the
        region, so no tree is ever cut, neighbouring rectangles merge into one canopy (L shapes,
        corners...) and the outline is always the original one. `edges` only matters at the map
        border: a side touching the border and NOT listed continues beyond the map (trees cut
        by the screen edge, like a forest going on); a listed side closes on whole trees.
        Leave room: a rectangle narrower than a tree (4-5 cells) or shorter than 5 cells draws
        nothing. Returns the bounding box of the cells actually covered by trees of this call."""
        self._need_ow("forest")
        import forest as F
        self._check_rect(x, y, w, h, "forest")
        if not hasattr(self, "_forest_region"):
            self._forest_region = np.zeros((self.H, self.W), bool)
            self._forest_open = np.zeros((self.H, self.W), np.uint8)
            self._forest_cells = np.zeros((self.H, self.W), bool)
        self._forest_region[y:y + h, x:x + w] = True
        opn = self._forest_open
        if "n" not in edges and y == 0:
            opn[0, x:x + w] |= 1
        if "s" not in edges and y + h == self.H:
            opn[self.H - 1, x:x + w] |= 2
        if "w" not in edges and x == 0:
            opn[y:y + h, 0] |= 4
        if "e" not in edges and x + w == self.W:
            opn[y:y + h, self.W - 1] |= 8
        area = self.area_at_cell(x, y)
        ids, approx, _ = F.render(self._forest_region, opn, area.atlas if area else LIGHT)
        new = (ids >= 0) & ~self._forest_cells
        # re-render every forest cell (a new rectangle can change the trees next to it)
        put = ids >= 0
        clash = put & (self.owner > 0) & ~self._forest_cells
        if clash.any():
            yy, xx = np.nonzero(clash)
            self._error(f"forest ({x},{y}) {w}×{h} : ses arbres recouvrent {self._owners[int(self.owner[yy[0], xx[0]])]} "
                        f"en ({int(xx[0])},{int(yy[0])}) : poser la forêt d'abord, ou éloigner l'élément")
        if "forêt" not in self._owners:
            self._owners.append("forêt")
        self.owner[put] = self._owners.index("forêt")
        self.ids[put] = ids[put]
        self.src[put] = 0
        self.terr[put] = 0
        self._forest_cells |= put
        self._forest_approx = approx
        sub = put[y:y + h, x:x + w]
        if not sub.any():
            self._warn(f"forest ({x},{y}) {w}×{h} : aucun arbre entier n'y tient (5×5 cellules minimum)")
            return Placed("forest", x, y, 0, 0)
        ys, xs = np.nonzero(sub)
        del new
        return Placed("forest", x + int(xs.min()), y + int(ys.min()), int(xs.max() - xs.min() + 1),
                      int(ys.max() - ys.min() + 1))

    def plateau(self, x: int, y: int, w: int, h: int, stairs: tuple = ()) -> Placed:
        """Raised dirt plateau with low walls on all four sides (Link can jump down from every
        side; to climb up, add stairs). Minimum 6×6. stairs = columns (absolute cells) where a
        3-wide stone stair is cut into the south wall (the column given is its left cell)."""
        self._need_ow("plateau")
        if w < 6 or h < 6:
            raise MapError(f"plateau ({x},{y}) {w}×{h} : minimum 6×6")
        P = T.PLATEAU
        ids = np.full((h, w), P["fill"], np.int32)
        # north rows A B C
        for j in range(3):
            ids[j, :] = P["north"][j]
        for j in range(3, h - 3):
            ids[j, 0:2] = P["west"]
            ids[j, w - 2:w] = P["east"]
        for j in range(3):
            ids[h - 3 + j, :] = P["south"][j]
        for j in range(3):
            ids[j, 0:3] = P["nw"][j]
            ids[j, w - 3:w] = P["ne"][j]
            ids[h - 3 + j, 0:2] = P["sw"][j]
            ids[h - 3 + j, w - 2:w] = P["se"][j]
        mask = ids != 0x34
        self._put(x, y, ids, mask, 0, owner=f"le plateau ({x},{y})")
        self._plateau_owners = getattr(self, "_plateau_owners", []) + [len(self._owners) - 1]
        for sx in stairs:
            if not (x + 2 <= sx and sx + 3 <= x + w - 2):
                raise MapError(f"plateau : escalier en x={sx} hors du mur sud ({x + 2}..{x + w - 5})")
            self.stamp("stairs_cliff", sx, y + h - 3)
        return Placed("plateau", x, y, w, h)

    # ================================================================ tile8 (interiors)
    def room(self, sx: int, sy: int, room: str, *, name: str | None = None, music: str = "",
             dark: bool | None = None) -> None:
        """Put a room into screen (sx, sy) of an interior / dungeon map. `room` = id of a room
        built with tools/roomgen (game/assets/rom/underworld/custom/<id>.json) — the normal case —
        or of an original room (rooms/<id>.json: samples / tests only, see MAPS.md §0).
        With name=..., zones are created from the room's used quadrants (rect_px)."""
        if not _room_is_custom(room):
            self._test_only(f"room({room!r}) (salle d'origine)", True)
        self.s8[(sx, sy)] = _load_room(room)
        if name is not None:
            self._room_areas(sx, sy, _room_json(room), name, music, dark)

    def room_custom(self, sx: int, sy: int, spec: dict, *, name: str | None = None, music: str = "",
                    dark: bool | None = None) -> dict:
        """Build a NEW room with INTERIORS' room builder (tools/roomgen, docs/tech/ROOMGEN.md) from
        a spec (list of ALttP room objects + header) and put it in screen (sx, sy). Returns the
        built room dict (doors, stairs... in tile8 units)."""
        room = _build_custom(spec)
        self.s8[(sx, sy)] = _screen_from(room)
        if name is not None:
            self._room_areas(sx, sy, room, name, music, dark)
        return room

    def _room_areas(self, sx, sy, room: dict, name, music, dark) -> None:
        q = room.get("layout", {}).get("used_quadrants") or [0, 1, 2, 3]
        # unused quadrants: erase (empty tiles, walls) so nothing stray is drawn or reachable
        scr = self.s8[(sx, sy)]
        for i in range(4):
            if i not in q:
                ys, xs = slice((i // 2) * 32, (i // 2) * 32 + 32), slice((i % 2) * 32, (i % 2) * 32 + 32)
                scr.bg[ys, xs] = 0
                scr.fg[ys, xs] = 0
                scr.types[ys, xs] = 0x01
        if dark is None:
            dark = bool(room.get("layout", {}).get("lights_out", False))
        qs = set(q)
        cols = sorted({i % 2 for i in qs})
        rows = sorted({i // 2 for i in qs})
        full = {r * 2 + c for r in rows for c in cols}
        ox, oy = sx * 512, sy * 512
        if full == qs:   # one rectangle
            self.area(px=(ox + cols[0] * 256, oy + rows[0] * 256, len(cols) * 256, len(rows) * 256),
                      name=name, music=music, dark=dark)
        else:
            for i in sorted(qs):
                self.area(px=(ox + (i % 2) * 256, oy + (i // 2) * 256, 256, 256), name=name, music=music, dark=dark)

    def blank8(self, sx: int, sy: int, tileset: str, bg: int = 0, type: int = 0x01) -> None:
        """Start a screen from nothing (every tile = bg word, type)."""
        self.s8[(sx, sy)] = Screen8(tileset, np.full((64, 64), bg, np.uint16), np.zeros((64, 64), np.uint16),
                                    np.full((64, 64), type, np.uint8))

    def _s8_at(self, X: int, Y: int) -> tuple[Screen8, int, int]:
        key = (X // 64, Y // 64)
        if key not in self.s8:
            raise MapError(f"écran {key} sans salle : appelez m.room() ou m.blank8() d'abord")
        return self.s8[key], X % 64, Y % 64

    def copy8(self, room: str | None, x: int, y: int, w: int, h: int, dx: int, dy: int,
              layers: tuple = ("bg", "fg", "types")) -> None:
        """Copy a tile8 rectangle (8x8 px units) from an original room (or from this map when
        room=None, x/y being map tile8 coordinates) to map tile8 coordinates (dx, dy).
        Use it to block a door with a piece of wall, remove an object by copying floor over it,
        or bring a piece of another room."""
        if room is None:
            srcs = {}
            for layer in layers:
                blk = np.zeros((h, w), np.uint16 if layer != "types" else np.uint8)
                for j in range(h):
                    for i in range(w):
                        s, lx, ly = self._s8_at(x + i, y + j)
                        blk[j, i] = getattr(s, layer)[ly, lx]
                srcs[layer] = blk
            tileset = None
        else:
            r = _load_room(room)
            if not _room_is_custom(room):
                self._test_only(f"copy8 depuis la salle d'origine {room}", w * h > 16 * 16)
            if x < 0 or y < 0 or x + w > 64 or y + h > 64:
                raise MapError(f"copy8 : ({x},{y}) {w}×{h} hors de la salle {room} (64×64)")
            srcs = {layer: getattr(r, layer)[y:y + h, x:x + w].copy() for layer in layers}
            tileset = r.tileset
        for j in range(h):
            for i in range(w):
                s, lx, ly = self._s8_at(dx + i, dy + j)
                if tileset and s.tileset != tileset:
                    self._warn(f"copy8 : jeu de tuiles {tileset} copié sur un écran en {s.tileset}")
                    tileset = None
                for layer in layers:
                    getattr(s, layer)[ly, lx] = srcs[layer][j, i]

    def fill8(self, x: int, y: int, w: int, h: int, bg: int | None = None, fg: int | None = None,
              type: int | None = None) -> None:
        """Fill a tile8 rectangle with a tilemap word (bg / fg) and/or a behaviour type."""
        for j in range(h):
            for i in range(w):
                s, lx, ly = self._s8_at(x + i, y + j)
                if bg is not None:
                    s.bg[ly, lx] = bg
                if fg is not None:
                    s.fg[ly, lx] = fg
                if type is not None:
                    s.types[ly, lx] = type

    def _door_rect(self, sx, sy, door: dict) -> tuple:
        """(warp rect px, spawn px, facing) for a room door {dir, x, y} of screen (sx, sy)."""
        scr = self.s8[(sx, sy)]
        t = scr.types
        import validate as V
        def walk(x, y):
            return 0 <= x < 64 and 0 <= y < 64 and V.kind(int(t[y, x])) not in V.BLOCKING

        def through(x, y):  # doorway cells (0x80-0xAF) are walked through indoors
            return walk(x, y) or (0 <= x < 64 and 0 <= y < 64 and 0x80 <= int(t[y, x]) <= 0xAF)
        d, x, y = door["dir"], door["x"], door["y"]
        ox, oy = sx * 512, sy * 512
        if d in ("down", "up"):
            step = -1 if d == "down" else 1
            r = y
            for _ in range(12):
                if all(walk(c, r) for c in range(x + 1, x + 3)):
                    break
                r += step
            # from 8 px inside the room to the far end of the doorway, so the hero's feet
            # centre (feet top + 8) is always inside while he walks through the door
            out = r
            while 0 <= out - step < 64 and all(through(c, out - step) for c in range(x + 1, x + 3)):
                out -= step
            if d == "up":
                rect = (ox + x * 8, oy + out * 8, 32, (r + 2 - out) * 8)
            else:
                rect = (ox + x * 8, oy + r * 8 - 8, 32, (out + 1 - r + 1) * 8)
            sp_y = r * 8 - 24 if d == "down" else r * 8 + 8   # arrival just outside the warp
            return rect, (ox + x * 8 + 8, oy + sp_y), ("up" if d == "down" else "down")
        step = -1 if d == "right" else 1
        c = x
        for _ in range(12):
            if all(walk(c, rr) for rr in range(y + 1, y + 3)):
                break
            c += step
        out = c
        while 0 <= out - step < 64 and all(through(out - step, rr) for rr in range(y + 1, y + 3)):
            out -= step
        if d == "left":
            rect = (ox + out * 8, oy + y * 8, (c + 2 - out) * 8, 32)
        else:
            rect = (ox + c * 8 - 8, oy + y * 8, (out + 1 - c + 1) * 8, 32)
        sp_x = c * 8 - 24 if d == "right" else c * 8 + 8   # arrival just outside the warp
        return rect, (ox + sp_x, oy + y * 8 + 8), ("left" if d == "right" else "right")

    def warp_room_door(self, door: dict, to: str, spawn: str, screen: tuple = (0, 0), style: str = "door") -> dict:
        """Warp on the last walkable row in front of a room door (door = an item of
        room["doors"], tile8 units)."""
        rect, _, _ = self._door_rect(*screen, door)
        wd = self.warp(*rect, to, spawn, style)
        wd["dir"] = door["dir"]  # the hero walks towards the wall the door is in
        return wd

    def spawn_room_door(self, name: str, door: dict, screen: tuple = (0, 0)) -> None:
        """Arrival point just inside a room door, facing into the room."""
        _, (x, y), facing = self._door_rect(*screen, door)
        self.spawn(name, x, y, facing)

    def room_doors(self, room: str) -> list[dict]:
        """Doors listed by INTERIORS for a room (dir, x, y in tile8 units, kind)."""
        return _room_json(room).get("doors", [])

    # ================================================================ entities
    def _pos(self, x, y, cell):
        if cell is not None:
            unit = 16 if self.kind == "overworld" else 8
            return cell[0] * unit, cell[1] * unit
        if x is None or y is None:
            raise MapError("position manquante : x=, y= (pixels) ou cell=(cx, cy)")
        return int(x), int(y)

    def entity(self, type: str, id: str, x: int | None = None, y: int | None = None, *,
               cell: tuple | None = None, **fields) -> dict:
        """Any entity of CONTRACT §4. Position = top-left of its 16x16 footprint, in pixels
        (or cell=(cx, cy) in map16 cells for overworld, tile8 for interiors)."""
        if type not in ENTITY_TYPES:
            raise MapError(f"type d'entité inconnu {type!r} ({', '.join(ENTITY_TYPES)})")
        px, py = self._pos(x, y, cell)
        cond = fields.pop("cond", None)
        e = {"type": type, "id": id, "x": px, "y": py}
        if cond:
            e["if"] = cond
        e.update({k: v for k, v in fields.items() if v is not None})
        self.entities.append(e)
        return e

    def npc(self, id, x=None, y=None, *, cell=None, sprite, facing="down", dialogue=None, script=None,
            wander=0, name="", cond=None):
        return self.entity("npc", id, x, y, cell=cell, sprite=sprite, facing=facing, dialogue=dialogue,
                           script=script, wander=wander, name=name or None, cond=cond)

    def enemy(self, id, x=None, y=None, *, cell=None, kind, facing="down", respawn=True, cond=None):
        return self.entity("enemy", id, x, y, cell=cell, kind=kind, facing=facing, respawn=respawn, cond=cond)

    def chest(self, id, x=None, y=None, *, cell=None, item, amount=1, big=False, flag=None, locked=None,
              spawn_on_clear=None, cond=None):
        """locked: big key required (CORE default: = big in a dungeon); spawn_on_clear: appears when
        the zone's enemies are all defeated."""
        return self.entity("chest", id, x, y, cell=cell, item=item, amount=amount, big=big, flag=flag,
                           locked=locked, spawn_on_clear=spawn_on_clear, cond=cond)

    def torch(self, id, x=None, y=None, *, cell=None, group=None, flag=None, script=None, lit=None,
              sprite=None, cond=None):
        """Torch (CONTRACT §4): lighting every torch of `group` sets `flag` / runs `script`.
        sprite="" = drawn by the tiles (no sprite)."""
        return self.entity("torch", id, x, y, cell=cell, group=group, flag=flag, script=script, lit=lit,
                           sprite=sprite, cond=cond)

    def switch(self, id, x=None, y=None, *, cell=None, script=None, flag=None, kind=None, sprite=None, cond=None):
        """Switch: kind "floor" | "crystal"; `script` or `flag`."""
        return self.entity("switch", id, x, y, cell=cell, script=script, flag=flag, kind=kind, sprite=sprite, cond=cond)

    def block(self, id, x=None, y=None, *, cell=None, pushable=None, dir=None, sprite=None, cond=None):
        return self.entity("block", id, x, y, cell=cell, pushable=pushable, dir=dir, sprite=sprite, cond=cond)

    def crystal(self, id, x=None, y=None, *, cell=None, group=None, sprite=None, cond=None):
        return self.entity("crystal", id, x, y, cell=cell, group=group, sprite=sprite, cond=cond)

    def peg(self, id, x=None, y=None, *, cell=None, group=None, color=None, sprite=None, cond=None):
        """Coloured peg: color "blue" (raised by default) / "orange"."""
        return self.entity("peg", id, x, y, cell=cell, group=group, color=color, sprite=sprite, cond=cond)

    def sign(self, id, cx: int, cy: int, dialogue: str, place_tile: bool = True, cond=None):
        """A readable sign at cell (cx, cy) (overworld: also paints the sign tile)."""
        if place_tile and self.kind == "overworld":
            self.tile(cx, cy, "sign")
        return self.entity("sign", id, cell=(cx, cy), dialogue=dialogue, cond=cond)

    def pickup(self, id, x=None, y=None, *, cell=None, item, amount=1, cond=None):
        return self.entity("pickup", id, x, y, cell=cell, item=item, amount=amount, cond=cond)

    def trigger(self, id, x, y, w, h, script, once=True, on="enter", cond=None):
        return self.entity("trigger", id, x, y, w=w, h=h, script=script, once=once, on=on, cond=cond)

    # ================================================================ links
    def spawn(self, name: str, x: int, y: int, facing: str = "down") -> None:
        """Arrival point (pixels, top-left of Link's 16x16 footprint)."""
        if facing not in DIRS:
            raise MapError(f"spawn {name}: direction {facing!r} invalide ({', '.join(DIRS)})")
        if name in self.spawns:
            raise MapError(f"spawn {name!r} défini deux fois")
        self.spawns[name] = [int(x), int(y), facing]

    def spawn_cell(self, name: str, cx: int, cy: int, facing: str = "down") -> None:
        unit = 16 if self.kind == "overworld" else 8
        self.spawn(name, cx * unit, cy * unit, facing)

    def warp(self, x: int, y: int, w: int, h: int, to: str, spawn: str, style: str = "door") -> dict:
        """Link touching this pixel rectangle goes to map `to`, spawn `spawn`."""
        if style not in WARP_STYLES:
            raise MapError(f"warp : style {style!r} invalide ({', '.join(WARP_STYLES)})")
        wd = {"rect": [int(x), int(y), int(w), int(h)], "to": to, "spawn": spawn, "style": style}
        self.warps.append(wd)
        return wd

    def warp_door(self, placed: Placed, to: str, spawn: str, style: str = "door") -> dict:
        """Warp for the door of a placed house / cave stamp. CORE triggers a warp when the
        centre of the hero's feet (x+8, y+8) enters the rectangle, so the rectangle is put on
        the last walkable row of the threshold: the door cell if it is walkable, else the
        top 8 px of the cell below it."""
        import validate as V
        cx, cy = placed.door
        dw = placed.door_w
        tid = int(self.ids[cy, cx])
        words = D.map16()["defs"][tid]
        walk = all(V.kind(D.tile8_type(w)) not in V.BLOCKING for w in words[2:])
        # 16 px deep: the hero stops right at the blocking threshold, his feet centre must
        # still be inside (reported by LEVEL-CH2).
        # The hero's feet centre is 8 px below his feet top: blocked door cell -> he stops with
        # his feet top on the row below, feet centre at (cy+1)*16+8; walkable door cell -> he
        # can reach feet centre cy*16+8. 16 px tall so that point is well inside.
        if walk:
            wd = self.warp(cx * 16, cy * 16 + 4, 16 * dw, 16, to, spawn, style)
        else:
            wd = self.warp(cx * 16, cy * 16 + 16, 16 * dw, 16, to, spawn, style)
        wd["dir"] = "up"  # house doors face south: the hero walks up into them
        return wd

    def warp_edge(self, side: str, to: str, spawn: str, start: int = 0, length: int | None = None) -> dict:
        """Warp along a map border ('up', 'down', 'left', 'right'); start/length in pixels."""
        Wp, Hp = self.sw * 512, self.sh * 512
        if side in ("up", "down"):
            length = length or Wp - start
            # 16 px: the feet centre never goes closer than 8 px to the map border
            y = 0 if side == "up" else Hp - 16
            wd = self.warp(start, y, length, 16, to, spawn, "edge")
        else:
            length = length or Hp - start
            x = 0 if side == "left" else Wp - 16
            wd = self.warp(x, start, 16, length, to, spawn, "edge")
        wd["dir"] = side
        return wd

    def patch(self, cond: str, cells: list[dict]) -> dict:
        """Conditional tile layer (CONTRACT §3 "patches"): cells shown while `cond` holds.
        map16 cells: {"x", "y", "id"} ; tile8 cells: {"x", "y", "bg", "fg", "type"} (pixels)."""
        p = {"if": cond, "cells": [dict(c) for c in cells]}
        if not hasattr(self, "patches"):
            self.patches = []
        self.patches.append(p)
        return p

    # ================================================================ compile
    def compile(self) -> tuple[dict, dict]:
        """-> (compiled map dict (CONTRACT §3), composite atlases {name: {id: atlas}})"""
        import compiler
        compiled, composites = compiler.compile_map(self)
        if getattr(self, "patches", None):
            compiled.setdefault("patches", []).extend(self.patches)
        if getattr(self, "foliage", None):
            compiled["foliage"] = self.foliage
        return compiled, composites


def _fix_deep(v: np.ndarray) -> np.ndarray:
    """The original deep water has no inner corner: remove deep corners until every cell
    has 0, 1, 2 adjacent or 4 deep corners (no 3-corner nor diagonal cell)."""
    v = v.copy()
    for _ in range(200):
        a, b, c, d = v[:-1, :-1], v[:-1, 1:], v[1:, :-1], v[1:, 1:]
        n = a.astype(int) + b + c + d
        bad = (n == 3) | ((n == 2) & ((a & d) | (b & c)))
        if not bad.any():
            break
        vp = np.pad(v, 1)
        deg = vp[:-2, 1:-1].astype(int) + vp[2:, 1:-1] + vp[1:-1, :-2] + vp[1:-1, 2:]
        for cy, cx in zip(*np.nonzero(bad)):
            corners = [(cy, cx), (cy, cx + 1), (cy + 1, cx), (cy + 1, cx + 1)]
            on = [p for p in corners if v[p]]
            if len(on) in (3, 2) and v[cy, cx] + v[cy, cx + 1] + v[cy + 1, cx] + v[cy + 1, cx + 1] == len(on):
                p = min(on, key=lambda p: deg[p])
                v[p] = False
    return v


NOT_FOLIAGE = {"stump", "trunk_log", "log", "hollow_log", "trunk_v", "trunk_h"}

_TERRAIN_IDS = set(T.PATH.values()) | set(T.SHORE.values()) | set(T.DEEP.values())
_RESOLVABLE = _TERRAIN_IDS | set(T.TALL.values()) | {0x37D, 0x34}
FOREST_CYCLE = T.FOREST_CYCLE


# ------------------------------------------------------------------ rooms (INTERIORS)

_room_cache: dict[str, dict] = {}


def _room_json(room: str) -> dict:
    if room in _room_cache:
        return _room_cache[room]
    p = D.ASSETS / "underworld" / "custom" / f"{room}.json"
    if not p.exists():
        p = D.ASSETS / "underworld" / "rooms" / f"{room}.json"
    if not p.exists():
        stub = D.MAPS_OUT / "stub_rooms" / f"{room}.json"
        if stub.exists():
            p = stub
        else:
            raise MapError(f"salle {room!r} introuvable ({p}) : l'étape INTERIORS l'a-t-elle produite ?")
    d = json.load(open(p))
    _room_cache[room] = d
    return d


def _room_is_custom(room: str) -> bool:
    return (D.ASSETS / "underworld" / "custom" / f"{room}.json").exists()


def _build_custom(spec: dict) -> dict:
    key = json.dumps(spec, sort_keys=True)
    if key in _room_cache:
        return _room_cache[key]
    sys.path.insert(0, str(D.ROOT / "tools" / "roomgen"))
    try:
        import roomgen
    except ImportError as e:
        raise MapError(f"room_custom : tools/roomgen indisponible ({e})")
    room = roomgen.build_room(spec)
    _room_cache[key] = room
    return room


def _screen_from(d: dict) -> Screen8:
    return Screen8(d["tileset"], np.array(d["bg"], np.uint16).reshape(64, 64),
                   np.array(d["fg"], np.uint16).reshape(64, 64), np.array(d["types"], np.uint8).reshape(64, 64))


def _load_room(room: str) -> Screen8:
    d = _room_json(room)
    try:
        return Screen8(d["tileset"], np.array(d["bg"], np.uint16).reshape(64, 64),
                       np.array(d["fg"], np.uint16).reshape(64, 64),
                       np.array(d["types"], np.uint8).reshape(64, 64))
    except KeyError as e:
        raise MapError(f"salle {room}: champ {e} absent (attendu : tileset, bg, fg, types)")


class W:
    """World-cell tile references: W.lw(x, y) -> ('lw', x, y) usable wherever a tile is expected."""
    @staticmethod
    def lw(x, y):
        return ("lw", x, y)

    @staticmethod
    def dw(x, y):
        return ("dw", x, y)
