"""Map locks: the overworld layout of each map as compiled with the reference ROM (JP 1.0).

A few compiler choices compare tile pixels (forest corners, composite atlases), and other
versions of the game have other colours (the European ones are brighter) or retouched blocks:
compiled on their own they would differ by a few cells. So a build made with the reference
ROM writes, per map, the result of those choices -- map16 ids (reference numbering, see
tools/rom_extract/versions) and atlas names, our own layout, no graphics -- to
content/maps/_lock/<id>.json, and a build made with another version reuses it while the
sources have not changed since (same hash).
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCK_DIR = ROOT / "content" / "maps" / "_lock"
MAPGEN = Path(__file__).resolve().parent


def source_hash(source: Path) -> str:
    """Hash of the map source and of the map tools (a change in either can move tiles)."""
    h = hashlib.sha1()
    for p in [Path(source)] + sorted(MAPGEN.glob("*.py")):
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def is_reference() -> bool:
    import rom
    return rom.profile().identity


def save(mid: str, source: Path, compiled: dict, composites: dict) -> None:
    screens = [{k: s[k] for k in ("atlas", "base_atlas", "tiles")} if s and s.get("format") == "map16" else None
               for s in compiled["screens"]]
    data = {"hash": source_hash(source), "screens": screens,
            "composites": {n: {"base": c["base"], "mapping": {str(i): a for i, a in sorted(c["mapping"].items())}}
                           for n, c in sorted(composites.items())}}
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, separators=(",", ":")) + "\n"
    p = LOCK_DIR / f"{mid}.json"
    if not p.exists() or p.read_text() != text:
        p.write_text(text)


def apply(mid: str, source: Path, compiled: dict, composites: dict) -> dict:
    """Replace the layout of a map compiled with another version by its lock (when the lock
    matches the sources). Returns the composites to write."""
    p = LOCK_DIR / f"{mid}.json"
    if not p.exists():
        return composites
    lock = json.loads(p.read_text())
    if lock["hash"] != source_hash(source) or len(lock["screens"]) != len(compiled["screens"]):
        return composites
    for s, ls in zip(compiled["screens"], lock["screens"]):
        if s and ls and s.get("format") == "map16":
            s.update(ls)
    return {n: {"base": c["base"], "mapping": {int(i): a for i, a in c["mapping"].items()}}
            for n, c in lock["composites"].items()}


def stale() -> list[str]:
    """Maps whose lock is missing or older than their sources (the web build refuses them)."""
    import build
    out = []
    for mid, src in build.sources(None).items():
        p = LOCK_DIR / f"{mid}.json"
        if not p.exists() or json.loads(p.read_text())["hash"] != source_hash(src):
            out.append(mid)
    return out
