"""Bakes the behaviour type of every 8x8 cell into compiled map16 screens ("types": 4096),
so the game no longer needs the original map16 -> tile -> type tables at runtime
(step "désenrobage", docs/ROADMAP.md). Slopes keep the original rule: horizontal flip of
the tile sets bit 0 of the type.
"""
import json
from functools import lru_cache
from pathlib import Path



@lru_cache(maxsize=4)
def _tables_of(assets: Path):
    m = json.load(open(assets / "overworld" / "map16.json"))
    return m["defs"], m["tile8_types"]


def _tables():
    import data as D
    return _tables_of(D.ASSETS)


def cell_type(map16_id: int, quadrant: int) -> int:
    defs, t8 = _tables()
    word = defs[map16_id][quadrant]
    t = t8[word & 0x1FF]
    if 0x10 <= t < 0x1C:
        t |= (word >> 14) & 1
    return t


def bake_screen(s: dict) -> None:
    if not s or s.get("format") != "map16":
        return
    types = [0] * 4096
    tiles = s["tiles"]
    for cy in range(64):
        for cx in range(64):
            m = tiles[(cy >> 1) * 32 + (cx >> 1)]
            types[cy * 64 + cx] = cell_type(m, ((cy & 1) << 1) | (cx & 1))
    s["types"] = types


def bake(compiled: dict) -> dict:
    for s in compiled.get("screens", []):
        bake_screen(s)
    # tree canopies are walkable (the hero goes behind them; the engine draws them on top)
    sw = compiled.get("screens_w", 1)
    for f in compiled.get("foliage", []):
        for cx, cy in f.get("cells", []):
            s = compiled["screens"][(cy // 32) * sw + cx // 32]
            if not s or "types" not in s:
                continue
            lx, ly = (cx % 32) * 2, (cy % 32) * 2
            for q in range(4):
                s["types"][(ly + (q >> 1)) * 64 + lx + (q & 1)] = 0
    return compiled
