"""Visual seam check of overworld maps (QA-CH1): finds the places where two neighbouring
map16 do not join like anything in the original game — a stamp pasted with its own grass
on a path, a tree or a forest cut, a notch in a forest outline, a terrain edge that does not
match its neighbour.

For every 8-pixel boundary between two tile8 (inside and between map16):
  1. accepted if this pair of tile8 (words, flips) is adjacent somewhere in the original worlds;
  2. else accepted if the two pixel columns (rows) that touch are adjacent somewhere in the
     original worlds (same colours);
  3. else it is a seam when at least 3 of the 8 touching pixel pairs are two different
     *materials* (grass, dirt, water, canopy, tall grass: colours of the pure tiles of the
     atlas; outlines and object colours are neutral), or when both sides are canopy
     (two tree patterns that do not continue each other).

    python3 tools/mapgen/seams.py <map_id> [-o out.png]   # list + picture of the seams
"""
from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import data as D  # noqa: E402

GRASS, DIRT, WATER, CANOPY, TALL, PAVE = 1, 2, 3, 4, 5, 6
NAMES = {GRASS: "herbe", DIRT: "terre", WATER: "eau", CANOPY: "feuillage", TALL: "herbes hautes",
         PAVE: "pavés"}
POND = "ow_20_27_04_0"
KAK = "ow_20_23_08_0"


def _t8grid(ids: np.ndarray) -> np.ndarray:
    defs = np.array(D.map16()["defs"], np.int64)
    w = defs[ids]
    h, wd = ids.shape
    g = np.zeros((h * 2, wd * 2), np.int64)
    g[0::2, 0::2] = w[..., 0]
    g[0::2, 1::2] = w[..., 1]
    g[1::2, 0::2] = w[..., 2]
    g[1::2, 1::2] = w[..., 3]
    return g & ~0x2000  # priority bit does not change the look


def _pack(img: np.ndarray) -> np.ndarray:
    a = img.astype(np.uint32)
    return (a[..., 0] << 16) | (a[..., 1] << 8) | a[..., 2]


def _world_image(world: str) -> np.ndarray:
    g = D.world_grid(world)
    out = np.zeros((256 * 16, 256 * 16, 3), np.uint8)
    for sy in range(8):
        for sx in range(8):
            out[sy * 512:(sy + 1) * 512, sx * 512:(sx + 1) * 512] = D.render_cells(
                g[sy * 32:(sy + 1) * 32, sx * 32:(sx + 1) * 32], D.screen_atlas(world, sx, sy))
    return out


def _edge_keys(c: np.ndarray):
    """(horizontal, vertical) boundary keys (bytes) of a packed image, 8-px segments."""
    H, W = c.shape
    L = c[:, 7:W - 1:8]
    R = c[:, 8::8]
    nb = H // 8
    Lb = np.ascontiguousarray(L.reshape(nb, 8, -1).transpose(0, 2, 1)).reshape(-1, 8)
    Rb = np.ascontiguousarray(R.reshape(nb, 8, -1).transpose(0, 2, 1)).reshape(-1, 8)
    kh = np.concatenate([Lb, Rb], 1)
    T_ = c[7:H - 1:8, :]
    B_ = c[8::8, :]
    Tb = np.ascontiguousarray(T_).reshape(-1, 8)
    Bb = np.ascontiguousarray(B_).reshape(-1, 8)
    kv = np.concatenate([Tb, Bb], 1)
    return kh, kv


@lru_cache(None)
def learned():
    """Pairs seen in the original worlds: tile8 pairs (H, V) and pixel boundary keys (H, V)."""
    th, tv, ph, pv = set(), set(), set(), set()
    for world in ("lw", "dw"):
        g = _t8grid(D.world_grid(world))
        th |= set(zip(g[:, :-1].ravel().tolist(), g[:, 1:].ravel().tolist()))
        tv |= set(zip(g[:-1, :].ravel().tolist(), g[1:, :].ravel().tolist()))
        kh, kv = _edge_keys(_pack(_world_image(world)))
        ph |= {r.tobytes() for r in kh}
        pv |= {r.tobytes() for r in kv}
    return th, tv, ph, pv


@lru_cache(None)
def materials(atlas: str) -> dict:
    """packed colour -> material, from the pure tiles of the atlas."""
    t = D.atlas_px_cache(atlas)
    pond = D.atlas_px_cache(POND)

    def cols(tiles, *ids):
        s = set()
        for i in ids:
            s |= set(_pack(tiles[i]).ravel().tolist())
        return s
    g = cols(t, 0x34)
    d = cols(t, 0xC6)
    w = cols(t, 0x2C6, 0x2CC) | cols(pond, 0x2C6, 0x2CC)
    c = cols(t, 0x02, 0x16, 0x12)
    tl = cols(t, 0x37D) - g
    pv = cols(D.atlas_px_cache(KAK), 0x3C7) | cols(t, 0x3C7)
    out = {}
    groups = ((GRASS, g), (DIRT, d), (WATER, w), (CANOPY, c), (TALL, tl), (PAVE, pv))
    for mat, s in groups:
        others = set().union(*[x for _, x in groups if x is not s])
        for col in s - others:
            out[col] = mat
    return out


def map_image(compiled: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """(packed pixels, map16 ids, atlas name per cell) of a compiled overworld map."""
    sw, sh = compiled["screens_w"], compiled["screens_h"]
    img = np.zeros((sh * 512, sw * 512, 3), np.uint8)
    ids = np.full((sh * 32, sw * 32), 0x34, np.int64)
    atl = np.empty((sh * 32, sw * 32), object)
    for i, s in enumerate(compiled["screens"]):
        if not s or s.get("format") != "map16":
            continue
        sx, sy = i % sw, i // sw
        blk = np.array(s["tiles"]).reshape(32, 32)
        ids[sy * 32:(sy + 1) * 32, sx * 32:(sx + 1) * 32] = blk
        atl[sy * 32:(sy + 1) * 32, sx * 32:(sx + 1) * 32] = s["atlas"]
        img[sy * 512:(sy + 1) * 512, sx * 512:(sx + 1) * 512] = D.render_cells(blk, s["atlas"])
    return _pack(img), ids, atl


def find(compiled: dict) -> list[tuple]:
    """-> [(dir 'H'|'V', x, y, why)]: seam between cell (x, y) and its right ('H') or lower
    ('V') neighbour, at most one entry per cell pair."""
    if compiled.get("kind") != "overworld":
        return []
    th, tv, ph, pv = learned()
    c, ids, atl = map_image(compiled)
    g = _t8grid(ids)
    H8, W8 = g.shape
    found = {}
    base = [s.get("base_atlas", s.get("atlas")) if s else None for s in compiled["screens"]]
    sw = compiled["screens_w"]

    def mats(cx, cy):
        b = base[(cy // 32) * sw + cx // 32]
        return materials(b) if b else {}

    def judge(a, b, mat):
        ma = [mat.get(int(v)) for v in a]
        mb = [mat.get(int(v)) for v in b]
        seam = sum(1 for x, y in zip(ma, mb) if x and y and x != y and {x, y} != {GRASS, TALL})
        if seam >= 3:
            pairs = {(x, y) for x, y in zip(ma, mb) if x and y and x != y}
            x, y = sorted(pairs)[0]
            return f"{NAMES[x]} contre {NAMES[y]}"
        if sum(1 for x in ma if x == CANOPY) >= 5 and sum(1 for y in mb if y == CANOPY) >= 5:
            return "feuillages qui ne se prolongent pas (arbre coupé)"
        return None

    for y8 in range(H8):
        for x8 in range(1, W8):
            if (int(g[y8, x8 - 1]), int(g[y8, x8])) in th:
                continue
            a = c[y8 * 8:y8 * 8 + 8, x8 * 8 - 1]
            b = c[y8 * 8:y8 * 8 + 8, x8 * 8]
            if (a.tobytes() + b.tobytes()) in ph:
                continue
            cx, cy = (x8 * 8 - 1) // 16, y8 // 2
            why = judge(a, b, mats(cx, cy))
            if why:
                found.setdefault(("H", cx, cy), why)
    for y8 in range(1, H8):
        for x8 in range(W8):
            if (int(g[y8 - 1, x8]), int(g[y8, x8])) in tv:
                continue
            a = c[y8 * 8 - 1, x8 * 8:x8 * 8 + 8]
            b = c[y8 * 8, x8 * 8:x8 * 8 + 8]
            if (a.tobytes() + b.tobytes()) in pv:
                continue
            cx, cy = x8 // 2, (y8 * 8 - 1) // 16
            why = judge(a, b, mats(cx, cy))
            if why:
                found.setdefault(("V", cx, cy), why)
    return [(d, x, y, why) for (d, x, y), why in sorted(found.items(), key=lambda kv: (kv[0][2], kv[0][1]))]


def describe(seams: list[tuple], limit: int = 25) -> list[str]:
    out = []
    for d, x, y, why in seams[:limit]:
        other = (x + 1, y) if d == "H" else (x, y + 1)
        out.append(f"raccord incohérent entre les cellules ({x},{y}) et {other} : {why}")
    if len(seams) > limit:
        out.append(f"… et {len(seams) - limit} autres raccords incohérents (python3 tools/mapgen/seams.py <id>)")
    return out


def picture(compiled: dict, seams: list[tuple], out: str, scale: int = 2) -> None:
    from PIL import Image, ImageDraw
    c, _, _ = map_image(compiled)
    rgb = np.stack([(c >> 16) & 255, (c >> 8) & 255, c & 255], -1).astype(np.uint8)
    im = Image.fromarray(rgb).resize((rgb.shape[1] * scale, rgb.shape[0] * scale), Image.NEAREST)
    dr = ImageDraw.Draw(im)
    s = 16 * scale
    for d, x, y, _ in seams:
        if d == "H":
            dr.line([((x + 1) * s, y * s), ((x + 1) * s, (y + 1) * s - 1)], fill=(255, 0, 0), width=3)
        else:
            dr.line([(x * s, (y + 1) * s), ((x + 1) * s - 1, (y + 1) * s)], fill=(255, 0, 255), width=3)
    im.save(out)


if __name__ == "__main__":
    import argparse
    import json
    ap = argparse.ArgumentParser()
    ap.add_argument("map")
    ap.add_argument("-o", "--out", default=None)
    a = ap.parse_args()
    comp = json.load(open(D.MAPS_OUT / f"{a.map}.json"))
    ss = find(comp)
    for line in describe(ss, 10 ** 6):
        print(line)
    print(len(ss), "raccord(s) incohérent(s)")
    if a.out:
        picture(comp, ss, a.out)
        print(a.out)
