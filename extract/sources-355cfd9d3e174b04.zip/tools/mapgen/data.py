"""Shared data access for the map tools: extracted overworld data, atlases (generated on
demand), original worlds as big map16 grids, map16 rendering.

Everything here reads game/assets/rom/ (produced by tools/rom_extract/extract.py).
Atlases missing for a (main theme, aux theme, palette set, palette mode) combination are
rendered on the fly with the extractor's own modules (render.py / palettes.py).
"""
from __future__ import annotations

import json
import re
import sys
from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools" / "rom_extract"))

ASSETS = ROOT / "game" / "assets" / "rom"
OW = ASSETS / "overworld"
MAPS_OUT = ASSETS / "maps"
CONTENT = ROOT / "content" / "maps"

SCREEN_CELLS = 32          # map16 per screen side
SCREEN_PX = 512
ATLAS_RE = re.compile(r"^ow_([0-9a-f]{2})_([0-9a-f]{2})_([0-9a-f]{2})_([0-3])$")

_ASSETS_OVERRIDE: list[Path] = []


class MapError(Exception):
    """User-facing error (bad map source, missing asset...)."""


def set_assets(path: Path) -> None:
    """Point the tools at another extraction folder (used by the zz_maps extraction step)."""
    global ASSETS, OW, MAPS_OUT
    ASSETS = Path(path)
    OW = ASSETS / "overworld"
    MAPS_OUT = ASSETS / "maps"
    for f in (map16, screens, world_grid, world_atlas_grid, atlas_rgba, atlas_px_cache):
        f.cache_clear()


def _need(path: Path) -> Path:
    if not path.exists():
        raise MapError(f"{path} introuvable : lancez d'abord python3 tools/rom_extract/extract.py")
    return path


@lru_cache(None)
def map16() -> dict:
    return json.load(open(_need(OW / "map16.json")))


def map16_count() -> int:
    return map16()["count"]


@lru_cache(None)
def screens() -> list[dict]:
    return json.load(open(_need(OW / "screens.json")))["screens"]


# ------------------------------------------------------------------ worlds

WORLDS = {"lw": 0x00, "light": 0x00, "dw": 0x40, "dark": 0x40}


def world_base(world: str) -> int:
    try:
        return WORLDS[world]
    except KeyError:
        raise MapError(f"monde inconnu {world!r} (attendu : 'lw' ou 'dw')")


@lru_cache(None)
def world_grid(world: str) -> np.ndarray:
    """(256, 256) map16 ids of a whole original world (8x8 screens), [y, x]."""
    base = world_base(world)
    g = np.zeros((256, 256), np.int32)
    sc = screens()
    for s in range(64):
        x, y = (s & 7) * 32, (s >> 3) * 32
        g[y:y + 32, x:x + 32] = np.array(sc[base + s]["map16"]).reshape(32, 32)
    return g


@lru_cache(None)
def world_atlas_grid(world: str) -> tuple:
    """8x8 atlas names of the screens of a world, [sy][sx]."""
    base = world_base(world)
    sc = screens()
    return tuple(tuple(sc[base + sy * 8 + sx]["atlas"] for sx in range(8)) for sy in range(8))


def screen_atlas(world: str, sx: int, sy: int) -> str:
    return world_atlas_grid(world)[sy][sx]


def screen_id(world: str, sx: int, sy: int) -> int:
    return world_base(world) + sy * 8 + sx


# ------------------------------------------------------------------ atlases

def atlas_name(main: int, aux: int, palette_set: int, mode: int = 0) -> str:
    return "ow_%02x_%02x_%02x_%d" % (main, aux, palette_set, mode)


def parse_atlas(name: str) -> tuple[int, int, int, int]:
    m = ATLAS_RE.match(name)
    if not m:
        raise MapError(f"nom d'atlas invalide {name!r} (attendu ow_<main>_<aux>_<palette>_<mode>, hexadécimal)")
    return tuple(int(g, 16) for g in m.groups())


def existing_atlases() -> list[str]:
    return sorted(p.stem for p in (OW / "atlases").glob("ow_*.png"))


_rom = None


def get_rom():
    global _rom
    if _rom is None:
        from rom import Rom, find_rom
        import rom as _r
        _rom = _r.current() or Rom(find_rom(ROOT))
    return _rom


def set_rom(rom) -> None:
    global _rom
    _rom = rom


# palette modes: 0 light world, 1 dark world, 2 light Death Mountain, 3 dark Death Mountain
_MODE_SCREEN = {0: 0x00, 1: 0x40, 2: 0x03, 3: 0x43}


def ensure_atlas(name: str) -> str:
    """Make sure overworld/atlases/<name>.png/.json exist; render them if not."""
    if (OW / "atlases" / f"{name}.png").exists():
        return name
    main, aux, palset, mode = parse_atlas(name)
    if palset > 30:
        raise MapError(f"atlas {name}: jeu de palettes {palset:#x} hors limites (0-0x1e)")
    import gfx
    import palettes as pal
    import render as R
    rom = get_rom()
    defs = map16()["defs"]
    bank = R.bg_tile_bank(rom, main, aux)
    cg = pal.overworld_bg_cgram(rom, _MODE_SCREEN[mode], palset)
    px = R.map16_pixels(defs, bank)
    rgb = R.cgram_rgb(cg)
    d = OW / "atlases"
    d.mkdir(parents=True, exist_ok=True)
    R.colorize(R.atlas(px, 64), rgb).save(d / f"{name}.png")
    with open(d / f"{name}.json", "w") as f:
        json.dump({
            "main_theme": main, "aux_theme": aux, "palette_set": palset, "palette_mode": mode,
            "sheets": gfx.bg_vram_sheets(rom, main, aux),
            "cgram": [gfx.hex_color(c) for c in cg],
            "backdrop": gfx.hex_color(cg[0]),
            "columns": 64, "tile_size": 16, "count": len(defs),
            "generated_by": "tools/mapgen",
        }, f, indent=1)
    atlas_rgba.cache_clear()
    atlas_px_cache.cache_clear()
    return name


def atlas_info(name: str) -> dict:
    ensure_atlas(name)
    return json.load(open(OW / "atlases" / f"{name}.json"))


@lru_cache(None)
def atlas_rgba(name: str) -> np.ndarray:
    """(H, W, 4) uint8 atlas image, backdrop composited under transparent pixels."""
    ensure_atlas(name)
    im = np.array(Image.open(OW / "atlases" / f"{name}.png").convert("RGBA"))
    bd = atlas_info(name)["backdrop"]
    rgb = np.array([int(bd[i:i + 2], 16) for i in (1, 3, 5)], np.uint8)
    a = im[..., 3:4] > 0
    out = np.where(a, im[..., :3], rgb).astype(np.uint8)
    return out


@lru_cache(None)
def atlas_px_cache(name: str) -> np.ndarray:
    """(count, 16, 16, 3) rendered map16 tiles of an atlas."""
    a = atlas_rgba(name)
    n = map16_count()
    rows = a.shape[0] // 16
    t = a.reshape(rows, 16, 64, 16, 3).transpose(0, 2, 1, 3, 4).reshape(rows * 64, 16, 16, 3)
    return t[:n]


def render_cells(ids: np.ndarray, atlas: str) -> np.ndarray:
    """(h, w) map16 ids -> (h*16, w*16, 3) RGB with one atlas. Negative ids = magenta checker."""
    tiles = atlas_px_cache(atlas)
    h, w = ids.shape
    safe = np.clip(ids, 0, len(tiles) - 1)
    img = tiles[safe]  # h, w, 16, 16, 3
    img = img.transpose(0, 2, 1, 3, 4).reshape(h * 16, w * 16, 3).copy()
    if (ids < 0).any():
        yy, xx = np.nonzero(ids < 0)
        chk = np.zeros((16, 16, 3), np.uint8)
        chk[:] = (255, 0, 255)
        chk[(np.arange(16)[:, None] // 4 + np.arange(16)[None, :] // 4) % 2 == 0] = (60, 0, 60)
        for y, x in zip(yy, xx):
            img[y * 16:(y + 1) * 16, x * 16:(x + 1) * 16] = chk
    return img


def tile_diff(ids, atlas_a: str, atlas_b: str) -> float:
    """Fraction of differing pixels when rendering the same map16 ids with two atlases."""
    ids = np.asarray(ids)
    ids = ids[ids >= 0]
    if atlas_a == atlas_b or ids.size == 0:
        return 0.0
    u = np.unique(ids)
    a = atlas_px_cache(atlas_a)[u].astype(np.int16)
    b = atlas_px_cache(atlas_b)[u].astype(np.int16)
    d = (np.abs(a - b).sum(-1) > 24)
    # weight by use count
    counts = np.array([(ids == i).sum() for i in u], np.float64)
    per = d.reshape(len(u), -1).mean(1)
    return float((per * counts).sum() / counts.sum())


# ------------------------------------------------------------------ collision summary

def map16_types(i: int) -> list[int]:
    return map16()["types"][i]


def tile8_type(word: int) -> int:
    t = map16()["tile8_types"][word & 0x1FF]
    if 0x10 <= t < 0x1C:
        t |= (word >> 14) & 1
    return t
