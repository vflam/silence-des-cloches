"""Forest regions made of whole trees (QA-CH1).

The original forest canopy is a staggered lattice of identical big trees (canopy 3 cells high,
trunk 2 cells, 3 cells apart horizontally, bands of trees every 3 rows, odd bands shifted by
1.5 cells). A forest is described as a *region* (union of rectangles, extended beyond the map
border on open sides); the trees kept are the lattice trees that fit ENTIRELY inside the
region, so a tree is never cut and every border closes on whole trees. The lattice is global
(same phase for the whole map) so neighbouring forest blocks merge seamlessly.

Each cell covered by trees gets the map16 whose look matches the set of trees around it:
the (cell phase, trees present around it) -> map16 table is learnt from the rectangular
forest tables of tiles.py (the original outlines). Configurations the tables never show
(inner corners of an L-shaped forest...) are drawn by pasting tree pictures in pixels and
picking the closest forest map16 (reported as approximations by `render`).
"""
from __future__ import annotations

from functools import lru_cache

import numpy as np

import data as D
import tiles as T

# Lattice in half cells. A trees: anchor (2 + 6i, 6 + 12j); B trees: (-1 + 6i, 12 + 12j).
# The anchor is the top-left of the 7x5 block the tables draw around one tree.
SPR_W, SPR_H = 7, 5


def _block(rows_cols):
    rows, cols = rows_cols
    ids = np.zeros((len(rows), len(cols)), np.int32)
    for j, r in enumerate(rows):
        left, fill, right = T.FOREST_ROWS[r]
        for i, c in enumerate(cols):
            ids[j, i] = {"L2": left[0], "L1": left[1], "R0": right[0], "R1": right[1]}.get(c) if isinstance(c, str) \
                else fill[c[1]]
    return ids


def table_block(w: int, h: int, edges: str) -> np.ndarray:
    """The rectangular forest of the original tables (old m.forest), used to learn the rules."""
    n, s, e, wst = ("n" in edges), ("s" in edges), ("e" in edges), ("w" in edges)
    side = (2 if wst else 0) + (2 if e else 0)
    nf = w - side
    if e and wst:
        nf = max(3, nf - nf % 3)
    nf = max(1, nf)
    c0 = (3 - nf % 3) % 3 if e else 0
    cols = (["L2", "L1"] if wst else []) + [("F", (c0 + i) % 3) for i in range(nf)] + (["R0", "R1"] if e else [])
    top = ["T", "r4f", "r5f"] if n else []
    nb = h - len(top) - (2 if s else 0)
    if s:
        if n:
            nb = max(0, nb - nb % 3)
            start = 0
        else:
            nb = max(1, nb)
            start = (6 - nb % 6) % 6 if nb % 3 == 0 else (3 - nb % 3) % 3
        body = [T.FOREST_CYCLE[(start + i) % 6] for i in range(nb)]
        last = body[-1] if body else "r5f"
        bottom = ["BB1", "BB2"] if last == "r2" else ["BA1", "BA2"]
    else:
        body = [T.FOREST_CYCLE[i % 6] for i in range(max(0, nb))]
        bottom = []
    return _block((top + body + bottom, cols))


def lattice(W: int, H: int, margin: int = 8):
    """All lattice trees near a W x H cell map: (kind, hx, hy) in half cells (anchor)."""
    out = []
    for jy in range(-margin, (2 * H) // 12 + margin):
        for ix in range(-margin, (2 * W) // 6 + margin):
            out.append(("A", 2 + 6 * ix, 6 + 12 * jy))
            out.append(("B", -1 + 6 * ix, 12 + 12 * jy))
    return out


def footprint(t) -> tuple[int, int, int, int]:
    """Cells (x0, y0, x1, y1) (exclusive ends) touched by the tree's picture."""
    _, hx, hy = t
    # picture spans px [anchor + 24, anchor + 88) horizontally, 5 cells vertically
    px0 = hx * 8 + 24
    px1 = hx * 8 + 88
    return px0 // 16, hy // 2, (px1 + 15) // 16, hy // 2 + SPR_H


PAD = 12


def _padded(region: np.ndarray, opn: np.ndarray) -> np.ndarray:
    """Region extended by PAD cells beyond each border where the border cells are open."""
    H, W = region.shape
    P = PAD
    R = np.zeros((H + 2 * P, W + 2 * P), bool)
    R[P:P + H, P:P + W] = region
    n = region[0] & (opn[0] & 1 > 0)
    s = region[H - 1] & (opn[H - 1] & 2 > 0)
    w = region[:, 0] & (opn[:, 0] & 4 > 0)
    e = region[:, W - 1] & (opn[:, W - 1] & 8 > 0)
    R[:P, P:P + W] = n[None, :]
    R[P + H:, P:P + W] = s[None, :]
    R[P:P + H, :P] = w[:, None]
    R[P:P + H, P + W:] = e[:, None]
    R[:P, :P] = n[0] and w[0]
    R[:P, P + W:] = n[-1] and e[0]
    R[P + H:, :P] = s[0] and w[-1]
    R[P + H:, P + W:] = s[-1] and e[-1]
    return R


def trees_in(region: np.ndarray, open_sides: np.ndarray | None = None) -> list:
    """Trees of the forest filling `region` ((H, W) bool): lattice trees whose footprint lies
    entirely in the region, then pruned so the canopy keeps the original structure (a tree of
    an odd band B needs a tree of the band above it; a tree of band A needs both B trees that
    flank it in the band above or below). Parts outside the map are accepted where the border
    cells are open (open_sides = (H, W) uint8 bit flags: 1 north, 2 south, 4 west, 8 east)."""
    H, W = region.shape
    opn = open_sides if open_sides is not None else np.zeros((H, W), np.uint8)
    R = _padded(region, opn)
    P = PAD
    cand = set()
    for t in lattice(W + 2 * P, H + 2 * P, margin=P // 3 + 4):
        x0, y0, x1, y1 = footprint(t)
        if x0 < -P or y0 < -P or x1 > W + P or y1 > H + P:
            continue
        if R[y0 + P:y1 + P, x0 + P:x1 + P].all():
            cand.add(t)
    changed = True
    while changed:
        changed = False
        for t in list(cand):
            k, hx, hy = t
            if k == "B":
                ok = ("A", hx - 3, hy - 6) in cand or ("A", hx + 3, hy - 6) in cand
            else:
                fl = [("B", hx - 3, hy - 6) in cand, ("B", hx + 3, hy - 6) in cand,
                      ("B", hx - 3, hy + 6) in cand, ("B", hx + 3, hy + 6) in cand]
                ok = (fl[0] and fl[1]) or (fl[2] and fl[3]) or not any(fl)   # lone row of A trees
            if not ok:
                cand.discard(t)
                changed = True
    out = []
    for t in cand:
        x0, y0, x1, y1 = footprint(t)
        if x1 > 0 and y1 > 0 and x0 < W and y0 < H:
            out.append(t)
    return out


def _near_trees(cx, cy):
    """Lattice trees (relative to the cell's phase) whose footprint can contain the cell."""
    res = []
    for t in lattice(12, 12, margin=3):
        x0, y0, x1, y1 = footprint(t)
        if x0 <= cx < x1 and y0 <= cy < y1:
            res.append(t)
    return res


@lru_cache(None)
def _phase_trees(px: int, py: int) -> tuple:
    """For a cell of phase (px, py) (= x % 3, y % 6), offsets (kind, dhx, dhy) of the trees
    that may cover it, relative to the cell's own phase origin."""
    cx, cy = 6 + px, 12 + py
    base_x, base_y = cx - px, cy - py
    return tuple((k, hx - 2 * base_x, hy - 2 * base_y) for k, hx, hy in _near_trees(cx, cy))


def cell_key(cx: int, cy: int, present: set) -> tuple:
    px, py = cx % 3, cy % 6
    bx, by = cx - px, cy - py
    bits = tuple(int((k, dx + 2 * bx, dy + 2 * by) in present) for k, dx, dy in _phase_trees(px, py))
    return (px, py, bits)


def _training():
    """(layout list) rectangular table forests placed in phase with the global lattice on a
    64x64 test map: (x, y, w, h, edges, open sides)."""
    out = []
    for w in (7, 10, 13):
        for h in (5, 8, 11, 14):
            out.append((1 + 3 * 2, 3 + 6 * 2, w, h, "nsew"))
    for h in (6, 12):          # top border, open north
        for w in (7, 10):
            out.append((4, 0, w, h + 2, "sew"))
    for w in (5, 8, 11):       # left border, open west
        out.append((0, 15, w, 11, "nse"))
        out.append((0, 0, w, 14, "se"))
    return out


@lru_cache(None)
def rules() -> dict:
    """cell_key -> map16, learnt from the rectangular tables."""
    table: dict = {}
    conflicts = 0
    for (x, y, w, h, edges) in _training():
        blk = table_block(w, h, edges)
        H2, W2 = blk.shape
        Wm, Hm = 64, 64
        ids = np.full((Hm, Wm), 0x34, np.int32)
        ids[y:y + H2, x:x + W2] = blk
        region = np.zeros((Hm, Wm), bool)
        region[y:y + H2, x:x + W2] = True
        opn = np.zeros((Hm, Wm), np.uint8)
        if "n" not in edges and y == 0:
            opn[0, x:x + W2] |= 1
        if "w" not in edges and x == 0:
            opn[y:y + H2, 0] |= 4
        present = set(trees_in(region, opn))
        # cells out of the map on open sides count
        cov = coverage(present, Wm, Hm)
        for cy in range(Hm):
            for cx in range(Wm):
                if not cov[cy, cx]:
                    continue
                k = cell_key(cx, cy, present)
                v = int(ids[cy, cx])
                if k in table and table[k] != v:
                    conflicts += 1
                    continue
                table[k] = v
    rules.conflicts = conflicts
    return table


def coverage(present, W, H) -> np.ndarray:
    cov = np.zeros((H, W), bool)
    for t in present:
        x0, y0, x1, y1 = footprint(t)
        cov[max(0, y0):max(0, min(H, y1)), max(0, x0):max(0, min(W, x1))] = True
    return cov


# ------------------------------------------------------------------ pixel fallback

@lru_cache(None)
def _sprite(atlas: str):
    blk = table_block(7, 5, "nsew")
    img = D.render_cells(blk, atlas).astype(np.int32)
    grass = D.atlas_px_cache(atlas)[0x34].astype(np.int32)
    mask = np.abs(img - np.tile(grass, (SPR_H, SPR_W, 1))).sum(-1) > 0
    return img, mask


# other canopy tiles of the original light world forests (inner corners, overlaps), used by
# the pixel fallback only
EXTRA_CANOPY = {0x0D, 0x17, 0x44, 0x53, 0x5A, 0x77, 0x8B, 0xB1, 0xCB, 0xCD}


@lru_cache(None)
def _vocab(atlas: str):
    v = set()
    for r in T.FOREST_ROWS.values():
        v |= {r[0][0], r[0][1], *r[1], r[2][0], r[2][1]}
    v |= set(rules().values())
    v |= EXTRA_CANOPY
    v = sorted(v)
    tiles = D.atlas_px_cache(atlas).astype(np.int32)
    return v, tiles[v].reshape(len(v), -1)


def paint_cell(cx, cy, present, atlas) -> tuple[int, int]:
    """Closest forest map16 to the pixel picture of the trees over cell (cx, cy)."""
    img, mask = _sprite(atlas)
    canvas = D.atlas_px_cache(atlas)[0x34].astype(np.int32).copy()
    trees = [t for t in present if footprint(t)[0] <= cx < footprint(t)[2] and footprint(t)[1] <= cy < footprint(t)[3]]
    for t in sorted(trees, key=lambda t: (t[2], -t[1])):
        ox, oy = t[1] * 8 - cx * 16, t[2] * 8 - cy * 16      # sprite origin relative to cell
        for yy in range(16):
            sy = yy - oy
            if not 0 <= sy < SPR_H * 16:
                continue
            for xx in range(16):
                sx = xx - ox
                if 0 <= sx < SPR_W * 16 and mask[sy, sx]:
                    canvas[yy, xx] = img[sy, sx]
    v, V = _vocab(atlas)
    d = np.abs(V - canvas.reshape(-1)).sum(1)
    k = int(d.argmin())
    return v[k], int(d[k])


def render(region: np.ndarray, open_sides: np.ndarray, atlas: str = "ow_20_20_00_0"):
    """-> (ids (H, W) int32 with -1 where no tree, list of approximated cells [(x, y, dist)])."""
    H, W = region.shape
    present = set(trees_in(region, open_sides))
    cov = coverage(present, W, H)
    tab = rules()
    out = np.full((H, W), -1, np.int32)
    approx = []
    for cy, cx in zip(*np.nonzero(cov)):
        k = cell_key(int(cx), int(cy), present)
        if k in tab:
            out[cy, cx] = tab[k] if tab[k] != 0x34 else -1
        else:
            tid, dist = paint_cell(int(cx), int(cy), present, atlas)
            out[cy, cx] = tid
            approx.append((int(cx), int(cy), dist))
    return out, approx, present
