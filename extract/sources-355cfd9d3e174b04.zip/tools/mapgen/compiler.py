"""Map -> compiled JSON (CONTRACT §3) + composite atlases."""
from __future__ import annotations

import json

import numpy as np
from PIL import Image

import data as D
from data import MapError


def _differs(i: int, a: str, b: str) -> bool:
    if a == b:
        return False
    ta, tb = D.atlas_px_cache(a)[i].astype(np.int16), D.atlas_px_cache(b)[i].astype(np.int16)
    return bool((np.abs(ta - tb).sum(-1) > 24).mean() > 0.02)


def compile_map(m) -> tuple[dict, dict]:
    if m._default is not None:
        tid, a = m._resolve_tile(m._default)
        unset = m.ids < 0
        m.ids[unset] = tid
        m.src[unset] = a
    m._merge_grounds()
    screens = []
    composites: dict[str, dict] = {}
    groups: list[tuple[str, dict, str]] = []  # (base, mapping, name)
    for sy in range(m.sh):
        for sx in range(m.sw):
            if (sx, sy) in m.null_screens:
                screens.append(None)
                continue
            if m.kind != "overworld":
                s = m.s8.get((sx, sy))
                if s is None:
                    m._warn(f"écran ({sx},{sy}) sans salle : laissé vide (null)")
                    screens.append(None)
                    continue
                screens.append({"format": "tile8", "tileset": s.tileset,
                                "bg": s.bg.ravel().tolist(), "fg": s.fg.ravel().tolist(),
                                "types": s.types.ravel().tolist()})
                continue
            area = m.area_at_cell(sx * 32, sy * 32)
            if area is None:
                raise MapError(f"écran ({sx},{sy}) hors de toute zone : ajoutez m.area(...) ou m.empty_screen({sx}, {sy})")
            base = area.atlas
            blk = m.ids[sy * 32:(sy + 1) * 32, sx * 32:(sx + 1) * 32]
            src = m.src[sy * 32:(sy + 1) * 32, sx * 32:(sx + 1) * 32]
            if (blk < 0).any():
                raise MapError(f"écran ({sx},{sy}) : {int((blk < 0).sum())} cellules jamais peintes")
            mapping: dict[int, str] = {}
            for i, a_idx in zip(blk.ravel().tolist(), src.ravel().tolist()):
                a = m._atlases[a_idx] or base
                if a == base:
                    continue
                if not _differs(i, base, a):
                    continue
                if i in mapping and mapping[i] != a and _differs(i, mapping[i], a):
                    m._warn(f"écran ({sx},{sy}) : map16 {i:#x} utilisée avec deux atlas ({mapping[i]}, {a}) ; {mapping[i]} gardé")
                    continue
                mapping.setdefault(i, a)
            # base-atlas uses of an overridden id on the same screen
            used_base = {i for i, a_idx in zip(blk.ravel().tolist(), src.ravel().tolist())
                         if (m._atlases[a_idx] or base) == base}
            for i in list(mapping):
                if i in used_base:
                    m._warn(f"écran ({sx},{sy}) : map16 {i:#x} utilisée à la fois avec {base} et {mapping[i]}")
            if not mapping:
                name = base
            else:
                name = None
                for gbase, gmap, gname in groups:
                    if gbase != base:
                        continue
                    if all(gmap.get(i, a) == a or not _differs(i, gmap[i], a) for i, a in mapping.items()) and \
                            all(i not in used_base or not _differs(i, base, a) for i, a in gmap.items()):
                        gmap.update(mapping)
                        name = gname
                        break
                if name is None:
                    name = f"map_{m.id}_{len(groups)}"
                    groups.append((base, dict(mapping), name))
            screens.append({"format": "map16", "atlas": name, "base_atlas": base,
                            "tiles": blk.ravel().tolist()})
    for base, gmap, gname in groups:
        composites[gname] = {"base": base, "mapping": gmap}
    out = {
        "id": m.id,
        "name": m.name,
        "kind": m.kind,
        "dungeon": m.dungeon,
        "screens_w": m.sw,
        "screens_h": m.sh,
        "areas": [{**({"rect_px": list(a.px)} if a.px else {"rect": list(a.rect)}),
                   "name": a.name, "music": a.music, "dark": a.dark,
                   **({"atlas": a.atlas} if m.kind == "overworld" else {})} for a in m.areas],
        "screens": screens,
        "entities": m.entities,
        "warps": m.warps,
        "spawns": m.spawns,
    }
    if m.on_enter:
        out["on_enter"] = m.on_enter
    return out, composites


def write_composite(name: str, base: str, mapping: dict[int, str]) -> None:
    """Atlas where map16 i is drawn with mapping.get(i, base): keeps each stamp's original look."""
    d = D.OW / "atlases"
    base_img = np.array(Image.open(d / f"{base}.png").convert("RGBA"))
    imgs = {}
    for a in set(mapping.values()):
        D.ensure_atlas(a)
        imgs[a] = np.array(Image.open(d / f"{a}.png").convert("RGBA"))
    out = base_img.copy()
    for i, a in mapping.items():
        x, y = (i % 64) * 16, (i // 64) * 16
        out[y:y + 16, x:x + 16] = imgs[a][y:y + 16, x:x + 16]
    Image.fromarray(out).save(d / f"{name}.png")
    info = json.load(open(d / f"{base}.json"))
    by_atlas: dict[str, list[int]] = {}
    for i, a in sorted(mapping.items()):
        by_atlas.setdefault(a, []).append(i)
    info.update({"composite": True, "base": base, "overrides": by_atlas, "generated_by": "tools/mapgen"})
    with open(d / f"{name}.json", "w") as f:
        json.dump(info, f, indent=1)
    D.atlas_rgba.cache_clear()
    D.atlas_px_cache.cache_clear()
