#!/usr/bin/env python3
"""Look at the original worlds (or at a stamp / a map16 id) with a map16 coordinate grid,
to pick rectangles to copy or to define new stamps.

    python3 tools/mapgen/look.py world lw 0 96 64 64            # x y w h in world map16 cells
    python3 tools/mapgen/look.py world lw 0 96 64 64 --scale 2 -o /tmp/k.png
    python3 tools/mapgen/look.py screen 0x18                     # one original screen (32x32)
    python3 tools/mapgen/look.py stamp house_red_m               # one stamp, with its info
    python3 tools/mapgen/look.py tiles 0x34 0x2cc 0x36 --atlas ow_20_23_08_0
    python3 tools/mapgen/look.py ids lw 0 96 8 8                 # print the map16 ids of a rect

World map16 coordinates: 256x256 cells per world (8x8 screens of 32x32), (0,0) = top-left
of screen $00 (light) / $40 (dark). Screen $SS covers x = (SS & 7) * 32, y = (SS >> 3 & 7) * 32.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
import data as D  # noqa: E402


def world_image(world: str, x: int, y: int, w: int, h: int) -> np.ndarray:
    """RGB of a world rect (map16 cells), each screen with its own atlas."""
    g = D.world_grid(world)
    out = np.zeros((h * 16, w * 16, 3), np.uint8)
    for sy in range(y // 32, (y + h - 1) // 32 + 1):
        for sx in range(x // 32, (x + w - 1) // 32 + 1):
            x0, y0 = max(x, sx * 32), max(y, sy * 32)
            x1, y1 = min(x + w, sx * 32 + 32), min(y + h, sy * 32 + 32)
            atlas = D.screen_atlas(world, sx, sy)
            out[(y0 - y) * 16:(y1 - y) * 16, (x0 - x) * 16:(x1 - x) * 16] = D.render_cells(g[y0:y1, x0:x1], atlas)
    return out


def grid_overlay(img: np.ndarray, x0: int, y0: int, scale: int = 2, every: int = 4,
                 label_every: int = 4) -> Image.Image:
    """Scale up and draw a map16 grid with coordinates (x0, y0 = coords of the top-left cell)."""
    im = Image.fromarray(img).resize((img.shape[1] * scale, img.shape[0] * scale), Image.NEAREST)
    margin = 28
    canvas = Image.new("RGB", (im.width + margin, im.height + margin), (20, 20, 28))
    canvas.paste(im, (margin, margin))
    dr = ImageDraw.Draw(canvas, "RGBA")
    c = 16 * scale
    w, h = img.shape[1] // 16, img.shape[0] // 16
    for i in range(w + 1):
        X = margin + i * c
        strong = (x0 + i) % every == 0
        dr.line([(X, margin), (X, margin + h * c)], fill=(255, 255, 255, 110 if strong else 35))
        if (x0 + i) % label_every == 0 and i < w:
            dr.text((X + 1, 2), str(x0 + i), fill=(255, 255, 160))
    for j in range(h + 1):
        Y = margin + j * c
        strong = (y0 + j) % every == 0
        dr.line([(margin, Y), (margin + w * c, Y)], fill=(255, 255, 255, 110 if strong else 35))
        if (y0 + j) % label_every == 0 and j < h:
            dr.text((1, Y + 2), str(y0 + j), fill=(255, 255, 160))
    return canvas


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("what", choices=["world", "screen", "stamp", "tiles", "ids"])
    ap.add_argument("args", nargs="*")
    ap.add_argument("--scale", type=int, default=2)
    ap.add_argument("--atlas", default="ow_20_23_08_0")
    ap.add_argument("-o", "--out", default="/tmp/mapgen_look.png")
    a = ap.parse_args()
    if a.what in ("world", "ids"):
        world = a.args[0]
        x, y, w, h = (int(v, 0) for v in a.args[1:5])
        if a.what == "ids":
            g = D.world_grid(world)[y:y + h, x:x + w]
            for row in g:
                print(" ".join("%4x" % v for v in row))
            return 0
        img = world_image(world, x, y, w, h)
        grid_overlay(img, x, y, a.scale).save(a.out)
    elif a.what == "screen":
        s = int(a.args[0], 0)
        world = "dw" if s & 0x40 else "lw"
        sx, sy = (s & 7) * 32, ((s & 0x3F) >> 3) * 32
        grid_overlay(world_image(world, sx, sy, 32, 32), sx, sy, a.scale).save(a.out)
    elif a.what == "stamp":
        import stamps as S
        st = S.get(a.args[0])
        print(S.describe(st))
        img = D.render_cells(np.where(st.mask, st.ids, -1), st.atlas)
        grid_overlay(img, 0, 0, max(a.scale, 3), every=1, label_every=1).save(a.out)
    elif a.what == "tiles":
        ids = [int(v, 0) for v in a.args]
        arr = np.array(ids).reshape(1, -1)
        img = D.render_cells(arr, a.atlas)
        im = Image.fromarray(img).resize((img.shape[1] * 4, img.shape[0] * 4), Image.NEAREST)
        canvas = Image.new("RGB", (im.width, im.height + 14), (20, 20, 28))
        canvas.paste(im, (0, 14))
        dr = ImageDraw.Draw(canvas)
        for i, v in enumerate(ids):
            dr.text((i * 64 + 2, 1), hex(v), fill=(255, 255, 160))
        canvas.save(a.out)
    print(a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
