"""Named single map16 tiles and autotiled terrains.

Map16 ids are plain indices into the player's extracted overworld/map16.json (no graphics
here). Every named tile carries the atlas it is meant to be seen with (None = whatever atlas
the area uses: these tiles look the same in all light-world atlases).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Tile:
    id: int
    atlas: str | None = None   # source atlas (None = area atlas)
    desc: str = ""


LW = None                       # shared by all light-world atlases
POND = "ow_20_27_04_0"          # aux theme 0x27: grass <-> water shores (Hylia swamp)
KAK = "ow_20_23_08_0"           # Kakariko
DM = "ow_20_22_07_2"            # Death Mountain

TILES: dict[str, Tile] = {
    # grounds
    "grass": Tile(0x34, LW, "herbe"),
    "grass_tuft": Tile(0x35, LW, "herbe avec touffe"),
    "flowers": Tile(0xE2, LW, "fleurs blanches"),
    "flowers2": Tile(0xE1, LW, "fleurs blanches (variante)"),
    "tall_grass": Tile(0x37D, LW, "herbe haute (ralentit, se coupe)"),
    "dirt": Tile(0xC6, LW, "terre / chemin"),
    "paving": Tile(0x3C7, KAK, "pavés clairs (Cocorico)"),
    "stones": Tile(0x419, KAK, "dalles de pierre"),
    "mountain": Tile(0x2E5, DM, "sol de montagne"),
    "shallow": Tile(0x2C6, LW, "eau peu profonde (on y marche)"),
    "water": Tile(0x2CC, LW, "eau profonde (bloque)"),
    # objects on one cell (CORE handles lifting / cutting at runtime)
    "bush": Tile(0x36, LW, "buisson (se soulève / se coupe)"),
    "rock": Tile(0x20F, LW, "pierre claire (se soulève)"),
    "rock_heavy": Tile(0x239, LW, "pierre sombre (gants)"),
    "sign": Tile(0x101, LW, "panneau (bloque ; ajouter m.sign pour le texte)"),
    "peg": Tile(0x719, LW, "piquet (marteau)"),
    "warp_tile": Tile(0x212, LW, "dalle de téléportation"),
    "desert_bush": Tile(0x727, LW, "buisson sec"),
    "fence_post": Tile(0xF2, LW, "piquet de clôture"),
    "stake": Tile(0x21B, LW, "pieu de bois"),
    "grave_wall": Tile(0x372, "ow_20_29_01_0", "muret du cimetière"),
    "cobble": Tile(0x38F, "ow_20_29_01_0", "pavés sombres (cimetière)"),
    "water_stake": Tile(0x2F8, LW, "pieu dans l'eau profonde"),
    "sand": Tile(0x6E4, "ow_20_2b_09_0", "sable du désert"),
}


def tile(name: str) -> Tile:
    try:
        return TILES[name]
    except KeyError:
        import difflib
        close = difflib.get_close_matches(name, list(TILES), 5)
        from data import MapError
        raise MapError(f"tuile inconnue {name!r}" + (f" (vouliez-vous : {', '.join(close)} ?)" if close else ""))


# ------------------------------------------------------------------ autotile tables
# Marching squares on cell corners. Signature bits = (TL, TR, BL, BR), 1 = the terrain.
# Learnt from the original worlds with learn_terrain.py, checked by eye.

def _sig(tl, tr, bl, br):
    return tl << 3 | tr << 2 | bl << 1 | br


PATH = {  # dirt path on grass (all light-world atlases)
    _sig(0, 0, 0, 0): 0x34,
    _sig(0, 0, 0, 1): 0x9E, _sig(0, 0, 1, 0): 0x17C, _sig(0, 1, 0, 0): 0xAD, _sig(1, 0, 0, 0): 0xAC,
    _sig(0, 0, 1, 1): 0x9F, _sig(1, 1, 0, 0): 0xA5, _sig(0, 1, 0, 1): 0xA9, _sig(1, 0, 1, 0): 0x179,
    _sig(0, 1, 1, 1): 0xA3, _sig(1, 0, 1, 1): 0x1FF, _sig(1, 1, 0, 1): 0x1C4, _sig(1, 1, 1, 0): 0xA4,
    _sig(1, 1, 1, 1): 0xC6,
}

SHORE = {  # grass <-> shallow water (aux theme 0x27 only -> drawn with the POND atlas)
    _sig(0, 0, 0, 0): 0x34,
    _sig(0, 0, 0, 1): 0xAFD, _sig(0, 0, 1, 0): 0x2EA, _sig(0, 1, 0, 0): 0xB94, _sig(1, 0, 0, 0): 0x2C8,
    _sig(0, 0, 1, 1): 0x2E9, _sig(1, 1, 0, 0): 0x2DA, _sig(0, 1, 0, 1): 0xAFF, _sig(1, 0, 1, 0): 0x2D2,
    _sig(0, 1, 1, 1): 0xAFE, _sig(1, 0, 1, 1): 0x2E8, _sig(1, 1, 0, 1): 0xB01, _sig(1, 1, 1, 0): 0x2C7,
    _sig(1, 1, 1, 1): 0x2C6,
}

DEEP = {  # shallow <-> deep water (all atlases); 3-corner signatures fall back to deep
    _sig(0, 0, 0, 0): 0x2C6,
    _sig(0, 0, 0, 1): 0x2EE, _sig(0, 0, 1, 0): 0x2DE, _sig(0, 1, 0, 0): 0x2D6, _sig(1, 0, 0, 0): 0x2D1,
    _sig(0, 0, 1, 1): 0x2F5, _sig(1, 1, 0, 0): 0x2D8, _sig(0, 1, 0, 1): 0x69F, _sig(1, 0, 1, 0): 0x2C5,
    _sig(1, 1, 1, 1): 0x2CC,
}

TALL = {  # tall grass patch: only the four outer corners are rounded
    _sig(0, 0, 0, 1): 0x37C, _sig(0, 0, 1, 0): 0x382, _sig(0, 1, 0, 0): 0x383, _sig(1, 0, 0, 0): 0x381,
}

# ------------------------------------------------------------------ forest generator tables
# A forest block is built from the canopy pattern of the original forests: 3 columns x 6 rows,
# plus its left / right / top / bottom outlines (see stamps.py 'forest').
# Each row type: (left2, left1, (fill c0, c1, c2), right0, right1).  0x34 = transparent.
FOREST_ROWS = {
    "T":  ((0x34, 0xB5), (0xB6, 0x26, 0x78), (0x79, 0x34)),
    "r4f": ((0x34, 0xB9), (0x11, 0x12, 0x13), (0x7B, 0x34)),
    "r5f": ((0x34, 0xBE), (0x01, 0x02, 0x00), (0x7C, 0x34)),
    "r0": ((0xAE, 0xAF), (0x0B, 0x0C, 0x0A), (0x7E, 0x7F)),
    "r1": ((0xB0, 0x14), (0x15, 0x16, 0x14), (0x15, 0xA8)),
    "r2": ((0x89, 0x1C), (0x1D, 0x1E, 0x1C), (0x1D, 0x76)),
    "r3": ((0xF1, 0xD7), (0x07, 0x08, 0x09), (0xD8, 0xD9)),
    "r4": ((0x9A, 0xDE), (0x11, 0x12, 0x13), (0x94, 0x95)),
    "r5": ((0x34, 0xBE), (0x01, 0x02, 0x00), (0x7C, 0x34)),
    "BA1": ((0x34, 0xE7), (0x83, 0x25, 0x82), (0xE8, 0x34)),   # trunks after r5
    "BA2": ((0x34, 0x34), (0x87, 0x88, 0x86), (0x34, 0x34)),
    "BB1": ((0xF1, 0x4E), (0x4F, 0xD6, 0x4E), (0x4F, 0xD9)),   # trunks after r2
    "BB2": ((0x9A, 0x9B), (0x9C, 0x9D, 0x9B), (0x9C, 0x95)),
}
FOREST_CYCLE = ["r0", "r1", "r2", "r3", "r4", "r5"]

# ------------------------------------------------------------------ plateau (raised ground)
# Learnt from the light world's low plateaus (south of Link's house): dirt top, jumpable walls
# on all sides (north lip = ledge 0x28, west 0x2a, east 0x2b, south 0x29).
# Columns: x0 x1 = west wall, fill..., e0 e1 = east wall. Rows: A B C = north edge,
# wall rows, S1 S2 S3 = south wall. 0x34 = leave the ground under it.
PLATEAU = {
    "fill": 0xC6,
    "north": (0x15E, 0x165, 0xC6),                      # rows A, B, C in the fill columns
    "west": (0xCE, 0xC5),                                # wall rows, cols x0 x1
    "east": (0x21C, 0x16A),                              # wall rows, cols e0 e1
    "south": (0xD1, 0xC9, 0xE3),                         # rows S1 S2 S3 in the fill columns
    # corners, rows top->bottom, cols left->right
    "nw": ((0x34, 0x15C, 0x15D), (0x15C, 0x162, 0x106), (0x162, 0x106, 0x107)),   # cols x0 x1 x2
    "ne": ((0x15F, 0x160, 0x34), (0x166, 0x167, 0x160), (0x171, 0x166, 0x167)),  # cols e-1 e0 e1
    "sw": ((0xD4, 0xD0), (0xDB, 0xC8), (0x34, 0xDB)),                           # cols x0 x1
    "se": ((0x183, 0x1FA), (0x153, 0x186), (0x186, 0x34)),                        # cols e0 e1
}
