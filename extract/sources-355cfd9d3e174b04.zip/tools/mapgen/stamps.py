"""Stamp library: named pieces of the original overworlds, referenced by coordinates only
(no Nintendo data here: the map16 ids are read from the player's extraction at build time).

A stamp = a rectangle of an original world (map16 cells, world coordinates, see look.py),
with a mask: cells equal to the stamp's *ground* (plain grass by default) are transparent,
so a tree / house / statue drops onto whatever ground is already there.

Kinds:
  fixed   m.stamp(name, x, y)
  hstrip  m.strip(name, x, y, length)      left cap | repeated middle | right cap
  vstrip  m.strip(name, x, y, length)      top cap  | repeated middle | bottom cap
  box     m.box(name, x, y, w, h)          9-slice: corners, repeated edges, repeated centre

Every stamp is drawn with the atlas of its source screen (`atlas`); the compiler warns when
a stamp is placed on a screen whose atlas renders its tiles differently.

    python3 tools/mapgen/stamps.py            # checks + contact sheets (game/assets/rom/maps/stamps/)
    python3 tools/mapgen/look.py stamp NAME   # one stamp, zoomed, with its info
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

from functools import lru_cache

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import data as D  # noqa: E402

# ------------------------------------------------------------------ ground sets
# Ids treated as "empty" when cutting a stamp out of an original screen.
GROUNDS = {
    "grass": {0x34},
    "dirt": {0xC6},
    "mountain": {0x2E5},
    "paving": {0x3C7},   # pale Kakariko paving
    "lawn": {0x34, 0x35, 0x36, 0xE1, 0xE2, 0xDA, 0x37D, 0x9E, 0x9F, 0x17C, 0xA9, 0xC6, 0x179, 0xAD, 0xA5, 0xAC},
    "sand": {0x6E4},
    "none": set(),
}
# Human description of what the stamp's border must sit on.
GROUND_FR = {
    "grass": "herbe", "dirt": "terre", "mountain": "terre de montagne",
    "paving": "pavés clairs", "none": "(rectangle plein)", "lawn": "herbe", "sand": "sable",
}


@dataclass
class Stamp:
    name: str
    kind: str                 # fixed | hstrip | vstrip | box
    world: str
    rect: tuple               # (x, y, w, h) in world map16 cells, after trimming
    ids: np.ndarray           # (h, w) map16 ids
    mask: np.ndarray          # (h, w) bool: True = written
    atlas: str
    ground: str
    tags: tuple
    desc: str
    cuts: tuple = ()          # strip: (a, b) ; box: (a, b, c, d)
    anchor: tuple = (0, 0)    # informative: e.g. door cell relative to the stamp
    extra: dict = field(default_factory=dict)

    @property
    def w(self) -> int:
        return self.ids.shape[1]

    @property
    def h(self) -> int:
        return self.ids.shape[0]


_DEFS: list[dict] = []
# map16 pairs that form a 2-cell house door (left, right): used to find doors automatically
DOOR_PAIRS = [(0xFB, 0xFC), (0x746, 0x747)]
_CACHE: dict[str, Stamp] = {}


def _def(name, kind, world, rect, ground="grass", tags=(), desc="", cuts=(), drop=(), trim=True,
         door=None, **extra):
    _DEFS.append(dict(name=name, kind=kind, world=world, rect=rect, ground=ground, tags=tuple(tags),
                      desc=desc, cuts=tuple(cuts), drop=tuple(drop), trim=trim, door=door, extra=extra))


def fixed(name, world, rect, ground="grass", tags=(), desc="", drop=(), door=None, trim=True, **kw):
    """A fixed-size stamp. rect = (x, y, w, h) in world cells; trimmed to the non-ground cells.
    drop = world cells to leave out (neighbouring objects caught in the rect).
    door = world cell (x, y) of the door / entrance (reported relative to the stamp)."""
    _def(name, "fixed", world, rect, ground, tags, desc, (), drop, trim, door, **kw)


def hstrip(name, world, rect, a, b, ground="grass", tags=(), desc="", drop=(), rects=None):
    """Horizontal strip: columns [0,a) = left cap, [a,b) = repeated unit, [b,w) = right cap
    (relative to rect, NOT trimmed). rects = list of rects glued left to right instead of rect."""
    _def(name, "hstrip", world, rect, ground, tags, desc, (a, b), drop, False, rects=rects)


def vstrip(name, world, rect, a, b, ground="grass", tags=(), desc="", drop=(), rects=None):
    _def(name, "vstrip", world, rect, ground, tags, desc, (a, b), drop, False, rects=rects)


def box(name, world, rect, xa, xb, ya, yb, ground="grass", tags=(), desc="", drop=()):
    """9-slice: columns [0,xa) [xa,xb) [xb,w), rows [0,ya) [ya,yb) [yb,h); middles repeat."""
    _def(name, "box", world, rect, ground, tags, desc, (xa, xb, ya, yb), drop, False)


def _build(d: dict) -> Stamp:
    world = d["world"]
    g = D.world_grid(world)
    if d["extra"].get("rects"):
        # pieces glued along the strip axis (e.g. a left cap and a right cap from 2 places)
        rs = d["extra"]["rects"]
        axis = 0 if d["kind"] == "vstrip" else 1
        ids = np.concatenate([g[ry:ry + rh, rx:rx + rw] for rx, ry, rw, rh in rs], axis=axis).copy()
        x, y = rs[0][0], rs[0][1]
        h, w = ids.shape
    else:
        x, y, w, h = d["rect"]
        ids = g[y:y + h, x:x + w].copy()
    ground = GROUNDS[d["ground"]]
    mask = ~np.isin(ids, list(ground)) if ground else np.ones_like(ids, bool)
    for (cx, cy) in d["drop"]:
        mask[cy - y, cx - x] = False
    if d["extra"].get("rects"):
        d = dict(d, extra={k: v for k, v in d["extra"].items() if k != "rects"})
    if d["trim"] and mask.any():
        ys, xs = np.nonzero(mask)
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        ids, mask = ids[y0:y1, x0:x1], mask[y0:y1, x0:x1]
        x, y, w, h = x + x0, y + y0, x1 - x0, y1 - y0
    # cells that show nothing but grass (a bare lawn cell, a tuft of the original ground) are
    # transparent: only the object is copied, it sits on whatever ground is already there
    if d["ground"] != "none" or d.get("drop_lawn"):
        mask &= ~_lawn_only(ids, d["extra"].get("atlas") or D.screen_atlas(world, x // 32, y // 32))
    atl = {D.screen_atlas(world, sx, sy) for sx in range(x // 32, (x + w - 1) // 32 + 1)
           for sy in range(y // 32, (y + h - 1) // 32 + 1)}
    atlas = d["extra"].get("atlas") or D.screen_atlas(world, x // 32, y // 32)
    extra = {k: v for k, v in d["extra"].items() if k != "atlas"}
    if d["extra"].get("atlas"):
        atl = {atlas}
    if len(atl) > 1:
        extra["mixed_atlases"] = sorted(a for a in atl if a)
    anchor = (0, 0)
    if not d["door"] and d["kind"] == "fixed":
        for a, b in DOOR_PAIRS:
            hits = [(xx, yy) for yy in range(ids.shape[0]) for xx in range(ids.shape[1] - 1)
                    if ids[yy, xx] == a and ids[yy, xx + 1] == b and mask[yy, xx]]
            if hits:
                d = dict(d, door=(x + hits[0][0], y + hits[0][1], 2))
                break
    if d["door"]:
        anchor = (d["door"][0] - x, d["door"][1] - y)
        extra["door"] = anchor
        extra["door_w"] = d["door"][2] if len(d["door"]) > 2 else 1
    return Stamp(d["name"], d["kind"], world, (x, y, w, h), ids, mask, atlas, d["ground"],
                 d["tags"], d["desc"], d["cuts"], anchor, extra)


LAWN_ATLAS, LAWN_TILES = "ow_20_20_00_0", (0x34, 0x35)   # plain grass, grass tuft (light world)


@lru_cache(None)
def lawn_colours() -> frozenset:
    """Colours of the light world grass and grass tuft, read from the player's own atlas (the
    European versions use brighter palettes: no colour is written here)."""
    t = D.atlas_px_cache(LAWN_ATLAS)
    return frozenset(tuple(int(c) for c in p) for i in LAWN_TILES for p in np.unique(t[i].reshape(-1, 3), axis=0))


def _lawn_only(ids: np.ndarray, atlas: str) -> np.ndarray:
    """(h, w) bool: cells whose pixels are only grass / tuft colours."""
    t = D.atlas_px_cache(atlas)
    out = np.zeros(ids.shape, bool)
    for (j, i), v in np.ndenumerate(ids):
        px = t[int(v)].reshape(-1, 3)
        out[j, i] = all(tuple(int(c) for c in p) in lawn_colours() for p in np.unique(px, axis=0))
    return out


def names() -> list[str]:
    return [d["name"] for d in _DEFS]


def get(name: str) -> Stamp:
    if name not in _CACHE:
        for d in _DEFS:
            if d["name"] == name:
                _CACHE[name] = _build(d)
                break
        else:
            import difflib
            close = difflib.get_close_matches(name, names(), 5)
            raise D.MapError(f"tampon inconnu {name!r}" + (f" (vouliez-vous : {', '.join(close)} ?)" if close else ""))
    return _CACHE[name]


def all_stamps() -> list[Stamp]:
    return [get(n) for n in names()]


def _repeat(n_total: int, a: int, b: int, size: int) -> list[int]:
    """Source indices for a target length n_total with caps [0,a) and [b,size), middle [a,b)."""
    left, mid, right = list(range(a)), list(range(a, b)), list(range(b, size))
    n_mid = n_total - len(left) - len(right)
    if n_mid < 0:
        raise D.MapError(f"longueur {n_total} trop courte (minimum {len(left) + len(right)})")
    if not mid and n_mid:
        raise D.MapError("ce tampon n'a pas de partie répétable")
    return left + [mid[i % len(mid)] for i in range(n_mid)] + right


def expand(st: Stamp, w: int | None = None, h: int | None = None) -> tuple[np.ndarray, np.ndarray]:
    """(ids, mask) of a stamp at a given size (strips / boxes)."""
    if st.kind == "fixed":
        return st.ids, st.mask
    if st.kind == "hstrip":
        cols = _repeat(w, st.cuts[0], st.cuts[1], st.w)
        return st.ids[:, cols], st.mask[:, cols]
    if st.kind == "vstrip":
        rows = _repeat(h, st.cuts[0], st.cuts[1], st.h)
        return st.ids[rows, :], st.mask[rows, :]
    xa, xb, ya, yb = st.cuts
    cols = _repeat(w, xa, xb, st.w)
    rows = _repeat(h, ya, yb, st.h)
    return st.ids[np.ix_(rows, cols)], st.mask[np.ix_(rows, cols)]


def size_rule(st: Stamp) -> str:
    if st.kind == "fixed":
        return f"{st.w}x{st.h}"
    if st.kind == "hstrip":
        a, b = st.cuts
        return f"Lx{st.h}, L>={a + st.w - b}" + (f", milieu par {b - a}" if b - a > 1 else "")
    if st.kind == "vstrip":
        a, b = st.cuts
        return f"{st.w}xL, L>={a + st.h - b}" + (f", milieu par {b - a}" if b - a > 1 else "")
    xa, xb, ya, yb = st.cuts
    return (f"WxH, W>={xa + st.w - xb}, H>={ya + st.h - yb}"
            + (f", pas {xb - xa}x{yb - ya}" if (xb - xa, yb - ya) != (1, 1) else ""))


def describe(st: Stamp) -> str:
    x, y, w, h = st.rect
    s = (f"{st.name} [{st.kind}] {size_rule(st)} — {st.desc}\n"
         f"  source {st.world} ({x},{y}) {w}×{h}, atlas {st.atlas}, bord : {GROUND_FR[st.ground]}, "
         f"tags : {', '.join(st.tags)}")
    if "door" in st.extra:
        s += f"\n  porte en ({st.extra['door'][0]},{st.extra['door'][1]}) relative au tampon"
    if "mixed_atlases" in st.extra:
        s += f"\n  ⚠ source à cheval sur plusieurs atlas : {st.extra['mixed_atlases']}"
    return s


# ====================================================================== catalogue
# Coordinates: world map16 cells (python3 tools/mapgen/look.py world lw X Y W H).
# LW screen $SS -> x = (SS & 7) * 32, y = (SS >> 3) * 32.

# (definitions below)
# --- houses (Kakariko, atlas ow_20_23_08_0) --------------------------------------------
fixed("house_red_m", "lw", (10, 115, 7, 6), ground="lawn", drop=[(10, 120)], tags=["house"],
      desc="maison au toit rouge (Cocorico)")
fixed("house_red_l", "lw", (36, 103, 11, 6), ground="lawn", drop=[(40, 108), (41, 108), (46, 108)], tags=["house"],
      desc="grande maison rouge à deux portes (taverne) ; 2e porte 4 cellules à droite de la 1re")
fixed("house_blue_m", "lw", (37, 133, 7, 6), ground="lawn", tags=["house"], desc="maison au toit bleu")
fixed("house_blue_woodpile", "lw", (22, 133, 8, 7), ground="lawn", tags=["house"],
      desc="maison bleue avec tas de bois à droite")
fixed("house_blue_skylight", "lw", (49, 132, 7, 6), ground="lawn", tags=["house"],
      desc="maison bleue à deux lucarnes")
fixed("house_blue_big", "lw", (38, 145, 7, 10), ground="lawn", tags=["house"],
      desc="grande maison bleue avec enseigne (bibliothèque)")
fixed("shed_thatch", "lw", (26, 146, 4, 5), ground="lawn", tags=["house"], desc="petite remise au toit de chaume")
fixed("barn_back", "lw", (5, 149, 4, 4), ground="lawn", tags=["house"], desc="grange vue de dos (sans porte)")
fixed("links_house", "lw", (137, 171, 7, 7), ground="lawn", tags=["house"], desc="petite maison au toit rouge (maison de Link)")
fixed("house_thatch", "lw", (76, 132, 6, 7), ground="lawn", drop=[(81, 138)], tags=["house"],
      desc="maison au toit de chaume avec cheminée")
fixed("shop_green", "lw", (163, 202, 7, 5), ground="lawn", tags=["house"], desc="boutique au toit vert (lac)")
fixed("witch_hut", "lw", (203, 81, 4, 7), ground="lawn", tags=["house"], desc="hutte de la sorcière")
# --- trees --------------------------------------------------------------------------------
fixed("tree", "lw", (22, 104, 4, 5), tags=["tree"], desc="grand arbre rond")
fixed("tree_pink", "lw", (10, 100, 2, 2), tags=["tree"], desc="petit arbre rose (Cocorico)")
fixed("tree_pink_pair", "lw", (10, 100, 4, 2), tags=["tree"], desc="deux arbres roses côte à côte")
fixed("tree_small", "lw", (60, 102, 2, 2), ground="lawn", tags=["tree"], desc="arbuste rond")
fixed("stump", "lw", (45, 6, 2, 2), tags=["tree"], desc="souche")
vstrip("log_v", "lw", None, 2, 4, rects=[(20, 8, 3, 2), (20, 10, 3, 2), (20, 16, 3, 2)], ground="none",
       tags=["tree"], desc="tronc creux couché (vertical, Bois Perdus), on passe dessous par le bas")
# --- village props -------------------------------------------------------------------------
fixed("weathervane", "lw", (29, 119, 7, 5), tags=["village"], desc="girouette au coq sur socle de dalles (place du village)")
fixed("well", "lw", (5, 108, 2, 2), tags=["village"], desc="puits (trou carré)")
fixed("bench", "lw", (9, 141, 2, 1), ground="paving", tags=["village"], desc="banc en bois")
fixed("trough_pair", "lw", (20, 145, 4, 2), tags=["village"], desc="deux abreuvoirs")
fixed("trough", "lw", (20, 145, 2, 2), tags=["village"], desc="abreuvoir")
fixed("kakariko_gate", "lw", (53, 154, 6, 3), ground="lawn", tags=["village"], desc="portique d'entrée de village")
fixed("stairs_cliff", "lw", (27, 112, 3, 3), ground="none", tags=["cliff"], desc="escalier de pierre dans une falaise (3 de haut)")
fixed("cave_cliff", "lw", (8, 104, 10, 6), door=(11, 109, 2), tags=["cliff"], desc="butte rocheuse avec entrée de grotte")
fixed("statue_armos", "lw", (180, 164, 2, 3), tags=["statue"], desc="statue (armos)")
fixed("pond_tiny", "lw", (164, 164, 6, 6), ground="lawn", tags=["water"], desc="petite mare ronde")
fixed("tombstone", "lw", (132, 74, 2, 2), tags=["graveyard"], desc="pierre tombale")
# --- rocks & small nature -------------------------------------------------------------------
fixed("boulder", "lw", (106, 214, 2, 2), tags=["nature"], desc="gros rocher 2×2 (bloque ; soulevable avec les gants d'or)")
fixed("rock_pile", "lw", (99, 74, 2, 2), tags=["nature"], desc="tas de pierres 2×2")
fixed("cactus", "lw", (36, 208, 1, 2), ground="sand", tags=["nature"], desc="cactus (désert)")
fixed("bones", "lw", (36, 216, 2, 2), ground="sand", tags=["nature"], desc="ossements (désert)")
fixed("barrel", "lw", (46, 148, 1, 2), tags=["village"], desc="tonneau rouge")
fixed("mailbox", "lw", (10, 120, 1, 2), tags=["village"], desc="boîte aux lettres")
fixed("cave_in_wall", "lw", (11, 107, 2, 3), ground="none", door=(11, 109, 2), tags=["cliff"],
      desc="entrée de grotte à poser dans le mur sud d'un plateau : m.stamp('cave_in_wall', x, y_plateau + h - 3)")
hstrip("ledge_s", "lw", (32, 112, 1, 3), 0, 1, ground="none", tags=["cliff"],
       desc="rebord sud (petite falaise de 3 de haut, on saute vers le bas) ; finir les bouts contre un obstacle")
# --- dark world --------------------------------------------------------------------------------
fixed("dw_house", "lw", (10, 115, 7, 6), ground="lawn", drop=[(10, 120)], atlas="ow_21_3f_1e_1", tags=["dark"],
      desc="maison du village des parias (même dessin que house_red_m, couleurs des ténèbres)")
fixed("dw_house_blue", "lw", (37, 133, 7, 6), ground="lawn", atlas="ow_21_3f_1e_1", tags=["dark"],
      desc="maison bleue (house_blue_m) aux couleurs des ténèbres")
fixed("tree_autumn", "lw", (113, 71, 4, 5), atlas="ow_20_25_09_0", tags=["tree"], desc="gros arbre olive (automne) = tree_red, atlas du palais de l'est")
fixed("tree_dark", "lw", (22, 104, 4, 5), atlas="ow_20_21_06_0", tags=["tree"], desc="grand arbre aux couleurs des Bois Perdus")
fixed("dw_tree", "lw", (113, 71, 4, 5), atlas="ow_21_3f_1e_1", tags=["dark"], desc="gros arbre rose (ténèbres) = tree_red avec l'atlas des ténèbres")
# --- graveyard, ruins, statues -------------------------------------------------------------
fixed("grave_gate", "lw", (147, 86, 5, 2), ground="lawn", tags=["graveyard"], desc="portail de cimetière (piliers + grille)")
fixed("grave_pillar", "lw", (147, 86, 1, 2), tags=["graveyard"], desc="pilier de pierre à boule")
fixed("sanctuary", "lw", (114, 64, 8, 6), ground="none", door=(117, 69, 2), tags=["house"], desc="sanctuaire / chapelle (façade)")
fixed("tree_red", "lw", (113, 71, 4, 5), tags=["tree"], desc="gros arbre sombre (rouge au sanctuaire, olive près du palais de l'est selon l'atlas)")
fixed("pink_shrub", "lw", (122, 121, 2, 3), tags=["tree"], desc="arbuste rose taillé (jardin du château)")
vstrip("orange_flowers_v", "lw", (117, 121, 1, 2), 0, 2, tags=["fence"], desc="rangée de fleurs orange (verticale, jardin du château)")
vstrip("hedge_v", "lw", None, 1, 2, rects=[(47, 102, 1, 1), (47, 103, 1, 1), (47, 107, 1, 1)], ground="none",
       tags=["fence"], desc="haie taillée verticale")
fixed("tree_bush", "lw", (43, 16, 2, 2), tags=["tree"], desc="petit arbre buissonnant (Bois Perdus)")
fixed("gargoyle", "lw", (198, 131, 3, 3), ground="mountain", tags=["statue"], desc="statue de gargouille (ruines, sur terre de montagne)")
fixed("ruin_arch", "lw", (198, 147, 7, 4), ground="lawn", tags=["statue"], desc="arche en ruine")
fixed("stairs_high", "lw", (200, 141, 3, 5), ground="none", tags=["cliff"], desc="escalier de pierre (5 de haut, falaise haute)")
fixed("stone_slab", "lw", (110, 73, 2, 2), tags=["nature"], desc="dalle de pierre octogonale")
# --- mountain -----------------------------------------------------------------------------------
hstrip("bridge_rope_h", "lw", None, 3, 4, rects=[(115, 5, 3, 3), (118, 5, 1, 3), (131, 5, 3, 3)], ground="none", tags=["bridge"],
       desc="pont de corde est-ouest (Montagne de la Mort : atlas DEATH_MOUNTAIN)")
fixed("dm_boulder", "lw", (104, 6, 2, 2), tags=["nature"], desc="rocher brun (montagne)")
vstrip("ladder_v", "lw", None, 1, 2, rects=[(102, 23, 2, 1), (102, 24, 2, 1)], ground="none", tags=["cliff"],
       desc="échelle de bois dans une falaise haute (haut en 1re rangée)")
# --- fences & hedges ------------------------------------------------------------------------
hstrip("fence_h", "lw", (31, 111, 1, 1), 0, 1, tags=["fence"], desc="clôture de piquets horizontale")
vstrip("fence_v", "lw", (18, 148, 1, 1), 0, 1, tags=["fence"], desc="clôture de piquets verticale")
hstrip("hedge_h", "lw", None, 1, 2, rects=[(8, 143, 2, 2), (31, 117, 1, 2)], ground="none", tags=["fence"],
       desc="haie taillée horizontale (2 de haut)")
# --- bridges ---------------------------------------------------------------------------------
hstrip("bridge_wood_h", "lw", (174, 107, 9, 6), 1, 3, ground="none", tags=["bridge"],
       desc="pont de bois est-ouest (au-dessus d'une rivière nord-sud)")
vstrip("bridge_stone_v", "lw", None, 2, 4, rects=[(174, 172, 7, 2), (174, 174, 7, 2), (174, 181, 7, 2)],
       ground="none", tags=["bridge"], desc="pont de pierre nord-sud (au-dessus d'une rivière est-ouest)")


# ------------------------------------------------------------------ contact sheets

def sheets(out_dir: Path | None = None) -> list[Path]:
    """Contact sheets of all stamps, grouped by first tag, into game/assets/rom/maps/stamps/."""
    from PIL import Image, ImageDraw
    out_dir = out_dir or (D.MAPS_OUT / "stamps")
    out_dir.mkdir(parents=True, exist_ok=True)
    groups: dict[str, list[Stamp]] = {}
    for st in all_stamps():
        groups.setdefault(st.tags[0] if st.tags else "misc", []).append(st)
    paths = []
    bg = np.array((52, 60, 70), np.uint8)
    for tag, sts in groups.items():
        tiles = []
        for st in sts:
            if st.kind == "fixed":
                ids, mask = st.ids, st.mask
            elif st.kind == "hstrip":
                ids, mask = expand(st, w=st.w + (st.cuts[1] - st.cuts[0]))
            elif st.kind == "vstrip":
                ids, mask = expand(st, h=st.h + (st.cuts[1] - st.cuts[0]))
            else:
                ids, mask = expand(st, st.w + (st.cuts[1] - st.cuts[0]), st.h + (st.cuts[3] - st.cuts[2]))
            img = D.render_cells(ids, st.atlas)
            m = np.repeat(np.repeat(mask, 16, 0), 16, 1)
            chk = ((np.arange(img.shape[0])[:, None] // 8 + np.arange(img.shape[1])[None, :] // 8) % 2)
            under = np.where(chk[..., None] == 0, bg, bg + 14)
            img = np.where(m[..., None], img, under).astype(np.uint8)
            tiles.append((st, Image.fromarray(img)))
        W = 1280
        # shelf packing
        x = y = 0
        row_h = 0
        pos = []
        for st, im in tiles:
            cw = max(im.width, 150) + 12
            ch = im.height + 30
            if x + cw > W:
                x, y = 0, y + row_h
                row_h = 0
            pos.append((x, y))
            x += cw
            row_h = max(row_h, ch)
        H = y + row_h + 4
        sheet = Image.new("RGB", (W, H), (28, 30, 38))
        dr = ImageDraw.Draw(sheet)
        for (st, im), (px, py) in zip(tiles, pos):
            dr.text((px + 2, py + 2), st.name, fill=(255, 240, 150))
            dr.text((px + 2, py + 13), size_rule(st) + ("" if st.kind == "fixed" else f" [{st.kind}]"),
                    fill=(170, 200, 255))
            sheet.paste(im, (px + 2, py + 26))
            if "door" in st.extra:
                dx, dy = st.extra["door"]
                dw = st.extra.get("door_w", 1)
                dr.rectangle([px + 2 + dx * 16, py + 26 + dy * 16, px + 2 + dx * 16 + 16 * dw - 1, py + 26 + dy * 16 + 15],
                             outline=(255, 60, 60))
        p = out_dir / f"stamps_{tag}.png"
        sheet.save(p)
        paths.append(p)
    # everything in one picture
    ims = [Image.open(p) for p in paths]
    allim = Image.new("RGB", (max(i.width for i in ims), sum(i.height + 18 for i in ims)), (20, 20, 26))
    dr = ImageDraw.Draw(allim)
    y = 0
    for p, i in zip(paths, ims):
        dr.text((4, y + 3), p.stem.replace("stamps_", "== ").upper(), fill=(255, 120, 120))
        allim.paste(i, (0, y + 18))
        y += i.height + 18
    allim.save(out_dir / "stamps_all.png")
    return paths


def check() -> list[str]:
    problems = []
    seen = set()
    for d in _DEFS:
        if d["name"] in seen:
            problems.append(f"nom en double : {d['name']}")
        seen.add(d["name"])
        st = get(d["name"])
        if not st.mask.any():
            problems.append(f"{st.name}: vide")
        if "mixed_atlases" in st.extra:
            problems.append(f"{st.name}: source sur plusieurs atlas {st.extra['mixed_atlases']}")
    return problems


def compatible_atlases(st: Stamp, candidates: list[str], tol: float = 0.02) -> list[str]:
    ids = st.ids[st.mask]
    return [a for a in candidates if D.tile_diff(ids, st.atlas, a) <= tol]


if __name__ == "__main__":
    for p in check():
        print("!", p)
    print(len(_DEFS), "tampons")
    for p in sheets():
        print(p)
