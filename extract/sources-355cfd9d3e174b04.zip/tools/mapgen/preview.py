"""PNG preview of a compiled map, with entities, links, spawns and zones annotated."""
from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

import data as D

COLORS = {
    "npc": (80, 200, 255), "enemy": (255, 70, 70), "chest": (255, 200, 40), "sign": (230, 230, 230),
    "pot": (200, 140, 90), "bush": (120, 220, 90), "rock": (170, 170, 170), "pickup": (255, 120, 220),
    "trigger": (255, 150, 0), "door": (170, 100, 255), "switch": (0, 255, 200), "block": (150, 120, 90),
    "boss": (255, 0, 120), "spawner": (255, 255, 0),
}


def _tileset(name: str) -> np.ndarray | None:
    for p in (D.ASSETS / "underworld" / "tilesets" / f"{name}.png", D.MAPS_OUT / "stub_rooms" / f"{name}.png"):
        if p.exists():
            return np.array(Image.open(p).convert("RGBA"))
    return None


def render_tile8(s: dict) -> np.ndarray:
    out = np.zeros((512, 512, 3), np.uint8)
    ts = _tileset(s["tileset"])
    if ts is None:
        out[:] = (90, 0, 90)
        return out
    for layer in ("bg", "fg"):
        words = s[layer]
        for i, w in enumerate(words):
            if not w and layer == "fg":
                continue
            tile, pal = w & 0x3FF, (w >> 10) & 7
            cell = pal * 512 + (tile & 0x1FF)
            tx, ty = (cell % 64) * 8, (cell // 64) * 8
            t = ts[ty:ty + 8, tx:tx + 8]
            if w & 0x4000:
                t = t[:, ::-1]
            if w & 0x8000:
                t = t[::-1, :]
            x, y = (i % 64) * 8, (i // 64) * 8
            a = t[..., 3:4] > 0
            out[y:y + 8, x:x + 8] = np.where(a, t[..., :3], out[y:y + 8, x:x + 8])
    return out


def render(compiled: dict) -> np.ndarray:
    sw, sh = compiled["screens_w"], compiled["screens_h"]
    img = np.zeros((sh * 512, sw * 512, 3), np.uint8)
    img[:] = (24, 24, 30)
    for si, s in enumerate(compiled["screens"]):
        if s is None:
            continue
        sx, sy = si % sw, si // sw
        if s["format"] == "map16":
            blk = D.render_cells(np.array(s["tiles"]).reshape(32, 32), s["atlas"])
        else:
            blk = render_tile8(s)
        img[sy * 512:(sy + 1) * 512, sx * 512:(sx + 1) * 512] = blk
    return img


def annotate(compiled: dict, img: np.ndarray, grid: bool = False, scale: int = 1) -> Image.Image:
    im = Image.fromarray(img)
    if scale != 1:
        im = im.resize((im.width * scale, im.height * scale), Image.NEAREST)
    dr = ImageDraw.Draw(im, "RGBA")
    S = scale
    unit = 16 if compiled["kind"] == "overworld" else 8
    if grid:
        W, H = im.size
        for x in range(0, W, unit * S):
            c = x // (unit * S)
            dr.line([(x, 0), (x, H)], fill=(255, 255, 255, 70 if c % 8 == 0 else 22))
        for y in range(0, H, unit * S):
            c = y // (unit * S)
            dr.line([(0, y), (W, y)], fill=(255, 255, 255, 70 if c % 8 == 0 else 22))
        for y in range(0, H, unit * S * 8):
            for x in range(0, W, unit * S * 8):
                dr.text((x + 2, y + 1), f"{x // (unit * S)},{y // (unit * S)}", fill=(255, 255, 160, 200))
    # zones
    for a in compiled["areas"]:
        if "rect_px" in a:
            x0, y0, w, h = (v * S for v in a["rect_px"])
        else:
            x, y, w, h = a["rect"]
            x0, y0, w, h = x * 512 * S, y * 512 * S, w * 512 * S, h * 512 * S
        dr.rectangle([x0, y0, x0 + w - 1, y0 + h - 1], outline=(255, 0, 255, 200), width=2)
        label = f"{a['name']} [{a.get('music', '')}]" + (" (sombre)" if a.get("dark") else "")
        dr.rectangle([x0 + 2, y0 + 2, x0 + 8 + 6 * len(label), y0 + 14], fill=(0, 0, 0, 150))
        dr.text((x0 + 5, y0 + 3), label, fill=(255, 150, 255))
    # warps
    for w in compiled["warps"]:
        x, y, ww, hh = (v * S for v in w["rect"])
        dr.rectangle([x, y, x + ww - 1, y + hh - 1], outline=(0, 255, 255, 255), width=2)
        _label(dr, x, y + hh + 1, f"→{w['to']}:{w['spawn']} ({w['style']})", (0, 255, 255))
    # spawns
    arrows = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}
    for name, (x, y, d) in compiled["spawns"].items():
        x, y = x * S, y * S
        dr.rectangle([x, y, x + 16 * S - 1, y + 16 * S - 1], outline=(255, 255, 0, 255), width=1)
        cx, cy = x + 8 * S, y + 8 * S
        ax, ay = arrows.get(d, (0, 0))
        dr.line([(cx, cy), (cx + ax * 7 * S, cy + ay * 7 * S)], fill=(255, 255, 0, 255), width=2)
        _label(dr, x, y - 11, f"◆{name}", (255, 255, 0))
    # entities
    for e in compiled["entities"]:
        x, y = e["x"] * S, e["y"] * S
        col = COLORS.get(e["type"], (255, 255, 255))
        w = e.get("w", 16) * S
        h = e.get("h", 16) * S
        dr.rectangle([x, y, x + w - 1, y + h - 1], outline=col + (255,), width=2)
        extra = e.get("kind") or e.get("item") or e.get("dialogue") or e.get("script") or ""
        _label(dr, x, y + h + 1, f"{e['type']}:{e['id']}" + (f" ({extra})" if extra else ""), col)
    return im


def _label(dr, x, y, text, col):
    w = 6 * len(text) + 4
    dr.rectangle([x, y, x + w, y + 11], fill=(0, 0, 0, 160))
    dr.text((x + 2, y), text, fill=col)


def save_preview(compiled: dict, path: Path, grid: bool = False) -> Path:
    img = render(compiled)
    scale = 2 if compiled["screens_w"] * compiled["screens_h"] <= 1 else 1
    im = annotate(compiled, img, grid=grid, scale=scale)
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path)
    return path
