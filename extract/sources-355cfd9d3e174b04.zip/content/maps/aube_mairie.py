"""Mairie de l'Aube : maison bourgeoise neuve en T (roomgen, murs posés à la main). En haut,
l'alcôve du bureau du maire (bibliothèques, portrait royal, tapis, bureau couvert du discours) ;
en bas, la grande salle où Hortense tricote près de la fenêtre."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("aube_mairie", "Mairie de l'Aube", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch1_aube_mairie", "blockset": 0x03, "palette": 21,
    "floor1": 3, "floor2": 14, "layout": 7, "bg_mode": "off",
    "objects": [
        *G.fill("ceiling_block", 0, 0, 64, 28), *G.fill("ceiling_block", 0, 28, 20, 16),
        *G.fill("ceiling_block", 44, 28, 20, 16), *G.fill("ceiling_block", 0, 44, 8, 20),
        *G.fill("ceiling_block", 56, 44, 8, 20),
        # alcôve du bureau (x 20-44, y 28-44)
        *G.hwall("n", 24, 28, 16), ["corner_out_nw", 20, 28], ["corner_out_ne", 40, 28],
        *G.vwall("w", 20, 32, 12), *G.vwall("e", 40, 32, 12),
        # grande salle (x 8-56, y 44-62)
        *G.hwall("n", 12, 44, 8), *G.hwall("n", 44, 44, 8),
        ["corner_out_nw", 8, 44], ["corner_out_ne", 52, 44],
        ["corner_in_nw", 20, 44], ["corner_in_ne", 40, 44],
        *G.vwall("w", 8, 48, 10), *G.vwall("e", 52, 48, 10),
        *G.hwall("s", 12, 58, 40), ["corner_out_sw", 8, 58], ["corner_out_se", 52, 58],
        # bureau : tapis, bibliothèques, portrait, table de travail
        {"o": "floor_area4", "x": 26, "y": 36, "w": 2, "h": 1},
        ["bookshelf", 24, 30], ["wall_painting", 30, 30], ["bookshelf", 34, 30],
        ["table", 28, 38], ["plate_on_table", 28, 38], ["chair", 29, 35],
        # salle : coin d'Hortense (est), tonneaux et banc (ouest)
        ["table", 44, 50], ["chair", 48, 48], ["chair", 41, 51],
        ["barrel", 12, 48], ["barrel", 14, 49], ["chair", 20, 52],
    ],
    "doors": [["down", 7, "normal"]],
})
m.area(px=(64, 224, 384, 288), name="Mairie de l'Aube", music="village")

door = room["doors"][0]
m.warp_room_door(door, to="aube_village", spawn="mairie")
m.spawn_room_door("porte", door)

m.npc("hortense", 392, 408, sprite="npc_young_snitch_lady", facing="left", dialogue="ch1_mairie_epouse",
      name="Hortense", cond="!ch1_silence")
m.npc("hortense_post", 392, 408, sprite="npc_young_snitch_lady", facing="left",
      dialogue="ch1_mairie_epouse_post", name="Hortense", cond="ch1_silence")
m.entity("sign", "bureau", 232, 312, dialogue="ch1_mairie_bureau", any_side=True)
m.entity("sign", "portrait", 248, 256, dialogue="ch1_mairie_portrait")
m.entity("sign", "bibliotheque", 200, 256, dialogue="common_etagere")
m.entity("pot", "jarre_1", 96, 440)
m.entity("pot", "jarre_2", 400, 440, drop="rupee5")
m.entity("pot", "jarre_3", 384, 440)
