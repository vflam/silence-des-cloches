"""Nef de l'abbaye de la Sainte-Cloche (salle neuve, plan inventé) : la cloche muette de
l'abbaye repose au centre sur une estrade entourée de quatre colonnes ; à l'ouest, le
scriptorium de frère Anselme (tables, étagères, notes partout) ; à l'est, deux courts rangs de
bancs tournés vers la cloche ; au nord, une chapelle basse fermée par un muret."""
from mapdsl import *
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("abbaye_nef", "Nef de l'abbaye", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch2_abbaye_nef", "blockset": 0x00, "palette": 0, "floor1": 0, "layout": 7,
    "objects": [
        # l'estrade de la cloche au centre, quatre colonnes autour
        ["floor_area", 24, 24, 15],
        *G.pillar(28, 28, 8, 8),                   # le socle de la cloche
        ["column_v", 20, 20, 1], ["column_v", 42, 20, 1],
        ["column_v", 20, 40, 1], ["column_v", 42, 40, 1],
        # chapelle basse au nord : muret percé au centre
        ["wall_n_low", 8, 14, 5], ["wall_n_low", 38, 14, 5],
        ["stand_torch_h", 26, 8, 1],
        # scriptorium (ouest) : étagères, tables couvertes de notes
        ["carpet_v", 8, 22, 3], ["carpet_v", 12, 22, 3], ["carpet_v", 8, 38, 3], ["carpet_v", 12, 38, 3],
        ["stand_torch_h", 6, 20, 1], ["stand_torch_h", 6, 52, 1],
        # bancs (est), tournés vers la cloche
        ["church_pew", 46, 28], ["church_pew", 46, 36], ["church_pew", 46, 44],
        ["statue", 54, 52],
    ],
    "doors": [["down", 7]],
}, name="Nef de l'abbaye", music="sanctuary")

door = room["doors"][0]
m.warp_room_door(door, to="abbaye_parvis", spawn="porte")
m.spawn_room_door("porte", door)
m.npc("anselme", cell=(16, 36), sprite="npc_priest", facing="down", script="ch2_anselme", name="Anselme")
m.entity("sign", "cloche_abbaye", cell=(31, 36), dialogue="ch2_abbaye_cloche")
m.entity("sign", "note_banc", cell=(47, 37), dialogue="ch2_abbaye_note_3", any_side=True)
m.entity("sign", "note_porte", cell=(24, 56), dialogue="ch2_abbaye_note_2", any_side=True)
m.entity("sign", "vitrail", cell=(30, 6), dialogue="ch1_chapelle_vitrail")
m.entity("sign", "notes_anselme", cell=(10, 30), dialogue="ch2_abbaye_note_1", any_side=True)
m.entity("pot", "jarre_1", cell=(6, 56), drop="heart")
m.entity("pot", "jarre_2", cell=(56, 8))
