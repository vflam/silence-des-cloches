"""Temple de Sylve — sous-sol (donjon `sylve`), LEVEL-TEMPLE.

8 salles neuves construites avec tools/roomgen (tools/roomgen/rooms/temple_sylve.py) :

           x0                    x1                     x2
   y0  [R13 Yeux      ]──────[R12 Grand coffre]═(sens unique)═[R8 Racines ▲]
                                     │                              ║ (petite clé)
   y1  [R11 Gde clé   ]═(clé)═[R10 Balcon     ]──────────────[R9 Obscure ]
                                     ║ (grande clé)
   y2                         [R14 Veilleurs  ]═(après le boss)═[R15 Carillon]
                               (herse au milieu : interrupteur de R13)

Chemin : R8 → (clé) R9 [clé 3] → R10 [Oriane : pont ; cristal au boomerang → plots] →
(clé) R11 [grande clé] → R10 → R12 [Arc ; interrupteur → raccourci vers R8] → R13 [yeux à
l'arc ; interrupteur → herse de R14] → R10 → (grande clé) R14 [boss] → R15.
"""
import sys
from pathlib import Path

from mapdsl import *

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools" / "roomgen"))
sys.path.insert(0, str(ROOT / "tools" / "roomgen" / "rooms"))
import temple_sylve as T  # noqa: E402

MAP = "temple_sylve_s1"
m = Map(MAP, "Temple de Sylve – sous-sol", kind="dungeon", size=(3, 3), dungeon="sylve")
m.empty_screen(0, 2)

SCREENS = {"r8": (2, 0), "r9": (2, 1), "r10": (1, 1), "r11": (0, 1), "r12": (1, 0), "r13": (0, 0),
           "r14": (1, 2), "r15": (2, 2)}
SPECS = {"r8": T.R8, "r9": T.R9, "r10": T.R10, "r11": T.R11, "r12": T.R12, "r13": T.R13, "r14": T.R14, "r15": T.R15}
NAMES = {"r8": "Crypte des Racines", "r9": "Salle obscure", "r10": "Balcon d'Oriane",
         "r11": "Salle de la Grande Clé", "r12": "Salle du Grand Coffre", "r13": "Galerie des Yeux",
         "r14": "Arène des Veilleurs", "r15": "Salle du Carillon"}


def P(r, cx, cy):
    """Room-local tile8 cell -> map pixels."""
    sx, sy = SCREENS[r]
    return sx * 512 + cx * 8, sy * 512 + cy * 8


def O(r):
    sx, sy = SCREENS[r]
    return sx * 512, sy * 512


# ------------------------------------------------------------------ rooms (base + variants)
VAR = {
    "r8_keyopen": T.variant(T.R8, "keyopen", doors={0: "normal"}),
    "r8_open": T.variant(T.R8, "open", doors={1: "normal"}),
    "r9_t1": T.variant(T.R9, "t1", torches=[[12, 30, True], [50, 26, False]]),
    "r9_t2": T.variant(T.R9, "t2", torches=[[12, 30, False], [50, 26, True]]),
    "r10_pont": T.variant(T.R10, "pont", objects=T.R10_BRIDGE),
    "r10_plots": T.variant(T.R10, "plots", objects=T.R10_PEGS),
    "r10_keyopen": T.variant(T.R10, "keyopen", doors={1: "normal"}),
    # north door drawn as a big key door: mirrored onto the south door (ALttP has no big key
    # door object for south walls), in the room's own palette
    "r10_upbk": T.variant(T.R10, "upbk", doors={2: "big_key"}),
    "r11_shut": T.variant(T.R11, "shut", doors={0: "shutter"}),
    "r12_open": T.variant(T.R12, "open", doors={2: "normal"}),
    "r14_herse": T.variant(T.R14, "herse", doors={1: "normal"}),
    "r14_east": T.variant(T.R14, "east", doors={2: "normal"}),
}
built = T.build(list(SPECS.values()) + list(VAR.values()))
B = {k: built[s["name"]] for k, s in SPECS.items()}
V = {k: built[s["name"]] for k, s in VAR.items()}

rooms = {}
for k, spec in SPECS.items():
    sx, sy = SCREENS[k]
    rooms[k] = m.room_custom(sx, sy, spec, name=NAMES[k], music="dungeon", dark=(k == "r9"))
    T.install(m.s8[(sx, sy)], B[k], rooms[k])

def patch(cond, cells):
    m.patch(cond, cells)


def key_door(id, r, var, lock, dir):
    ox, oy = O(r)
    open_cells = T.diff_cells(B[r], V[var], ox, oy)
    x, y, w, h = T.bbox(open_cells)
    m.entities.append({"type": "door", "id": id, "x": x, "y": y, "w": w, "h": h, "lock": lock, "dir": dir,
                       "open_patch": open_cells})


# ================================================================ R8 — Crypte des Racines
st = rooms["r8"]["stairs"][0]
m.warp(*P("r8", st["x"] + 1, st["y"] + 1), 16, 16, to="temple_sylve_rdc", spawn="escalier", style="stairs")
m.spawn("escalier", *P("r8", st["x"] + 1, st["y"] + 5), "down")
key_door("porte_r8_s", "r8", "r8_keyopen", "key", "down")
# raccourci à sens unique : la grille s'ouvre avec l'interrupteur de R12 (des deux côtés)
patch("sylve_r12_raccourci", T.diff_cells(B["r8"], V["r8_open"], *O("r8")))
for i, (cx, cy) in enumerate([(30, 20), (20, 52), (48, 30)]):
    m.enemy(f"stalfos_r8_{i + 1}", *P("r8", cx, cy), kind="stalfos", respawn=False)
for i, (cx, cy) in enumerate([(30, 10), (54, 50)]):
    m.enemy(f"keese_r8_{i + 1}", *P("r8", cx, cy), kind="keese", respawn=False)

# ================================================================ R9 — Salle obscure
for i, (cx, cy) in enumerate([(12, 30), (50, 26)]):
    tid = f"torche_r9_{i + 1}"
    m.entities.append({"type": "torch", "id": tid, "x": P("r9", cx, cy)[0], "y": P("r9", cx, cy)[1],
                       "lit": False, "group": "r9", "sprite": ""})
    patch(f"torch:{MAP}:{tid}", T.diff_cells(B["r9"], V[f"r9_t{i + 1}"], *O("r9")))
m.chest("coffre_cle_r9", *P("r9", 51, 51), item="key", flag="sylve_cle_r9")
for i, (cx, cy) in enumerate([(20, 12), (44, 52), (10, 50), (52, 10), (30, 48)]):
    m.enemy(f"keese_r9_{i + 1}", *P("r9", cx, cy), kind="keese", respawn=False)

# ================================================================ R10 — Balcon d'Oriane
patch("ch2_balcon", T.diff_cells(B["r10"], V["r10_pont"], *O("r10")))
patch("!crystal:sylve", T.diff_cells(B["r10"], V["r10_plots"], *O("r10")))
m.entities.append({"type": "crystal", "id": "cristal_r10", "x": P("r10", 39, 47)[0], "y": P("r10", 39, 47)[1],
                   "group": "sylve"})
key_door("porte_r10_o", "r10", "r10_keyopen", "key", "left")
# porte de la grande clé (mur sud) : les tuiles de la porte « grande clé » du mur nord, retournées
# verticalement (lignes 2-6 -> 63-59), posées sur la porte normale du sud (closed_patch) ; la porte
# normale revient à l'ouverture (open_patch). Pas de sprite : tout est dans le décor de la salle.
def big_key_door_south():
    ox, oy = O("r10")
    closed, opened = [], []
    for ny in range(2, 7):
        sy = 65 - ny
        for cx in range(30, 34):
            bg, fg = int(V["r10_upbk"]["bg"][ny, cx]), int(V["r10_upbk"]["fg"][ny, cx])
            closed.append({"x": ox + cx * 8, "y": oy + sy * 8, "bg": bg ^ 0x8000 if bg else 0,
                           "fg": fg ^ 0x8000 if fg else 0, "type": int(V["r10_upbk"]["types"][ny, cx])})
            opened.append({"x": ox + cx * 8, "y": oy + sy * 8, "bg": int(B["r10"]["bg"][sy, cx]),
                           "fg": int(B["r10"]["fg"][sy, cx]), "type": int(B["r10"]["types"][sy, cx])})
    return closed, opened


_bk_closed, _bk_open = big_key_door_south()
m.entities.append({"type": "door", "id": "porte_boss", "x": P("r10", 30, 59)[0], "y": P("r10", 30, 59)[1],
                   "w": 32, "h": 40, "lock": "big_key", "dir": "down",
                   "closed_patch": _bk_closed, "open_patch": _bk_open})
m.npc("oriane_balcon", *P("r10", 14, 12), sprite="npc_zelda", facing="down", script="ch2_oriane_balcon",
      name="Oriane", cond="ch2_trappe & !sylve_boss")
m.trigger("t_balcon", *P("r10", 46, 24), 96, 128, "ch2_balcon", once=True)
m.trigger("t_plots", *P("r10", 6, 28), 32, 64, "ch2_temple_plots", once=True)
m.trigger("t_boss_porte", *P("r10", 26, 50), 64, 24, "ch2_boss_porte", once=True)
m.enemy("stalfos_r10_1", *P("r10", 16, 40), kind="stalfos", respawn=False)

# ================================================================ R11 — Salle de la Grande Clé
# piège : la porte se referme derrière le héros (patch) jusqu'à ce que la salle soit vide
patch("sylve_r11_piege & !sylve_r11_vide", T.diff_cells(B["r11"], V["r11_shut"], *O("r11")))
m.trigger("t_r11_piege", *P("r11", 44, 26), 32, 72, "ch2_temple_r11_piege", once=True)
m.entities.append({"type": "trigger", "id": "t_r11_vide", "x": O("r11")[0] + 48, "y": O("r11")[1] + 48, "w": 416, "h": 416,
                   "script": "ch2_temple_r11_vide", "once": True, "spawn_on_clear": True})
# piège dosé pour un premier donjon : 3 Stalfos (le Stalfos jaune est gardé pour le ch7), 2 jarres à cœur
for i, (cx, cy) in enumerate([(47, 18), (15, 44)]):
    m.enemy(f"stalfos_r11_{i + 1}", *P("r11", cx, cy), kind="stalfos", respawn=False)
m.enemy("stalfos_r11_3", *P("r11", 31, 12), kind="stalfos", respawn=False)
m.entity("pot", "pot_r11_1", *P("r11", 20, 54), drop="heart")
m.entity("pot", "pot_r11_2", *P("r11", 42, 54), drop="heart")
m.chest("coffre_grande_cle", *P("r11", 31, 29), item="big_key", flag="sylve_grande_cle")

# ================================================================ R12 — Salle du Grand Coffre
m.chest("grand_coffre_arc", *P("r12", 30, 13), item="bow", big=True, flag="sylve_arc")
patch("sylve_r12_raccourci", T.diff_cells(B["r12"], V["r12_open"], *O("r12")))
m.entities.append({"type": "switch", "id": "inter_r12", "x": P("r12", 52, 36)[0], "y": P("r12", 52, 36)[1],
                   "kind": "floor", "flag": "sylve_r12_raccourci", "script": "ch2_temple_raccourci", "sprite": ""})
m.trigger("t_arc", *P("r12", 28, 28), 48, 16, "ch2_arc", once=False)
for i, (cx, cy) in enumerate([(6, 38), (56, 38), (20, 54), (42, 54)]):
    m.entity("pot", f"pot_r12_{i + 1}", *P("r12", cx, cy), drop=["heart", "arrows", "rupee", "arrows"][i])
m.enemy("popo_r12_1", *P("r12", 12, 32), kind="popo", respawn=False)
m.enemy("popo_r12_2", *P("r12", 40, 38), kind="popo", respawn=False)

# ================================================================ R13 — Galerie des Yeux
for i, (cx, cy) in enumerate([(55, 12), (30, 8), (6, 26)]):
    m.enemy(f"oeil_r13_{i + 1}", *P("r13", cx, cy), kind="eyegore_green", respawn=False)
m.chest("coffre_r13", *P("r13", 6, 46), item="rupee", amount=50, flag="sylve_r13_rubis")
m.entity("pot", "pot_r13_1", *P("r13", 56, 40), drop="arrows")
m.entity("pot", "pot_r13_2", *P("r13", 56, 46), drop="arrows")
m.entities.append({"type": "switch", "id": "inter_r13", "x": P("r13", 6, 54)[0], "y": P("r13", 6, 54)[1],
                   "kind": "floor", "script": "ch2_herse_r10", "flag": "sylve_herse_r10", "sprite": ""})

# ================================================================ R14 — Arène des Veilleurs
patch("sylve_herse_r10", T.diff_cells(B["r14"], V["r14_herse"], *O("r14")))
# the gate closes behind the hero during the fight (applied after the one above)
patch("sylve_boss_eveil & !sylve_boss", T.diff_cells(V["r14_herse"], B["r14"], *O("r14")))
patch("sylve_boss", T.diff_cells(B["r14"], V["r14_east"], *O("r14")))
# antichambre : deux jarres à cœur avant le combat
m.entity("pot", "pot_r14_1", *P("r14", 14, 22), drop="heart")
m.entity("pot", "pot_r14_2", *P("r14", 48, 22), drop="heart")
m.trigger("t_boss_intro", *P("r14", 24, 40), 128, 24, "ch2_boss_intro", once=True)
BOSS = {"type": "boss", "id": "veilleurs", "kind": "armos_knights", "x": P("r14", 31, 48)[0], "y": P("r14", 31, 48)[1],
        "count": 6, "flag": "sylve_boss", "on_defeat": "ch2_boss_fin",
        # arène = le dallage central sans les coins effondrés (les Veilleurs ne se posent jamais sur un trou)
        "arena": [O("r14")[0] + 104, O("r14")[1] + 312, 304, 152]}
m.entities.append(dict(BOSS, **{"if": "sylve_boss_eveil & !sylve_boss"}))

# ================================================================ R15 — Salle du Carillon
m.trigger("t_carillon", *P("r15", 2, 40), 64, 80, "ch2_carillon", once=True)
# la cloche (sprite original `bell`, 32x32) pend sous la racine horizontale (cases 30-33 x 11-14),
# au-dessus de la fosse : on la lit / la frappe depuis le bord de la fosse (dalle de lecture en (31,16))
m.entity("sign", "carillon", *P("r15", 30, 11), sprite="bell", dialogue="ch2t_carillon", any_side=True)
m.entity("sign", "carillon_bord", *P("r15", 31, 16), dialogue="ch2t_carillon")
m.npc("teleporteur", *P("r15", 50, 52), sprite="", facing="down", script="ch2_temple_sortie",
      cond="ch2_carillon")
