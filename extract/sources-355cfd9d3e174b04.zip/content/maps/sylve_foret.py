"""Forêt des Murmures (ch2, 2×2 écrans) : bois profond, clairières reliées par des sentiers,
tronc creux à traverser, trois arbres qui parlent, mauvaises sorties qui ramènent à l'entrée,
butte creuse du repaire de Fifine (nord-ouest), rocher creux de la grotte au quart de cœur
(sud-ouest), clairière secrète derrière une haie (sud-est). Disposition nouvelle.

La canopée est générée : on décrit les espaces ouverts (rectangles) et la forêt remplit le reste
(une seule région de forêt faite d'arbres entiers, tools/mapgen/forest.py). Les murs de forêt
entre deux sentiers font au moins 7 cellules (un arbre A + ses deux arbres B) pour être pleins ;
les espaces ouverts s'élargissent d'une à deux cellules là où aucun arbre entier ne tient.
(Refait par QA-CH2 pour les règles d'arbres entiers.)"""
import numpy as np
from mapdsl import *

W = H = 64
m = Map("sylve_foret", "Forêt des Murmures", size=(2, 2))
m.area(0, 0, 2, 2, name="Forêt des Murmures", music="forest", atlas=LOST_WOODS)
m.fill("grass")
m.on_enter = "ch2_brume"

# ------------------------------------------------------------------ espaces ouverts (cellules)
OPEN = [   # bords alignés sur le réseau des arbres (lignes 2 mod 3 / 2 mod 6, colonnes 1-2 / 0 mod 3)
    (28, 56, 9, 8),     # entrée sud
    (23, 47, 17, 10),   # A : clairière de l'entrée (arbre 1)
    (30, 39, 3, 8),     # tronc creux (tunnel A -> B)
    (13, 23, 27, 16),   # B : grande clairière (arbre 2, vol de Fifine)
    (0, 29, 13, 4),     # sentier ouest (mauvaise sortie au bord)
    (8, 14, 5, 15),     # sentier vers la butte creuse
    (2, 2, 17, 13),     # clairière de la butte creuse (repaire)
    (29, 0, 5, 23),     # sentier nord (mauvaise sortie)
    (40, 29, 21, 4),    # chemin des feuilles rousses (est)
    (47, 14, 14, 15),   # les deux troncs couchés : passer ENTRE eux (à l'ouest : le détour)
    (44, 2, 17, 13),    # C : clairière de l'arbre 3
    (61, 7, 3, 4),      # sortie est -> coupe des bûcherons
    (2, 44, 14, 7),     # clairière sud-ouest (écureuil, rocher creux)
    (16, 47, 7, 4),     # sentier A -> sud-ouest
    (40, 47, 7, 4),     # haie de buissons -> clairière secrète
    (47, 44, 14, 13),   # clairière secrète (coffre)
]
opn = np.zeros((H, W), bool)
for x, y, w, h in OPEN:
    opn[y:y + h, x:x + w] = True


def fill_forest():
    """The forest region = everything not open, as rectangles (runs merged vertically)."""
    runs = {}
    for y in range(H):
        x = 0
        while x < W:
            if opn[y, x]:
                x += 1
                continue
            x0 = x
            while x < W and not opn[y, x]:
                x += 1
            runs.setdefault(y, []).append((x0, x - x0))
    rects = []
    for y in range(H):
        for x0, w in runs.get(y, []):
            for r in rects:
                if r[0] == x0 and r[2] == w and r[1] + r[3] == y:
                    r[3] += 1
                    break
            else:
                rects.append([x0, y, w, 1])
    for x0, y0, w, h in rects:
        m.forest(x0, y0, w, h, edges="")      # les bords continuent au-delà de la carte
    # Map.forest ne retire pas les cellules d'un arbre dessiné par un appel précédent puis élagué
    # par un rectangle ajouté ensuite (bout d'arbre coupé) : on efface ces restes.
    import forest as F
    ids, _, _ = F.render(m._forest_region, m._forest_open, LOST_WOODS)
    for cy, cx in zip(*np.nonzero(m._forest_cells & (ids < 0))):
        m.erase(int(cx), int(cy))


# ------------------------------------------------------------------ terrain (avant la forêt)
P = "path"
m.terrain_rect(31, 48, 2, 16, P)                   # entrée -> A -> tronc creux
m.terrain_rect(31, 24, 2, 14, P)                   # tronc -> B
m.terrain_rect(1, 30, 31, 2, P)                    # B -> sentier ouest
m.terrain_rect(10, 23, 2, 7, P)                    # -> la butte creuse (des buissons coupent le sentier)
m.terrain_rect(10, 11, 2, 8, P)
m.terrain_rect(31, 18, 2, 6, P)                    # sentier nord (mauvais) ...
m.terrain_rect(31, 0, 2, 10, P)                    # ... coupé par un tronc couché
m.terrain_rect(33, 30, 23, 2, P)                   # est
m.terrain_rect(55, 9, 1, 21, P)                    # nord, entre les troncs
m.terrain_rect(55, 9, 8, 1, P)                     # sortie est
m.terrain_rect(14, 48, 17, 1, P)                   # A -> sud-ouest
# feuilles rousses : hautes herbes le long du bon chemin
m.terrain(47, 21, ["tt"] * 5)
m.terrain(47, 33, ["tttt"] * 2)
m.terrain(24, 34, ["tttt", "tttt", "tt.."])
m.terrain(52, 49, ["tttt", "tttt", "tt.."])

fill_forest()

# ------------------------------------------------------------------ troncs creux / couchés
m.strip("log_v", 30, 39, 8)                        # le tunnel A -> B (on passe dedans)
for y in range(39, 47):                            # broussailles entre le tronc et les arbres
    for x in list(range(26, 30)) + list(range(33, 37)):
        if not m._forest_cells[y, x]:
            m.tile(x, y, "bush")
m.strip("log_v", 30, 12, 4)                        # leurre sur le sentier nord (« les champignons »)
m.strip("log_v", 50, 17, 12)                       # les deux troncs couchés : passer ENTRE eux
m.strip("log_v", 58, 17, 6)

# ------------------------------------------------------------------ entrées secrètes
m.plateau(7, 3, 7, 7)                              # la butte creuse (repaire de Fifine)
repaire = m.stamp("cave_in_wall", 9, 7)
m.plateau(3, 44, 6, 6)                             # le rocher creux (grotte du quart de cœur)
creux = m.stamp("cave_in_wall", 5, 47)
m.rect(40, 47, 7, 4, "bush")                       # haie de la clairière secrète
m.rect(8, 20, 5, 2, "bush")                        # les buissons que Fifine traverse

# ------------------------------------------------------------------ décor des clairières
m.stamp("tree_dark", 35, 50)                       # A
m.stamp("stump", 25, 53)
m.tiles([(24, 55), (38, 55), (27, 55), (39, 48)], "bush")
m.tiles([(26, 51), (35, 55), (29, 55)], "flowers")
m.stamp("tree_dark", 17, 24)                       # B
m.stamp("tree_dark", 35, 33)
m.stamp("stump", 36, 26)
m.stamp("tree_small", 20, 35)
m.stamp("boulder", 26, 25)
m.tiles([(15, 35), (22, 25), (39, 26), (34, 37), (29, 34)], "bush")
m.tiles([(34, 28), (19, 33), (39, 24), (25, 28)], "flowers")
m.stamp("stump", 3, 11)                            # clairière de la butte creuse
m.stamp("stump", 15, 9)
m.tiles([(4, 4), (15, 4), (17, 6), (4, 8)], "bush")
m.stamp("tree_dark", 48, 3)                        # C
m.stamp("stump", 58, 11)
m.tiles([(46, 12), (59, 3), (52, 12)], "bush")
m.tiles([(52, 8), (57, 5), (46, 8)], "flowers")
m.stamp("stump", 12, 44)                           # sud-ouest
m.tiles([(3, 49), (14, 45)], "bush")
m.stamp("tree_small", 57, 46)                      # clairière secrète
m.tiles([(50, 46), (58, 54), (51, 54)], "flowers")
m.tiles([(48, 18), (47, 27)], "rock")              # détour : pierres (« les champignons »)
m.tiles([(31, 20), (32, 17), (32, 7)], "rock")

# ------------------------------------------------------------------ PNJ, panneau, coffre
m.npc("arbre_1", cell=(27, 51), sprite="npc_dw_hint_tree", script="ch2_arbre_1", name="Arbre")
m.npc("arbre_2", cell=(38, 30), sprite="npc_dw_hint_tree", script="ch2_arbre_2", name="Arbre")
m.npc("arbre_3", cell=(53, 9), sprite="npc_dw_hint_tree", script="ch2_arbre_3", name="Arbre")
m.npc("ecureuil", cell=(10, 49), sprite="npc_lost_woods_squirrel", dialogue="ch2_ecureuil", wander=16,
      name="Écureuil")
m.sign("panneau_foret", 34, 58, "ch2_panneau_foret")
m.chest("coffre_clairiere", cell=(56, 51), item="rupee", amount=20)

# ------------------------------------------------------------------ déclencheurs
m.trigger("t_vol", 21 * 16, 27 * 16, 5 * 16, 6 * 16, "ch2_fifine_vol", once=True,
          cond="ch2_cle_temple & !ch2_fifine_vol")
m.trigger("t_boucle_ouest", 0, 28 * 16, 24, 64, "ch2_foret_boucle", once=False)
m.trigger("t_boucle_nord", 28 * 16, 0, 96, 24, "ch2_foret_boucle", once=False)
m.trigger("t_boucle_detour", 47 * 16, 14 * 16, 48, 24, "ch2_foret_boucle", once=False)

# ------------------------------------------------------------------ ennemis
m.enemy("moblin_1", cell=(23, 36), kind="octorok")
m.enemy("moblin_2", cell=(42, 29), kind="octorok")
m.enemy("moblin_3", cell=(55, 5), kind="octorok")
m.enemy("moblin_4", cell=(52, 31), kind="octorok")
m.enemy("rope_1", cell=(33, 53), kind="rope")
m.enemy("rope_2", cell=(12, 47), kind="rope")
m.enemy("rope_3", cell=(59, 13), kind="rope")
m.enemy("corbeau_1", cell=(12, 30), kind="rope")

# ------------------------------------------------------------------ liaisons
m.warp_edge("down", to="sylve_lisiere", spawn="nord", start=29 * 16, length=6 * 16)
m.warp_edge("right", to="sylve_bucherons", spawn="ouest", start=7 * 16, length=4 * 16)
m.warp_door(repaire, to="fifine_repaire", spawn="porte")
m.warp_door(creux, to="sylve_grotte_coeur", spawn="porte")
m.spawn("repaire", *repaire.outside, "down")
m.spawn("arbre_creux", *creux.outside, "down")
m.spawn_cell("sud", 31, 61, "up")
m.spawn_cell("est", 61, 8, "left")
m.spawn_cell("start", 31, 55, "up")
