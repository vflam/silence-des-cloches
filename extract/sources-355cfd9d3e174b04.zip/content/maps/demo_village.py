"""Village de démonstration (2×2 écrans), entièrement recomposé avec les outils de terrain et
les tampons : forêt tout autour, chemins, place avec une mare, maisons, jardins, plateau
avec grotte. Sert d'exemple aux level designers (voir docs/tech/MAPS.md)."""
from mapdsl import *

m = Map("demo_village", "Village de démo", size=(2, 2))
m.area(0, 0, 2, 2, name="Village de démo", music="village", atlas=LIGHT)
m.fill("grass")

# --- 1. terrain (toujours avant les tampons) -------------------------------------------------
P = "path"
m.terrain_rect(22, 20, 20, 1, P)      # place : anneau de chemin
m.terrain_rect(22, 31, 20, 1, P)
m.terrain_rect(22, 20, 1, 12, P)
m.terrain_rect(41, 20, 1, 12, P)
m.terrain_rect(14, 18, 1, 5, P)       # maison rouge -> place
m.terrain_rect(14, 22, 9, 1, P)
m.terrain_rect(41, 20, 6, 1, P)       # maison bleue -> place
m.terrain_rect(46, 18, 1, 3, P)
m.terrain_rect(22, 31, 1, 11, P)      # place -> maisons du sud-ouest
m.terrain_rect(13, 41, 10, 1, P)
m.terrain_rect(13, 40, 1, 2, P)
m.terrain_rect(19, 39, 1, 3, P)
m.terrain_rect(41, 31, 1, 11, P)      # place -> maison au bois
m.terrain_rect(41, 41, 6, 1, P)
m.terrain_rect(46, 40, 1, 2, P)
m.terrain_rect(32, 31, 2, 33, P)      # grand chemin vers le sud (sortie)
m.terrain_rect(33, 53, 21, 1, P)      # vers la grotte du plateau
m.terrain(29, 24, [                   # la mare au milieu de la place
    ".~~~~.",
    "~~~~~~",
    "~~~~~~",
    ".~~~~.",
])
m.terrain(8, 24, ["tttt", "tttt", "tttttt", "tttttt", ".ttt"])       # herbes hautes
m.terrain(36, 45, ["..tttt", "..tttt", "tttttt", "tttt.."])

# --- 2. forêt tout autour (lisières dessinées côté village) ----------------------------------
m.forest(0, 0, 64, 9, edges="s")
m.forest(0, 8, 7, 56, edges="e")
m.forest(57, 8, 7, 56, edges="w")
m.forest(6, 55, 26, 9, edges="ne")
m.forest(34, 55, 24, 9, edges="nw")

# --- 3. maisons (porte en bas : chemin en dessous) --------------------------------------------
maison = m.stamp("house_red_m", 12, 12)          # la maison de la démo (porte -> demo_house)
m.stamp("house_blue_m", 44, 12)
m.stamp("house_thatch", 11, 33)
m.stamp("shed_thatch", 18, 34)
m.stamp("house_blue_woodpile", 44, 33)

# --- 4. la place : puits, arbres roses, fleurs, panneau ----------------------------------------
m.stamp("tree_pink", 24, 22)
m.stamp("tree_pink", 38, 22)
m.stamp("tree_pink", 24, 28)
m.stamp("tree_pink", 38, 28)
m.stamp("well", 26, 25)
m.tiles([(28, 23), (35, 23), (29, 29), (35, 28), (36, 25)], "flowers")
m.sign("panneau_place", 32, 29, "demo_panneau_place")

# --- 5. jardins : clôture et buissons, haie et fleurs ------------------------------------------
m.strip("fence_h", 8, 50, 11)
m.strip("fence_v", 8, 45, 5)
m.strip("fence_v", 18, 45, 5)
m.strip("fence_h", 8, 44, 4)
m.strip("fence_h", 15, 44, 4)
m.rect(10, 46, 7, 3, "bush")
m.strip("fence_h", 49, 22, 7)          # (les haies taillées ont un fond de pavés : clôture sur l'herbe)
m.rect(50, 24, 5, 2, "flowers")
m.rect(50, 26, 5, 1, "flowers2")
m.strip("fence_v", 49, 23, 4)

# --- 6. plateau au sud-est et sa grotte (rien ne se pose sur un plateau ; l'escalier de plateau
#        raccorde mal : pour une terrasse accessible, voir le rebord ledge_s de sylve_plateau) ---
m.plateau(44, 44, 12, 9)
m.stamp("cave_in_wall", 52, 50)
m.tiles([(42, 47), (43, 51), (56, 49)], "rock")

# --- 7. arbres, souches, statues ----------------------------------------------------------------
m.stamp("tree", 8, 13)
m.stamp("tree", 25, 10)
m.stamp("tree", 36, 10)
m.stamp("tree_small", 53, 29)
m.stamp("tree", 24, 45)
m.stamp("stump", 17, 28)
m.stamp("boulder", 38, 36)
m.stamp("statue_armos", 29, 50)
m.stamp("statue_armos", 35, 50)
m.tiles([(9, 30), (10, 31), (27, 39), (28, 40), (36, 40), (52, 40), (53, 41), (31, 14), (32, 15)], "bush")
m.tiles([(12, 30), (27, 35), (26, 36), (37, 38), (55, 32), (20, 15), (41, 15), (42, 16)], "flowers")

# --- 8. liaisons, arrivées, habitants ------------------------------------------------------------
m.warp_door(maison, to="demo_house", spawn="entry")
m.spawn("from_house", *maison.outside, "down")
m.warp_edge("down", to="test_overworld", spawn="demo", start=32 * 16, length=2 * 16)
m.spawn("south", 32 * 16, 60 * 16, "up")
m.spawn("start", 32 * 16, 33 * 16, "up")
m.npc("ancien", cell=(30, 30), sprite="npc_old_man", facing="down", dialogue="demo_ancien", name="Ancien")
m.npc("enfant", cell=(18, 24), sprite="npc_flute_kid", facing="right", wander=32, dialogue="demo_enfant")
m.entity("pot", "pot_1", cell=(17, 16))
m.chest("coffre_plateau", cell=(42, 49), item="rupee", amount=20)
