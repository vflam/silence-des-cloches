"""Crypte des Fondeurs (chapitre 1) : mini-donjon tutoriel, 5 salles NEUVES construites avec
roomgen (pierre grise et terre ocre, graphismes du passage secret du château).

    C2 (0,0) ─ C1 (1,0)            C5 (2,0)
                 │ porte à clé        ║ grille (ch1_torches)
    (vide)     C3 (1,1) ─ bloc ─ C4 (2,1)

C1 entrée (escalier vers la chapelle) → C2 petite clé → C1 porte à clé → C3 lanterne + bloc
à pousser → C4 salle sombre (Ori, deux torches) → C5 battant + interrupteur (raccourci).
Portes fermées : entités `door` dont `open_patch` = différence entre la salle construite avec
la porte fermée et la même salle avec la porte ouverte."""
import copy
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("aube_crypte", "Crypte des Fondeurs", kind="dungeon", size=(3, 2), dungeon="crypte")
m.empty_screen(0, 1)
NAME, MUSIC = "Crypte des Fondeurs", "cave"
HEAD = {"blockset": 0x10, "palette": 1, "floor1": 0, "floor2": 0, "layout": 7, "bg_mode": "off"}


def P(sx, sy, x, y):
    """Map pixels of tile8 cell (x, y) of screen (sx, sy)."""
    return sx * 512 + x * 8, sy * 512 + y * 8


def room(sx, sy, name, objects, doors, dark=False, **kw):
    spec = {"name": name, **HEAD, "objects": objects, "doors": doors, **kw}
    return m.room_custom(sx, sy, spec, name=NAME, music=MUSIC, dark=dark), spec


def patch(sx, sy, closed_spec, open_spec):
    """(closed_patch, open_patch) : cells that differ between two builds of a room."""
    a, b = G.build_rooms([closed_spec, open_spec])
    ga = {k: G.grid(a, k) for k in ("bg", "fg", "types")}
    gb = {k: G.grid(b, k) for k in ("bg", "fg", "types")}
    closed, opened = [], []
    for y in range(64):
        for x in range(64):
            if any(ga[k][y, x] != gb[k][y, x] for k in ga):
                px, py = P(sx, sy, x, y)
                closed.append({"x": px, "y": py, "bg": int(ga["bg"][y, x]), "fg": int(ga["fg"][y, x]),
                               "type": int(ga["types"][y, x])})
                opened.append({"x": px, "y": py, "bg": int(gb["bg"][y, x]), "fg": int(gb["fg"][y, x]),
                               "type": int(gb["types"][y, x])})
    return closed, opened


def with_door(spec, i, kind):
    s = copy.deepcopy(spec)
    s["name"] += "_open"
    s["doors"][i] = [s["doors"][i][0], s["doors"][i][1], kind]
    return s


def mold(x, y):
    """A broken bell mould: a big jar (4x4)."""
    return ["fairy_pot", x, y]


# =============================================================================================
# C1 — Escalier des Fondeurs (écran 1,0)
# =============================================================================================
c1_objs = [
    *G.fill("floor_area4", 28, 8, 8, 52),                         # allée dallée nord-sud
    *G.fill("floor_area4", 8, 28, 20, 8),                          # allée vers C2 (ouest)
    ["spiral_up", 30, 3],                                           # escalier vers la chapelle
    ["wall_torches_n_h", 20, 4, 1], ["wall_torches_n_h", 40, 4, 1],
    ["statue", 24, 8], ["statue", 38, 8],
    ["wall_decor_n_h", 12, 4, 1], ["wall_decor_n_h", 48, 4, 1],
    mold(10, 12), mold(48, 12), mold(10, 44), mold(48, 44),         # moules brisés
    ["column_h", 20, 18, 1], ["column_h", 40, 18, 1],
    ["column_h", 20, 40, 1], ["column_h", 40, 40, 1],
    ["statue", 24, 52], ["statue", 38, 52],
]
c1_doors = [["left", 1, "normal"], ["down", 7, "small_key"]]
c1, c1_spec = room(1, 0, "ch1_crypte_c1", c1_objs, c1_doors)
c1_closed, c1_open = patch(1, 0, c1_spec, with_door(c1_spec, 1, "normal"))

# escalier → chapelle ; arrivée juste sous l'escalier
x, y = P(1, 0, 31, 4)
m.warp(x, y, 16, 16, "aube_chapelle", "crypte", style="stairs")
m.spawn("entree", *P(1, 0, 31, 8), "down")
m.entity("sign", "panneau_crypte", *P(1, 0, 12, 5), dialogue="ch1_crypte_panneau", w=32)
for i, (cx, cy) in enumerate([(22, 22), (40, 26), (30, 36)]):
    m.enemy(f"c1_rat_{i + 1}", *P(1, 0, cx, cy), kind="rat", respawn=False)
for i, ((cx, cy), drop) in enumerate(zip([(6, 52), (8, 54), (54, 52), (56, 54)], ["heart", "", "rupee", ""])):
    m.entity("pot", f"c1_jarre_{i + 1}", *P(1, 0, cx, cy), **({"drop": drop} if drop else {}))
m.entity("door", "c1_porte_cle", *P(1, 0, 30, 59), w=32, h=24, lock="key", dir="down",
         closed_patch=c1_closed, open_patch=c1_open)

# =============================================================================================
# C2 — Salle des Moules (écran 0,0) : on contourne une rangée de moules géants
# =============================================================================================
c2_objs = [
    *G.fill("floor_area4", 36, 28, 24, 8),                         # dallage devant la porte est
    *G.pillar(8, 16, 36, 12),                                       # massif nord (moules géants)
    *G.pillar(20, 36, 40, 12),                                      # massif sud : chemin en S
    mold(12, 30), mold(12, 50), mold(52, 8), mold(28, 50),
    ["statue", 14, 8], ["statue", 22, 8], ["statue", 30, 8],
    ["wall_torches_n_h", 46, 4, 1],
    ["floor_area3", 8, 32, 0],                                      # socle du coffre
]
c2, c2_spec = room(0, 0, "ch1_crypte_c2", c2_objs, [["right", 7, "normal"]])
m.chest("c2_cle", *P(0, 0, 9, 34), item="key", amount=1)
m.enemy("c2_rat_1", *P(0, 0, 46, 22), kind="rat", respawn=False)
m.enemy("c2_rat_2", *P(0, 0, 30, 54), kind="rat", respawn=False)
m.enemy("c2_rat_3", *P(0, 0, 50, 54), kind="rat", respawn=False)

# =============================================================================================
# C3 — Salle de la Lanterne (écran 1,1) : grand coffre, bloc qui bouche la sortie est
# =============================================================================================
BLK = "block"
c3_objs = [
    *G.fill("floor_area4", 24, 24, 16, 16),                        # dallage sous le grand coffre
    *G.fill("floor_area4", 28, 8, 8, 16),
    ["statue", 22, 20], ["statue", 40, 20], ["statue", 22, 38], ["statue", 40, 38],
    ["wall_torches_n_h", 16, 4, 1], ["wall_torches_n_h", 44, 4, 1],
    mold(8, 8), mold(8, 50), mold(26, 50),
    # murets qui ferment le couloir de la sortie est (rangées 32-33) : il faut pousser le bloc
    *[[BLK, bx, 30] for bx in range(44, 58, 2) if bx != 50],       # muret nord, trouée en x 50
    *[[BLK, bx, 34] for bx in range(44, 58, 2) if bx != 50],       # muret sud, niche en x 50
    [BLK, 44, 32], [BLK, 50, 36],                                   # bout ouest, fond de niche
]
c3, c3_spec = room(1, 1, "ch1_crypte_c3", c3_objs, [["up", 1, "normal"], ["right", 7, "normal"]])
m.entity("chest", "c3_lanterne", *P(1, 1, 30, 29), item="lantern", amount=1, big=True, locked=False)
m.entity("block", "c3_bloc", *P(1, 1, 50, 32), pushable=True, dir="down", sprite="rock_heavy",
         moved_to=list(P(1, 1, 50, 34)))
m.entity("sign", "c3_inscription", *P(1, 1, 50, 26), dialogue="ch1_crypte_bloc", any_side=True)
for i, (cx, cy) in enumerate([(12, 18), (52, 16), (30, 46)]):
    m.enemy(f"c3_keese_{i + 1}", *P(1, 1, cx, cy), kind="keese", respawn=False)

# =============================================================================================
# C4 — Salle des Runes (écran 2,1), sombre : Ori, deux torches, grille au nord
# =============================================================================================
c4_objs = [
    *G.fill("floor_area4", 28, 8, 8, 20),
    *G.fill("floor_area4", 8, 28, 28, 8),
    ["wall_decor_n_h", 12, 4, 2], ["wall_decor_n_h", 42, 4, 2],     # murs de runes
    ["statue", 20, 10], ["statue", 42, 10],
    mold(8, 48), mold(52, 48), mold(52, 8),
    ["column_h", 16, 40, 1], ["column_h", 44, 40, 1],
]
c4_doors = [["left", 1, "normal"], ["up", 1, "shutter"]]
c4, c4_spec = room(2, 1, "ch1_crypte_c4", c4_objs, c4_doors, dark=True,
                   torches=[[24, 8, False], [38, 8, False]])
c4_closed, c4_open = patch(2, 1, c4_spec, with_door(c4_spec, 1, "normal"))
m.entity("door", "c4_grille", *P(2, 1, 30, 4), w=32, h=24, lock="flag:ch1_torches", dir="up",
         closed_patch=c4_closed, open_patch=c4_open)
for i, cx in enumerate((24, 38)):   # type `torch` (CORE) inconnu du DSL : ajouté à la main
    tx, ty = P(2, 1, cx, 8)
    m.entities.append({"type": "torch", "id": f"torche_{i + 1}", "x": tx, "y": ty, "lit": False,
                       "group": "c4", "script": "ch1_torches_ok", "sprite": "torch"})
# pas de sprite `torch` : les torches sont dessinées par la salle ; une fois les deux allumées,
# une « porte » invisible (drapeau ch1_torches) remplace leurs tuiles par des torches allumées
lit_spec = copy.deepcopy(c4_spec)
lit_spec["name"] += "_lit"
lit_spec["torches"] = [[24, 8, True], [38, 8, True]]
t_closed, t_open = patch(2, 1, c4_spec, lit_spec)
m.entity("door", "c4_torches_allumees", *P(2, 1, 24, 8), w=16, h=16, lock="flag:ch1_torches", dir="up",
         closed_patch=t_closed, open_patch=t_open)
m.npc("ori", *P(2, 1, 16, 10), sprite="npc_zelda", facing="up", dialogue="ch1_crypte_ori_repete",
      name="Ori", cond="!ch1_torches")
m.trigger("c4_entree", *P(2, 1, 6, 28), 16, 48, "ch1_crypte_ori", once=True)
m.entity("sign", "c4_grille_panneau", *P(2, 1, 30, 10), dialogue="ch1_crypte_porte_torches",
         cond="!ch1_torches", w=32)
m.chest("c4_rubis", *P(2, 1, 50, 30), item="rupee", amount=20, cond="ch1_torches")

# =============================================================================================
# C5 — Chambre du Battant (écran 2,0) : salle ronde, socle au centre, interrupteur, raccourci
# =============================================================================================
c5_objs = [
    *G.fill("floor_area4", 20, 20, 24, 24),
    *G.fill("floor_area4", 28, 44, 8, 16),
    *G.pillar(5, 7, 12, 12), *G.pillar(47, 7, 12, 12),            # angles comblés
    *G.pillar(5, 47, 12, 12), *G.pillar(47, 47, 12, 12),
    ["table_rock", 30, 28],                                         # le socle du battant
    ["statue", 24, 26], ["statue", 38, 26], ["statue", 24, 36], ["statue", 38, 36],
    ["floor_switch", 44, 48],
    ["wall_torches_n_h", 18, 4, 1], ["wall_torches_n_h", 42, 4, 1],
]
c5_stairs = ["spiral_up", 30, 3]
c5, c5_spec = room(2, 0, "ch1_crypte_c5", c5_objs, [["down", 7, "normal"]])
open_spec = copy.deepcopy(c5_spec)
open_spec["name"] += "_open"
open_spec["objects"].append(c5_stairs)
c5_closed, c5_open = patch(2, 0, c5_spec, open_spec)
m.entity("door", "c5_trappe", *P(2, 0, 30, 3), w=32, h=32, lock="flag:ch1_raccourci", dir="up",
         closed_patch=c5_closed, open_patch=c5_open)
x, y = P(2, 0, 31, 4)
wd = m.warp(x, y, 16, 16, "aube_chapelle", "trappe", style="stairs")
wd["if"] = "ch1_raccourci"
m.spawn("trappe", *P(2, 0, 31, 8), "down")
m.entity("sign", "socle", *P(2, 0, 30, 30), w=32, h=32, script="ch1_battant", any_side=True, solid=True)
m.entity("switch", "c5_interrupteur", *P(2, 0, 44, 48), kind="floor", script="ch1_raccourci",
         sprite="shadow")   # l'interrupteur est dessiné par la salle
m.enemy("c5_rat_1", *P(2, 0, 14, 40), kind="rat", respawn=False)
m.enemy("c5_rat_2", *P(2, 0, 48, 38), kind="rat", respawn=False)
m.enemy("c5_keese_1", *P(2, 0, 16, 16), kind="keese", respawn=False)
m.enemy("c5_keese_2", *P(2, 0, 46, 16), kind="keese", respawn=False)
