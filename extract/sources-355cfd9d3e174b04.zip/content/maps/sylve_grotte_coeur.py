"""Grotte de l'arbre creux (salle neuve, plan inventé) : sous les racines, une cavité en
fer à cheval autour d'un bloc de roche ; deux flaques ; le coffre au quart de cœur attend
au fond, côté est, derrière le rocher."""
from mapdsl import *
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("sylve_grotte_coeur", "Grotte de l'arbre creux", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch2_sylve_grotte_coeur", "blockset": 0x14, "palette": 7, "floor1": 1, "layout": 0,
    "objects": [
        *G.pillar(12, 36, 12, 16),                 # le rocher central (fer à cheval autour)
        ["water_area", 6, 52, 0],                  # flaques
        ["water_area", 22, 54, 0],
    ],
    "doors": [["down", 6, "exit_cave"]],
}, name="Grotte de l'arbre creux", music="cave")

door = room["doors"][0]
m.warp_room_door(door, to="sylve_foret", spawn="arbre_creux")
m.spawn_room_door("porte", door)
m.chest("coffre_coeur", cell=(24, 39), item="heart_piece")
m.entity("pot", "jarre_1", cell=(6, 40), drop="rupee")
m.entity("pot", "jarre_2", cell=(8, 40))
m.entity("pot", "jarre_3", cell=(25, 50), drop="heart")
m.enemy("keese_1", cell=(8, 46), kind="keese")
