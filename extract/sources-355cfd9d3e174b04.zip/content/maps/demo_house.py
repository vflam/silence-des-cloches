"""Intérieur de la maison rouge du village de démo : une salle NEUVE construite avec le
constructeur de salles d'INTERIORS (tools/roomgen, objets de salle d'ALttP), placée dans le
quart bas-droit de l'écran ; zone = ce quart (rect_px)."""
from mapdsl import *

m = Map("demo_house", "Maison de l'ancien", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "demo_house", "blockset": 3, "palette": 21, "floor1": 3, "layout": 0, "start_quadrant": 3,
    "objects": [["bed", 38, 38], ["table", 48, 44], ["chest", 56, 40], ["pot", 37, 52], ["pot", 39, 52]],
    "doors": [["down", 8]],
}, name="Maison de l'ancien", music="village")

door = room["doors"][0]                      # porte du bas : {"dir", "x", "y"} en cases 8×8
m.warp_room_door(door, to="demo_village", spawn="from_house")
m.spawn_room_door("entry", door)
m.npc("ancien_maison", cell=(44, 48), sprite="npc_old_man", facing="down", dialogue="demo_ancien_maison")
