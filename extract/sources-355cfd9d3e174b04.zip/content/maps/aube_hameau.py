"""Val de l'Aube — le hameau de la Forge (chapitre 1). Disposition inventée : un promontoire
herbeux fermé par la forêt au nord, à l'ouest, au sud et à l'est ; un étang au nord-est. La
maison-forge au centre-ouest, son potager clôturé, la route du nord bouchée par un éboulement,
et le grand chemin qui file vers l'ouest (bois de l'Aube) par une trouée de la forêt.
(Refait par QA-CH1 : forêt en arbres entiers, objets posés sur l'herbe.)"""
from mapdsl import *

m = Map("aube_hameau", "Val de l'Aube", size=(1, 1))
m.area(0, 0, 1, 1, name="Val de l'Aube", music="village", atlas=LIGHT)
m.on_enter = "aube_village_enter"
m.fill("grass")

# --- 1. terrain ----------------------------------------------------------------------------
P = "path"
m.terrain_rect(14, 6, 2, 11, P)         # route du nord (jusqu'à l'éboulement)
m.terrain_rect(11, 17, 5, 2, P)         # seuil de la forge
m.terrain_rect(0, 20, 16, 2, P)         # grand chemin vers l'ouest (bois)
m.terrain_rect(14, 19, 2, 1, P)
m.terrain_rect(16, 17, 8, 2, P)         # sentier vers l'étang
m.terrain_rect(22, 12, 2, 5, P)
m.terrain(19, 4, [
    "...~~~~.",
    "..~~~~~~",
    ".~~~~~~~",
    ".~~~~~~~",
    "..~~~~~.",
    "...~~~..",
])
m.terrain(5, 24, ["..tttt", "tttttt", "tttt.."])     # herbes hautes au sud-ouest
m.terrain(23, 21, ["tttt", "tttt", "..tt"])

# --- 2. bordures : forêt tout autour, trouée à l'ouest (chemin) et au nord (route) -----------
m.forest(0, 0, 13, 7, edges="se")
m.forest(12, 0, 7, 4, edges="s")   # la forêt se referme au-dessus de l'éboulement
m.forest(17, 0, 11, 4, edges="sw")
m.forest(0, 7, 5, 12, edges="e")
m.forest(0, 23, 5, 9, edges="ne")
m.forest(5, 27, 27, 5, edges="n")
m.forest(28, 0, 4, 27, edges="w")

# --- 3. la maison-forge et son potager --------------------------------------------------------
forge = m.stamp("house_thatch", 10, 10)
m.strip("fence_h", 5, 11, 4)
m.strip("fence_v", 5, 12, 4)
m.strip("fence_h", 5, 16, 4)
m.rect(6, 12, 3, 4, "bush")          # rangs du potager (buissons à couper)
m.tiles([(6, 13), (8, 14)], "grass")
m.stamp("barrel", 17, 12)
m.stamp("barrel", 18, 13)
m.stamp("trough", 17, 15)
m.stamp("mailbox", 16, 15)

# --- 4. éboulement sur la route du nord ------------------------------------------------------
m.stamp("rock_pile", 13, 4)
m.stamp("boulder", 15, 4)
m.tiles([(12, 5), (17, 5), (16, 6), (13, 6)], "rock_heavy")
m.sign("panneau_eboulement", 17, 7, "ch1_panneau_eboulement")

# --- 5. arbres, souches, fleurs --------------------------------------------------------------
m.stamp("tree_small", 20, 10)
m.stamp("stump", 19, 24)
m.stamp("tree_pink", 7, 18)
m.tiles([(8, 8), (10, 8), (19, 9), (26, 14), (27, 15), (11, 25), (12, 25), (18, 21),
         (24, 15), (21, 20), (6, 22)], "flowers")
m.tiles([(19, 15), (20, 16), (26, 18), (27, 19), (13, 24)], "grass_tuft")
m.tiles([(25, 11), (26, 11), (27, 12), (15, 25), (16, 25), (22, 25)], "bush")
m.tiles([(20, 22), (21, 23)], "rock")

# --- 6. panneaux, habitants ----------------------------------------------------------------
m.sign("panneau_forge", 9, 17, "ch1_panneau_forge")
m.sign("panneau_ouest", 4, 19, "ch1_panneau_hameau_ouest")
m.npc("colin", cell=(18, 22), sprite="npc_locksmith", dialogue="ch1_colin_1", wander=48,
      name="Colin", cond="!ch1_silence")
m.npc("colin_post", cell=(18, 22), sprite="npc_locksmith", dialogue="ch1_colin_post", wander=16,
      name="Colin", cond="ch1_silence")
for i, (cx, cy, drop) in enumerate([(22, 25, "rupee"), (15, 25, "heart"), (16, 25, "rupee5"),
                                     (6, 12, "heart"), (27, 12, "rupee")]):
    m.entity("bush", f"buisson_{i + 1}", cell=(cx, cy), drop=drop)
m.entity("pot", "jarre_hameau", cell=(20, 13), drop="rupee")
m.enemy("rat_hameau", cell=(24, 24), kind="rat", cond="ch1_silence")

# --- 7. liaisons ----------------------------------------------------------------------------
m.warp_door(forge, to="forge_maison", spawn="porte")["rect"][3] = 12
m.spawn("porte", *forge.outside, "down")
# bande de 12 px : le centre des pieds du héros ne descend pas sous x = 8 au bord de la carte
m.warp(0, 19 * 16, 12, 4 * 16, "aube_bois", "est", style="edge")
m.spawn_cell("ouest", 1, 20, "right")
m.spawn_cell("start", 13, 19, "down")
