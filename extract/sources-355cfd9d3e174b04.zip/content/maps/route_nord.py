"""Route du Nord (ch2) : carrefour de nuit entre le village de l'Aube (sud), l'abbaye (est)
et la Forêt des Murmures (ouest). Relais de Sibylle dans son enclos. Disposition nouvelle."""
from mapdsl import *

m = Map("route_nord", "Route du Nord", size=(1, 1))
m.area(0, 0, 1, 1, name="Route du Nord", music="overworld", atlas=LIGHT)
m.fill("grass")
m.on_enter = "ch2_nuit"

# --- terrain ---------------------------------------------------------------------------------
P = "path"
m.terrain_rect(20, 9, 2, 23, P)       # grand axe nord-sud (sortie sud -> village)
m.terrain_rect(0, 9, 22, 2, P)        # branche ouest -> lisière
m.terrain_rect(20, 21, 12, 2, P)      # branche est -> abbaye
m.terrain_rect(13, 19, 1, 4, P)       # sentier du relais
m.terrain_rect(13, 22, 8, 1, P)
m.terrain(4, 14, [".~~~.",
                  "~~~~~",
                  "~~~~~",
                  ".~~~."])           # mare
m.terrain(3, 23, ["..tttt.",
                  ".tttttt",
                  "ttttttt",
                  "tttttt.",
                  ".ttt..."])        # hautes herbes (octoroks)
m.terrain(24, 3, [".tttt",
                  "ttttt",
                  "tttt.",
                  ".tt.."])

# --- bois tout autour ------------------------------------------------------------------------
m.forest(0, 0, 32, 3, edges="s")
m.forest(0, 12, 3, 17, edges="e")          # ouest, sous la branche
m.forest(29, 2, 3, 18, edges="w")          # est, au-dessus de la branche est
m.forest(29, 24, 3, 5, edges="w")          # est, sous la branche est
m.forest(0, 29, 20, 3, edges="n")
m.forest(22, 29, 10, 3, edges="n")
m.forest(0, 2, 3, 7, edges="e")            # coin nord-ouest (au-dessus de la branche)

# --- le relais de Sibylle et son enclos -------------------------------------------------------
relais = m.stamp("house_red_m", 11, 13)
m.strip("fence_v", 9, 13, 7)
m.strip("fence_h", 9, 20, 3)
m.strip("fence_h", 16, 20, 3)
m.strip("fence_h", 9, 12, 10)
m.strip("fence_v", 18, 13, 7)
m.tiles([(10, 14), (10, 17)], "bush")
m.tiles([(11, 19), (16, 19), (17, 19)], "flowers")

# --- décor : arbres, souches, rochers ---------------------------------------------------------
m.stamp("tree", 6, 3)
m.stamp("tree", 14, 3)
m.stamp("tree_small", 11, 5)
m.stamp("stump", 25, 13)                   # la souche d'Hector
m.stamp("tree", 24, 15)
m.stamp("boulder", 19, 4)
m.stamp("tree_small", 25, 25)
m.stamp("tree", 13, 25)
m.tiles([(5, 7), (18, 7), (22, 4), (24, 10), (7, 22), (18, 25), (8, 20), (11, 24), (17, 26)], "bush")
m.tiles([(7, 19), (4, 20), (27, 11), (24, 26), (11, 27), (12, 3)], "flowers")
m.tiles([(3, 12), (22, 6), (27, 27)], "rock")

# --- panneaux ---------------------------------------------------------------------------------
m.sign("panneau_route", 23, 24, "ch2_panneau_route")
m.sign("panneau_relais", 10, 22, "ch2_panneau_relais")

# --- habitants et ennemis ---------------------------------------------------------------------
m.npc("voyageur", cell=(25, 12), sprite="npc_hobo", facing="left", script="ch2_voyageur", name="Hector")
m.enemy("soldat_1", cell=(12, 9), kind="soldier_green", facing="left")
m.enemy("soldat_2", cell=(25, 21), kind="soldier_green", facing="right")
m.enemy("corbeau_1", cell=(12, 7), kind="rope")
m.enemy("corbeau_2", cell=(23, 16), kind="rope")
m.enemy("octorok_1", cell=(5, 25), kind="octorok")
m.enemy("octorok_2", cell=(8, 26), kind="octorok")
m.enemy("octorok_3", cell=(26, 5), kind="octorok")
m.entity("bush", "buisson_rubis", cell=(11, 24), drop="rupee")

# --- liaisons ---------------------------------------------------------------------------------
_w = m.warp_door(relais, to="relais_sibylle", spawn="porte")
_w["rect"][1] -= 8
_w["rect"][3] = 20   # le seuil de la maison bloque : le centre des pieds s'arrête à y+8
m.spawn("porte", *relais.outside, "down")
m.warp_edge("down", to="aube_village", spawn="nord", start=20 * 16, length=2 * 16)
m.warp_edge("right", to="abbaye_parvis", spawn="ouest", start=21 * 16, length=2 * 16)
m.warp_edge("left", to="sylve_lisiere", spawn="est", start=9 * 16, length=2 * 16)["rect"][2] = 16   # 8 px : le centre des pieds ne l'atteint pas
m.spawn_cell("from_aube", 20, 29, "up")     # arrivée depuis le village de l'Aube (LEVEL-CH1)
m.spawn_cell("sud", 20, 29, "up")           # alias
m.spawn_cell("start", 20, 27, "up")
m.spawn_cell("est", 29, 21, "left")         # retour de l'abbaye
m.spawn_cell("ouest", 2, 9, "right")        # retour de la forêt
