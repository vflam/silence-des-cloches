"""Terrain d'essai : le monde de la lumière d'origine en entier (8×8 écrans), avec ses zones
et ses atlas d'origine. Sert aux tests du moteur (déplacements, collisions, transitions)."""
from mapdsl import *

m = Map("test_overworld", "Monde de la lumière (essai)", size=(8, 8))
m.original_world("lw", music="overworld", names={
    0x00: "Bois Perdus", 0x03: "Montagne de la Mort (ouest)", 0x05: "Montagne de la Mort (est)",
    0x18: "Cocorico", 0x1B: "Château d'Hyrule", 0x1E: "Palais de l'Est", 0x2C: "Maison de Link",
    0x30: "Désert", 0x35: "Lac Hylia", 0x13: "Sanctuaire", 0x14: "Cimetière",
})
m.spawn("start", 2232, 2832, "down")          # devant la maison de Link
m.spawn("kakariko", 34 * 16, 120 * 16, "down")  # place de Cocorico
m.spawn("demo", 2232, 2880, "up")
m.warp(2232, 2848 + 96, 32, 16, "demo_village", "south", "fade")   # passage de test vers la démo
