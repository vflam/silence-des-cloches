"""Coupe des Frères (ch2) : clairière de coupe au sortir de la forêt. Le grand chêne à moitié
scié au milieu, les deux frères fâchés de part et d'autre, leur cabane, la butte de la grotte
de Cornebique au nord. Au nord-ouest, une corniche derrière un ravin : quand les frères se
réconcilient, le chêne abattu devient un pont (tronc creux) — calque conditionnel `patches`.
Disposition nouvelle."""
from mapdsl import *

m = Map("sylve_bucherons", "Coupe des Frères", size=(1, 1))
m.area(0, 0, 1, 1, name="Coupe des Frères", music="forest", atlas=LOST_WOODS)
m.fill("grass")
m.on_enter = "ch2_jour"

# --- terrain ---------------------------------------------------------------------------------
P = "path"
m.terrain_rect(0, 14, 17, 2, P)                 # arrivée de la forêt (ouest)
m.terrain_rect(16, 9, 2, 7, P)
m.terrain_rect(16, 9, 8, 1, P)                  # vers la grotte de Cornebique
m.terrain_rect(17, 15, 8, 1, P)                 # vers la cabane
m.terrain_rect(24, 15, 1, 3, P)
m.terrain(4, 22, ["tttt", "tttt", ".ttt"])
m.terrain(21, 24, ["ttt", "ttt"])
# le ravin (eau vive) en équerre autour de la corniche : il sort du bord ouest et du bord nord de
# la carte (pas de rive praticable pour le contourner) ; d'un seul tenant tant que le chêne n'est
# pas couché, coupé par la berge du chêne-pont ensuite.
RAV = ["~" * 14] * 4
m.terrain(9, 0, ["~~~~"] * 8)
m.terrain(1, 6, ["~~~"] * 2)                    # une anse dans la corniche
m.terrain(0, 8, RAV)
ravine = m.ids[6:14, 0:14].copy()               # ravin continu (calque « pas de pont »)
m.erase(0, 7, 9, 6)
m.terrain(0, 8, ["~~~~"] * 4)                   # ... coupé en deux par la berge du chêne
m.terrain(1, 6, ["~~~"] * 2)
m.terrain(9, 8, ["~~~~~"] * 4)

# --- bordures ---------------------------------------------------------------------------------
m.forest(0, 0, 8, 3, edges="")
m.forest(14, 0, 18, 3, edges="")
m.forest(0, 18, 3, 14, edges="")
m.forest(29, 3, 3, 29, edges="")
m.forest(3, 27, 25, 5, edges="")

# --- la butte de Cornebique -------------------------------------------------------------------
butte = m.stamp("cave_cliff", 20, 2)

# --- corniche nord-ouest (coffre) au-dessus du ravin, et pont du chêne ---------------------------
m.tiles([(1, 4), (7, 3), (7, 6)], "bush")
m.tiles([(3, 6), (6, 5)], "flowers")
m.strip("log_v", 5, 7, 6)                       # le chêne abattu devenu pont (visible avec bucherons_pont)
bridge_cells = [{"x": i * 16, "y": (6 + j) * 16, "id": int(ravine[j, i])}
                for j in range(1, 7) for i in range(14)
                if int(ravine[j, i]) != int(m.ids[6 + j, i]) and not m._forest_cells[6 + j, i]]

# --- la cabane des frères ----------------------------------------------------------------------
cabane = m.stamp("house_blue_woodpile", 20, 11)

# --- le grand chêne scié, souches, bois coupé ----------------------------------------------------
m.stamp("tree_autumn", 11, 16)                  # le chêne (x 11-14, y 16-20)
m.stamp("stump", 6, 18)
m.stamp("stump", 18, 21)
m.stamp("stump", 9, 24)
m.stamp("stump", 24, 20)
m.stamp("stump", 14, 24)
m.tiles([(3, 20), (26, 25), (17, 26), (8, 17)], "bush")
m.tiles([(19, 19), (5, 16), (13, 22), (22, 26)], "flowers")
m.sign("panneau_bucherons", 19, 12, "ch2_panneau_bucherons")

# --- les frères, le tronc ------------------------------------------------------------------------
m.npc("bastien", cell=(6, 21), sprite="npc_quarrel_bro", facing="right", script="ch2_bastien", name="Bastien")
m.npc("brice", cell=(21, 21), sprite="npc_quarrel_bro", facing="left", script="ch2_brice", name="Brice")
m.entity("sign", "tronc", cell=(12, 20), script="ch2_tronc")
m.chest("coffre_corniche", cell=(4, 4), item="rupee", amount=20)

# --- ennemis -------------------------------------------------------------------------------------
m.enemy("octorok_1", cell=(5, 23), kind="octorok")
m.enemy("octorok_2", cell=(23, 25), kind="octorok")
m.enemy("corbeau_1", cell=(16, 18), kind="rope")

# --- liaisons ------------------------------------------------------------------------------------
m.warp_edge("left", to="sylve_foret", spawn="est", start=14 * 16, length=2 * 16)["rect"][2] = 16   # 8 px : le centre des pieds ne l'atteint pas
m.warp_door(butte, to="cornebique_grotte", spawn="ouest")
_w = m.warp_door(cabane, to="bucherons_cabane", spawn="porte")
_w["rect"][1] -= 8
_w["rect"][3] = 20   # le seuil de la maison bloque : le centre des pieds s'arrête à y+8
m.spawn_cell("ouest", 1, 14, "right")
m.spawn("grotte", *butte.outside, "down")
m.spawn("cabane", *cabane.outside, "down")
m.spawn_cell("start", 16, 13, "down")

# --- calque conditionnel : tant que les frères sont fâchés, pas de pont -------------------------
_compile = m.compile


def _compile_with_patches():
    out, comp = _compile()
    out["patches"] = [{"if": "!bucherons_pont", "cells": bridge_cells}]
    return out, comp


m.compile = _compile_with_patches
