"""Maison de Tobie : maison familiale neuve, basse et large (roomgen, murs posés à la main),
coupée en deux coins par la cheminée centrale : chambre à l'ouest (deux lits), cuisine à l'est ;
table d'écriture de Tobie près de la fenêtre."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

BX, BY, BW, BH = 8, 32, 48, 30
m = Map("aube_maison_tobie", "Maison de Tobie", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch1_aube_maison_tobie", "blockset": 0x03, "palette": 21,
    "floor1": 3, "floor2": 14, "layout": 7, "bg_mode": "off",
    "objects": [
        *G.fill("ceiling_block", 0, 0, 64, BY), *G.fill("ceiling_block", 0, BY, BX, 64 - BY),
        *G.fill("ceiling_block", BX + BW, BY, 64 - BX - BW, 64 - BY),
        *G.room_box(BX, BY, BW, BH),
        # cheminée : un gros bloc de maçonnerie au milieu du mur nord (chambre / cuisine)
        *G.pillar(26, 32, 12, 12),
        # chambre (ouest) : deux lits, étagère
        ["bed", 12, 36], ["bed", 18, 36], ["bookshelf", 12, 44],
        {"o": "floor_area4", "x": 12, "y": 50, "w": 1, "h": 0},
        # cuisine (est) : table, tabourets, tonneaux, table d'écriture
        ["table", 44, 38], ["plate_on_table", 44, 38], ["chair", 41, 39], ["chair", 49, 39],
        ["barrel", 52, 36], ["barrel", 52, 52],
        ["table", 40, 50], ["chair", 38, 54],
    ],
    "doors": [["down", 7, "normal"]],
})
m.area(px=(BX * 8, BY * 8, BW * 8, 512 - BY * 8), name="Maison de Tobie", music="village")

door = room["doors"][0]
m.warp_room_door(door, to="aube_village", spawn="tobie")
m.spawn_room_door("porte", door)

m.npc("tobie", 344, 424, sprite="npc_trough_boy", facing="up", script="ch1_tobie", wander=16, name="Tobie")
m.npc("mere_tobie", 368, 344, sprite="npc_young_snitch_lady", facing="down", dialogue="ch1_tobie_mere",
      name="Mère de Tobie", cond="!ch1_silence")
m.npc("mere_tobie_post", 368, 344, sprite="npc_young_snitch_lady", facing="down",
      dialogue="ch1_tobie_mere_post", name="Mère de Tobie", cond="ch1_silence")
m.entity("sign", "cheminee", 248, 352, dialogue="common_cheminee")
m.entity("sign", "etagere", 104, 352, dialogue="common_etagere", any_side=True)
m.entity("sign", "lit", 104, 304, dialogue="common_lit", any_side=True)
m.entity("pot", "jarre_1", 96, 440, drop="rupee")
m.entity("pot", "jarre_2", 424, 440, drop="rupee5")
