"""Chez Lise (boutique du Village de l'Aube) : boutique neuve en L (roomgen, murs posés à la
main) — haute salle à l'est avec le petit comptoir où Lise sert le café, aile basse à l'ouest
pour les étalages ; tonneaux et jarres."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("aube_boutique", "Chez Lise", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch1_aube_boutique", "blockset": 0x03, "palette": 5,
    "floor1": 3, "floor2": 14, "layout": 7, "bg_mode": "off",
    "objects": [
        # pièce en L : partie haute à l'est (x 28-52), aile basse à l'ouest (x 12-28, y 44-62)
        *G.fill("ceiling_block", 0, 0, 64, 28), *G.fill("ceiling_block", 0, 28, 12, 36),
        *G.fill("ceiling_block", 52, 28, 12, 36), *G.fill("ceiling_block", 12, 28, 16, 16),
        *G.hwall("n", 32, 28, 16), ["corner_out_nw", 28, 28], ["corner_out_ne", 48, 28],
        *G.vwall("e", 48, 32, 26), ["corner_out_se", 48, 58],
        *G.hwall("s", 16, 58, 32), ["corner_out_sw", 12, 58],
        *G.vwall("w", 12, 48, 10), ["corner_out_nw", 12, 44],
        *G.hwall("n", 16, 44, 12), *G.vwall("w", 28, 32, 12), ["corner_in_nw", 28, 44],
        # étagère au mur nord, comptoir de Lise au nord-est, tonneaux de café
        ["shelf_h", 32, 30, 0], ["bar_h", 40, 33, 0], ["bottles_on_bar", 41, 33],
        ["barrel", 45, 32], ["barrel", 45, 40],
        {"o": "floor_area4", "x": 34, "y": 44, "w": 1, "h": 1},
        # étalages dans l'aile ouest
        ["table", 16, 48], ["plate_on_table", 16, 48], ["table", 22, 48], ["bottles_on_bar", 23, 48],
        ["barrel", 45, 54], ["chair", 17, 54],
    ],
    "doors": [["down", 7, "normal"]],
})
m.area(px=(96, 224, 320, 288), name="Chez Lise", music="minigame")

door = room["doors"][0]
m.warp_room_door(door, to="aube_village", spawn="boutique")
m.spawn_room_door("porte", door)

m.npc("lise", 328, 296, sprite="npc_young_snitch_lady", facing="down", script="ch1_lise", name="Lise")
m.entity("sign", "etageres", 264, 256, dialogue="common_etagere")
m.entity("pot", "jarre_1", 200, 440, drop="rupee")
m.entity("pot", "jarre_2", 384, 440, drop="rupee5")
