"""Lisière de la Forêt des Murmures (ch2) : clairière du camp (souche), sentier qui s'enfonce
au nord, butte de la fontaine des fées cachée par des buissons. Disposition nouvelle."""
from mapdsl import *

m = Map("sylve_lisiere", "Lisière de Sylve", size=(1, 1))
m.area(0, 0, 1, 1, name="Lisière de la Forêt des Murmures", music="forest", atlas=LOST_WOODS)
m.fill("grass")
m.on_enter = "ch2_nuit"

# --- terrain ---------------------------------------------------------------------------------
m.terrain_rect(15, 0, 2, 20, "path")         # sentier nord (vers la forêt)
m.terrain_rect(15, 18, 17, 2, "path")        # chemin est (route du Nord)
m.terrain_rect(17, 11, 8, 1, "path")         # sentier vers la butte de la fontaine
m.terrain(9, 22, ["..tttt", "tttttt", "tttttt", "tttt.."])
m.terrain(20, 22, ["ttt.", "tttt", ".ttt"])

# --- forêt dense tout autour (une seule région : arbres entiers) --------------------------------
m.forest(0, 0, 14, 10, edges="")                        # nord-ouest (continue au-delà des bords)
m.forest(17, 0, 15, 3, edges="")                        # troncs au-dessus de la butte
m.forest(28, 3, 4, 14, edges="")                        # est, au-dessus du chemin
m.forest(0, 10, 8, 22, edges="")                        # ouest
m.forest(27, 21, 5, 11, edges="")                       # sud-est
m.forest(0, 27, 32, 5, edges="")                        # sud

# --- la butte de la fontaine -----------------------------------------------------------------
butte = m.stamp("cave_cliff", 19, 3)
dx, dy = butte.door
m.tiles([(dx - 1, dy + 1), (dx, dy + 1), (dx + 1, dy + 1), (dx + 2, dy + 1)], "bush")

# --- la clairière du camp ----------------------------------------------------------------------
m.stamp("stump", 12, 19)                      # la souche du camp
m.stamp("tree_dark", 9, 12)
m.stamp("tree_small", 23, 14)
m.stamp("tree_small", 10, 17)
m.strip("fence_h", 8, 26, 3)                  # vieille clôture effondrée
m.tiles([(13, 13), (19, 15), (26, 12), (16, 23)], "bush")
m.tiles([(13, 16), (19, 13), (19, 24), (15, 25)], "flowers")
m.tiles([(9, 20), (21, 16)], "rock")

m.sign("panneau_lisiere", 18, 7, "ch2_panneau_lisiere")

# --- déclencheurs ------------------------------------------------------------------------------
m.trigger("t_camp", 27 * 16, 16 * 16, 48, 80, "ch2_camp", once=True, cond="ch2_anselme & !ch2_camp")
m.trigger("t_bloque", 15 * 16, 3 * 16, 32, 16, "ch2_lisiere_bloque", once=False, cond="!ch2_anselme")

# --- ennemis -----------------------------------------------------------------------------------
m.enemy("rope_1", cell=(8, 20), kind="rope")
m.enemy("rope_2", cell=(22, 24), kind="rope")
m.enemy("buzzblob_1", cell=(10, 23), kind="octorok")
m.enemy("buzzblob_2", cell=(20, 14), kind="octorok")

# --- liaisons ------------------------------------------------------------------------------------
m.warp_edge("up", to="sylve_foret", spawn="sud", start=15 * 16, length=2 * 16)["rect"][3] = 16   # 8 px : le centre des pieds ne l'atteint pas
m.warp_edge("right", to="route_nord", spawn="ouest", start=18 * 16, length=2 * 16)
m.warp_door(butte, to="sylve_fontaine", spawn="porte")
m.spawn("fontaine", dx * 16 + 8, (dy + 2) * 16 + 2, "down")
m.spawn_cell("est", 29, 18, "left")
m.spawn_cell("nord", 15, 2, "down")
m.spawn_cell("start", 18, 18, "left")
