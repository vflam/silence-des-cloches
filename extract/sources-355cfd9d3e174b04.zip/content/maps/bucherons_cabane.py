"""Cabane des frères bûcherons (salle neuve, plan inventé) : une longue pièce basse coupée en
deux par une ligne tracée au sol ; chaque frère a sa moitié (lit, chaise, tonneaux) et a
tourné son lit dos à l'autre ; la table commune est à cheval sur la ligne."""
from mapdsl import *
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("bucherons_cabane", "Cabane des frères", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch2_bucherons_cabane", "blockset": 0x03, "palette": 21, "floor1": 3, "layout": 5,
    "objects": [
        *G.fill("ceiling_block", 0, 0, 64, 32),
        ["red_carpet_floor_trim_v", 31, 40, 5],      # la ligne de partage
        ["red_carpet_floor_trim_v", 31, 52, 1],
        ["bed", 6, 38], ["bed", 54, 38],
        ["table", 29, 45], ["chair", 26, 46], ["chair", 35, 46],
        ["bookshelf", 12, 36], ["bookshelf", 44, 36],
        ["barrel", 6, 54], ["barrel", 9, 54], ["barrel", 56, 54], ["barrel", 56, 51],
        ["chair", 14, 50], ["chair", 48, 50],
        ["wall_painting", 30, 36],
    ],
    "doors": [["down", 7]],
}, name="Cabane des frères", music="village")

door = room["doors"][0]
m.warp_room_door(door, to="sylve_bucherons", spawn="cabane")
m.spawn_room_door("porte", door)
m.entity("sign", "lit", cell=(7, 43), dialogue="ch2_cabane_lit")
m.entity("sign", "etagere", cell=(45, 38), dialogue="common_etagere")
m.entity("pot", "jarre_1", cell=(20, 54), drop="heart")
m.entity("pot", "jarre_2", cell=(42, 56), drop="rupee")
