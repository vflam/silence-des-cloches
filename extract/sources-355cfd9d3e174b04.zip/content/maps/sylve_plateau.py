"""Plateau de Sylve (ch2, 2×2 écrans). On sort de la grotte de Cornebique au pied d'une butte
rocheuse (nord-ouest). La prairie basse, l'abri des pèlerins et leur autel (sauvegarde), puis
l'allée des statues qui monte vers le nord jusqu'à l'escalier taillé dans le rebord de la terrasse
haute. Sur la terrasse, le parvis dallé et l'arche des Fondeurs : l'entrée du Temple de Sylve,
murée de dalles tant qu'Oriane n'a pas chanté le sceau (calque conditionnel `patches`).
Disposition nouvelle. (Refait par QA-CH2 : rebord `ledge_s` raccordé au mur de la butte au lieu
d'un plateau à escalier, décor posé sur l'herbe, forêts en arbres entiers.)"""
from mapdsl import *

m = Map("sylve_plateau", "Plateau de Sylve", size=(2, 2))
m.area(0, 0, 2, 2, name="Plateau de Sylve", music="overworld", atlas=LIGHT)
m.fill("grass")
m.on_enter = "ch2_jour"


def paved(x, y, w, h):
    """Pavés clairs bordés d'une rangée de dalles (raccord avec l'herbe)."""
    m.rect(x, y, w, h, "stones")
    m.rect(x + 1, y + 1, w - 2, h - 2, "paving")


# --- terrain ---------------------------------------------------------------------------------
P = "path"
m.terrain_rect(9, 23, 2, 9, P)                  # sortie de la grotte
m.terrain_rect(9, 31, 17, 2, P)                 # -> l'abri des pèlerins
m.terrain_rect(24, 33, 2, 12, P)
m.terrain_rect(24, 43, 26, 2, P)                # -> le pied de l'allée des statues
m.terrain(4, 46, ["..tttt", "tttttt", "tttttt", "tttt..", "tttt.."])
m.terrain(36, 50, ["tttt", "tttt", "..tt"])
m.terrain(14, 51, ["..~~~.", ".~~~~~", "~~~~~~", ".~~~~."])   # mare

# --- bordures : forêt en contrebas, en arbres entiers ------------------------------------------
m.forest(0, 57, 64, 7, edges="")
m.forest(0, 21, 3, 36, edges="")
m.forest(61, 21, 3, 36, edges="")
m.forest(23, 0, 41, 3, edges="")               # au-dessus de la terrasse haute

# --- butte rocheuse du nord-ouest (grotte de Cornebique dans son mur sud) ------------------------
m.plateau(0, 0, 23, 21)                         # (contre les bords : on ne la contourne pas)
grotte = m.stamp("cave_in_wall", 9, 18)

# --- la terrasse haute : son rebord part du mur de la butte jusqu'au bord de la carte -------------
m.strip("ledge_s", 23, 18, 41)
m.stamp("stairs_cliff", 52, 18, over=True)      # l'escalier du parvis

# --- le parvis dallé et l'arche des Fondeurs -------------------------------------------------------
paved(49, 9, 9, 9)                               # parvis (x 49-57, y 9-17)
m.rect(52, 17, 3, 1, "paving")                   # ... ouvert sur l'escalier
arche = m.stamp("ruin_arch", 50, 4)
for x in (45, 60):
    m.stamp("statue_armos", x, 5)
for y in (10, 14):
    m.stamp("statue_armos", 46, y)
    m.stamp("statue_armos", 59, y)
m.stamp("stone_slab", 30, 8)                     # dalles tombées de l'arche
m.stamp("stone_slab", 37, 12)
m.tiles([(27, 5), (41, 7), (34, 15), (29, 13)], "rock_heavy")
m.tiles([(33, 6), (40, 14)], "flowers")

# --- abri des pèlerins et leur autel ------------------------------------------------------------
abri = m.stamp("shed_thatch", 28, 24)
m.stamp("statue_armos", 33, 25)                  # l'autel (la statue qui tend les mains)
m.tiles([(27, 29), (32, 29), (36, 28)], "flowers")
m.sign("panneau_plateau", 22, 35, "ch2_panneau_plateau")

# --- l'allée des statues (décor + 4 statues qui s'éveillent) -------------------------------------
paved(51, 21, 5, 22)                             # allée (x 51-55, y 21-42)
m.rect(52, 21, 3, 1, "paving")                   # ... au pied de l'escalier
m.rect(52, 42, 3, 1, "paving")                   # ... et au bout du sentier
for y in (23, 29, 35):
    m.stamp("statue_armos", 48, y)
    m.stamp("statue_armos", 57, y)

# --- décor de la prairie ----------------------------------------------------------------------
m.stamp("tree", 40, 30)
m.stamp("tree", 56, 47)
m.stamp("tree_small", 30, 38)
m.stamp("boulder", 12, 38)
m.stamp("rock_pile", 47, 52)
m.tiles([(6, 30), (18, 27), (20, 40), (33, 49), (44, 53), (58, 44)], "bush")
m.tiles([(15, 35), (29, 47), (35, 55), (44, 39), (22, 49), (58, 52)], "flowers")
m.stamp("stump", 26, 51)
m.stamp("tree_small", 8, 38)
m.stamp("tree", 17, 43)
m.tiles([(28, 53), (29, 53), (52, 49), (12, 55)], "bush")

# --- entités ------------------------------------------------------------------------------------
m.entity("sign", "statue_pelerins", cell=(33, 27), script="ch2_statue", any_side=True)
m.entity("sign", "porte_abri", cell=(29, 28), dialogue="common_maison_fermee")
m.trigger("t_temple", 51 * 16, 9 * 16, 5 * 16, 32, "ch2_temple_entree", once=True, cond="!ch2_sceau")
m.entity("sign", "porte_temple", cell=(53, 7), dialogue="ch2_temple_porte", cond="!ch2_sceau")
m.enemy("armos_1", cell=(50, 25), kind="armos_statue")
m.enemy("armos_2", cell=(56, 28), kind="armos_statue")
m.enemy("armos_3", cell=(50, 33), kind="armos_statue")
m.enemy("armos_4", cell=(56, 38), kind="armos_statue")
m.enemy("octorok_1", cell=(8, 47), kind="octorok")
m.enemy("octorok_2", cell=(38, 51), kind="octorok")
m.enemy("buzzblob_1", cell=(44, 36), kind="octorok")

# --- liaisons -----------------------------------------------------------------------------------
m.warp_door(grotte, to="cornebique_grotte", spawn="est")
m.spawn("grotte", *grotte.outside, "down")
m.warp(53 * 16, 5 * 16, 16, 12, to="temple_sylve_rdc", spawn="entree", style="door")
m.spawn_cell("temple", 53, 9, "down")
m.spawn_cell("start", 24, 36, "up")

# --- l'arche est murée tant que le sceau n'est pas ouvert ------------------------------------------
_compile = m.compile


def _compile_with_patches():
    out, comp = _compile()
    slab = [int(v) for v in m.ids[8:10, 30:32].ravel()]
    cells = [{"x": (53 + i) * 16, "y": (5 + j) * 16, "id": slab[j * 2 + i]} for j in range(2) for i in range(2)]
    out["patches"] = [{"if": "!ch2_sceau", "cells": cells}]
    return out, comp


m.compile = _compile_with_patches
