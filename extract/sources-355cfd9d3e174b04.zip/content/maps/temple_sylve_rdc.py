"""Temple de Sylve — niveau principal (donjon `sylve`), LEVEL-TEMPLE.

7 salles neuves construites avec tools/roomgen (tools/roomgen/rooms/temple_sylve.py), une par
écran (512x512, ou 512x256 pour le couloir R7) :

          x0                 x1                 x2
   y0  [R6 Torches ]──────[R5 Trappe   ]──(clé)──[R7 Couloir ▼]
                                 ║ herse (bloc de R4)
   y1  [R3 Chauves ]──────[R2 Échos    ]─────────[R4 Carte    ]
                                 ║ porte de bronze (Clé du Temple)
   y2                     [R1 Hall     ]
                                 ║ (plateau)

Les portes entre salles voisines sont alignées (même colonne / ligne de porte) : on passe
d'une salle à l'autre par défilement de zone. Tuiles qui changent (portes, herse, trou de la
trappe, torches, blocs) = patches conditionnels ou `open_patch` / `closed_patch` des portes,
calculés comme la différence entre deux constructions de la salle.
"""
import sys
from pathlib import Path

from mapdsl import *

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools" / "roomgen"))
sys.path.insert(0, str(ROOT / "tools" / "roomgen" / "rooms"))
import temple_sylve as T  # noqa: E402

MAP = "temple_sylve_rdc"
m = Map(MAP, "Temple de Sylve", kind="dungeon", size=(3, 3), dungeon="sylve")
m.empty_screen(0, 2)
m.empty_screen(2, 2)

SCREENS = {"r1": (1, 2), "r2": (1, 1), "r3": (0, 1), "r4": (2, 1), "r5": (1, 0), "r6": (0, 0), "r7": (2, 0)}
SPECS = {"r1": T.R1, "r2": T.R2, "r3": T.R3, "r4": T.R4, "r5": T.R5, "r6": T.R6, "r7": T.R7}
NAMES = {"r1": "Hall d'entrée", "r2": "Galerie des Échos", "r3": "Salle des Chauves-souris",
         "r4": "Salle de la Carte", "r5": "Salle de la Trappe", "r6": "Salle des Torches",
         "r7": "Couloir verrouillé"}


def P(r, cx, cy):
    """Room-local tile8 cell -> map pixels."""
    sx, sy = SCREENS[r]
    return sx * 512 + cx * 8, sy * 512 + cy * 8


def O(r):
    sx, sy = SCREENS[r]
    return sx * 512, sy * 512


# ------------------------------------------------------------------ rooms (base + variants)
VAR = {
    "r1_open": T.variant(T.R1, "open", doors={1: "normal"}),
    "r2_open": T.variant(T.R2, "open", doors={1: "normal"}),
    "r5_trappe": T.variant(T.R5, "trappe"),
    "r5_keyopen": T.variant(T.R5, "keyopen", doors={2: "normal"}),
    "r5_shut": T.variant(T.R5, "shut", doors={0: "shutter", 1: "shutter"}),
    "r6_t1": T.variant(T.R6, "t1", torches=[[21, 9, True], [41, 9, False]]),
    "r6_t2": T.variant(T.R6, "t2", torches=[[21, 9, False], [41, 9, True]]),
    "r6_open": T.variant(T.R6, "open", drop_objects=[["block", 31, 10]]),
}
built = T.build(list(SPECS.values()) + list(VAR.values()))
B = {k: built[s["name"]] for k, s in SPECS.items()}
V = {k: built[s["name"]] for k, s in VAR.items()}

rooms = {}
for k, spec in SPECS.items():
    sx, sy = SCREENS[k]
    rooms[k] = m.room_custom(sx, sy, spec, name=NAMES[k], music="dungeon")
    scr = m.s8[(sx, sy)]
    # the map keeps the painted version (free-form pits)
    T.install(scr, B[k], rooms[k])

def patch(cond, cells):
    m.patch(cond, cells)


def door_entity(id, r, base, var, lock, dir):
    """Locked door: closed tiles = base room (baked), open tiles = the variant."""
    ox, oy = O(r)
    open_cells = T.diff_cells(base, var, ox, oy)
    x, y, w, h = T.bbox(open_cells)
    return {"type": "door", "id": id, "x": x, "y": y, "w": w, "h": h, "lock": lock, "dir": dir,
            "open_patch": open_cells}


# ================================================================ R1 — Hall d'entrée
exit_door = next(d for d in rooms["r1"]["doors"] if d["dir"] == "down")
m.warp_room_door(exit_door, to="sylve_plateau", spawn="temple", screen=SCREENS["r1"])
m.spawn_room_door("entree", exit_door, screen=SCREENS["r1"])
# porte de bronze : s'ouvre avec la Clé du Temple (script au contact)
patch("sylve_porte_bronze", T.diff_cells(B["r1"], V["r1_open"], *O("r1")))
m.trigger("t_porte_bronze", *P("r1", 26, 8), 64, 24, "ch2_temple_porte_bronze", once=True)
m.trigger("t_hall", *P("r1", 26, 48), 64, 32, "ch2_temple_hall", once=True)
m.entity("sign", "runes_r1", *P("r1", 31, 42), dialogue="ch2t_runes_r1", any_side=True)
m.entity("pot", "pot_r1_1", *P("r1", 6, 26), drop="heart")
m.entity("pot", "pot_r1_2", *P("r1", 56, 26))
m.entity("pot", "pot_r1_3", *P("r1", 6, 36), drop="rupee")
m.entity("pot", "pot_r1_4", *P("r1", 56, 36), drop="heart")

# ================================================================ R2 — Galerie des Échos
patch("sylve_herse_r2", T.diff_cells(B["r2"], V["r2_open"], *O("r2")))
m.entity("sign", "runes_r2", *P("r2", 31, 50), dialogue="ch2_temple_rune_r2", any_side=True)
# rouleaux (cylindres de 64 px de large) : un par couloir de 8 cases (deux dans un même couloir se
# traversaient), ils vont et viennent nord-sud, décalés (l'un part du haut, l'autre du bas)
for i, (cx, cy) in enumerate([(14, 12), (42, 50)]):
    m.enemy(f"roller_r2_{i + 1}", *P("r2", cx, cy), kind="roller", respawn=False)
m.enemy("popo_r2_1", *P("r2", 8, 28), kind="popo", respawn=False)
m.enemy("popo_r2_2", *P("r2", 54, 36), kind="popo", respawn=False)

# ================================================================ R3 — Salle des Chauves-souris
m.entity("pot", "jarre_cle_r3", *P("r3", 26, 26), drop="key")
m.entity("pot", "pot_r3_2", *P("r3", 36, 26))
m.entity("pot", "pot_r3_3", *P("r3", 26, 36))
m.entity("pot", "pot_r3_4", *P("r3", 36, 36), drop="rupee")
m.entity("pot", "pot_r3_5", *P("r3", 10, 46), drop="heart")
for i, (cx, cy) in enumerate([(8, 22), (54, 22), (10, 44), (52, 44)]):
    m.enemy(f"keese_r3_{i + 1}", *P("r3", cx, cy), kind="keese", respawn=False)

# ================================================================ R4 — Salle de la Carte
m.chest("coffre_carte", *P("r4", 45, 15), item="map", flag="sylve_carte")
m.entity("block", "bloc_r4", *P("r4", 14, 46), pushable=True, dir="left", script="ch2_herse_r2",
         moved_to=list(P("r4", 12, 46)))
m.entity("sign", "runes_r4", *P("r4", 22, 36), dialogue="ch2_temple_rune_r4", any_side=True)
m.enemy("stalfos_r4_1", *P("r4", 30, 32), kind="stalfos", respawn=False)
m.enemy("stalfos_r4_2", *P("r4", 46, 44), kind="stalfos", respawn=False)
m.entity("pot", "pot_r4_1", *P("r4", 54, 30), drop="rupee")

# ================================================================ R5 — Salle de la Trappe
patch("ch2_trappe", T.diff_cells(B["r5"], V["r5_trappe"], *O("r5")))
m.entities.append(door_entity("porte_r5_e", "r5", B["r5"], V["r5_keyopen"], "key", "right"))
m.trigger("t_trappe", *P("r5", 26, 40), 96, 24, "ch2_trappe", once=True)
# after the fall: these appear as soon as ch2_trappe is set (conditional entities)
R5_FIGHT = "ch2_trappe & !sylve_r5_clear"
# premier combat « portes fermées » (héros à 3 cœurs, un Stalfos ôte un cœur) : 2 Stalfos + 2 Popo
R5_ENEMIES = [("r5_stalfos_1", "stalfos", 7, 31), ("r5_stalfos_2", "stalfos", 54, 31),
              ("r5_popo_1", "popo", 8, 20), ("r5_popo_2", "popo", 54, 42)]
for eid, kind, cx, cy in R5_ENEMIES:
    m.enemy(eid, *P("r5", cx, cy), kind=kind, respawn=False, cond=R5_FIGHT)
# the south and west doors slam shut until the room is clear (patch, cells of the "shut" variant)
patch(R5_FIGHT, T.diff_cells(B["r5"], V["r5_shut"], *O("r5")))
m.entities.append({"type": "chest", "id": "r5_boussole", "x": P("r5", 31, 16)[0], "y": P("r5", 31, 16)[1],
                   "item": "compass", "flag": "sylve_boussole", "spawn_on_clear": True, "if": "ch2_trappe"})
m.entities.append({"type": "trigger", "id": "t_r5_fin", "x": O("r5")[0] + 40, "y": O("r5")[1] + 56, "w": 432, "h": 416,
                   "script": "ch2_trappe_fin", "once": True, "spawn_on_clear": True, "if": R5_FIGHT})

# ================================================================ R6 — Salle des Torches
for i, (cx, cy) in enumerate([(21, 9), (41, 9)]):
    tid = f"torche_r6_{i + 1}"
    m.entities.append({"type": "torch", "id": tid, "x": P("r6", cx, cy)[0], "y": P("r6", cx, cy)[1],
                       "lit": False, "group": "r6", "script": "ch2_torches_r6", "sprite": ""})
    patch(f"torch:{MAP}:{tid}", T.diff_cells(B["r6"], V[f"r6_t{i + 1}"], *O("r6")))
patch("sylve_torches_r6", T.diff_cells(B["r6"], V["r6_open"], *O("r6")))
m.chest("coffre_cle_r6", *P("r6", 31, 8), item="key", flag="sylve_cle_r6")
m.enemy("popo_r6_1", *P("r6", 12, 12), kind="popo", respawn=False)
m.enemy("popo_r6_2", *P("r6", 48, 28), kind="popo", respawn=False)
m.entity("pot", "pot_r6_1", *P("r6", 28, 52), drop="heart")
m.entity("pot", "pot_r6_2", *P("r6", 34, 52), drop="rupee")

# ================================================================ R7 — Couloir verrouillé
st = rooms["r7"]["stairs"][0]
m.warp(*P("r7", st["x"] + 1, st["y"] + 1), 16, 16, to="temple_sylve_s1", spawn="escalier", style="stairs")
m.spawn("escalier", *P("r7", st["x"] + 1, st["y"] - 4), "down")
# rouleau vertical (64 px de haut) qui balaie le couloir d'ouest en est : se cacher dans la niche
m.enemy("roller_r7_1", *P("r7", 20, 7), kind="roller_v", respawn=False)
m.enemy("popo_r7_1", *P("r7", 50, 22), kind="popo", respawn=False)
