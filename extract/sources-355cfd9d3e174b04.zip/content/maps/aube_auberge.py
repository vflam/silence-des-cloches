"""Auberge du Grelot : taverne neuve (roomgen, murs posés à la main) — une salle basse et
large, un cellier en alcôve au nord-ouest derrière le comptoir de Maïté, cheminée au nord,
tables et tabourets ; Mathurin ronfle dans le coin est."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("aube_auberge", "Auberge du Grelot", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch1_aube_auberge", "blockset": 0x03, "palette": 31,
    "floor1": 3, "floor2": 14, "layout": 7, "bg_mode": "off",
    "objects": [
        # salle basse et large (x 8-60, y 40-62) + cellier en alcôve au nord-ouest (x 8-28, y 24-40)
        *G.fill("ceiling_block", 0, 0, 64, 24), *G.fill("ceiling_block", 0, 24, 8, 40),
        *G.fill("ceiling_block", 28, 24, 36, 16), *G.fill("ceiling_block", 60, 40, 4, 24),
        *G.hwall("n", 12, 24, 12), ["corner_out_nw", 8, 24], ["corner_out_ne", 24, 24],
        *G.vwall("w", 8, 28, 30), *G.vwall("e", 24, 28, 12), ["corner_in_ne", 24, 40],
        *G.hwall("n", 28, 40, 28), ["corner_out_ne", 56, 40],
        *G.vwall("e", 56, 44, 14), *G.hwall("s", 12, 58, 44),
        ["corner_out_sw", 8, 58], ["corner_out_se", 56, 58],
        # cellier : tonneaux, étagère
        ["shelf_h", 14, 26, 0], ["barrel", 12, 29], ["barrel", 20, 29], ["barrel", 12, 33],
        # comptoir à l'entrée du cellier, bouteilles
        ["bar_h", 12, 42, 1], ["bottles_on_bar", 13, 42], ["bottles_on_bar", 16, 42],
        # cheminée (four) au mur nord, coin de Mathurin à l'est
        ["forge", 36, 40], ["wall_painting", 46, 42],
        ["barrel", 52, 44],
        # tables et tabourets
        ["table", 26, 47], ["plate_on_table", 26, 47], ["chair", 24, 51], ["chair", 30, 51],
        ["table", 14, 51], ["chair", 12, 55], ["chair", 18, 55],
        ["table", 40, 51], ["plate_on_table", 40, 51], ["chair", 38, 55], ["chair", 44, 55],
    ],
    "doors": [["down", 7, "normal"]],
})
m.area(px=(64, 192, 416, 320), name="Auberge du Grelot", music="minigame")

door = room["doors"][0]
m.warp_room_door(door, to="aube_village", spawn="auberge")
m.spawn_room_door("porte", door)

m.npc("aubergiste", 120, 360, sprite="npc_young_snitch_lady", facing="down", script="ch1_maite", name="Maïté")
m.npc("mathurin", 424, 376, sprite="npc_hobo", facing="left", script="ch1_mathurin", name="Mathurin")
m.entity("sign", "tonneaux", 128, 272, dialogue="common_tonneau", any_side=True)
m.entity("sign", "cheminee", 304, 336, dialogue="common_cheminee")
m.entity("pot", "jarre_1", 424, 440, drop="heart")
m.entity("pot", "jarre_2", 120, 448, drop="rupee5")
