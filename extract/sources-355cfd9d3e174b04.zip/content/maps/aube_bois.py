"""Bois de l'Aube (chapitre 1) : petit bois clair entre le hameau (est) et le village (nord).
Disposition inventée : un sentier en S bouché deux fois par des buissons (tutoriel « couper pour
avancer »), une grande clairière au sud-ouest (poule égarée), une clairière au nord-ouest avec
une butte où se cache l'entrée de la fontaine des fées derrière des buissons, un coffre au
nord-est. (Refait par QA-CH1 : forêt en arbres entiers, objets posés sur l'herbe.)"""
from mapdsl import *

m = Map("aube_bois", "Bois de l'Aube", size=(1, 1))
m.area(0, 0, 1, 1, name="Bois de l'Aube", music="village", atlas=LIGHT)
m.on_enter = "aube_village_enter"
m.fill("grass")

# --- 1. terrain ----------------------------------------------------------------------------
P = "path"
m.terrain_rect(16, 21, 16, 2, P)        # arrivée depuis le hameau (est)
m.terrain_rect(13, 20, 4, 2, P)
m.terrain_rect(13, 9, 2, 12, P)         # le couloir vers le nord
m.terrain_rect(13, 7, 3, 2, P)
m.terrain_rect(15, 0, 2, 8, P)          # sortie nord -> village
m.terrain(3, 21, ["..tttt", "tttttt", "tttt.."])        # herbes hautes
m.terrain(19, 5, ["ttt.", "tttt", ".ttt"])

# --- 2. forêt (les lisières regardent les clairières) ----------------------------------------
m.forest(0, 0, 14, 4, edges="se")
m.forest(18, 0, 14, 4, edges="sw")
m.forest(28, 4, 4, 14, edges="w")
m.forest(0, 15, 13, 5, edges="nes")
m.forest(15, 9, 13, 11, edges="nsw")
m.forest(0, 27, 32, 5, edges="n")

# --- 3. la butte de la fontaine (nord-ouest), cachée par des buissons ------------------------
butte = m.stamp("cave_cliff", 0, 4)     # le bord coupé de la butte contre le bord de la carte
m.tiles([(2, 11), (5, 11), (2, 12), (3, 12), (4, 12), (5, 12)], "bush")

# --- 4. clairière du nord-est : coffre, souche ------------------------------------------------
m.stamp("stump", 25, 7)
m.stamp("tree_small", 23, 4)
m.tiles([(21, 8), (17, 8), (27, 5), (26, 4), (10, 5), (13, 4)], "flowers")

# --- 5. bouchons de buissons sur le sentier ------------------------------------------------------
m.rect(24, 20, 2, 7, "bush")            # bouchon 1 (est)
m.rect(13, 16, 3, 2, "bush")            # bouchon 2 (couloir nord)

# --- 6. clairière du sud-ouest -------------------------------------------------------------------
m.stamp("tree_small", 18, 24)
m.stamp("stump", 21, 24)
m.tiles([(9, 24), (10, 25), (14, 18), (15, 25), (19, 20), (23, 26), (9, 21), (27, 20)], "flowers")
m.tiles([(4, 20), (3, 20), (13, 25), (14, 25), (21, 20), (22, 20), (28, 25), (27, 25)], "bush")
m.tiles([(17, 25), (8, 26)], "grass_tuft")

# --- 7. entités ----------------------------------------------------------------------------------
m.sign("panneau_bois", 28, 19, "ch1_panneau_bois")
m.sign("souche", 12, 23, "ch1_bois_souche", place_tile=False)
m.chest("coffre_bois", cell=(23, 7), item="rupee", amount=5)
m.npc("poule_3", cell=(6, 24), sprite="npc_cucco", script="ch1_poule_3", wander=24, name="Brigitte",
      cond="!poule_3")
m.entity("bush", "bouchon_rubis", cell=(24, 26), drop="rupee5")
m.entity("bush", "buisson_coeur", cell=(3, 20), drop="heart")
m.entity("bush", "buisson_rubis", cell=(27, 25), drop="rupee")
m.enemy("rat_bois_1", cell=(20, 22), kind="rat", cond="ch1_silence")
m.enemy("rat_bois_2", cell=(8, 22), kind="rat", cond="ch1_silence")
m.enemy("efface_bois", cell=(19, 7), kind="poe", cond="ch1_silence")

# --- 8. liaisons ---------------------------------------------------------------------------------
m.warp(32 * 16 - 12, 18 * 16, 12, 9 * 16, "aube_hameau", "ouest", style="edge")
m.spawn_cell("est", 30, 21, "left")
m.warp(14 * 16, 0, 4 * 16, 12, "aube_village", "sud", style="edge")   # 12 px (bord haut)
m.spawn_cell("nord", 15, 1, "down")
m.warp_door(butte, to="aube_fontaine", spawn="entree")["rect"][3] = 12
m.spawn("fontaine", *butte.outside, "down")
