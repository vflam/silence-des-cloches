"""Chapelle de l'Aube : nef étroite et haute 256×512 neuve (roomgen, layout 1, moitié est
cachée). Allée centrale, bancs de part et d'autre, colonnes, autel au fond ; au nord, la porte
de chêne de la crypte (verrouillée : clé de Mathurin) ; trappe du raccourci derrière l'autel."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402


def spec(crypt_door: str, trap: bool) -> dict:
    return {
        "name": f"ch1_aube_chapelle_{crypt_door}_{int(trap)}", "blockset": 0x04, "palette": 29,
        "floor1": 0, "floor2": 0, "layout": 1, "bg_mode": "off",
        "objects": [
            *G.fill("ceiling_block", 32, 0, 32, 64),
            {"o": "carpet_v", "x": 14, "y": 8, "size": 12},
            # choeur : autel entre deux statues, torchères, vitraux (décor du mur nord)
            ["wall_decor_n_h", 6, 7, 0], ["wall_decor_n_h", 22, 7, 0],
            ["table", 14, 9], ["statue", 10, 8], ["statue", 20, 8],

            # nef : bancs par paires, colonnes le long de l'allée
            ["church_pew", 6, 24], ["church_pew", 20, 24],
            ["church_pew", 6, 29], ["church_pew", 20, 29],
            ["church_pew", 6, 38], ["church_pew", 20, 38],
            ["church_pew", 6, 43], ["church_pew", 20, 43],
            ["column_v", 10, 33, 0], ["column_v", 20, 33, 0],
            ["column_v", 10, 50, 0], ["column_v", 20, 50, 0],
            *( [["floor_stairs_down", 22, 15]] if trap else [] ),
        ],
        "doors": [["left", 0, crypt_door], ["down", 6, "normal"]],
    }


def patch(src: dict, dst: dict, sx: int = 0, sy: int = 0) -> list:
    """Cells (pixels) where room `dst` differs from `src`, with dst's words (door patches)."""
    out = []
    for i in range(4096):
        if (src["bg"][i], src["fg"][i], src["types"][i]) != (dst["bg"][i], dst["fg"][i], dst["types"][i]):
            out.append({"x": sx * 512 + (i % 64) * 8, "y": sy * 512 + (i // 64) * 8,
                        "bg": dst["bg"][i], "fg": dst["fg"][i], "type": dst["types"][i]})
    return out


m = Map("aube_chapelle", "Chapelle de l'Aube", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, spec("normal", True), name="Chapelle de l'Aube", music="sanctuary")
m.on_enter = "aube_chapelle_enter"

up, down = [next(d for d in room["doors"] if d["dir"] == k) for k in ("left", "down")]
m.warp_room_door(down, to="aube_village", spawn="chapelle")
m.spawn_room_door("porte", down)
m.warp_room_door(up, to="aube_crypte", spawn="entree", style="stairs")
m.spawn_room_door("crypte", up)
m.spawn("trappe", 184, 160, "down")

# variantes : porte de la crypte verrouillée, sol sans la trappe (différences = patches des portes)
locked, notrap = G.build_rooms([spec("small_key", True), spec("normal", False)])

# porte de chêne de la crypte (mur ouest) : s'ouvre quand Mathurin a donné la clé
m.entity("door", "porte_crypte", 40, 120, w=16, h=32, lock="need:ch1_cle_crypte", locked_dialogue="ch1_chapelle_crypte_verrou", dir="left",
         closed_patch=patch(room, locked), open_patch=patch(locked, room))
m.entity("sign", "porte_crypte_panneau", 40, 120, dialogue="ch1_chapelle_crypte_verrou", any_side=True,
         cond="!ch1_cle_crypte")
# trappe du raccourci (derrière l'autel, à l'est) : n'apparaît qu'avec l'interrupteur de C5
m.entity("door", "trappe_raccourci", 176, 120, w=32, h=32, lock="flag:ch1_raccourci", dir="trap",
         closed_patch=patch(room, notrap), open_patch=patch(notrap, room))
wd = m.warp(180, 124, 24, 24, "aube_crypte", "trappe", "stairs")  # the trap opening itself
wd["if"] = "ch1_raccourci"
wd["dir"] = ""  # a hole in the floor: taken as soon as the hero steps in

# décor lisible, jarres
m.entity("sign", "autel", 120, 96, dialogue="ch1_chapelle_autel")
m.entity("sign", "vitrail", 56, 72, dialogue="ch1_chapelle_vitrail")
m.entity("sign", "vitrail_2", 184, 72, dialogue="ch1_chapelle_vitrail")
m.entity("pot", "jarre_1", 48, 432, drop="heart")
m.entity("pot", "jarre_2", 192, 432, drop="rupee")
