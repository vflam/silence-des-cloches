"""Planque de Fifine (salles neuves, plan inventé), sous la grande souche. Deux pièces côte à
côte : la galerie d'entrée coupée par une rangée de blocs (l'un d'eux se pousse), puis la
chambre au trésor où Fifine entasse ce qu'elle « trouve »."""
from mapdsl import *
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

BARRIER_Y = 28
PUSH_X = 16
m = Map("fifine_repaire", "Planque de Fifine", kind="interior", size=(2, 1))
room = m.room_custom(0, 0, {
    "name": "ch2_fifine_repaire", "blockset": 0x14, "palette": 32, "floor1": 1, "layout": 1,
    "objects": [
        *G.fill("ceiling_block", 32, 0, 32, 64),       # seule la galerie ouest (haute) sert
        # la galerie monte en biais : roche à l'est en bas, à l'ouest en haut
        *G.pillar(16, 40, 16, 16),
        *G.pillar(0, 8, 12, 16),
        # rangée de blocs d'ouest en est, sauf le bloc poussable
        *[["block", x, BARRIER_Y] for x in range(6, 26, 2) if x != PUSH_X],
        ["water_area", 6, 50, 0],
        ["pot", 22, 10], ["pot", 24, 10],
    ],
    "doors": [["down", 6, "exit_cave"], ["up", 0, "normal"]],
}, name="Planque de Fifine — galerie", music="cave_secret")
tresor = m.room_custom(1, 0, {
    "name": "ch2_fifine_tresor", "blockset": 0x14, "palette": 32, "floor1": 1, "layout": 5,
    "objects": [
        *G.fill("ceiling_block", 0, 0, 64, 32),
        # chambre au trésor, large et basse : un pilier de roche coupe la salle en deux alcôves
        *G.pillar(28, 44, 12, 16),
        *G.fill("floor_area", 44, 40, 12, 12),          # le « salon » de Fifine (est)
        ["pot", 50, 38], ["pot", 52, 38], ["pot", 54, 38], ["skull_pot", 48, 38],
        ["block", 56, 42], ["block", 56, 46], ["block", 8, 38],
        ["torch_lit", 20, 38], ["torch_lit", 42, 38],
        ["water_area", 12, 52, 0],
    ],
    "doors": [["left", 2, "normal"]],
}, name="Planque de Fifine — trésor", music="cave_secret")

entry = room["doors"][0]
m.warp_room_door(room["doors"][1], to="fifine_repaire", spawn="tresor")
m.spawn_room_door("galerie", room["doors"][1])
m.warp_room_door(tresor["doors"][0], to="fifine_repaire", spawn="galerie", screen=(1, 0))
m.spawn_room_door("tresor", tresor["doors"][0], screen=(1, 0))
m.warp_room_door(entry, to="sylve_foret", spawn="repaire")
m.spawn_room_door("porte", entry)
m.entity("block", "bloc_passage", cell=(PUSH_X, BARRIER_Y), sprite="rock_heavy", pushable=True, dir="up", repeat=True,
         moved_to=[PUSH_X * 8, (BARRIER_Y - 2) * 8])
m.enemy("rat_1", cell=(8, 40), kind="rat")
m.enemy("rat_2", cell=(20, 16), kind="rat")
m.trigger("t_fifine", 512 + 6 * 8, 44 * 8, 24, 40, "ch2_fifine", once=True, cond="ch2_fifine_vol & !ch2_fifine")
m.npc("fifine", cell=(64 + 48, 46), sprite="npc_thief_friendly", facing="down", script="ch2_fifine_npc",
      name="Fifine", cond="ch2_fifine_vol")
m.entity("sign", "bazar", cell=(64 + 51, 39), dialogue="ch2_repaire_bazar")
m.chest("coffre_repaire", cell=(64 + 54, 54), item="rupee", amount=20)
m.entity("pot", "jarre_1", cell=(64 + 8, 54), drop="heart")
m.entity("pot", "jarre_2", cell=(64 + 22, 56))
m.entity("pot", "jarre_3", cell=(64 + 44, 56), drop="rupee")
m.entity("pot", "jarre_4", cell=(8, 56))
