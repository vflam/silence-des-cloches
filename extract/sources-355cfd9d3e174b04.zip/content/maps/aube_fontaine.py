"""Fontaine des fées du Bois de l'Aube : grotte neuve en L (roomgen) — un massif rocheux
occupe le nord-ouest ; on entre au sud, on longe le massif et le bassin lumineux dort dans le
recoin nord-est, où la grande fée apparaît."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("aube_fontaine", "Fontaine des fées", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch1_aube_fontaine", "blockset": 0x06, "palette": 39,
    "floor1": 1, "floor2": 5, "layout": 0, "start_quadrant": 3,
    "objects": [
        *G.pillar(40, 42, 8, 8),
        {"o": "water_area", "x": 51, "y": 39, "w": 1, "h": 1},
        ["water_edge_v", 50, 39, 8], ["water_edge_h_2", 50, 47, 7],
        ["torch_lit", 38, 54], ["torch_lit", 50, 51],
    ],
    "doors": [["down", 8, "exit_cave"]],
}, name="Fontaine des fées", music="fairy_fountain")

door = room["doors"][0]
m.warp_room_door(door, to="aube_bois", spawn="fontaine")
m.spawn_room_door("entree", door)

m.npc("bassin", 424, 352, sprite="fairy", facing="down", script="ch1_fontaine", name="Grande fée")
m.pickup("fee_1", 456, 424, item="fairy")
m.entity("pot", "jarre_1", 336, 448, drop="heart")
m.entity("pot", "jarre_2", 456, 448, drop="rupee")
