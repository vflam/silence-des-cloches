"""Village de l'Aube (chapitre 1), 2×2 écrans. Disposition inventée (fiche
docs/story/levels/aube_village.md) : une grande place pavée au centre avec le portique de
l'Aubette, la chapelle au nord sur son parvis, la corniche et le puits au nord-ouest, la mairie
et la boutique à l'est de la place, l'étang d'Anatole à l'est, le carrefour de la rencontre au
sud de la place, l'avenue du sud (vers le bois), la rue de l'ouest (maisons, jardin fleuri),
l'auberge du Grelot au sud-est. Sortie nord (route du Nord) gardée jusqu'au Silence."""
from mapdsl import *

m = Map("aube_village", "Village de l'Aube", size=(2, 2))
m.area(0, 0, 2, 2, name="Village de l'Aube", music="village", atlas=LIGHT)
m.on_enter = "aube_village_enter"
m.fill("grass")

PAVE = "paving"


def paved(x, y, w, h):
    """Pavés clairs bordés d'une rangée de dalles."""
    m.rect(x, y, w, h, "stones")
    m.rect(x + 1, y + 1, w - 2, h - 2, PAVE)


# --- 1. terrain (chemins de terre, étang, herbes hautes) --------------------------------------
P = "path"
m.terrain_rect(49, 0, 2, 13, P)          # route du Nord
m.terrain_rect(43, 11, 8, 2, P)         # ... qui rejoint le parvis
m.terrain_rect(21, 33, 24, 4, P)         # carrefour de la rencontre
m.terrain_rect(4, 34, 18, 2, P)          # rue de l'ouest
m.terrain_rect(32, 36, 2, 28, P)         # avenue du sud (vers le bois)
m.terrain_rect(7, 25, 2, 9, P)           # maison Picot -> rue de l'ouest
m.terrain_rect(10, 45, 2, 6, P)          # maison close -> ruelle du sud
m.terrain_rect(18, 50, 2, 1, P)          # maison de Tobie -> ruelle du sud
m.terrain_rect(10, 51, 22, 2, P)         # ruelle du sud -> avenue
m.terrain_rect(34, 51, 14, 1, P)         # auberge -> avenue
m.terrain_rect(43, 23, 6, 2, P)          # mairie -> place
m.terrain_rect(47, 32, 2, 1, P)          # boutique -> carrefour
m.terrain_rect(44, 33, 5, 2, P)
m.terrain_rect(34, 57, 20, 1, P)         # vers la cabane d'Anatole
m.terrain_rect(14, 12, 2, 23, P)         # la butte -> rue de l'ouest
m.terrain_rect(3, 10, 11, 2, P)          # devant la grotte de la butte
m.terrain_rect(9, 17, 6, 1, P)           # puits
m.terrain(54, 18, [                      # l'étang d'Anatole (une bande d'herbe le sépare de la forêt)
    "..~~~",
    ".~~~~",
    "~~~~~",
    "~~~~~",
    "~~~~~",
    "~~~~~",
    ".~~~~",
    ".~~~~",
    "..~~~",
    "..~~~",
    ".~~~~",
    "~~~~~",
    "~~~~~",
    ".~~~~",
    "..~~~",
])
m.terrain(4, 40, ["tttt", "tttt", "ttt."])
m.terrain(52, 38, ["tt", "ttt", "tttt", ".ttt"])
m.terrain(24, 54, ["tttt", "ttttt", ".tttt", "..tt"])

# --- 2. bordures ------------------------------------------------------------------------------
m.forest(0, 0, 48, 3, edges="s")
m.forest(52, 0, 12, 3, edges="sw")
m.forest(0, 11, 3, 49, edges="e")
m.forest(61, 3, 3, 57, edges="w")
m.forest(0, 60, 31, 4, edges="n")
m.forest(35, 60, 29, 4, edges="n")

# --- 3. la butte (nord-ouest) et sa grotte, le puits -------------------------------------------
grotte = m.stamp("cave_cliff", 0, 3)     # bord coupé de la butte contre le bord de la carte
puits = m.stamp("well", 7, 15)
m.stamp("tree_small", 4, 13)

# --- 4. la chapelle et son parvis, la place pavée ------------------------------------------------
paved(24, 9, 17, 6)                     # parvis de la chapelle (x 24-40, y 9-14)
paved(29, 14, 8, 4)                     # allée parvis -> place
paved(22, 17, 21, 15)                   # la place (x 22-42, y 17-31)
m.rect(30, 14, 6, 4, PAVE)
for bx, by in [(23, 18), (37, 18), (23, 27), (37, 27)]:   # parterres aux quatre coins
    m.rect(bx, by, 5, 4, "stones")
    m.rect(bx + 1, by + 1, 3, 2, "grass")
chapelle = m.stamp("sanctuary", 28, 3)
m.stamp("statue_armos", 25, 5)
m.stamp("statue_armos", 37, 5)
m.strip("fence_h", 18, 8, 7)
m.strip("fence_h", 39, 8, 4)
m.rect(26, 22, 10, 5, "stones")          # le portique de l'Aubette dans son parterre
m.rect(27, 23, 8, 3, "grass")
portique = m.stamp("kakariko_gate", 29, 23)
m.stamp("tree_pink", 24, 19)
m.stamp("tree_pink", 39, 19)
m.stamp("tree_pink", 24, 28)
m.stamp("tree_pink", 39, 28)
m.tiles([(26, 19), (38, 20), (26, 28), (38, 28)], "flowers")
m.stamp("bench", 29, 28)
m.stamp("bench", 34, 28)
m.stamp("barrel", 23, 12)
m.stamp("barrel", 41, 12)

# --- 5. est de la place : mairie, boutique ------------------------------------------------------
mairie = m.stamp("house_blue_big", 45, 14)
boutique = m.stamp("shop_green", 45, 27)
m.stamp("mailbox", 52, 21)
m.stamp("trough", 52, 36)
m.strip("fence_v", 44, 14, 8)

# --- 6. l'étang et la cabane d'Anatole ---------------------------------------------------------
cabane = m.stamp("shed_thatch", 52, 52)
m.stamp("tree", 56, 4)
m.stamp("tree_small", 53, 8)
m.stamp("stump", 58, 10)
m.tiles([(55, 13), (56, 14), (57, 36), (53, 46), (55, 48)], "flowers")
m.tiles([(52, 15), (59, 15), (60, 38), (60, 41)], "bush")

# --- 7. l'ouest : maison Picot + enclos, maison close, maison de Tobie, jardin -----------------
picot = m.stamp("house_red_m", 5, 19)
m.strip("fence_h", 3, 26, 3)
m.strip("fence_v", 3, 27, 5)
m.strip("fence_h", 3, 32, 3)
m.stamp("trough", 4, 28)
close = m.stamp("house_blue_skylight", 8, 39)
tobie = m.stamp("house_blue_woodpile", 16, 43)
m.strip("fence_h", 4, 54, 10)          # jardin fleuri
m.strip("fence_v", 4, 55, 5)
m.rect(6, 55, 6, 3, "flowers")
m.tiles([(8, 56), (10, 55)], "flowers2")
m.stamp("bench", 7, 58)
m.stamp("tree_pink_pair", 10, 58)
m.stamp("tree", 22, 38)
m.stamp("tree_small", 26, 41)

# --- 8. le sud-est : l'auberge du Grelot -------------------------------------------------------
auberge = m.stamp("house_red_l", 40, 45)
m.stamp("barrel", 38, 47)
m.stamp("barrel", 51, 47)
m.stamp("trough_pair", 36, 42)
m.stamp("tree", 45, 38)

# --- 9. arbres et détails dispersés ------------------------------------------------------------
m.stamp("tree", 56, 43)
m.stamp("tree_small", 28, 44)
m.stamp("stump", 22, 57)
m.tiles([(27, 38), (29, 40), (38, 39), (17, 30), (19, 22), (12, 21), (21, 27), (48, 36),
         (26, 49), (14, 47), (6, 37), (40, 55), (44, 59)], "flowers")
m.tiles([(17, 5), (18, 6), (17, 25), (18, 26), (20, 20), (49, 41), (49, 42), (29, 48), (21, 53), (15, 55)], "bush")

# --- 10. panneaux ------------------------------------------------------------------------------
m.sign("panneau_place", 27, 24, "ch1_panneau_place", cond="!ch1_silence")
m.entity("sign", "panneau_place_post", cell=(27, 24), dialogue="ch1_panneau_place_post", cond="ch1_silence")
m.sign("panneau_chapelle", 22, 11, "ch1_panneau_chapelle")
m.sign("panneau_mairie", 49, 24, "ch1_panneau_mairie")
m.sign("panneau_boutique", 44, 30, "ch1_panneau_boutique")
m.sign("panneau_picot", 11, 26, "ch1_panneau_picot")
m.sign("panneau_auberge", 38, 53, "ch1_panneau_auberge")
m.sign("panneau_puits", 10, 15, "ch1_panneau_puits")
m.sign("panneau_nord", 47, 5, "ch1_panneau_nord")
m.entity("sign", "porte_close", *[c * 16 for c in close.door], dialogue="common_maison_fermee",
         cond="!ch1_silence")
m.entity("sign", "porte_close_post", *[c * 16 for c in close.door], dialogue="common_maison_fermee_post",
         cond="ch1_silence")
m.entity("sign", "cabane_anatole", *[c * 16 for c in cabane.door], dialogue="common_maison_fermee")

# --- 11. l'Aubette, les habitants ----------------------------------------------------------------
m.entity("sign", "aubette", 504, 384, dialogue="ch1_panneau_place", sprite="bell", solid=True,
         any_side=True)
m.npc("barnabe", 480, 416, sprite="npc_locksmith", script="ch1_barnabe", name="Barnabé")
m.npc("brunehaut_place", 560, 416, sprite="npc_mrs_sahasrahla", facing="left", script="ch1_brunehaut",
      name="Brunehaut", cond="ch1_battant & !ch1_silence")
m.trigger("rencontre_ori", 496, 544, 64, 32, "ch1_rencontre_ori", once=True, cond="!ch1_ori_rencontree")
m.npc("poule_1", cell=(26, 21), sprite="npc_cucco", script="ch1_poule_1", wander=24, name="Marguerite",
      cond="!poule_1")
m.npc("poule_2", cell=(12, 6), sprite="npc_cucco", script="ch1_poule_2", wander=16, name="Colette",
      cond="!poule_2")
m.npc("garde_nord", cell=(49, 2), sprite="soldier_green", dialogue="ch1_garde_nord_1", name="Garde",
      cond="!ch1_silence")
m.npc("oriane_nord", cell=(50, 5), sprite="npc_zelda", script="ch1_oriane_nord", name="Oriane",
      cond="ch1_silence & !ch2_debut")
m.trigger("depart_ch2", 768, 48, 80, 16, "ch2_debut", once=True, cond="ch1_silence & !ch2_debut")
m.npc("rose", cell=(38, 16), sprite="npc_old_snitch_lady", dialogue="ch1_rose_1", wander=16, name="Rose",
      cond="!ch1_silence")
m.npc("rose_post", cell=(38, 16), sprite="npc_old_snitch_lady", dialogue="ch1_rose_post", name="Rose",
      cond="ch1_silence")
m.npc("anatole", cell=(53, 22), sprite="npc_hobo", facing="right", dialogue="ch1_anatole_1", name="Anatole",
      cond="!ch1_silence")
m.npc("anatole_post", cell=(53, 22), sprite="npc_hobo", facing="right", dialogue="ch1_anatole_post",
      name="Anatole", cond="ch1_silence")
m.npc("villageoise_1", cell=(25, 25), sprite="npc_young_snitch_lady", dialogue="common_villageois_1",
      wander=32, cond="!ch1_silence")
m.npc("villageoise_1_post", cell=(25, 25), sprite="npc_young_snitch_lady",
      dialogue="common_villageois_1_post", cond="ch1_silence")
m.npc("vieil_homme_1", cell=(17, 36), sprite="npc_locksmith", dialogue="common_villageois_2",
      cond="!ch1_silence")
m.npc("vieil_homme_1_post", cell=(17, 36), sprite="npc_locksmith", dialogue="common_villageois_2_post",
      cond="ch1_silence")
m.npc("villageois_post_1", cell=(46, 24), sprite="npc_young_snitch_lady",
      dialogue="ch1_village_post_generique", cond="ch1_silence")
m.npc("poule_deco_1", cell=(5, 30), sprite="npc_cucco", dialogue="ch1_poule_sans_quete", wander=16,
      name="Poule")
m.enemy("errant_1", cell=(16, 35), kind="poe", cond="ch1_silence")
m.enemy("errant_2", cell=(44, 40), kind="poe", cond="ch1_silence")
m.enemy("errant_3", cell=(50, 10), kind="poe", cond="ch1_silence")
m.enemy("rat_village", cell=(13, 53), kind="rat", cond="ch1_silence")

# buissons et jarres qui donnent quelque chose
for i, (cx, cy, drop) in enumerate([(18, 26, "rupee"), (49, 41, "heart"), (21, 53, "rupee5"),
                                     (59, 15, "rupee"), (17, 5, "heart")]):
    m.entity("bush", f"buisson_{i + 1}", cell=(cx, cy), drop=drop)
for i, (cx, cy, drop) in enumerate([(13, 23, "rupee"), (38, 50, "heart"), (52, 24, "rupee"),
                                     (24, 10, "rupee5"), (41, 10, "heart"), (15, 45, "rupee")]):
    m.entity("pot", f"jarre_{i + 1}", cell=(cx, cy), drop=drop)

# --- 12. liaisons et arrivées ------------------------------------------------------------------
def door_link(placed, to, spawn_back, spawn_here):
    wd = m.warp_door(placed, to=to, spawn=spawn_back)
    if wd["rect"][1] % 16 == 0:     # porte non praticable : bande étendue (le centre des pieds s'arrête à +8)
        wd["rect"][3] = 12
    m.spawn(spawn_here, *placed.outside, "down")


door_link(chapelle, "aube_chapelle", "porte", "chapelle")
door_link(mairie, "aube_mairie", "porte", "mairie")
door_link(boutique, "aube_boutique", "porte", "boutique")
door_link(picot, "aube_maison_picot", "porte", "picot")
door_link(tobie, "aube_maison_tobie", "porte", "tobie")
door_link(auberge, "aube_auberge", "porte", "auberge")
m.warp(auberge.door[0] * 16 + 64, auberge.door[1] * 16 + 16, 32, 12, "aube_auberge", "porte")
m.warp_door(grotte, to="aube_puits", spawn="sortie")["rect"][3] = 12
m.spawn("falaise", grotte.outside[0], grotte.outside[1], "down")
# le puits : on y saute en s'approchant par le sud
m.warp(puits.x * 16 + 8, puits.y * 16 + 32, 16, 12, "aube_puits", "chute", style="hole")
m.warp(31 * 16, 64 * 16 - 12, 4 * 16, 12, "aube_bois", "nord", style="edge")
wd = m.warp(48 * 16, 0, 4 * 16, 12, "route_nord", "sud", style="edge")   # 12 px (bord haut)
wd["if"] = "ch1_silence"
m.spawn_cell("sud", 32, 62, "up")
m.spawn_cell("nord", 49, 1, "down")
m.spawn("ceremonie", 504, 416, "up")
m.spawn_cell("start", 32, 40, "up")
