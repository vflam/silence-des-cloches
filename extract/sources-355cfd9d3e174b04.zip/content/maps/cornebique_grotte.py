"""Grotte de Cornebique (salles neuves, plan inventé). Ouest : l'ermitage, une longue salle
basse où le vieux compte ses tas de cailloux ; une porte de bois (fermée tant qu'on n'a pas
donné le mot de passe) mène à l'est. Est : un boyau en lacets sur trois étages qui monte
jusqu'à l'escalier du plateau."""
from mapdsl import *
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("cornebique_grotte", "Grotte de Cornebique", kind="interior", size=(2, 1))
ermitage = m.room_custom(0, 0, {
    "name": "ch2_cornebique_ermitage", "blockset": 0x14, "palette": 7, "floor1": 1, "layout": 5,
    "objects": [
        *G.fill("ceiling_block", 0, 0, 64, 32),
        *G.pillar(20, 48, 16, 16),                   # éboulis au sud (la salle fait un U renversé)
        ["bed", 8, 38],
        ["block", 40, 40], ["block", 44, 40], ["block", 40, 44],   # les tas de cailloux
        ["block", 26, 38], ["block", 30, 38],
        ["pot", 8, 54], ["pot", 10, 54], ["pot", 12, 54],
        ["torch_lit", 16, 38], ["torch_lit", 52, 38],
    ],
    "doors": [["down", 6, "exit_cave"], ["right", 8, "normal"]],
}, name="Ermitage de Cornebique", music="cave")
boyau = m.room_custom(1, 0, {
    "name": "ch2_cornebique_boyau", "blockset": 0x14, "palette": 7, "floor1": 1, "layout": 7,
    "objects": [
        *G.pillar(0, 34, 48, 12),                    # sépare le bas du milieu (ouvert à l'est)
        *G.pillar(16, 16, 48, 12),                   # sépare le milieu du haut (ouvert à l'ouest)
        ["water_area", 26, 50, 0],
        ["floor_stairs_up", 52, 8],
        ["torch_lit", 50, 8], ["torch_lit", 58, 8],
    ],
    "doors": [["left", 2, "normal"]],
}, name="Boyau de Cornebique", music="cave")

entree = ermitage["doors"][0]
vers_est = ermitage["doors"][1]
m.warp_room_door(entree, to="sylve_bucherons", spawn="grotte")
m.spawn_room_door("ouest", entree)
m.warp_room_door(vers_est, to="cornebique_grotte", spawn="boyau")
m.spawn_room_door("ermitage", vers_est)
m.warp_room_door(boyau["doors"][0], to="cornebique_grotte", spawn="ermitage", screen=(1, 0))
m.spawn_room_door("boyau", boyau["doors"][0], screen=(1, 0))

# escalier de sortie vers le plateau
m.warp(512 + 52 * 8, 8 * 8, 32, 24, to="sylve_plateau", spawn="grotte", style="stairs")
m.spawn("est", 512 + 52 * 8 + 8, 15 * 8, "down")

# la porte de bois : fermée tant que Cornebique n'a pas entendu le mot de passe
m.entity("door", "porte_plateau", 55 * 8, 46 * 8, w=24, h=40, lock="flag:ch2_cornebique", dir="right")
m.npc("cornebique", cell=(50, 50), sprite="npc_old_man", facing="right", script="ch2_cornebique",
      name="Cornebique")
m.entity("sign", "cailloux", cell=(41, 45), dialogue="ch2_cornebique_cailloux", any_side=True)
m.enemy("keese_1", cell=(64 + 20, 10), kind="keese")
m.enemy("keese_2", cell=(64 + 40, 52), kind="keese")
m.entity("pot", "jarre_1", cell=(64 + 8, 30), drop="heart")
