"""Maison-forge de Brunehaut (chapitre 1) : intérieur neuf construit avec roomgen.
Une grande pièce 512×256 (layout 5, haut caché) : coin d'Aël à l'ouest (lit, étagère, coffre
de l'épée), table au centre, forge et lit de Brunehaut à l'est, jarres, tonneaux."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("forge_maison", "Maison-forge", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch1_forge_maison", "blockset": 0x03, "palette": 2,
    "floor1": 3, "floor2": 14, "layout": 5, "bg_mode": "off",
    "objects": [
        *G.fill("ceiling_block", 0, 0, 64, 32),
        # coin d'Aël (ouest) : étagère, lit, tableau
        ["bookshelf", 7, 36], ["wall_painting", 15, 36], ["bed", 7, 42],
        # centre : grande table et tabourets, tapis devant la porte
        ["table", 26, 44], ["plate_on_table", 26, 44], ["chair", 23, 45], ["chair", 31, 45],
        # forge (est, contre le mur nord) et moules
        ["forge", 36, 36], ["bookshelf", 44, 36],
        ["bed", 53, 42],
        # tonneaux et bric-à-brac
        ["barrel", 6, 53], ["barrel", 9, 54], ["barrel", 55, 52],
    ],
    "doors": [["down", 7, "normal"]],
}, name="Maison-forge", music="village")

m.on_enter = "forge_maison_enter"

door = room["doors"][0]
m.warp_room_door(door, to="aube_hameau", spawn="porte")
m.spawn_room_door("porte", door)
m.spawn("start", 8 * 8, 47 * 8, "down")          # à côté du lit d'Aël

# entités (pixels) --------------------------------------------------------------------------
m.npc("brunehaut", 176, 392, sprite="npc_mrs_sahasrahla", facing="left", script="ch1_brunehaut",
      name="Brunehaut", cond="!ch1_battant | ch1_silence")
m.chest("coffre_epee", 128, 344, item="sword", amount=1)
m.trigger("porte_sans_epee", 232, 432, 48, 16, "ch1_porte_sans_epee", once=False, cond="!item:sword")
m.entity("sign", "etagere", 80, 304, dialogue="ch1_etagere")
m.entity("sign", "lit_ael", 64, 344, dialogue="ch1_lit_ael", any_side=True)
m.entity("sign", "four", 304, 312, dialogue="ch1_forge_four")
m.entity("sign", "lit_brunehaut", 432, 344, dialogue="common_lit", any_side=True)
m.entity("pot", "jarre_1", 400, 448, drop="rupee5")
m.entity("pot", "jarre_2", 424, 448)
m.entity("pot", "jarre_3", 448, 448, drop="heart")
