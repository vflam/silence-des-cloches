"""Relais de Sibylle (salle neuve, plan inventé) : pièce en L — le coin nord-est est muré (le
cellier) ; Sibylle trône dans l'angle nord-ouest derrière sa table ronde, on lui parle
par-dessus la table. Tonneaux et jarres dans l'aile sud."""
from mapdsl import *
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("relais_sibylle", "Relais de Sibylle", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch2_relais_sibylle", "blockset": 0x03, "palette": 31, "floor1": 3, "layout": 0,
    "objects": [
        *G.pillar(18, 36, 12, 12),                  # le cellier muré (coin nord-est)
        ["red_carpet_floor_h", 5, 40, 1],
        ["red_carpet_floor_h", 5, 44, 1],
        ["table", 8, 44],
        ["bookshelf", 12, 38],
        ["chair", 6, 49],
        ["barrel", 24, 50], ["barrel", 22, 54], ["barrel", 24, 54],
        ["wall_painting", 5, 52],
    ],
    "doors": [["down", 6]],
}, name="Relais de Sibylle", music="fortune")

door = room["doors"][0]
m.warp_room_door(door, to="route_nord", spawn="porte")
m.spawn_room_door("porte", door)
m.npc("sibylle", cell=(9, 41), sprite="npc_fortune_teller", facing="down", script="ch2_sibylle", name="Sibylle")
# on parle à Sibylle par-dessus la table (lecture depuis le bas)
m.entity("sign", "table_sibylle", cell=(9, 46), script="ch2_sibylle")
m.entity("sign", "etagere", cell=(13, 39), dialogue="common_etagere")
m.entity("pot", "jarre_1", cell=(20, 50), drop="heart")
m.entity("pot", "jarre_2", cell=(18, 56))
