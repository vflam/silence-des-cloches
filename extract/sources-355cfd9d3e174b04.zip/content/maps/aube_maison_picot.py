"""Maison de Mme Picot (et de ses poules) : pièce neuve plus haute que large (roomgen, murs
posés à la main dans une salle vide). Perchoirs / caisses-nids (tonneaux) contre le mur nord,
table rustique, lit ; les poules rapportées y apparaissent."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

BX, BY, BW, BH = 16, 28, 32, 34          # murs de la pièce (tile8), porte sud au milieu (x 30)
m = Map("aube_maison_picot", "Maison de Mme Picot", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch1_aube_maison_picot", "blockset": 0x03, "palette": 31,
    "floor1": 3, "floor2": 14, "layout": 7, "bg_mode": "off",
    "objects": [
        *G.fill("ceiling_block", 0, 0, 64, BY), *G.fill("ceiling_block", 0, BY, BX, 64 - BY),
        *G.fill("ceiling_block", BX + BW, BY, 64 - BX - BW, 64 - BY),
        *G.room_box(BX, BY, BW, BH),
        # nids (tonneaux) et paille le long du mur nord
        ["barrel", 20, 32], ["barrel", 23, 32], ["barrel", 42, 32], ["barrel", 39, 32],
        ["wall_painting", 30, 30],
        # table rustique au centre, lit au sud-est
        ["table", 26, 40], ["chair", 23, 41], ["chair", 31, 41],
        ["bed", 40, 50],
        ["chair", 25, 54],
    ],
    "doors": [["down", 7, "normal"]],
})
m.area(px=(BX * 8, BY * 8, 256, 512 - BY * 8), name="Maison de Mme Picot", music="village")

door = room["doors"][0]
m.warp_room_door(door, to="aube_village", spawn="picot")
m.spawn_room_door("porte", door)

m.npc("picot", 312, 376, sprite="npc_old_snitch_lady", facing="left", script="ch1_picot", wander=16,
      name="Mme Picot")
m.npc("poule_maison_1", 176, 296, sprite="npc_cucco", script="ch1_poule_maison", wander=16,
      name="Marguerite", cond="poule_1")
m.npc("poule_maison_2", 296, 296, sprite="npc_cucco", script="ch1_poule_maison", wander=16,
      name="Colette", cond="poule_2")
m.npc("poule_maison_3", 200, 400, sprite="npc_cucco", script="ch1_poule_maison", wander=16,
      name="Brigitte", cond="poule_3")
m.entity("sign", "nids", 168, 272, dialogue="common_etagere", any_side=True)
m.entity("pot", "jarre_1", 168, 440, drop="rupee")
m.entity("pot", "jarre_2", 336, 440, drop="heart")
