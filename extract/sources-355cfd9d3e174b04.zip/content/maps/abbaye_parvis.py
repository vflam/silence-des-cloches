"""Parvis de l'abbaye de la Sainte-Cloche (ch2) : façade au nord, parvis dallé, jardin des
simples à l'ouest, petit cimetière emmuré à l'est (Effacés, tombe qui bouge). Disposition nouvelle."""
from mapdsl import *

m = Map("abbaye_parvis", "Abbaye de la Sainte-Cloche", size=(1, 1))
m.area(0, 0, 1, 1, name="Abbaye de la Sainte-Cloche", music="sanctuary", atlas=LIGHT)
m.fill("grass")
m.on_enter = "ch2_nuit"

# --- terrain ---------------------------------------------------------------------------------
m.terrain_rect(0, 18, 13, 2, "path")          # chemin de la route du Nord
m.terrain(3, 9, ["ttttt", "ttttt", "tttt", ".ttt"])   # jardin des simples

# --- bordures ----------------------------------------------------------------------------------
m.forest(0, 0, 10, 6, edges="se")
m.forest(18, 0, 14, 6, edges="sw")
m.forest(29, 6, 3, 26, edges="w")
m.forest(0, 6, 3, 11, edges="e")
m.forest(0, 21, 3, 11, edges="e")
m.forest(3, 26, 26, 6, edges="n")

# --- l'abbaye ----------------------------------------------------------------------------------
abbaye = m.stamp("sanctuary", 10, 0)


def paved(x, y, w, h):
    """Pavés clairs bordés d'une rangée de dalles (raccord avec l'herbe)."""
    m.rect(x, y, w, h, "stones")
    m.rect(x + 1, y + 1, w - 2, h - 2, "paving")


paved(9, 6, 10, 5)                             # parvis (x 9-18, y 6-10)
paved(12, 10, 4, 12)                           # allée vers le sud (x 12-15, y 10-21)
m.rect(13, 10, 2, 1, "paving")                 # parvis et allée d'un seul tenant
m.stamp("statue_armos", 9, 11)                 # deux statues gardent l'allée
m.stamp("statue_armos", 17, 11)
m.tiles([(10, 14), (17, 15), (17, 18)], "flowers2")

# --- jardin des simples : haie de buissons, ouverture au sud ------------------------------------
for x in range(2, 9):
    m.tile(x, 7, "bush")
for y in range(8, 15):
    m.tile(2, y, "bush")
    m.tile(8, y, "bush")
for x in (2, 3, 7, 8):
    m.tile(x, 15, "bush")
m.stamp("well", 4, 13)

# --- cimetière emmuré ----------------------------------------------------------------------------
for x in range(20, 29):
    m.tile(x, 9, "grave_wall")
    m.tile(x, 24, "grave_wall")
for y in range(10, 24):
    m.tile(28, y, "grave_wall")
    if y not in (16, 17):
        m.tile(20, y, "grave_wall")
m.rect(21, 10, 7, 14, "cobble")
# niche contre le mur nord : le coffre derrière la tombe mobile
m.tiles([(23, 10), (25, 10)], "grave_wall")
m.stamp("tombstone", 21, 12)
m.stamp("tombstone", 26, 12)
m.stamp("tombstone", 21, 19)
m.stamp("tombstone", 26, 19)
m.stamp("grave_pillar", 23, 21)
m.stamp("grave_pillar", 25, 21)

# --- décor ---------------------------------------------------------------------------------------
m.stamp("tree", 4, 21)
m.stamp("tree_small", 18, 21)
m.tiles([(8, 22), (9, 23), (17, 24), (20, 25), (9, 25)], "bush")
m.tiles([(10, 24), (11, 23), (17, 20)], "flowers")

# --- panneaux, tombes, coffre --------------------------------------------------------------------
m.sign("panneau_abbaye", 10, 16, "ch2_panneau_abbaye")
m.entity("sign", "tombe_1", cell=(21, 13), dialogue="ch2_tombe_1")
m.entity("sign", "tombe_2", cell=(26, 13), dialogue="ch2_tombe_2")
m.entity("sign", "stele_tombe", cell=(21, 20), dialogue="ch2_tombe_bouge")
m.chest("coffre_tombe", cell=(24, 10), item="rupee", amount=20)
m.entity("block", "tombe_bouge", cell=(24, 11), sprite="rock_heavy", pushable=True, dir="left right",
         moved_to=[400, 176])
m.enemy("efface_1", cell=(22, 16), kind="poe")
m.enemy("efface_2", cell=(26, 17), kind="poe")

# --- liaisons ------------------------------------------------------------------------------------
m.warp_door(abbaye, to="abbaye_nef", spawn="porte")
m.spawn("porte", *abbaye.outside, "down")
m.warp_edge("left", to="route_nord", spawn="est", start=18 * 16, length=2 * 16)["rect"][2] = 16   # 8 px : le centre des pieds ne l'atteint pas
m.spawn_cell("ouest", 1, 18, "right")
m.spawn_cell("start", 13, 14, "up")
