"""Fontaine de la lisière (salle neuve, plan inventé) : grotte en biais, masse rocheuse au
nord-ouest, source allongée contre la paroi est, la fée sur la rive ouest. On entre par le
sud-ouest et on longe la roche jusqu'à la source."""
from mapdsl import *
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("sylve_fontaine", "Fontaine de la lisière", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch2_sylve_fontaine", "blockset": 0x06, "palette": 39, "floor1": 1, "layout": 0,
    "objects": [
        *G.pillar(0, 32, 16, 16),                  # roche au nord-ouest
        *G.pillar(20, 48, 16, 16),                   # éboulis au sud-est
        ["water_area", 18, 38, 6],                 # source allongée (8×12) contre la paroi est
        ["water_edge_h", 17, 37, 7], ["water_edge_v", 17, 38, 11],
        ["water_edge_h_2", 17, 50, 7], ["water_edge_v_2", 26, 38, 11],
        ["floor_torch", 14, 48], ["floor_torch", 8, 54],
        ["pot", 6, 48], ["pot", 12, 56],
    ],
    "doors": [["down", 6, "exit_cave"]],
}, name="Fontaine de la lisière", music="fairy_fountain")

door = room["doors"][0]
m.warp_room_door(door, to="sylve_lisiere", spawn="fontaine")
m.spawn_room_door("porte", door)
m.npc("fontaine", 136, 344, sprite="fairy", facing="left", script="ch2_fontaine", name="Fée")
