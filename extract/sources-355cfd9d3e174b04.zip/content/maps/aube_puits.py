"""Grotte sous le puits du village : caverne humide 512×256 neuve (roomgen, layout 5, haut
caché). On tombe dans la flaque à l'ouest ; massifs rocheux, graffitis de Tobie, coffre du
quart de cœur au nord-est ; la sortie (est) débouche sur la grotte de la falaise."""
import sys
from pathlib import Path
from mapdsl import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools" / "roomgen"))
import roomgen as G  # noqa: E402

m = Map("aube_puits", "Grotte du puits", kind="interior", size=(1, 1))
room = m.room_custom(0, 0, {
    "name": "ch1_aube_puits", "blockset": 0x14, "palette": 7,
    "floor1": 1, "floor2": 5, "layout": 5, "bg_mode": "off",
    "objects": [
        *G.fill("ceiling_block", 0, 0, 64, 32),
        # flaque sous le puits
        {"o": "water_area", "x": 8, "y": 40, "w": 1, "h": 1},
        ["water_edge_h", 7, 39, 7], ["water_edge_v", 7, 40, 7],
        ["water_edge_h_2", 7, 48, 7], ["water_edge_v_2", 16, 40, 7],
        # massifs rocheux qui dessinent un boyau
        *G.pillar(24, 36, 8, 12),
        *G.pillar(36, 48, 12, 8),
        # décor
        ["torch_lit", 20, 54], ["torch_lit", 56, 54],
    ],
    "doors": [["down", 8, "exit_cave"]],
}, name="Grotte du puits", music="cave_secret")

door = room["doors"][0]
m.warp_room_door(door, to="aube_village", spawn="falaise")
m.spawn_room_door("sortie", door)
m.spawn("chute", 88, 344, "down")

m.chest("puits_coeur", 440, 320, item="heart_piece", amount=1)
m.pickup("puits_rubis_1", 112, 440, item="rupee", amount=5)
m.pickup("puits_rubis_2", 272, 424, item="rupee", amount=5)
m.entity("sign", "graffiti", 64, 408, dialogue="ch1_puits_panneau", any_side=True)
m.entity("pot", "puits_jarre", 448, 400, drop="heart")
m.enemy("keese_puits", 320, 344, kind="keese", respawn=False, cond="ch1_silence")
